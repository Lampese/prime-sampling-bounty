"""Two-sided physical character moments and a squared Laguerre test on the sampled modulus."""
from fractions import Fraction as F
from functools import cache
from math import comb,factorial,isqrt,prod


@cache
def powers(shifts,phi,triangle,n):
    if not triangle:return tuple([F(0)]+[F(1,(shifts*phi)**(j-1)) for j in range(1,n+1)])
    # sums[k] = sum_{i=1}^{shifts-1} i^k.
    sums=[shifts-1]
    for k in range(1,n+1):
        sums.append((shifts**(k+1)-1-sum(comb(k+1,j)*sums[j] for j in range(k)))//(k+1))
    return tuple([F(0)]+[F(shifts**k+2*sums[k],shifts**(2*k)*phi**(k-1)) for k in range(1,n+1)])


def one(mode,inside,order,a,b):
    j=a+b
    if j==0:return F(1)
    if inside:
        if mode=='pair':return F(j%2==0)
        return F(1,6)+F(1,2)*F(-1,3)**j
    if (a-b)%order:return F(0)
    return F(1,2) if mode=='pair' else F(1,6)+F(1,3*4**j)


@cache
def slots(a,b):
    if a:
        return [(i,j,comb(a-1,i-1)*comb(b,j)) for i in range(1,a+1) for j in range(b+1)]
    return [(0,j,comb(b-1,j-1)) for j in range(1,b+1)]


@cache
def cumulants(mode,inner,order,r):
    mu={(a,b):one(mode,inner,order,a,b) for a in range(r+1) for b in range(r+1)}
    out={}
    for d in range(1,2*r+1):
        for a in range(max(0,d-r),min(d,r)+1):
            b=d-a
            out[a,b]=mu[a,b]-sum(h*out[i,j]*mu[a-i,b-j] for i,j,h in slots(a,b) if i+j<d)
    return out


@cache
def exact_diagonals(mode,inner,order,S,r):
    z=cumulants(mode,inner,order,r);v={(0,0):F(1)}
    for d in range(1,2*r+1):
        for a in range(max(0,d-r),min(d,r)+1):
            b=d-a
            v[a,b]=sum(h*z[i,j]*S[i+j]*v[a-i,b-j] for i,j,h in slots(a,b) if z[i,j])
    labels=3 if mode=='six' else 1
    return tuple(labels*v[j,j] for j in range(r+1))


@cache
def orthogonal(inner,r):
    # Monic Laguerre polynomials for x^ell times the unit-mean gamma law.
    a=F(1,2) if inner else F(1);ell=r%2;k=r//2
    p=[F(1)];prev=[]
    for j in range(k):
        c=(2*j+a+ell)/a;d=j*(j+a+ell-1)/a**2
        new=[-c*v for v in p]+[F(0)]
        for i,v in enumerate(p):new[i+1]+=v
        for i,v in enumerate(prev):new[i]-=d*v
        prev,p=p,new
    # Root upper bound for the monic polynomial from Gershgorin applied
    # to its symmetric tridiagonal recurrence matrix (offdiag <= (j+2)/a).
    edge=(4*k+a+ell+2)/a
    coeff=[F(0)]*(r+1)
    for i,u in enumerate(p):
        for j,v in enumerate(p):coeff[i+j+ell]+=u*v
    return tuple(p),tuple(coeff),edge


def val(poly,x):
    v=0
    for c in reversed(poly):v=v*x+c
    return v


def inverse(poly,ell,edge,z):
    # z upper-bounds co sum Q^2. A feasible rational right endpoint is
    # checked exactly; the proposed point and root solve may use floats.
    def adequate(y):return y**ell*val(poly,y)**2>=z
    if adequate(edge):return edge
    p=[float(c) for c in poly];x=float(edge);lo=x;hi=max(1.,x*2);rhs=float(z)
    while hi**ell*val(p,hi)**2<rhs:hi*=2
    for _ in range(55):
        mid=(lo+hi)/2
        if mid**ell*val(p,mid)**2>=rhs:hi=mid
        else:lo=mid
    eps=F(1,10**15);result=max(edge,F.from_float(hi)*(1+eps)+eps)
    while not adequate(result):result=result*(1+eps)+eps
    return result


def candidates(mode,inner,pmin,p,shifts,phi,triangle,co,root,fourier=None,audit=None):
    rmax=6;S=powers(shifts,phi,triangle,2*rmax);sigma=S[2]
    m=3 if mode=='six' else 1
    D=(F(2,9) if inner else F(3,16)) if mode=='six' else (F(1) if inner else F(1,2))
    tau=D*sigma
    out={};sqrtp=isqrt(p)+1
    orders=(1,) if inner else ((5,7) if mode=='six' else (3,5,7))
    for order in orders:
        exc=exact_diagonals(mode,inner,order,S,rmax)
        assert exc[1]==m*tau
        plus=[F(0)];minus=[F(m*p)]
        for k in range(1,rmax+1):
            C=F(1)+F(2,16**k) if mode=='six' and not inner else F(1)
            if k==1:
                # Exact Jacobi identity subtracting m*tau*p^2.
                c=m*D+(2-sigma)*C;d=m*D*(1+sigma)+C*sigma
                plus.append(c-pmin*d);minus.append(p*d-c)
                continue
            odd=((2*k-1)**2-1)*p+2*k
            even=((2*k-2)**2-1)*p+2*(2*k-2)*sqrtp+1+2*k
            # Net-principal events are even in eta at infinity.
            even_mass=C if mode=='pair' and inner else (C+(F(3,3**(2*k)) if mode=='six' and inner else 0))/2
            ue=(even_mass-exc[k])*even+(C-even_mass)*odd
            if fourier and k in fourier:
                spectral_no_lead=fourier[k]
                lead=m*(prod(range(1,2*k,2)) if inner else factorial(k))*tau**k
                diff=lead-exc[k]
                ue=min(ue,spectral_no_lead+diff*(p*p if diff>=0 else pmin*pmin))
            plus.append(ue)
            el=(C-exc[k])*p+(2*k+1)*p*exc[k]
            # Positive X=|K|^2: from the exact first moment, normalized
            # by m p_actual^2, and the fact that the count is <=m p_actual^2,
            # Jensen also supplies a lower k-th moment in every order.
            C1=F(9,8) if mode=='six' and not inner else F(1)
            mu_min=max(F(0),tau-(m*D*(1+sigma)+C1*sigma)/(m*pmin))
            dgap=exc[k]-m*mu_min**k
            el=min(el,dgap*(p*p if dgap>=0 else pmin*pmin))
            minus.append(el)
        for r in range(2,rmax+1):
            p0,cs0,edge0=orthogonal(inner,r)
            for beta in (F(0),F(1,16),F(1,4),F(1)):
                poly=tuple(c*beta**(len(p0)-1-j) for j,c in enumerate(p0))
                cs=tuple(c*beta**(r-j) for j,c in enumerate(cs0));edge=edge0*beta
                # Every exceptional main term uses the same actual p^2. Its
                # sum is nonnegative by the independent group expectation.
                lead=sum(c*exc[j]/tau**j for j,c in enumerate(cs));assert lead>=0
                raw=p*p*lead+sum((c*plus[j] if c>=0 else -c*minus[j])/tau**j for j,c in enumerate(cs))
                assert raw>=0
                if beta==0:
                    from prime_sampling.spectrum.pair10 import nroot
                    off=nroot(co*raw*tau**r,2*r)
                else:off=root(tau*inverse(poly,r%2,edge,co*raw))
                out[r,beta]=max(off,out.get((r,beta),0))
            # A single free root in Q(s)=s^(r-2)(s^2-c). At a trial
            # location y the sufficient inequality is a quadratic in c,
            # so its maximizer can be proposed directly at any order.
            from prime_sampling.spectrum.pair10 import nroot
            U=(p*p*exc[r]+plus[r])/tau**r
            L=(p*p*exc[r-1]-minus[r-1])/tau**(r-1)
            B=(p*p*exc[r-2]+plus[r-2])/tau**(r-2)
            if audit is not None:
                target=co*U
                none=(L<=0 or (co*L)**r<=target**(r-1)) and (co*B)**r>=target**(r-2)
                audit[r,order]=none
            y=nroot(co*U,r);top=y;alpha=F(0)
            for _ in range(3):
                den=co*B-y**(r-2);num=co*L-y**(r-1)
                if den<=0 or num<=0:break
                trial=min(y,F.from_float(float(num/den)))
                if trial<=0 or trial==alpha:break
                alpha=trial
                rad=co*(U-2*alpha*L+alpha*alpha*B)
                assert rad>=0
                y=inverse((-alpha,F(1)),r-2,alpha,rad)
                top=min(y,top)
            off=root(tau*top)
            out[r,F(-1)]=max(off,out.get((r,F(-1)),0))
    return out
