# Signed higher moments for the labeled displacement kernels

Let `K_v(x,y)` be the weighted kernel from the problem, with `K_v=Σχ wχ ζ^(jχv) Kχ`. Put `M_r=Σ_{v,x≠y}|K_v|^(2r)` and `S_j=Σ_z w(z)^j` for the displacement law. The number of label differences is `m=1` for the pair and `m=3` for the six-character group. The statements below apply for each nonzero displacement parameter and each allowed prime and scale. No average over the modulus, the shift or the rectangular test phases is used. The bounds control the sum over all labels, which is sufficient when the sample is partitioned by its actual label difference.

## Exact principal contribution including all equal shifts

In the complete expansion, sum over `v` first. Only terms with equal three-label totals survive and all remaining coefficients are nonnegative. Their total at order `r` is `C_r=Σ_v|Σχ wχ ζ^(jχv)|^(2r)`, equal to 1 except for the external six group where it is `1+2/16^r`. Give every distinct shift an independent uniform element of the finite cyclic group dual to the character group. Let `Y_z` be the weighted sum of the menu characters at this element. Orthogonality gives exactly the weight of terms net-principal *at each shift* as

```
E_r = m E |Σ_z w(z) Y_z|^(2r).
```

Indeed per-shift balance forces label balance globally and gives the full factor `m`. The four group laws are elementary. The single quadratic `Y` is a uniform sign. For the internal six group it equals 1, 0 or −1/3 with respective probabilities 1/6, 1/3 and 1/2. For an external group `Y=Aξ` with an independent uniform `h`-th root `ξ`, where `h` is the order of the odd base character. For pair, `A=1,0` with equal probabilities. For six, `A=1,1/4,0` with probabilities 1/6, 1/3 and 1/2. Consequently `E(Y^a conjugate(Y)^b)=1[h|(a−b)]E A^(a+b)` for external characters. At orders through `r=6`, all `h≥7` give the same answer. Check `h=3,5,≥7` for pair and `h=5,≥7` for six; take an upper bound across the possible orders. The internal laws are real.

For a one-site mixed cumulant `κ_ab`, independence of shifts shows that the cumulant of the displacement-weighted sum is `κ_ab S_(a+b)`. The program computes cumulants from moments and then recovers the moments of the full sum by the elementary set-partition recurrence. One distinguishes one of the `a` left positions and selects its whole block, choosing `i−1` of the other left positions and `j` right positions. The factor is `binom(a−1,i−1) binom(b,j)`, with a right position distinguished when `a=0`. This uses a finite polynomial identity in the moments. On the three-box law with a triangular difference of two uniform boxes of length `L` and `φ` distinct unit residues, the exact power sum is `[L^j+2Σ_{i=1}^{L−1}i^j]/[L^(2j)φ^(j−1)]`. The flat law gives `(Lφ)^(1−j)`. The original injectivity guard guarantees these are the actual weights. `small.py` checks 343 one-site balances by finite group convolution and 49 full diagonal moments by independently enumerating both multinomial shift multiplicities on three unequal atoms.

## Signed upper and lower remainders

Write `M_r=p² E_r+e_r`. In a surviving expansion term with `d` distinct shifts, the contribution is `|Σ_x F(x)|²−(p−d)`. The nonprincipal terms thus have a uniform lower bound `−p`. A principal term contributes exactly `(p−d)(p−d−1)` and `d≤r`, since no menu contains a principal character. For `r≥2` these facts give

```
−e_r ≤ (C_r−E_r)p + (2r+1)p E_r.
```

For the upper bound take the existing projective-line Weil bound on even net parity at infinity and the affine Weil bound on odd parity, using the original constants. Remove exactly `E_r` from the even coefficient before charging generic terms. The total even weight is 1 for the internal pair; elsewhere it is `(C_r+s_r)/2` with `s_r=3/3^(2r)` for the internal six group and 0 otherwise. The exceptional contributions are already included in `p²E_r`. In the triangular kernel, the published Fourier upper moment may further reduce the price of a positive coefficient: subtract the same exact `p²E_r` from it. In the difference between the old leading coefficient and `E_r`, multiply by `p_max²` if positive and `p_min²` if negative before rounding. For order two the available Fourier bound on `Σ(|K_v|²−D S₂)²` is converted back using the exact order-one identity and `M₀=m p(p−1)`.

With `τ=D S₂` and `D=Σχwχ²`, Jacobi sums give the exact first moment

```
M₁ = mD(p−1)(p S₂−1) + C₁(2−(p+1)S₂).
```

Therefore `e₁=mD+(2−S₂)C₁−p[mD(1+S₂)+C₁S₂]` and its extrema on the window follow from the two prime endpoints; `e₀=−mp` exactly. The bounds on all remainders are kept two-sided. In evaluating any nonnegative polynomial square, the principal contributions are combined *at one common value of p* before multiplication by `p_max²`. The resulting leading sum is nonnegative by its finite-group expectation. This avoids a loss from separately bounding oppositely signed `p²` terms over the window.

## Laguerre price on the true sampling measure

Write `s=|K_v|/sqrt(τ)`. For each `2≤r≤6`, put `ell=r mod 2`, `k=floor(r/2)`, and use `Q_r(s)=s^ell P_k(s²)`, with `P_k` monic and all roots nonnegative. The program uses the monic Laguerre polynomials for the weight `y^ell` times a unit-mean gamma density with shape `a=1` externally and `a=1/2` internally. This chooses coefficients; the proof only needs their nonnegative roots. The recurrence is `P_(j+1)=(y−(2j+a+ell)/a)P_j−j(j+a+ell−1)P_(j−1)/a²`. It is the characteristic-polynomial recurrence of a symmetric tridiagonal matrix with positive principal minors: its zero-point determinants follow from the recurrence as `∏_{i=0}^{j−1}(i+a+ell)/a`. Gershgorin bounds the largest root by `(4k+a+ell+2)/a`, using the adjacent off-diagonal entries `sqrt(j(j+a+ell−1))/a`. The program also scales all roots by the fixed rational `β=0,1/16,1/4,1`. The choice zero gives the exact-exceptional raw moment as a comparator.

If `c_j` are the coefficients of `y^ell P_k(y)^2`, the signed-bound price of the complete square is

```
V = p_max² Σ_j c_j E_j/τ^j + Σ_j [c_j upper(e_j) if c_j≥0, c_j lower(e_j) otherwise]/τ^j.
```

For `s` beyond the largest root of `Q_r`, every factor in `s^ell∏(s−sqrt(a_i))(s+sqrt(a_i))` is nonnegative, increasing and affine, so the product is increasing and convex. Its increasing inverse on that branch is concave. It dominates `s` at `|Q_r(s)|` also for smaller `s`, since then `s` lies below the inverse branch. The nonnegative sampling weights over `(v,x,y)` have total at most one and squared sum at most `co`. Apply Jensen to the inverse, putting any missing mass at argument zero, then Cauchy to the weighted absolute polynomial. It suffices to find a rational `y` above all the roots with `y^ell P_k(y)^2 ≥ co V`. The physical kernel-amplitude upper bound is `sqrt(τ y)`. The proposer uses floating point but checks this inequality in rationals before using the price. The original rate is `sqrt(front(1/s_input + amplitude))`, with its unchanged geometric parameters and outward roots. The sample includes both sides and both label groups without multiplying a single-label bound by an assumed label frequency.

`probe.py` reuses the upstream geometry and candidate wheel parameters of the earlier triangular and flat code. It adds the above independent exact prices for these same parameters and keeps their minimum with the original guarantee. The optional reference-table switch asserts that every rate it replaces agrees with the previous full row before changing the four rate fields. All mass and edge fields are copied from that table. For either mode, given `UP` for the upstream checkout at `63a2d41`, `K` for the earlier `harmonic-research/kernel` directory and `CAP` for `residue-bridge/crt-fast`:

```
python -B small.py
python -B probe.py --repo UP --kernels K --cap CAP --mode six --strips 1200,1216,1248,1280,1440,1568 --reference BASE/six.dat --table six.dat
```

`BASE` denotes `residue-bridge/target-layered` in the earlier calculation. For pair replace both occurrences of `six` by `pair`. Python 3 and a C++17 compiler exposed as `CXX` suffice. Each whole microband has width `1/3200` and left endpoint `strip/3200`. The figures arise from the character model and the unchanged finite prime-rectangle geometry, without constructing a counterexample or treating arbitrary score arrays as characters.
