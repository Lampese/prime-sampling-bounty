from smooth import F,smooth,stock
for a,bit in ((F(26),26),(F('26.125'),26),(F('26.25'),26),(F('26.375'),26),(F('26.5'),26),(F(27),26),(F(28),25),(F(30),24)):
    b=a+F(1,8)
    v=smooth(a,b,F(1,30000),F(15),bit)[0]
    o=stock(a,b)
    print(a,b,bit,'old',float(o),'new',float(v),'save',float(o-v),flush=True)
