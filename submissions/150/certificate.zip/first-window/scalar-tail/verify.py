"""Verify the finite replacement and the exact branch-specific rank-37 line."""
import argparse
from pathlib import Path
import subprocess
import sys
from brun import make


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--repo',type=Path,required=True)
    ap.add_argument('--base-row',type=Path,required=True)
    args=ap.parse_args();here=Path(__file__).resolve().parent
    assert __debug__
    for bits in (6,12,18):
        make((2,5,7,11,13,17,19),bits,with_second=True,check_small=True)
    expected='150 4801/32 37 556950952 586889698 619177852 654422000'.split()
    assert args.base_row.read_text(encoding='utf-8-sig').split()==expected
    got=subprocess.check_output([sys.executable,'-B',str(here/'multilevel.py'),'--repo',str(args.repo.resolve()),'--rank','37','--emit'],text=True)
    assert got.split()==(here/'150-without3.dat').read_text().split()
    print(got,end='')


if __name__=='__main__':
    main()
