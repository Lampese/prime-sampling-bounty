"""Price one complete post-26 transition using supported trapezoids and Type-I projection."""
from compare import F,s,seq,g,lo,hi,zh,zl,px,stock,r,args
from rough import rough
from brun import make
import sys
from functools import cache


@cache
def polynomial(bit):
    return make(seq,bit,with_second=True)


def smooth(a,b,rho,k,bit,poly_data=None):
    delta=b-a; x=s.eu(delta); lam=s.LAM; eps=s.eta_for(a,s.eta)
    q=(x-1+(1+x)*eps)/a
    Ylo=zl-a;Yhi=zh-a;invY=s.eu(-Ylo)
    B=rough(a,Ylo,Yhi,lam*s.trans(-delta,'exp',False),F(1))
    # Each collar is measured relative to X/q, then enlarged by X/e^a.
    E=rough(a,zl-b,zh-a,lam,lam+rho+invY*x)+rough(a,zl-b,zh-a,1-rho-2*invY*x,F(1))
    W=q*rough(a,zl-b,zh-a,lam,F(1))
    t=rho/x-2*invY; assert t>0 and t/invY>10**12
    short=s.trans(-delta,'exp',False)-lam-4*rho-4*invY
    assert short>F('0.75') and s.eu(zh-a-lo)<F(1,10**6)
    pi=F('3.14');h=sum(F(1,j*(4*j*j-1)) for j in range(1,33))
    L=s.lu(F('3.01')/t)+F('0.001')
    A=F('1.419')+2/pi*((2/pi+2/(65*pi))*L+4/pi*h/short)
    D=s.eu(k).__ceil__()
    assert zh<6*a and s.trans(a,'exp',False)>5
    assert D<s.trans(a,'exp',False) and D/(t/invY)<F(1,10000)
    A1=F('2.031')+2/pi*((2/pi+2/(65*pi))*(s.lu(F('1.003')/t)+F('.021'))+4/pi*h)
    width=1-lam*s.trans(-delta,'exp',False)+invY
    cap=width/s.ld(D+1)+D*D*invY
    c=min(F(1,2),B/cap)
    b2=(1-2*c)*B+c*c*cap
    if poly_data is None:
        m,co,sec=polynomial(bit);co-=1;c0=F(1)
    else:
        m,co,sec,c0=poly_data
    var=sec-m*m
    assert var>=0
    # Quantity divided by Y (X/e^a) after averaging a single q.
    ratio=px*s.eu(a)
    di=var*q*s.eu(-a)*(1+invY)
    diag_coef=co*co+2*co*abs(c0-m)
    off_coef=12*co*co+16*co*abs(c0-m)
    di+=8*diag_coef*A*ratio*q*s.eu(-a)
    of=off_coef*A*ratio*q*q
    # Absolute error for (1a) with k=1, tested against sampled trapezoids.
    first=8*co*A1*D*ratio*q
    square=5*2*zh*(1/g-1)*s.eu(-a)
    main=2*zh*(m/g-1)*W
    fluct=2*zh*(c*first+s.root(b2*(di+of)))/g
    collar=2*zh*(1/g-1)*q*E
    return main+fluct+collar+square,(main,fluct,collar,square,B,W,A,A1,c,first,di,of)


if __name__=='__main__':
    a,b=F(26),F(26)+F(1,8)
    base=stock(a,b)
    if args.emit:
        assert r==37
        val,_=smooth(a,b,F(1,30000),F(15),26)
        saved=(10**9*(base-val)).__floor__()
        prior=(556950952,586889698,619177852,654422000)
        assert saved>0
        print(150,F(4801,32),37,*[c-saved for c in prior]);sys.exit(0)
    print('stock',float(base),flush=True)
    for bit in (25,26,27):
        new,parts=smooth(a,b,F(1,30000),F(15),bit)
        print(bit,'price',float(new),'saving',float(base-new),'pieces',[float(v) for v in parts],flush=True)
