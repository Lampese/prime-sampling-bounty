"""Upper count of sorted rough cofactors in a fractional interval, normalised by its scale."""
from fractions import Fraction as F
from functools import cache
from prime_sampling.budget import widerough as s


@cache
def harmonic(a,b):
    eta=s.eta_for(a,s.eta)
    return s.up((1+eta)*s.lu(b/a)+2*eta/a+s.eu(-a))


@cache
def rough(a,zmin,zmax,left,right):
    assert 0<left<right<=1 and zmin+s.ld(left)>a
    limits=[left,*[x for x in map(F,('1/16','1/8','1/4','1/2','3/4')) if left<x<right],right]
    slices=[(c,d,s.ld(c)) for c,d in zip(limits,limits[1:])]
    def count(start,lower,upper):
        value=len(slices)*s.eu(upper-zmin)
        for c,d,logc in slices:
            y=max(start,zmin+logc-upper)
            eta=s.eta_for(y,s.eta)
            value+=((d-c)+(d+c)*eta)/y
        a0=start
        while 2*a0+lower<zmax:
            b0=min(a0+2,(zmax-lower)/2)
            value+=harmonic(a0,b0)*count(a0,lower+a0,upper+b0)
            a0=b0
        return s.up(value)
    return count(a,F(0),F(0))
