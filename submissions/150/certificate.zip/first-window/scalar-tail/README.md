# A supported Type II estimate for a complete terminal block

For every prime and integer scale allowed by the problem on `150≤log p≤4801/32`, and every admissible array in the branch without 3, three complete adjacently priced transfers from `exp(26)` to `exp(26+3/8)` save at least **0.000079887449801** against stock. The first, single-level construction below explains the supported minor and major weights; the last section proves the two-level improvement. Retain the earlier rank-37 budget from `scalar-global/150-without3.dat`, which uses the `1/80,1/1800` terminal mesh, replacing its first thirty complete terminal groups. Rounding the total saving down to 79,887 nanounits gives

```
150 4801/32 37 556871065 586809811 619097965 654342113
```

The with-3 branch has 38 coordinates on this window. Running the same tree and weights for it prices this block at 0.000779744601087 versus the stock 0.000509632189737. The published rank-38 row is retained. The reduction on the other branch leaves the first bounty open.

## Bilinear factor selection

For `g=∏(1−1/v_i)`, write `h=b/g−1`, and `S(Y)=−Σ_{m∈I,P⁻(m)>Y}h(m)/M`. Let `Ω(n)` count prime factors in `(Q,U]` with multiplicity. For primes `q∈(Q,U]` put `J_q=(λX/q,X/q]` and `B(n)=1[P⁻(n)>Q]/(1+Ω(n))`. The exact difference `M(S(U)−S(Q))` is `Σ_{q,n∈J_q} B(n)(1+ν_q(n))h(qn)`. Indeed each retained integer with factor multiplicities `k_q` gets weights `k_q/Σ k_q` summing to one. The extra terms with `ν_q(n)>0` contribute at most `5(1/g−1)X/Q`, because `ν_q(n)≤4`, and `Σ_{q>Q}q^-2≤1/floor(Q)≤5/(4Q)`. Their normalized cost is included in `square`.

The relevant aspect of Ford and Maynard's polytope is the choice of a proper subset of a product's prime factors whose log-sum falls in an available Type II interval. Here one eligible prime factor is chosen with weights that give an identical cofactor function `B(n)` across the block. Ford and Maynard require a Type II inequality for every pair of divisor-bounded complex coefficient sequences, with arbitrarily large log savings in their asymptotic formulation. This note proves one finite weighted inequality, using (1a) from the problem. The asymptotic constants in their paper do not supply its finite error. [Ford and Maynard, conditions (I), (II) and Definition 4.3](https://arxiv.org/html/2407.14368v1)

## Coordinate polynomial

`brun.py` constructs a multilinear upper polynomial `P` for `b`. Starting from a constant upper 1 and lower 0, one can extend through a new coordinate `x` by `U=U₀−xL₁` and `L=L₀−xU₁`, taking `U₀,L₀,U₁,L₁` to be bounds for the remaining coordinates. At empty depth the exact answer is 1. Each node may choose the appropriate trivial bound instead. These operations sandwich the pass product for every input in `[0,1]^r`. The two terms at a node have disjoint monomial supports, so the raw coefficient count and signs are determined exactly. The constant term at the root is 1. The integer Lagrangian with 16 log₂ cells per unit and cutoff `2^26` selects a tree. Correctness holds for any permitted pruning decisions.

Let `m=E P`, `V=E P²−m²` for the independent reference Bernoulli coordinates, and `C` be the absolute sum of the nonconstant *raw* coefficients. The program obtains `C=71984`, `m=0.164027238471827…`, `E P²=0.165157010218846…`. For two tree nodes `L=L₀−xL₁` and `R=R₀−xR₁`, the product moment is `E L₀R₀−a E(L₁R₀+L₀R₁−L₁R₁)` where `a=1/v`. This computes both moments exactly using integer numerators over the product of the reference primes. For fractional inputs, `(P(x)−m)²` is at most the multilinear extension of the square on Boolean vertices by independent Bernoulli rounding and Jensen.

## Populations and weights

Write `Y=X/Q`, `δ=log(U/Q)`, `N_q=X/q` and `J=(λY exp(−δ),Y]`. With `ρ=1/30000`, take `t_q=floor(ρN_q)`, `T_q={0,…,t_q−1}` and `A_q` the integer interval `J_q` shortened at its upper end by `t_q−1` points. Set `w_q=1_{A_q}*1_{T_q}/t_q`. Then `0≤w_q≤1` and the support is in `J_q`. The missing part lies in the two intervals `(λN_q,(λ+ρ+1/N_q)N_q]` and `((1−ρ−2/N_q)N_q,N_q]`. There `h≤1/g−1`. Write `u` for an upper bound on the number of primes `q` divided by `Q`. With the explicit Chebyshev error `ε` applicable at 26, use `u=[exp(δ)−1+(1+exp(δ))ε]/26` rounded upwards. `rough.py` gives the following normalized upper estimates:

* `Σ_{n∈J}B(n)≤Y B₊`, with `B₊≤0.021991246739`.
* `Σ_q Σ_{n∈J_q} B(n)≤X W` with `W≤0.000112360127`.
* For each `q` the two endpoint densities sum to at most `E`, so the lost mass is at most `X u E` before multiplication by `1/g−1`.

For the counts, any rough cofactor has a sorted prime factorization, including repetitions. Choose all factors except its largest in log cells of width at most 2, extending a cell from log `v` upward only to half the maximum remaining log product. Sortedness permits the next cell to start at `v`. Each chosen cell `(v,w]`, including a possible left endpoint, contributes at most `(1+η)log(w/v)+2η/v+exp(−v)` to its reciprocal-prime sum. If the preceding logs sum to between `l` and `h` and the largest factor fills a fractional interval `(c,d]` of the original scale `Y₀`, then its count divided by `Y₀` is at most the reciprocal of the exact preceding product times `[(d−c)+(d+c)η]/max(v,log Y₀+log c−h)`, and one additional endpoint term divided by `Y₀`. This follows by clipping the lower endpoint to the minimum permitted largest prime and subtracting the two bounds on θ. The algorithm subdivides wide `(c,d]`, sums these quantities over the possible smaller factors, uses outward transcedental bounds and includes one endpoint per terminal interval. At this scale `n>1`. [Broadbent et al., Theorem 1 and Table 14](https://arxiv.org/abs/2002.11068)

## Supported Fourier estimates

Write `||f||_A=p^-1Σ|f̂|`. In every off-diagonal pair, `w_q w_r` is supported where both `qn` and `rn` lie in the actual interval `I`. For `q=r` the same weight supports one dilation. Put `t=ρexp(−δ)−2/Y₋` where `Y₋≤Y`, and `s₀=exp(−δ)−λ−4ρ−4/Y₋`. The individual smoothing lengths are at least `tY`. Intersecting any two translates of `A_q` and `A_r` in their convolution representations gives an interval of length `l` with `s₀Y≤l≤Y+1`. Averaging these interval indicators gives the exact product `w_qw_r`.

Let `h₀=floor(p/(2Y))`, `h₁=floor(1.5p/(tY))`. Below `h₀` the two-sided contribution including the zero frequency is at most `1.001` since `Y/p<10^-6`, `Y>10^12`. In the middle range `sin(πh/p)≥3.14 h/p`. Its harmonic sum is bounded by `L=log(3.01/t)+0.001`. For an interval of length `l`, use the exact numerator `|sin(πlh/p)|` and the absolutely convergent cosine series `|sin x|=2/π−(4/π)Σ cos(2jx)/(4j²−1)`. For `j≤32`, the cosines' partial sums are bounded by `1/|sin(πjl/p)|≤p/(2jl)`. Summation by parts from `h₀+1` bounds the reciprocal-weighted contribution by `1/(j s₀)`. The tail beyond `j=32` has `Σ(4j²−1)^−1=1/130` and is bounded using `L`. Average this estimate over the translated intervals to control the Fourier transform of the product.

For the high frequencies, `||Δw_q||₁≤2`, `||Δw_q||∞≤1/t_q` and `||Δ²w_q||₁≤4/t_q` by the two box convolution. The discrete product rule gives `||Δ²(w_qw_r)||₁≤12/(tY)`. Divide by `4 sin²(πh/p)` and sum. Below `p/100` use `sin(πh/p)≥3.14h/p`, above it use `2h/p`. The two-sided high contribution is at most `6p/(3.14² tY h₁)+160/(tY)<0.418`. Hence a uniform upper bound is

```
A₂ = 1.419 + (2/3.14)[(2/3.14+2/(65·3.14))L + (4/(3.14s₀))Σ_{j≤32}1/(j(4j²−1))]
   ≤ 6.539631277716.
```

For `d≤D=ceil(exp(15))`, the separate weight `w_q(n)1_{d|n}` is supported on its actual permitted domain. Split `A_q` and `T_q` by matching opposite residues modulo `d`, divide their progressions by `d`, then redilate in the field. This writes the restricted weight as a sum of interval convolutions divided by `t_q`, with shorter interval lengths `b` adding to `t_q`. Each pair of lengths `a≥b` has `b≥1000`, `a<p/100` and `a/b≤1.003/t`. Its convolution norm divided by `b` is bounded termwise: low frequencies `h≤floor(p/(2a))` contribute 1 with the zero frequency bounded by .01, the tail `h>floor(p/(2b))` contributes at most `p/(2b floor(p/(2b)))≤1.021`, and in the middle use the previous `|sin|` series for the longer transform while bounding the shorter by `b`. Here `s₀` in the partial-sum bound is replaced by 1 and the harmonic bound by `log(1.003/t)+.021`. This gives `A₁≤6.652360600338` after adding `2.031` to the resulting middle estimate. All numerical guards are checked in `smooth.py`.

## Type I projection and Type II estimate

Define `F(n)=Q^-1Σ_q w_q(n)(P(x(qn))−m)` on `J`, and let `L(n)=Σ_{d|n,d≤D}λ_d` be a Selberg divisor sum with `λ₁=1`. For the usual quadratic minimizer, `|λ_d|≤1` and `Σ_{d,e}λ_dλ_e/[d,e]=1/G` with `G=Σ_{d≤D}μ²(d)/φ(d)≥log(D+1)`. Indeed `λ_d=μ(d)dG_d(D/d)/(φ(d)G)`, with the sum defining `G_d` restricted to integers coprime to `d`; including divisors of `d` in `G` proves `|λ_d|≤1`. The quadratic identity follows by expanding `1/[d,e]=Σ_{f|d,e}φ(f)/(de)` and Möbius inversion. Grouping the harmonic series by squarefree kernel gives the lower bound on `G`. Thus `Σ_J L²/Y≤K=(1−λ exp(−δ)+1/Y₋)/log(D+1)+D²/Y₋`. `L=1` throughout the support of `B`. Set `c=min(1/2,B₊/K)`. Since `0≤B≤1`, `Σ_J(B−cL)²/Y≤(1−2c)B₊+c²K=:H`. [Selberg sieve quadratic form](https://kskedlaya.org/ant/chap-selberg.html)

Put `e≥sqrt(p)/Y`, using the outward bound `e=(lo+1)exp(a−lo/2)` at `a=26`, justified by `X≥p/(log p+1)`. Let `u` be the prime-count cap above. On each `w_q1_{d|n}`, (1a) with one dilation gives `|Σ_J LF|/Y≤8 C A₁ D e u=:E₁`. On `w_q w_r`, expand in the original monomials. At distinct primes the two-sided nonconstant pairs cost at most `12C² sqrt(p) A₂`, and the two one-sided parts at most `16|1−m|C sqrt(p) A₂`; the reference total is zero. On the diagonal the Boolean square dominates pointwise after multilinear extension. Its nonconstant coefficient norm is at most `C²+2|1−m|C`, and its reference mean is `V`. The result is

```
Σ_J F²/Y ≤ (u/Q) [ V(1+1/Y₋) + 8(C²+2|1−m|C) A₂ e ]
          + u² (12C²+16|1−m|C) A₂ e =: E₂ .
```

Use Cauchy on `Σ(B−cL)F` and the bound on `Σ LF`. The complete price is at most `2Z₊ [ (m/g−1)W + (cE₁+√(HE₂))/g + (1/g−1)uE + 5(1/g−1)/Q ]`. In that order the four terms cost at most .000251045903470, .000200890697602, .000011617582960 and .000000038111341. The polynomial coefficients, moments, interval caps, error terms and final comparison use integer or rational arithmetic with upward elementary functions. The decimal amounts in this text are rounded for display. The smaller rank-37 stock transitions in the other groups apply to the actual without-3 array by the affine embedding proved in `scalar-global`.

Run `python verify.py --repo <upstream-checkout> --base-row <scalar-global/150-without3.dat>` from any directory using the verifier's absolute path if needed. `--base-row` uses the preceding independent certificate; run its verifier to reconstruct that input from the upstream checkout. Python's standard library is sufficient for this terminal replacement.

## Simultaneous projections across divisor levels

Use the preceding supported `w_q` on each logarithmic block `(a,b]` of width 1/8. Take the original cut `D₁=ceil(exp(15))` and a larger `D₂=ceil(exp(19))`, both below `exp(a)`. The previous Fourier and sampling guards hold for both, as the verifier checks. On rough `n`, both Selberg divisor sums `L₁,L₂` equal one. Write `G_i` for their exact Selberg denominators and `N_i=Σ_d|λ_d(D_i)|`. Their cross quadratic form has main term **`1/G₂`**. Indeed, extend the weights for `D₁` by zeros to `D₂`. Both vectors have coefficient 1 at `d=1`. The derivative of the level-`D₂` minimizing quadratic form in the direction of their difference vanishes. The cross inner product with the `D₂` vector therefore equals the minimum, `1/G₂`. Applying the integer interval count with error at most one gives upper bounds for each Gram entry `Σ_J L_i L_j/Y` of

```
Kij = width/Gmax(i,j) + Ni Nj/Y₋,
width = 1−λ exp(a−b)+1/Y₋.
```

Bounds in the indicated directions suffice because the two nonnegative projection coefficients `c₁,c₂` sum to at most 1/2. The new squared residual cap is

```
(1−2c₁−2c₂) B₊ + c₁²K11 + 2c₁c₂K12 + c₂²K22.
```

The first-moment penalty `E₁c` becomes `8 C A₁ e u (c₁N₁+c₂N₂)`. The second moment `E₂` retains the complete off-diagonal covariance bound on the actual support. No independent charges for the two projections are added to the result. Finally both the main gap population and the two collars were counted above as a universal density bound times the individual scale `N_q=X/q`. Summing these densities before applying a norm replaces `u` by `min(u,(1+η)log(b/a)+2η/a)` in *only* those three mass terms. This follows from partial summation of the same explicit θ bounds. The Type I and Type II moments still use `u`, which counts the dilations.

For the divisor weights, the exact numerator of `N_i` is `Σ_{n≤D} μ²(n)σ(n)/φ(n)`. Expand the preceding formula for `λ_d` and group `n=dk`; each divisor `d|n` contributes `d/φ(n)` when `n` is squarefree. The following elementary bounds keep both levels explicit.

1. For `P={2,3,5,7}` take `W=∏_{p∈P}p²`. The factor `f(n)` of `μ²(n)σ(n)/φ(n)` from these four primes is periodic modulo `W`, with average `m=∏(1+1/p²)`. Compute its maximal excess over `mk` on partial periods `1≤k≤W` exactly. Call this excess `b`. For `(d,W)=1` one has `f(dn)=f(n)`. Majorize the contribution from primes outside `P` by `Σ_{d|n,(d,W)=1}u(d)` where `u(d)=μ²(d)2^ω(d)/φ(d)`. Hence the numerator is at most `m D E_P + b E_∅(1+log D)²`, where `E_P=∏_{p∉P}(1+2/[p(p−1)])`. All Euler products are taken explicitly up to 250, bounding the remaining product by `exp(2/250)` via the telescoping sum over all integers. To see the quadratic logarithmic bound for `Σu(d)`, expand `2/(p−1)=2/p+2/[p(p−1)]` separately for each prime dividing squarefree `d`. The convolution of `τ(n)/n` with the Euler product for the second factor dominates `u`. The sum of `τ(n)/n` up to `D` is at most `(1+log D)²`.

2. The identity `G(D)=Σ_{rad(n)≤D}1/n` follows by summing the powers of every prime in a squarefree kernel. Its contribution from `n≤D` is at least `log(D+1)+H₁₂₈−log(129)` since `H_n−log(n+1)` increases. For a residue `r mod W` put `a_r=∏_{p∈P,p²|r}p`. All numbers `n≡r mod W` in `(D,a_r D]` have `rad(n)≤D`. If `a_r>1`, their harmonic sum is at least `W^-1 log(a_r D/(D+W))` by integrating between successive points of this progression. Summing gives the additional lower bound `Σ_{p∈P} log(p)/p² − [1−∏_{p∈P}(1−1/p²)] log(1+W/D)`.

The polynomial tree uses the same integer cutoff `2^26` on all three retained blocks. The two weights are fixed rationals with denominator `10^7`. The verifier uses these rationals directly and independently checks the tree moments, raw coefficient norms and pointwise upper bounds in three enumerable Boolean cubes. All columns in the following table are per `M`.

| Logarithmic prime band | Numerators of `(c₁,c₂)` | Stock price | New upper price | Saving at least |
|---|---:|---:|---:|---:|
| 26 to 26.125 | 2159030, 1803531 | .000484564780861157… | .000438794405959 | .000045770374903 |
| 26.125 to 26.25 | 2307545, 1594134 | .000476184290844135… | .000448025774918 | .000028158515926 |
| 26.25 to 26.375 | 2467389, 1370623 | .000463936176541391… | .000457977617570 | .000005958558971 |

The next complete band, `26.375` to `26.5`, costs .000468667544295, versus .000453654620485 for stock. Further full-width checks with left endpoints 26.5, 27, 28 and 30 also retain their existing prices. `multilevel.py --repo <checkout> --rank 37` prints these diagnostic comparisons. `--emit` reconstructs only the three certified replacements and compares rational prices before rounding once for the final budget.
