"""Common first-window setup and published terminal prices for the two branch comparisons."""
from argparse import ArgumentParser
from fractions import Fraction as F
from math import prod
from pathlib import Path
import sys


ap=ArgumentParser(description=__doc__)
ap.add_argument('--repo',type=Path,required=True)
ap.add_argument('--rank',type=int,choices=(37,38),default=38)
ap.add_argument('--emit',action='store_true')
args=ap.parse_args()
sys.path.insert(0,str(args.repo.resolve()))

from prime_sampling.budget import band,menu,tight,widerough as s
from prime_sampling.accounting.ledger import rank

FINE,SIZE=F(1,1800),F(1,80)
lo,hi,r=F(150),F(4801,32),args.rank
seq=rank(hi,'with3' if r==38 else 'without3')
g=prod(1-F(1,p) for p in seq)
if str(r) not in tight.patterns:
    tight.patterns[str(r)]=[(h,n,t) for h in range(min(r,16)+1) for n in range(h,r+1) for t in (0,2,4) if t<=n-h]
raw=[row[:3] for row in menu.group(r)[1]]
choices=raw,[tuple(map(float,row)) for row in raw]
zh=s.up(hi-s.ld(hi-F('1.1')))
zl=s.dn(lo-s.lu(lo+1))
px=(lo+1)*s.eu(-lo/2)


def stock(a,b):
    total=F(0)
    while a<b:
        v=min(a+SIZE,b)
        n=((v-a)/FINE).__ceil__()
        rows=band.params(lo,hi,a,v,n)
        total+=n*band.price(rows,choices)
        a=v
    return total
