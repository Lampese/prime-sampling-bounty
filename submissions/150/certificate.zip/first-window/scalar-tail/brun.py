"""Upper and lower multilinear polynomials for coordinate survival on the Boolean cube."""
from fractions import Fraction as F
from functools import lru_cache
from math import prod


def make(primes, price_bits, mesh=16, with_second=False, check_small=False, raw=False, return_tree=False):
    primes=tuple(primes)
    den=[1]
    for p in primes: den.append(den[-1]*p)
    steps=[(p**mesh-1).bit_length() for p in primes]
    decisions={}
    @lru_cache(None)
    def visit(k,j,up):
        if j>=mesh*price_bits:
            return (den[k],1) if up else (0,0)
        if k==0:
            return 1,1
        q=primes[k-1]
        a,c=visit(k-1,j,up)
        b,d=visit(k-1,j+steps[k-1],not up)
        v=q*a-b; count=c+d
        # Dyadic fixed-point price, rounded down. Either pruning choice
        # preserves the pointwise inequality.
        scaled=den[k]*(1<<(j//mesh))*2**20*root_prices[j%mesh]
        unit=(1<<price_bits)*(1<<40)
        if up and (v-den[k])*unit+(count-1)*scaled>=0:
            return den[k],1
        if not up and v*unit-count*scaled<=0:
            return 0,0
        decisions[(k,j,up)]=True
        return v,count
    def iroot(n,k):
        lo,hi=0,1<<((n.bit_length()+k-1)//k)
        while hi-lo>1:
            mid=(lo+hi)//2
            if mid**k<=n:lo=mid
            else:hi=mid
        return lo
    root_prices=[iroot(1<<(20*mesh+j),mesh) for j in range(mesh)]
    n,c=visit(len(primes),0,True)
    if return_tree:return (den,steps,decisions,visit,n,c)
    if not with_second: return F(n,den[-1]),c
    @lru_cache(None)
    def mixed(k,l,r):
        if l>r:return mixed(k,r,l)
        i,sg=l;j,tg=r
        lv=visit(k,i,sg)[0];rv=visit(k,j,tg)[0]
        if (k,i,sg) not in decisions: return (lv//den[k])*rv
        if (k,j,tg) not in decisions: return (rv//den[k])*lv
        q=primes[k-1];di=steps[k-1]
        la,lb=(i,sg),(i+di,not sg)
        ra,rb=(j,tg),(j+di,not tg)
        return q*mixed(k-1,la,ra)-mixed(k-1,la,rb)-mixed(k-1,lb,ra)+mixed(k-1,lb,rb)
    sec=mixed(len(primes),(0,True),(0,True))
    if raw:
        terms=[]
        def expand(k,j,up,d,sign):
            if (k,j,up) not in decisions:
                if visit(k,j,up)[0]:terms.append((d,sign))
                return
            expand(k-1,j,up,d,sign)
            expand(k-1,j+steps[k-1],not up,d*primes[k-1],-sign)
        expand(len(primes),0,True,1,1)
        assert len(terms)==c and terms[0]==(1,1)
        return F(n,den[-1]),c,F(sec,den[-1]),terms
    if check_small:
        assert len(primes)<=9
        def evaluate(k,j,up,mask):
            if (k,j,up) not in decisions:return visit(k,j,up)[0]//den[k]
            left=evaluate(k-1,j,up,mask)
            return left-((mask>>(k-1))&1)*evaluate(k-1,j+steps[k-1],not up,mask)
        vertices=[];first=second=0
        for mask in range(1<<len(primes)):
            y=evaluate(len(primes),0,True,mask)
            assert y>=int(mask==0);vertices.append(y)
            prob=prod(p-1 for i,p in enumerate(primes) if not(mask>>i&1))
            first+=prob*y;second+=prob*y*y
        assert first==n and second==sec
        for j in range(len(primes)):
            for mask in range(len(vertices)):
                if (mask>>j)&1:vertices[mask]-=vertices[mask^(1<<j)]
        assert sum(map(abs,vertices))==c
    return F(n,den[-1]),c,F(sec,den[-1])


if __name__=='__main__':
    from math import isqrt
    primes=[p for p in range(2,164) if all(p%i for i in range(2,isqrt(p)+1))]
    g=prod(1-F(1,p) for p in primes)
    for sort in (primes,list(reversed(primes))):
        for n in range(10,41,2):
            x,c=make(sort,n)
            print(sort[0],n,'gap',float(x/g-1),'raw',c,flush=True)
