"""Two Selberg levels, exact off-diagonal Gram main terms and explicit divisor coefficient norms."""
from fractions import Fraction as F
from functools import cache
from math import prod,sqrt
from smooth import polynomial,smooth,stock,s,seq,g,lo,hi,zh,zl,px,r,args


@cache
def wheel():
    small=(2,3,5,7);W=prod(p*p for p in small)
    mean=prod(1+F(1,p*p) for p in small)
    scale=prod(p-1 for p in small)
    partial=0; discrepancy=F(0)
    for n in range(1,W+1):
        weight=scale
        for p in small:
            if n%(p*p)==0: weight=0;break
            if n%p==0: weight=weight*(p+1)//(p-1)
        partial+=weight
        discrepancy=max(discrepancy,F(partial,scale)-n*mean)
    assert F(partial,scale)==W*mean
    def euler(pp):
        return s.eu(F(2,250))*prod(1+F(2,p*(p-1)) for p in s.c.ps if p>pp)
    return small,W,mean,discrepancy,euler(7),euler(0)


@cache
def weights(k):
    small,W,mean,disc,tail,allp=wheel();D=s.eu(k).__ceil__()
    H0=sum(F(1,i) for i in range(1,129))-s.lu(129)
    more=sum(s.ld(p)/(p*p) for p in small)-(1-prod(1-F(1,p*p) for p in small))*s.lu(1+F(W,D))
    G=s.ld(D+1)+H0+more
    l1=(mean*D*tail+disc*allp*(1+s.lu(D))**2)/G
    return D,G,l1


def optimize(P,K,B,E):
    # The real minimizer on the triangle is interior, on an edge or at a vertex.
    # Floating point proposes feasible rational weights only.
    A,C,D=map(float,K);p,q=map(float,P);v=float(E);b=float(B)
    def inner(x,y):return A*x*x+2*C*x*y+D*y*y
    points=[(0.,0.),(.5,0.),(0.,.5)]
    det=A*D-C*C
    for x0,y0,dx,dy in ((0.,0.,1.,0.),(0.,0.,0.,1.),(0.,.5,1.,-1.)):
        k=inner(dx,dy);ell=(A*x0+C*y0-b)*dx+(C*x0+D*y0-b)*dy
        c=b-2*b*(x0+y0)+inner(x0,y0);pen=p*dx+q*dy
        z=v-pen*pen/k
        if z>0 and c-ell*ell/k>=0:
            t=max(0.,min(.5,-ell/k-pen/k*sqrt((c-ell*ell/k)/z)))
            points.append((x0+t*dx,y0+t*dy))
    if det>0:
        x0=b*(D-C)/det;y0=b*(A-C)/det
        u=(D*p-C*q)/det;w=(A*q-C*p)/det
        den=v-p*u-q*w;base=b-b*(x0+y0)
        if den>0 and base>=0:
            t=sqrt(base/den);points.append((x0-u*t,y0-w*t))
    ret=[]
    for xx,yy in points:
        x=F(int(xx*10**7),10**7);y=F(int(yy*10**7),10**7)
        if min(x,y)<0 or x+y>F(1,2):continue
        ret.append((price(P,K,B,E,x,y),x,y))
    return min(ret)


def price(P,K,B,E,x,y):
    assert min(x,y)>=0 and x+y<=F(1,2)
    a,c,d=K
    norm=(1-2*(x+y))*B+a*x*x+2*c*x*y+d*y*y
    return P[0]*x+P[1]*y+s.root(E*norm)


def charge(a,b,bit,levels=(F(15),F(19)),fixed=None,poly_data=None,off_saving=F(0)):
    rho=F(1,30000);_,detail=smooth(a,b,rho,F(15),bit,poly_data=poly_data)
    main,_,collar,square,B,W,A2,A1,_,_,di,off=detail
    assert 0<=off_saving<=off
    off-=off_saving
    e0=s.eu(b-a);eta=s.eta_for(a,s.eta);q=(e0-1+(1+e0)*eta)/a
    # The main population and both edge collars are counted on the real
    # scale X/q. Their common density bound therefore multiplies sum 1/q.
    har=min(q,(1+eta)*s.lu(b/a)+2*eta/a)
    main*=har/q;collar*=har/q
    invY=s.eu(a-zl);width=1-s.LAM*s.trans(a-b,'exp',False)+invY
    (d1,g1,l1),(d2,g2,l2)=map(weights,levels)
    assert d1<d2<s.trans(a,'exp',False) and d2/((rho/e0-2*invY)/invY)<F(1,10000)
    K=(width/g1+l1*l1*invY,width/g2+l1*l2*invY,width/g2+l2*l2*invY)
    if poly_data is None:
        _,co,_=polynomial(bit);co-=1
    else:
        _,co,_,_=poly_data
    pen=8*co*A1*px*s.eu(a)*q
    P=(pen*l1,pen*l2)
    if fixed is None:
        error,x,y=optimize(P,K,B,di+off)
    else:
        x,y=fixed;error=price(P,K,B,di+off,x,y)
    return main+collar+square+2*zh*error/g,(x,y,l1,l2)


if __name__=='__main__':
    if args.emit:
        assert r==37
        # Fixed rational coefficients from the two-variable proposal, no
        # floating-point search in the budget reconstruction.
        pairs=((2159030,1803531),(2307545,1594134),(2467389,1370623))
        delta=F(0)
        for i,(m,n) in enumerate(pairs):
            a=26+F(i,8);b=a+F(1,8)
            new,_=charge(a,b,26,fixed=(F(m,10**7),F(n,10**7)))
            saving=stock(a,b)-new
            assert saving>0
            delta+=saving
        prior=(556950952,586889698,619177852,654422000)
        units=(delta*10**9).__floor__()
        assert units==79887
        print(150,F(4801,32),37,*[c-units for c in prior]);raise SystemExit
    for a,bit in ((F(26),26),(F('26.125'),26),(F('26.25'),26),(F('26.375'),26),(F('26.5'),26),(F(27),26),(F(28),25),(F(30),24)):
        b=a+F(1,8);o=stock(a,b);v,cc=charge(a,b,bit)
        print(a,bit,'stock',float(o),'two-level',float(v),'saving',float(o-v),'weights',*cc[:2],flush=True)
