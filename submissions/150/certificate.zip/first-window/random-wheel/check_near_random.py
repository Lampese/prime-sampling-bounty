"""Enumerate CRT partitions, carries, collision counts and an actual character kernel."""
from argparse import ArgumentParser
from collections import Counter
from fractions import Fraction as F
from itertools import combinations,product
from math import gcd,prod
from pathlib import Path
import sys

here=Path(__file__).resolve().parent
ap=ArgumentParser(description=__doc__)
ap.add_argument('--repo',type=Path,default=here.parent/'prime-sampling')
args=ap.parse_args()
sys.path.insert(0,str(args.repo.resolve()))
from near_random import divisor_weights,random_near,random_co


def sets(factors):
    W=prod(ell for ell,_ in factors)
    choices=[list(combinations(range(ell),d)) for ell,d in factors]
    for pick in product(*choices):
        D=[r for r in range(W) if all(r%ell in ds for (ell,_),ds in zip(factors,pick))]
        E=[r for r in range(W) if all((-r)%ell not in ds for (ell,_),ds in zip(factors,pick))]
        yield D,E


def audit(factors,p,H,m,vertices,physical=False):
    W=prod(ell for ell,_ in factors)
    phi=prod(ell-1 for ell,_ in factors)
    d,e=prod(d for _,d in factors),prod(ell-d for ell,d in factors)
    selections=list(sets(factors))
    count=len(selections)
    J=H*d;S=len(vertices)
    weights=divisor_weights(factors)
    assert sum(c for v,c in weights)==1 and 2*W*H<p
    near=random_near(min(vertices),max(vertices),max(vertices)-min(vertices),p,p,factors,H)
    N=H*W
    pairs=list((a,b) for a in vertices for b in vertices if a!=b)
    inverses={a:pow(a,-1,p) for a in vertices}
    diffs=Counter((inverses[a]-inverses[b])%p for a,b in pairs)
    md=max(diffs.values())
    assert md>=2
    bound=random_co(min(vertices),max(vertices),max(vertices)-min(vertices),p,p,factors,H,S,md)
    rr=Counter(); total_samples=Counter();sigma=None
    all_rs=[];invs=[];shiftlaws=[]
    qden=m*m*e
    direct_R=Counter(i+j-k for i,j,k in product(range(H),range(m),range(m)))
    for D,E in selections:
        B=[i*W+r for i in range(H) for r in D]
        rs=Counter(i-j for i in B for j in B)
        rr.update(rs);all_rs.append(rs)
        invs.append(B)
        shifts=Counter(W*(i-j)+s for i,j,s in product(range(m),range(m),E))
        shiftlaws.append(shifts)
        assert sum(shifts.values())==qden and max(shifts.values())==m
        sigma=sum(F(n,qden)**2 for n in shifts.values())
        assert sigma==F(2*m*m+1,3*m*m*m*e)
        for x in B:
            for y,num in shifts.items():
                total_samples[x+y]+=num
    for k in range(1-N,N):
        expected=F(N-abs(k),N)*sum(c for v,c in weights if k%v==0)
        assert F(rr[k],count*J)==expected
    for n in range(-W*m,W*(H+m+1)):
        k,c=divmod(n,W)
        expectation=F((c+1)*direct_R[k]+(W-c-1)*direct_R[k-1],W*phi*H*m*m) if gcd(c,W)==1 else 0
        assert F(total_samples[n],count*J*qden)==expectation

    phi_character=[0 if x==0 else (1 if pow(x,(p-1)//2,p)==1 else -1) for x in range(p)]
    witnesses=0
    holds=0
    for t in range(1,p):
        # Enumerate the two nonzero differences and verify the exact collision identity.
        edge_labels={t*v%p:n for v,n in diffs.items()}
        near_max=F(0)
        for a in vertices:
            incidence=0
            for b in vertices:
                if a==b:continue
                k=t*(inverses[a]-inverses[b])%p
                incidence+=rr[k]+rr[k-p]
            near_max=max(near_max,F(incidence,count*J))
        assert near_max<=near
        expected_raw=count*J*S*(S-1)+sum((rr[h]+rr[h-p])*z*(z-1) for h,z in edge_labels.items())
        actual_raw=0
        for B in invs:
            clouds=Counter(((i+t*inverses[a])%p,(i+t*inverses[b])%p) for i in B for a,b in pairs)
            actual_raw+=sum(c*c for c in clouds.values())
        assert expected_raw==actual_raw
        assert F(actual_raw,count*(J*S*S)**2)<=bound
        if physical and t<=6:
            Eoff=F(0);M4=F(0);conditional=F(0)
            point_P=Counter();point_K=Counter()
            for B,shift in zip(invs,shiftlaws):
                clouds=Counter(((i+t*inverses[a])%p,(i+t*inverses[b])%p) for i in B for a,b in pairs)
                for x,y in product(range(p),repeat=2):
                    if x==y:continue
                    kr=sum(z*phi_character[(x+h)%p]*phi_character[(y+h)%p] for h,z in shift.items())
                    M4+=kr**4
                    if clouds[x,y]:
                        conditional+=clouds[x,y]*kr
                        Eoff+=clouds[x,y]*abs(kr)
                        point_P[x,y]+=clouds[x,y]
                    point_K[x,y]+=kr
            independent=sum(n*point_K[key] for key,n in point_P.items())
            if conditional*count!=independent:
                witnesses+=1
            assert (Eoff/(count*J*S*S*qden))**4<=F(actual_raw,count*(J*S*S)**2)*M4/(count*qden**4)
            holds+=1
    print('factors',factors,'p',p,'partitions',count,'all t',p-1,'maximum fibre',md,'joint Cauchy checks',holds,
          'observed dependent-product examples',witnesses)
    if physical:assert witnesses>0


audit(((2,1),(3,2)),43,2,2,(7,11,13,17,19,23,29,31),True)
audit(((3,1),(5,3)),101,2,2,(17,19,23,29,31,37,41,43))
audit(((2,1),(3,2),(5,2)),149,2,2,(31,37,41,43,47,53,59,61))
