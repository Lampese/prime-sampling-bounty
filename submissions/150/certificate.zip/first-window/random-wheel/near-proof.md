# 随机互补轮的采样、近邻和联合矩

取平方自由正整数 $W$。各个 $\ell\mid W$ 独立地均匀选择一个 $d_\ell$ 元子集 $D_\ell\subset\mathbb F_\ell$，$1\le d_\ell<\ell$，并置 $E_\ell=-(\mathbb F_\ell\setminus D_\ell)$。由 CRT 取 $[0,W)$ 中的代表集 $D,E$。写 $d=\prod d_\ell$，$e=\prod(\ell-d_\ell)$。基点集 $B_D$ 包含全部 $Wi+r,\ 0\le i<h,\ r\in D$；$J=hd$。给定划分，基点均匀；位移独立取 $W(j-j')+s$，其中 $j,j'$ 独立均匀于 $[0,m)$ 的整数，$s$ 均匀于 $E$。物理核和基点均使用同一划分。可按实际采样区间将基点整体平移 $W$ 的整数倍。

## 采样侧的精确质量，含整数进位

固定 $c\bmod W$。若某个 $\ell\mid c$，没有表示 $r+s=c\bmod W$。否则对每个 $0\le r<W$ 取唯一的 $s=c-r\bmod W$。事件 $r\in D,\ s\in E$ 在模 $\ell$ 等价于一个指定元素 $r$ 落入 $D_\ell$、另一个不同的指定元素 $r-c$ 不落入，因此概率是 $d_\ell(\ell-d_\ell)/[\ell(\ell-1)]$。独立相乘，除以 $de$，得到每个 $r$ 的平均概率都是 $1/[W\varphi(W)]$。

设 $R(k)=|\{(i,j,j'):i+j-j'=k\}|$，超出支撑取零，整体基点平移暂取为零。整数 $n=Wk+c,\ 0\le c<W$ 的平均采样质量，对于 $(c,W)=1$ 为

$$
\overline P(n)=\frac{(c+1)R(k)+(W-c-1)R(k-1)}
 {W\varphi(W)hm^2}.
$$

这两个计数分属 $r+s=c$ 与 $r+s=W+c$。当 $W=1$ 时只剩第一项。先在整数上计算，推到 $\mathbb F_p$ 时，模 $p$ 同值相加只会增加某个已覆盖整数点的概率。

因而逐角色的带权 Cauchy 使用的是 $\overline P$ 和所有素数上 $1/\overline P$ 的均值。可使用 $\min(R(k),R(k-1))/(\varphi(W)hm^2)$ 作下界。原来的 $d_{\rm box}=\lceil{\rm span}/W\rceil+5$ 容纳所有 $k,k-1$：两种 $k$ 均可写为 $(n-r-s)/W$，其中 $0\le r+s<2W$。落在左、右边缘的 $n$ 各自仍在长于对应格数至多 $3W$ 的区间内，所以原三盒单调计数与端点素数预算继续适用。该论证只需选择一个与划分无关的共同平移。

## 随机基点的二阶费用

设 $r_D(k)$ 为给定划分中差 $k$ 的有序基点对数。若 $|k|<Wh$，整数 $i$ 与 $i+k$ 同时在 $[0,Wh)$ 的选择有 $Wh-|k|$ 个。当 $\ell\mid k$ 时两点在模 $\ell$ 上相同，联合保留概率是 $d_\ell/\ell$；否则是 $d_\ell(d_\ell-1)/[\ell(\ell-1)]$。因此

$$
\frac{\mathbb E_D r_D(k)}J=
\left(1-\frac{|k|}{Wh}\right)_+
\prod_{\ell\nmid k,\,\ell\mid W}\frac{d_\ell-1}{\ell-1}.
$$

此显示中两个因子相乘。取 $\alpha_\ell=(d_\ell-1)/(\ell-1)$。局部乘子是 $\alpha_\ell+(1-\alpha_\ell)\mathbf1_{\ell\mid k}$，故整积可写成 $\sum_{v\mid W}c_v\mathbf1_{v\mid k}$，其中 $c_v=\prod_{\ell\mid v}(1-\alpha_\ell)\prod_{\ell\mid W/v}\alpha_\ell$，非负且和为一。

有 $2Wh<p_-$ 时，用带符号整数代表基点差不会绕模。对固定输入素数 $a$，若 $k=t(1/a-1/b)$ 且 $v\mid k$，则 $k/v=(t/v)(1/a-1/b)\bmod p$。因 $p\nmid v$，这是原题仍然允许的非零伸缩，三角权变为 $1-|k/v|/(Wh/v)$。等宽整数核的逐邻点有界性据此给出

$$
N=\sum_{v\mid W}c_v\,{\rm weighted\_near}(A,B,V,p_-,p_+,1,Wh/v).
$$

设 $S$ 是实际输入素数总数，$s\le S$，$M$ 同时上界全部非零倒数差的重数。给定 $D$ 的非对角采样质量 $P_D(x,y)$，每个 $(i,a,b)$、$i\in B_D,\ a\ne b$ 的质量是 $1/(JS^2)$。精确展开其平方和，未归一化量为

$$
JS(S-1)+\sum_{k\ne0}r_D(k)\,m(k/t)[m(k/t)-1].
$$

若将有序对按确定标签分组，则各组平方和相加只会更小。取 $\mathbb E_D$ 后，用上述逐顶点近邻费以及 $m\le M$，最终得到

$$
\mathbb E_D\sum_{x\ne y,\lambda}P_{D,\lambda}(x,y)^2
\le \frac{1+MN/s}{Js^2}.
$$

## 同一划分下的矩形 Cauchy

外部覆盖使用 $\overline P$ 后，将 $\sum_b\overline P(b)|S_\chi(b)|^2$ 展为对同一划分取期望，再做基点、位移、两个输入点的展开。对角项至多 $1/s$。非对角项中令 $T=\mathbb E_D\sum_{\lambda,x\ne y} P_{D,\lambda}|K_{D,\lambda}|$。由于采样总质量至多一，对任意整数 $r\ge1$，带权 Jensen 和对联合指标 $(D,\lambda,x,y)$ 的 Cauchy 给出

$$
T^r\le \mathbb E_D\sum P_{D,\lambda}|K_{D,\lambda}|^r
\le \sqrt{\left(\mathbb E_D\sum P_{D,\lambda}^2\right)
           \left(\mathbb E_D\sum |K_{D,\lambda}|^{2r}\right)} .
$$

此处第一因子是条件采样质量平方和的期望。只要第二因子有逐划分上界，或另有直接的期望上界，均可使用。不能把联合乘积拆成两个边缘期望。中心化四矩同样适用，先对 $T$ 平方，再在同一联合空间上将 $|K_{D,\lambda}|^2$ 减去原中心。由于每个 $D$ 的 $\sigma$ 相同，中心项仍按原中心常数乘至多一的非对角总质量估计；余项对 $P_{D,\lambda}$ 与中心化核再次作联合 Cauchy。

原支撑守卫使所有 $(Wj+s)\bmod p$ 对不同整数标签互异。故对每个划分的位移概率 $w_D$，均有

$$
\max_z w_D(z)=1/(me),\quad
\sum_z w_D(z)^2=(2m^2+1)/(3em^3).
$$

物理矩证明中只依赖这两个量的重合坐标分类与完全和估计可以逐划分使用，再取期望。通用的 Fourier 界 $\|\widehat w_D\|_1^2\le p^2/(m^2e)$ 亦逐划分成立：把一个长度 $m$ 的均匀盒与 $s$ 合并，Parseval 给出其平方质量 $1/(me)$，另一个均匀盒的平方质量是 $1/m$，用 Cauchy 即得。依赖全部单位剩余类的容斥 Fourier 界另需对随机 $E$ 的证明。

## 实现与审计

`near_random.py` 提供 `divisor_weights(factors)`、`random_near(A,B,V,pmin,pmax,factors,h)` 与 `random_co(A,B,V,pmin,pmax,factors,h,s,md)`。`factors` 是 $(\ell,d_\ell)$ 对的序列。

`check_near_random.py --repo REPO` 在 $p=43,101,149$ 穷举 6、30、60 种互补划分及合计 290 个非零伸缩。它逐项比对基点差、所有进位位置的平均采样概率、实际平方质量与倒数差公式，并检验近邻和碰撞费用。三组域内的最大真实非零纤维分别为 3、2、2。在 $p=43$ 另外用二次特征核做六次联合 Cauchy 检查；六次均有条件乘积期望与边缘期望之积不同。结果见 `near-check.txt`。
