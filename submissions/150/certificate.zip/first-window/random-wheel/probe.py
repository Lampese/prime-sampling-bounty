"""Compare genuine inner and outer rectangle prices at four first-window bands."""
from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
import os
import sys

here=Path(__file__).resolve().parent
work=here.parent
parser=ArgumentParser(description=__doc__)
parser.add_argument('--repo',type=Path,default=work/'prime-sampling')
parser.add_argument('--cap',type=Path,default=work/'residue-bridge'/'crt-fast')
parser.add_argument('--mode',choices=('pair','six'),required=True)
parser.add_argument('--grid',type=int,default=3200)
parser.add_argument('--u',nargs='+',default=['.42','.45','.47','.49'])
args=parser.parse_args()
sys.path[:0]=[str(args.repo.resolve()),str(args.cap.resolve())]
if (work/'zig-cxx.cmd').is_file():
    os.environ.setdefault('CXX',str(work/'zig-cxx.cmd'))
    os.environ.setdefault('ZIG_GLOBAL_CACHE_DIR',str(work/'zig-cache'))
    os.environ.setdefault('ZIG_LOCAL_CACHE_DIR',str(work/'zig-local-cache'))
from prime_sampling.rectangles import boxes,sieved_lift
from prime_sampling.spectrum import squarerates as sr
import crt_fibres,price

boxes.initialize(F(150),F(4801,32))
sieved_lift.install(boxes)
crt_fibres.install(corner=True,layered=True)
baseline=work/'residue-bridge'/('target-layered' if args.grid==3200 else 'target-layered-1600')/f'best-{args.mode}.dat'
if args.grid==4800:baseline=work/'harmonic-research'/'target'/f'{args.mode}-4800.dat'
rows={int(r.split()[0]):list(map(int,r.split())) for r in baseline.read_text().splitlines()}
boxes.rates=lambda *ignored:(F(1),F(1))
price.install(args.mode,boxes)
for u in map(F,args.u):
    v=u+F(1,args.grid)
    before=rows[int(u*args.grid)][1:5]
    g,q,_=boxes.joint(u,v,*boxes.inner(u,v))
    og,oq,_=boxes.outer(u,v)
    proposed=list(map(boxes.upint,(g,q,og,oq)))
    best=list(map(min,before,proposed))
    print(u,'old',*before,'candidate',*proposed,'best',*best,flush=True)
if os.name=='nt':
    import _ctypes
    _ctypes.FreeLibrary(sr._lib._handle)
