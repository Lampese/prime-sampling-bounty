#include <algorithm>
#include <cmath>
#include <vector>
#include <utility>

static double reps(double x,double h,double m) {
    double l=std::max(0.,x-h+1), r=std::min(2*m-2,x);
    double mid=std::min(r,m-1), sec=std::max(m,l);
    return std::max(0.,mid-l+1)*(l+mid+2)/2 + std::max(0.,r-sec+1)*(4*m-2-sec-r)/2;
}
extern "C" void choose(const double *opts,int length,double a,double b,double width,double s,double k,double span,
                     double pm,double p,double md,double logy,double qerr,int six,int *ids){
    
    const double mr[]={1./512,1./128,1./32,1./8,1./3,.7,1.5,3,6,12,24};
    const double hr[]={1./16,1./8,.25,.4,.5,2./3,5./6,1.};
    double best[]={1.,1.};ids[0]=ids[1]=-1;
    for(int wi=0;wi<length;++wi){
        const double *w=opts+6*wi;
        if(w[0]>=a)continue;
        const double d=std::ceil(span/w[0])+9, phi2=w[3];
        for(int j=0;j<11;++j){
        const double m=std::max(1.,std::floor(d*mr[j])), support=m*phi2;
        if(support<1.e6)continue;
        const double sigma=(2+1/(m*m))/(3*support);
        const double l1sq=w[5];
        const double f4=14*p*std::sqrt(p)*p*sigma*l1sq/(m*m);
        for(int bi=0;bi<8;++bi){
            const double h=std::max(1.,std::floor((d+2*m)*hr[bi]));
            if(2*w[0]*(h+2*m+d)>=pm)continue;
            const double maxx=h+2*m-3, start=std::floor((maxx+1-d)/2), peak=std::floor(maxx/2);
            if(start<0 || reps(start,h,m)<=0)continue;
            // Smooth divisor estimate for proposing parameters only.
            const double T=h*w[0], D=std::sqrt(width*pm/(4*b*T));
            const double U=b*(p/std::max(D,1.)+2*(D+2)*T);
            const double f=std::max(1.,std::floor(std::log(U)/std::log(a)));
            const double near=(1+1/h)*(f-1)+(4+6/h)*f/3*(1+std::sqrt(width*b*T/pm)*w[4]);
            const double co=(1+md*near/s)/(h*w[2]*s*s);
            double mean=1/reps(peak,h,m);
            for(int n=1;n<=16;++n){
                double lo=start+std::floor((peak-start)*(n-1)/16), hi=start+std::floor((peak-start)*n/16);
                double cnt=std::min(k,(2*(hi-start+5)*w[0]+4*qerr)/logy+2);
                mean+=(1/reps(lo,h,m)-1/reps(hi,h,m))*cnt/k;
            }
            double front=w[1]*h*m*m/k*mean;
            for(int q=0;q<2;++q){
                double D=six?(q?2./9:3./16):(q?1:.5);
                double labels=six?3:1, C=(six&&!q)?129./128:1.;
                double lead=1;
                for(int r=2;r<=5;++r){
                    double lead=1, mult=1;
                    for(int t=1;t<=r;++t){lead*=D*(q?(2*t-1):t);mult*=2*t-1;}
                    const double odd=((2*r-1)*(2*r-1)-1)*p;
                    const double even=((2*r-2)*(2*r-2)-1)*p+2*(2*r-2)*std::sqrt(p)+1;
                    const double gen=(!six&&q)?even:C*(odd+even)/2;
                    const double paired=labels*lead*std::pow(sigma,r)*p*p;
                    const double physical=gen+paired+C*p*p*std::pow(2.*r,2*r)*std::pow(sigma,r-1)/(support*support);
                    const double total=labels*mult*std::pow((q?2:1)*D,r);
                    const double spectral=C*(std::pow(4.,r)-2)*p*std::sqrt(p)*sigma*std::pow(p*l1sq/(m*m),r-1)
                        +paired+(total-labels*lead)*p*std::pow(sigma,r-1);
                    double off=std::pow(co*std::min(physical,spectral),1./(2*r));
                    if(r==2){
                        double var=std::min(gen+C*p*p*sigma/(support*support),C*f4)
                            +labels*(q?2.:1.)*std::pow(D*p*sigma,2)+12*p*sigma*(1+2*sigma);
                        off=std::sqrt(D*sigma+std::sqrt(co*var));
                    }
                    double rate=std::sqrt(front*(1/s+off));
                    if(rate<best[q]){best[q]=rate;ids[q]=(wi*11+j)*8+bi;}
                }
            }
        }}
    }
}
