"""Certified average near and collision bounds for a complementary CRT wheel."""
from fractions import Fraction
from functools import lru_cache
from math import isqrt,prod


@lru_cache(maxsize=None)
def _divisor_weights(factors):
    if not factors:
        return ((1,Fraction(1)),)
    if len({ell for ell,_ in factors})!=len(factors):
        raise ValueError('wheel primes must be distinct')
    terms={1:Fraction(1)}
    for ell,size in factors:
        if not 1<=size<ell or any(ell%q==0 for q in range(2,isqrt(ell)+1)):
            raise ValueError('each wheel factor requires prime ell and 1 <= size < ell')
        alpha=Fraction(size-1,ell-1)
        terms={v*m:c*w for v,c in terms.items() for m,w in ((1,alpha),(ell,1-alpha)) if w}
    return tuple(sorted(terms.items()))


def divisor_weights(factors):
    """Return (divisor, rational coefficient) pairs for (prime, base size) factors."""
    return _divisor_weights(tuple(factors))


@lru_cache(maxsize=65536)
def _unit_near(a,b,width,p_min,p_max,radius):
    from prime_sampling.rectangles.near import weighted_near
    return weighted_near(a,b,width,p_min,p_max,1,radius)


def random_near(a,b,width,p_min,p_max,factors,h):
    """Bound the normalized, averaged number of neighbours for an arbitrary nonzero t."""
    factors=tuple(factors)
    wheel=prod(ell for ell,_ in factors)
    if h<1 or 2*wheel*h>=p_min or p_min>p_max:
        raise ValueError('require h >= 1 and 2 W h < p_min <= p_max')
    return sum(weight*_unit_near(a,b,width,p_min,p_max,wheel*h//v)
               for v,weight in divisor_weights(factors))


def random_co(a,b,width,p_min,p_max,factors,h,s,md):
    """Upper-bound the expectation of the squared off-diagonal sampling mass."""
    factors=tuple(factors)
    if s<2 or md<0:
        raise ValueError('require s >= 2 and md >= 0')
    near=random_near(a,b,width,p_min,p_max,factors,h)
    points=h*prod(size for _,size in factors)
    return (1+Fraction(md,s)*near)/(points*s*s)
