"""Price randomized complementary residue masks using exact finite moment bounds."""
import ctypes as ct
import os
import subprocess
import sys
from fractions import Fraction as F
from functools import cache
from math import isqrt, prod
from pathlib import Path
from tempfile import TemporaryDirectory

here=Path(__file__).resolve().parent
sys.path.insert(0,str(here.parent/'harmonic-research/kernel'))
import centered_tri as tri
from near_random import random_co
from prime_sampling.spectrum import pair10,squarerates as sr

RATIOS=tuple(map(F,('1/512','1/128','1/32','1/8','1/3','.7','1.5','3','6','12','24')))
BASES=tri.BASE_FRACTIONS

def wheels():
    # Cardinalities alone determine our bounds. Include single prime moduli
    # as well as primorials, and include both extreme assignments for each end.
    prime_sets=[tri.PRIMES[:k] for k in range(1,len(tri.PRIMES)+1)]
    prime_sets += [(q,) for q in tri.PRIMES[1:]]
    prime_sets += [(2,q) for q in tri.PRIMES[2:]]
    for primes in prime_sets:
        seen=set()
        for prefix in range(min(6,len(primes))+1):
            for front in (0,1):
                for frac in (0,.1,.25,.4,.5,.6,.75,.9,1):
                    factors=tuple((q, (q-1 if front else 1) if i<prefix else
                                   max(1,min(q-1,round(q*frac)))) for i,q in enumerate(primes))
                    if factors not in seen:
                        seen.add(factors)
                        yield factors

@cache
def shape(factors):
    W=prod(q for q,_ in factors)
    base=prod(d for _,d in factors)
    shifts=prod(q-d for q,d in factors)
    totient=prod(q-1 for q,d in factors)
    near_factor=prod((d-1+(q-d)/q**.5)/(q-1) for q,d in factors)
    fourier=prod((1+((q-1)*d/(q-d))**.5)/q for q,d in factors)
    return W,totient,base,shifts,near_factor,fourier**2

def exact_rates(mode,p,s,support,m,e,front,co,l1sq):
    sqrt=isqrt(p)+1
    sigma=F(2*m*m+1,3*support*m*m)
    best=[]
    for internal in (False,True):
        if mode=='six':
            mass=F(2,9) if internal else F(3,16)
            norm,labels=(F(1) if internal else F(129,128)),3
            correction=12
        else:
            mass=F(1) if internal else F(1,2)
            norm,labels=F(1),1
            correction=2 if internal else 8
        generic4=14*F(p*p*sqrt,m*m)*sigma*l1sq
        physical4=tri.generic_bound(mode,internal,2,p,sqrt,norm,True)+norm*F(p*p,support**2)*sigma
        var=(min(norm*generic4,physical4)+labels*(2 if internal else 1)*(p*sigma*mass)**2+
             correction*p*sigma*(1+2*sigma))
        rate=sr.root(front*(F(1,s)+sr.root(mass*sigma+sr.root(co*var))))
        for r,mult,fact in ((3,15,6),(4,105,24),(5,945,120)):
            tot=labels*mult*((2*mass)**r if internal else mass**r)
            lead=labels*(mult if internal else fact)*mass**r
            paired=lead*p*p*sigma**r
            physical=(tri.generic_bound(mode,internal,r,p,sqrt,norm,True)+paired+
                      norm*p*p*sum(tri.partitions(2*r,j)*sigma**j/support**(2*r-2*j) for j in range(1,r)))
            spectral=(norm*(4**r-2)*p*sqrt*sigma*(F(p,m*m)*l1sq)**(r-1)+paired+
                      (tot-lead)*p*sigma**(r-1))
            rate=min(rate,sr.root(front*(F(1,s)+pair10.nroot(co*min(physical,spectral),2*r))))
        best.append(rate)
    return best

def install(mode,model):
    designs=list(wheels())
    options=(ct.c_double*(6*len(designs)))(*(x for d in designs for x in shape(d)))
    tmp=TemporaryDirectory(ignore_cleanup_errors=True)
    dll=Path(tmp.name)/'proposal.dll'
    subprocess.run([os.getenv('CXX','c++'),'-O3','-std=c++17','-shared','-fPIC',
                    str(here/'proposal.cpp'),'-o',str(dll)],check=True)
    lib=ct.CDLL(str(dll))
    choose=lib.choose
    choose.argtypes=[ct.POINTER(ct.c_double),ct.c_int]+[ct.c_double]*11+[ct.c_int,ct.POINTER(ct.c_int)]
    choose.restype=None
    previous=model.rates
    def rates(a,b,width,s,k,span,pm,p,_keep=(lib,tmp)):
        best=list(previous(a,b,width,s,k,span,pm,p))
        if max(best)<F(1,3000):return best
        md=min(sr.dirichlet_cap(a,b,width,pm,p),sr.previous_cap(width,b,pm),sr.square_cap(a,b,width,pm,p))
        logy=model.b(model.elo(model.zl)/(64*b),'ln',False)
        assert logy>=40
        err=model.thetaerr(logy)*2*model.eup(model.zh)/a
        ids=(ct.c_int*2)()
        choose(options,len(designs),*map(float,(a,b,width,s,k,span,pm,p,md,logy,err)),int(mode=='six'),ids)
        for code in set(ids)-{-1}:
            wi,bi=divmod(code,len(BASES))
            wi,mi=divmod(wi,len(RATIOS))
            factors=designs[wi]
            W,phi,n,e,_,_=shape(factors)
            assert W<a
            blocks=sr.ceildiv(span,W)+9
            m=max(1,int(blocks*RATIOS[mi]))
            h=max(1,int((blocks+2*m)*BASES[bi]))
            if m*e<10**6 or 2*W*(h+2*m+blocks)>=pm:continue
            harmonic=tri.harmonic_coverage(blocks,h,m,W,k,logy,err)
            if harmonic is None:continue
            front=F(phi*h*m*m,k)*harmonic
            co=random_co(a,b,width,pm,p,factors,h,s,md)
            l1sq=prod((1+sr.root(F((q-1)*d,q-d)))/q for q,d in factors)**2
            priced=exact_rates(mode,p,s,m*e,m,e,front,co,l1sq)
            if os.getenv('RW_TRACE'):
                print('random',factors,RATIOS[mi],BASES[bi],*[round(float(x),7) for x in priced],flush=True)
            best=list(map(min,best,priced))
        return best
    model.rates=rates
