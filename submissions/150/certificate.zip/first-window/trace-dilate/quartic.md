# 平移分式的完成核及其四次伸缩矩

设 $p>3$ 为素数，$\chi$ 是任一非主乘法角色，$\psi(x)=e_p(x)$。约定每个乘法角色在零处取零。写

$$K(h)=\sum_{z\ne0}\chi((z+1)/z)\psi(hz),\qquad T(h)=|K(h)|^2/p-1.$$

若 $h_i\ne0$，且有一个 $h_i$ 的模正负号类仅出现一次，则

$$\left|\sum_{x\ne0}\prod_{i=1}^4 T(h_i x)\right|\le80\sqrt p.$$

对任意四个非零 $h_i$，把四个位置分成两个无序对的三个配对记为 $\mathcal P$，令 $b(\mathbf h)=\sum_{\pi\in\mathcal P}\prod_{(i,j)\in\pi}1_{h_i=\pm h_j}$。统一界为

$$\left|\sum_{x\ne0}\prod_iT(h_i x)\right|
\le 80\sqrt p+(p+\sqrt p)b(\mathbf h).\tag{1}$$

## 识别层与伸缩群

取 $x=-tz, y=-1/z$，则 $xy=t$，从而

$$K(-t)=\sum_{xy=t}\psi(x)\chi(1-y).$$

这就是 Katz 超几何和 $\operatorname{Hyp}_\psi(1,1;\chi)(t)$ 除以一个绝对值为 $\sqrt p$ 的高斯常数。直接从超几何和的定义即可核对。和中置 $x_1=x,x_2=yv$，则 $x_1x_2=t v$；对 $v\ne0$ 作和得到 $G(\bar\chi)\chi(y-1)$，在 $y=1$ 也成立。负号和 $\chi(-1)$ 并入常数。归一权零后，所得秩二层 $\mathcal F$ 的迹与 $K(-t)/\sqrt p$ 仅相差模为一的因子。计算点上的 $|K|^2/p$ 时，该因子自动消去。[Katz，Another Look at the Dwork Family，第 3 节](https://web.math.princeton.edu/~nmk/dworkfam64.pdf)

两列 $\{1,1\}$ 和 $\{\chi\}$ 不相交，故 $\mathcal F$ 几何不可约，在 $\mathbb G_m$ 上光滑。零点温和单值是一个大小为二、特征值为一的 Jordan 块；无穷远处分为一条温和线与一条 break 为一的野线。由 Katz 的行列式公式，类型 $(D,D-1)$ 的几何行列式为上列字符的积张量 $\mathcal L_\psi$。本例上列积为一，所以无穷远野惯性上的两条线的字符为 $1,\mathcal L_\psi$。原 $K(h)$ 带一个变量负号，等效于把 $\psi$ 换成 $\bar\psi$，以下的正负号集合完全相同。[Katz，Exponential Sums and Differential Equations，Theorem 8.4.2 与 Lemma 8.11.6](https://web.math.princeton.edu/~nmk/wholebookcorrms.pdf)；[行列式公式的逐项表述，式 (4.1)](https://sites.math.rutgers.edu/~tl639/TY2.pdf)

秩二几何表示的射影群在 $\operatorname{PGL}_2$ 中不可约，并含无穷阶幺幂元。其 Zariski 闭包为整个 $\operatorname{PGL}_2$：闭包的单位连通分支含正维幺幂子群，若为真子群，只能为一个幺幂群或 Borel 群的子群，固定唯一一条线；完整群正规化该连通分支，亦固定这条线，违背不可约性。该论证涵盖 $\chi$ 为二次及任意更高阶。

取伴随层 $\mathcal A=\operatorname{End}^0\mathcal F$。其迹为 $T$，几何群为标准三维 $\operatorname{SO}_3\simeq\operatorname{PGL}_2$。其在 0 处温和，在无穷远野惯性上分解为 $1,\mathcal L_\psi,\mathcal L_{\bar\psi}$。因此 $[h\cdot]^*\mathcal A$ 的野字符参数集合是 $\{0,h,-h\}$。若两个伸缩的参数不同至正负号，它们几何上不可能同构。这里这些参数确实各不相同，因 $\mathcal L_{\psi(cx)}$ 在 $\infty$ 处对 $c\ne0$ 均有 Swan 一。

将四个伸缩按实际的几何表示同构分组。每个几何单值射影到 $\operatorname{SO}_3$ 都满，同构类之间的联合闭包是直积。理由为中心平凡的简单群的 Goursat 引理，真正的两因子耦合必须是群自同构的图像；$\operatorname{PGL}_2$ 在系数域特征零时的代数群自同构都是内自同构。这会使三维层几何同构。对更多因子按此归纳，因为从已知直积推出单个简单因子的商只能取其中一个因子。按正负号划分可以过度合并，任何只出现一次的正负号类一定是独立的单个三维因子。[Fouvry、Kowalski、Michel，第 2 节的 Goursat–Kolchin–Ribet 判据](https://people.math.ethz.ch/~kowalski/sums-of-products.pdf)

## 数值常数

四重张量 $\mathcal V$ 的秩为 81，在 $\mathbb G_m$ 上光滑、纯权零。零点为温和，$\infty$ 的野字符均为四个 $0,\pm h_i$ 参数之和。一律 break 至多一，全取零至少给一条温和线，所以 $\operatorname{Swan}_\infty\mathcal V\le80$。单个 $\mathcal A$ 的复杂度按「秩、几何奇点数与 Swan 之和」的约定是 $3+2+2=7$，四重张量至多 $81+2+80=163$。Grothendieck–Ogg–Shafarevich 公式和 $\chi_c(\mathbb G_m)=0$ 给 $\dim H_c^1\le80+e$，其中 $e$ 是几何不变量维数。$H_c^0=0$，$H_c^2$ 的维数是 $e$。对纯权零层使用 Deligne 的权界得到 $80\sqrt p+(p+\sqrt p)e$。[Deligne，La conjecture de Weil II](https://www.numdam.org/item/PMIHES_1980__52__137_0/)

若存在单次因子，则 $e=0$。若有两个不同实际层分别出现两次，则 $e=1$。若四个实际层都相同，$e=3$；这是因为三维标准表示的张量平方分解为互异的三个不可约表示，维数分别为 $1,3,5$。在每种情况下 $e\le b(\mathbf h)$。这证明 (1)，包含实际同构究竟是否发生在负号伸缩的两种可能。

## 固定任一非零位移的矩形

取任意非负概率 $w_h$，$\sigma=\sum_h w_h^2$；$w_0$ 可从 $\sum_h w_hT(h\delta)$ 的上界舍去，因为 $K(0)=-1$。由 (1)、实值性及配对的正负号拓宽，

$$\sum_{x\ne0}\left|\sum_{h\ne0}w_hT(hx)\right|^4
\le 80\sqrt p+12(p+\sqrt p)\sigma^2.\tag{2}$$

对每个配对，其总权至多 $(\sum_{u\ne0}w_u(w_u+w_{-u}))^2\le4\sigma^2$。这里 $\sigma^2$ 指 $\|w\|_2^4$。

设 $S=|U|$，$k\le|V|$。对每个非零倒数差 $\delta$，其有序表示数 $m(\delta)\le M$，且总和 $S(S-1)$。对任一 $t\ne0$，伸缩的第四矩 (2) 相同。Hölder 给

$$\frac1{S^2}\sum_\delta m(\delta)\sum_hw_h\frac{|K(ht\delta)|^2}{p}
\le 1+\left[\frac{M}{S^2}\left(80\sqrt p+12(p+\sqrt p)\sigma^2\right)\right]^{1/4}.$$

再作一次加权 Cauchy，$|K|/\sqrt p$ 均值不超过右侧平方根，记为 $b_4$，还可与逐点 Weil 界 $2$ 取小。

具体取 $C>R$，$2C<p$，以 $R$ 覆盖采样素数到所选区间中点的最大整数距离。三角完成权 $(1-|z|/C)_+$ 在采样区间上至少 $1-R/C$，其 Fourier 系数除了平移相位就是 $w_h=|\sum_{0\le j<C}\psi(hj)|^2/(pC)$。各 $w_h\ge0$、总和一，且 $\sigma=(2C^2+1)/(3pC)$。输入侧任意单位权与标签均可留在绝对值外直接舍去相位。对角 $S$ 项各至多 $C$，非对角对每个频率是 $K(ht\delta)$ 乘单位相位，于是两个方向都可分别使用

$$D_\chi\le \sqrt{\frac C{C-R}\frac{C/S+\sqrt p\min(2,b_4)}{k}}.$$

这对所有非主角色统一，因而同时适用于题目的 single、pair 和 six 的两种费率。$p$、$S$ 的区间取整时可用 $p\in[p_-,p_+]$，$S\ge s$，$\sqrt p$ 处用 $\lceil\sqrt{p_+}\rceil$，$p\sigma^2$ 处使用 $[(2C^2+1)/(3C)]^2/p_-$。`scale.py` 与 `probe.py` 实现这些单侧替换。采样四阶中取到的是固定任一 $t$ 的上界，无需对未选择的参数取平均。

## 针对模长的二次上包络

对奇数 $j=3,5$，令 $U_j$ 是射影群的 $j$ 维不可约表示的迹，在光滑点 $U_3=T$, $U_5=T^2-T-1$。两个表示都来自同一 $\mathrm{PGL}_2$，所以以上已证明的不同伸缩独立性可以原样使用。$U_j$ 在无穷远处的野参数为 $0,\pm h,\ldots,\pm ((j-1)/2)h$，单个张量的 Swan 至多 $j^4-1$。四个相同表示出现时，四次张量中不变量维数为 $j$，因为其张量平方含 $j$ 个互异不可约分量，各出现一次。两两异类时维数仍为一。从而 $e\le (j/3)b(\mathbf h)$，在 (2) 中获得 $j^4-1$ 和 $4j$ 两个常数。记

$$E_j=\left[\frac{M}{S^2}((j^4-1)\sqrt p+4j(p+\sqrt p)\sigma^2)\right]^{1/4}.$$

它控制非零频率对应 $U_j$ 的带权均值的绝对值。二阶也可直接对 $U_3$ 作 GOS：二重张量 Swan 至多 8，有不变量仅在实际同构时且维数一，故将原始二阶估计换成 $[M(8\sqrt p+2(p+\sqrt p)\sigma)/S^2]^{1/2}$。

对 $x=|K(h)|^2/p\in[0,4]$，$y>0$，令 $u=y^2$ 和 $d=1/[2y(2+y)^2]$。恒等式

$$y+\frac{x-u}{2y}-\sqrt x=\frac{(x-u)^2}{2y(\sqrt x+y)^2}$$

给上包络 $\sqrt x\le a+bU_3-dU_5$，其中 $a=y+(1-u)/(2y)-d(1+(1-u)^2)$，$b=1/(2y)-d(3-2u)$。取 $y=1$ 即 $a=17/18,b=4/9,d=1/18$。因此可将旧完成核常数与 $a+|b|E_3+d E_5$ 取小。对被定价的 $y=12/16,\ldots,26/16$ 逐个有理检验 $a>0.9$。非对角的总权至多一，非零频率主项至多 $a(1-w_0)$；零频对应的模长恰为 $1/\sqrt p\le a$，加回至多 $a w_0$。$E_j$ 只用 $h\ne0$，故未把光滑点的迹恒等式套在零点奇异纤维上。

入口 `completion(s,k,span,pm,p,M)` 依次接受输入侧素数数下界、采样侧素数数下界、采样侧跨度上界、质数窗下界和上界、倒数差有序对数上界，返回一个两种频道均可使用的有理率。浮点仅用于挑选整数 $C$，所有回报值均从明确的候选有理数向上计算。

### 短端倒数差的直接整式界

输入侧全为奇素数，位于 $[a,b]\subset(2,p)$，实际跨度至多 $V$。对不同素数 $u,v$，有理数 $(v-u)/(uv)$ 是既约分数；它唯一指定有序对，因为既约分母给出无序素数对，符号确定次序。若相同非零模 $p$ 倒数差有两个不同有序表示，二者交叉行列式为非零整数，包含因子 $p$，又因两项的分子皆为偶数而包含因子 $2$。行列式绝对值至多 $2Vb^2$。因此 $Vb^2<p$ 时每个非零差最多一个表示。一般情形，把同一模差的不同有理表示排序，相邻距离至少 $2p/b^4$；全体实倒数差范围长度最多 $2V/[a(a+V)]$。统一有

$$M\le1+\left\lfloor\frac{Vb^4}{p_-a(a+V)}\right\rfloor.$$

入口 `prime_fibre(a,b,width,pm,previous)` 与已有单纤维估计取小，输出可传给 `completion`，也可用在其他引用同一有序倒数差上界的方法。首窗 G3200 标准外盒 $u=0.335,0.35$ 的既有两层格上界为 19、31，经此均为 1，三次谱率依次为 0.0002387172 和 0.0006501921。

### 可选的三次上包络

传入 `degree=3` 还可使用相同群的七维不可约表示。其迹为 $U_7=x^3-5x^2+6x-1$，误差由上式 $E_j$ 取 $j=7$，动用的两个常数为 $2400,28$。每个 $a<b$ 为正有理数，以 $u=a^2,v=b^2$ 为节点对 $\sqrt x$ 作 Hermite 三次插值：

$$P(x)=a+\frac{x-u}{2a}-\frac{(x-u)^2}{2a(a+b)^2}
 +\frac{(x-u)^2(x-v)}{2ab(a+b)^3}.$$

$P$ 在两节点均重合函数值和导数。对 $x>0$ 标准插值余项为 $(\sqrt{\,\cdot\,})^{(4)}(\xi)(x-u)^2(x-v)^2/24\le0$，故 $\sqrt x\le P(x)$；零点由连续性。把 $P=p_0+p_1x+p_2x^2+p_3x^3$ 展成 $A_0+A_3U_3+A_5U_5+A_7U_7$，则

$$A_0=p_0+p_1+2p_2+5p_3,\quad A_3=p_1+3p_2+9p_3,\quad A_5=p_2+5p_3,\quad A_7=p_3.$$

完成核常数可以取 $A_0+|A_3|E_3+|A_5|E_5+|A_7|E_7$。六个有理节点对逐个检验 $A_0>4/5$，所以 $h=0$ 的处理也照前。该扩展为独立可选项，默认不改变二次包络的复算。
