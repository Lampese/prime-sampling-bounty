"""Completed Fejer mean for a nontrivial character, using geometric scale correlations."""
from fractions import Fraction as F
from math import isqrt
from prime_sampling.spectrum.fullprice import root


def _quadratic(y):
    u=y*y;lam=1/(2*y*(2+y)**2)
    mean=y+(1-u)/(2*y)-lam*(1+(1-u)**2)
    slope=1/(2*y)-lam*(3-2*u)
    assert mean>F(9,10)
    return mean,abs(slope),lam


QUADRATICS=tuple(_quadratic(F(i,16)) for i in range(12,27))
DOUBLE_QUADRATICS=tuple(tuple(map(float,c)) for c in QUADRATICS)


def _cubic(a,b):
    u=a*a;v=b*b
    mu=1/(2*a*(a+b)**2);nu=1/(2*a*b*(a+b)**3)
    p3=nu;p2=-mu-nu*(2*u+v)
    p1=1/(2*a)+2*u*mu+nu*(u*u+2*u*v)
    p0=a-u/(2*a)-mu*u*u-nu*u*u*v
    constant=p0+p1+2*p2+5*p3
    assert constant>F(4,5)
    return constant,abs(p1+3*p2+9*p3),abs(p2+5*p3),abs(p3)


CUBICS=tuple(_cubic(F(i,16),F(j,16)) for i,j in ((10,26),(12,26),(15,28),(18,30),(21,32),(24,32)))
DOUBLE_CUBICS=tuple(tuple(map(float,c)) for c in CUBICS)


def prime_fibre(a,b,width,pm,previous):
    """A fixed nonzero inverse difference among odd positive primes."""
    assert 2<a<=b and 0<width<=b and pm>2
    # Every nonzero cross-determinant is divisible by 2p.
    if width*b*b<pm:return min(previous,1)
    spacing=1+(width*b**4)//(pm*a*(a+width))
    return min(previous,spacing)


def _trials(R,s,rt):
    seed=isqrt(2*rt*R*s)
    trials={max(2*R,seed)}
    for j in range(1,65):
        trials.add(max(R+1,R*(j+8)//8))
        trials.add(max(R+1,seed*(j+4)//16))
    return trials


def completion(s,k,span,pm,p,M,degree=2):
    """Return one outward rate for either spectral channel. p is the upper endpoint."""
    R=(span+1)//2+1;rt=isqrt(p)+1
    trials=[c for c in _trials(R,s,rt) if R<c and 2*c<pm]
    if not trials:return F(1)
    weight=float(F(M,s*s));p0=float(pm);r=float(rt);ratio=(1+r/p0)/p0
    def predicted(c):
        H=(2*float(c)+1/float(c))/3
        D=H*H*ratio
        e3=(weight*(80*r+12*D))**.25
        e5=(weight*(624*r+20*D))**.25
        q=min(a+b*e3+d*e5 for a,b,d in DOUBLE_QUADRATICS)
        if degree>=3:
            e7=(weight*(2400*r+28*D))**.25
            q=min(q,min(a+b*e3+d*e5+e*e7 for a,b,d,e in DOUBLE_CUBICS))
        e2=(weight*(8*r+2*H*(1+r/p0)))**.5
        factor=min(2.,(1+e2)**.5,(1+e3)**.5,q)
        return float(c)/float(c-R)*(float(c)/float(s)+r*factor)
    best=F(1)
    for c in sorted(trials,key=predicted)[:3]:
        H=F(2*c*c+1,3*c);D=H*H*(1+F(rt,pm))/pm
        weight0=F(M,s*s)
        e2=root(weight0*(8*rt+2*H*(1+F(rt,pm))))
        e3=root(root(weight0*(80*rt+12*D)))
        e5=root(root(weight0*(624*rt+20*D)))
        q=min(a+b*e3+d*e5 for a,b,d in QUADRATICS)
        if degree>=3:
            e7=root(root(weight0*(2400*rt+28*D)))
            q=min(q,min(a+b*e3+d*e5+e*e7 for a,b,d,e in CUBICS))
        factor=min(2,root(1+e2),root(1+e3),q)
        best=min(best,root(F(c,c-R)*(F(c,s)+rt*factor)/k))
    return best


def prices(R,s,k,pm,p,M):
    rt=isqrt(p)+1
    best={q:F(1) for q in ('old','two','four','four-sharp','minor','ideal')}
    choices={}
    trials=_trials(R,s,rt)
    for c in trials:
        if c<=R or 2*c>=pm:continue
        P=F(2*c*c+1,3*c)
        fac2=root(F(M,s*s)*(16*rt+9+6*P))
        ex=F(972)*P*P/pm
        fac4=root(root(F(M,s*s)*(80*rt+ex)))
        D=P*P*(1+F(rt,pm))/pm
        fac4sharp=root(root(F(M,s*s)*(80*rt+12*D)))
        fac5=root(root(F(M,s*s)*(624*rt+20*D)))
        envelopes=[a+b*fac4sharp+d*fac5 for a,b,d in QUADRATICS]
        for key,factor in (('old',F(2)),('two',root(1+fac2)),('four',root(1+fac4)),
                           ('four-sharp',root(1+fac4sharp)),('minor',min(envelopes)),('ideal',F(1))):
            value=root(F(c,c-R)*(F(c,s)+factor*rt)/k)
            if value<best[key]:best[key]=value;choices[key]=(c,factor)
    return best,choices
