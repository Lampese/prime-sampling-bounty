from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
import sys,os

work=Path(__file__).resolve().parents[1]
ap=ArgumentParser()
ap.add_argument('--repo',type=Path,default=work/'prime-sampling')
ap.add_argument('--cap',type=Path,default=work/'residue-bridge/crt-fast')
ap.add_argument('--grid',type=int,default=3200)
args=ap.parse_args()
sys.path[:0]=[str(x.resolve()) for x in (args.repo,args.cap)]
if (work/'zig-cxx.cmd').exists():
    os.environ.setdefault('CXX',str(work/'zig-cxx.cmd'))
    os.environ.setdefault('ZIG_GLOBAL_CACHE_DIR',str(work/'zig-cache'))
    os.environ.setdefault('ZIG_LOCAL_CACHE_DIR',str(work/'zig-local-cache'))
from prime_sampling.rectangles import boxes as m,sieved_lift
from prime_sampling.spectrum import squarerates as sr
import crt_fibres
from scale import prices,completion,prime_fibre
m.initialize(F(150),F(4801,32));sieved_lift.install(m);crt_fibres.install(corner=True,layered=True)
for u in map(F,('.335','.35','.375','.40','.42','.45','.47','.49')):
    v=u+F(1,args.grid)
    cl=max(m.LAM*m.Xlo(u-v),m.Xlo(2*u-1));et=F(1)
    eps,_,a,b,s,width,ylo,yhi=m.params(u,v)
    eps=max(eps,m.thetaerr((1-u)*m.zl+m.b(cl,'ln',False)))
    k=(m.abel.lower_count(cl,et,eps,(1-u)*m.zh,m)*ylo).__ceil__()
    span=((et-cl)*yhi).__ceil__()+2
    M=min(sr.dirichlet_cap(a,b,width,m.pmin,m.pmax),sr.previous_cap(width,b,m.pmin),sr.square_cap(a,b,width,m.pmin,m.pmax))
    M0=M;M=prime_fibre(a,b,width,m.pmin,M)
    R=(span+1)//2+1
    result,choices=prices(R,s,k,m.pmin,m.pmax,M)
    print(u,'M old/new',M0,M,'input',s,'rates',*(m.upint(result[c]) for c in ('old','two','four','four-sharp','minor','ideal')),
          'new C and K factor',choices.get('minor',(0,0))[0],float(choices.get('minor',(0,0))[1]),
          'quadratic, cubic API',*(m.upint(completion(s,k,span,m.pmin,m.pmax,M,degree)) for degree in (2,3)),flush=True)
if os.name=='nt':
    import _ctypes
    _ctypes.FreeLibrary(sr._lib._handle)
