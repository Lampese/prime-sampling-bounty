"""Independent small-field numerical checks of the trace identities and bounds."""
from cmath import exp
from itertools import product
from math import pi,sqrt


def close(x,y):
    assert abs(x-y)<1e-6,(x,y)


total=0;scales=0;quad=0
for p in (5,7,11,13,17,19,23,31,37,43,53):
    g=next(g for g in range(2,p) if len({pow(g,j,p) for j in range(p-1)})==p-1)
    log={pow(g,j,p):j for j in range(p-1)}
    psi=[exp(2j*pi*j/p) for j in range(p)]
    eta=lambda x:(0 if x%p==0 else (-1)**log[x%p])
    for exponent in range(1,p-1):
        chi=[0]+[exp(2j*pi*exponent*log[x]/(p-1)) for x in range(1,p)]
        f=[0]+[chi[(1+pow(z,-1,p))%p] for z in range(1,p)]
        K=[sum(f[z]*psi[h*z%p] for z in range(p)) for h in range(p)]
        C=[sum(f[(z+k)%p]*f[z].conjugate() for z in range(p)) for k in range(p)]
        T=[abs(x)**2/p-1 for x in K]
        L=[x+2/p for x in T]
        for t in range(1,p):
            close(K[-t],sum(psi[x]*chi[(1-t*pow(x,-1,p))%p] for x in range(1,p)))
            if t not in (1,p-1):
                lam=((t+1)*pow(t-1,-1,p))**2%p
                close(C[t]+1,sum(chi[w]*eta((1-w)*(lam-w)) for w in range(p)))
            close(L[t],sum(C[k]*psi[t*k%p] for k in range(1,p))/p)
            scales+=1
        close(sum(L),0)
        close(sum(C[1:]),3-p)
        j=sum(eta(v)*chi[(1-v)%p] for v in range(1,p))
        close(C[1]+1,j)
        for hs in ((1,2,3,4),(1,1,2,2),(1,p-1,1,p-1),(1,2,2,3)):
            vals=[sum(T[a*x%p]*T[b*x%p]*T[c*x%p]*T[d*x%p] for x in range(1,p)) for a,b,c,d in [hs]]
            pairs=[((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2))]
            dim=sum(all((hs[i]-hs[j])%p==0 or (hs[i]+hs[j])%p==0 for i,j in pairing) for pairing in pairs)
            assert abs(vals[0])<=80*sqrt(p)+(p+sqrt(p))*dim+1e-6
            quad+=1
        total+=1
print('Checked nontrivial field/character pairs',total,'nonzero dilation identities',scales,'fourfold trace examples',quad)
