from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
import sys

ap=ArgumentParser()
ap.add_argument('--repo',type=Path,default=Path(__file__).resolve().parents[1]/'prime-sampling')
args=ap.parse_args()
sys.path.insert(0,str(args.repo.resolve()))
from scale import CUBICS,QUADRATICS,prime_fibre

num=0
for i,(c,bc,d) in zip(range(12,27),QUADRATICS,strict=True):
    y=F(i,16);u=y*y;lam=1/(2*y*(2+y)**2);b=1/(2*y)-lam*(3-2*u)
    assert abs(b)==bc
    for j in range(129):
        f=F(j,64);x=f*f
        pol=y+(x-u)/(2*y)-lam*(x-u)**2
        assert pol==c+b*(x-1)-d*(x*x-3*x+1) and pol>=f
        num+=1
for (i,j),envelope in zip(((10,26),(12,26),(15,28),(18,30),(21,32),(24,32)),CUBICS,strict=True):
    a,b=F(i,16),F(j,16);u,v=a*a,b*b
    mu=1/(2*a*(a+b)**2);nu=1/(2*a*b*(a+b)**3)
    p3=nu;p2=-mu-(v+2*u)*nu;p1=1/(2*a)+2*mu*u+nu*(2*u*v+u*u)
    p0=a-u/(2*a)-mu*u*u-nu*u*u*v
    coeff=(p0+p1+2*p2+5*p3,p1+3*p2+9*p3,p2+5*p3,p3)
    assert tuple(map(abs,coeff))==envelope
    for j in range(129):
        f=F(j,64);x=f*f
        pol=a+(x-u)/(2*a)-mu*(x-u)**2+nu*(x-u)**2*(x-v)
        traces=(1,x-1,x*x-3*x+1,x**3-5*x*x+6*x-1)
        assert pol==sum(c*t for c,t in zip(coeff,traces)) and pol>=f
        num+=1
print('Rational checks of quadratic and cubic trace expansions over [0,2]:',num)
from math import isqrt
from collections import Counter
checks=0
for p in (31,97,211,1009,10007):
    primes=[q for q in range(3,min(100,p),2) if all(q%d for d in range(2,isqrt(q)+1))]
    for i,a in enumerate(primes):
        for j in range(i+1,len(primes)):
            V=primes[j]-a
            ds=Counter((pow(q,-1,p)-pow(r,-1,p))%p for q in primes[i:j+1] for r in primes[i:j+1] if q!=r)
            assert max(ds.values())<=prime_fibre(a,primes[j],V,p,V+1)
            checks+=1
print('Exhaustive prime-interval reciprocal-difference caps',checks)
