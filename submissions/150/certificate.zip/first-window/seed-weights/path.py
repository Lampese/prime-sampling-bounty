"""Compare genuinely supported new seed prices using the unchanged upstream transition graph."""
from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
import sys

def paths(repo,table,r):
    sys.path.insert(0,str(repo.resolve()))
    from prime_sampling.budget import menu,tight,widerough as s
    lo,hi=F(150),F(4801,32)
    seeds={}
    for line in table.read_text().splitlines():
        w=line.split()
        if w and w[0]=='logY' and int(w[5])==r and F(12)<=F(w[1])<=14:
            seeds[F(w[1])]=min(seeds.get(F(w[1]),(F(1),0)),(F(w[-1]),int(w[3])))
    assert seeds
    if str(r) not in tight.patterns:
        tight.patterns[str(r)]=[(h,n,t) for h in range(min(r,16)+1) for n in range(h,r+1)
                                for t in (0,2,4) if t<=n-h]
    g=menu.group(r)[0];zh=s.up(hi-s.ld(hi-F('1.1')))
    nodes=[F(j,2) for j in range(24,53)]
    fn=s.bound(lo,hi,r,F(13),0,F(1,1800),[],options_for_rank=menu.group)
    fees={(u,v):fn(u,v,u,False) for j,v in enumerate(nodes) for u in nodes[max(0,j-7):j]}
    for y,(seed,m) in seeds.items():
        cost={y:(seed+2*zh*(1/g-1)/(s.trans(y,'exp',False)-1),[y])}
        for v in nodes:
            if v<=y:continue
            cost[v]=min((price+fees[u,v],path+[v]) for u,(price,path) in cost.items()
                        if (u,v) in fees)
        price,path=cost[F(26)]
        yield price,y,m,path


if __name__=='__main__':
    here=Path(__file__).resolve().parent
    ap=ArgumentParser(description=__doc__)
    ap.add_argument('seeds',type=Path)
    ap.add_argument('--repo',type=Path,default=here.parent/'prime-sampling')
    ap.add_argument('--rank',type=int,choices=(37,38),default=38)
    args=ap.parse_args()
    for price,y,m,path in paths(args.repo,args.seeds,args.rank):
        v=(price*10**12).__ceil__()
        print('start',y,'m',m,'prefix through 26 <=',f'{v//10**12}.{v%10**12:012d}',
              'path',*path,flush=True)
