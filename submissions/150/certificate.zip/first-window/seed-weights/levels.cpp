#include <algorithm>
#include <cassert>
#include <cstdint>
#include <iostream>
#include <vector>
using N=std::int64_t;
struct State {N lo,hi;};
struct Grid {std::vector<State> x;std::vector<N> eps;};
State step(State x,const Grid& y,int j,int p,int shift,N noise,N unit){
    if (j+shift<(int)y.x.size()){
        auto z=y.x[j+shift];
        x.lo=std::max<N>(0,x.lo-(z.hi+p-1)/p);
        x.hi-=z.lo/p;
    }else{
        x.lo=std::max<N>(0,x.lo-(unit+p-1)/p-noise);
    }
    assert(0<=x.lo && x.lo<=x.hi && x.hi<=2*unit);
    return x;
}
#ifndef SEED_GRID_LIBRARY
int main(){
    int n,m,k; N unit;
    if(!(std::cin>>unit>>n>>m>>k))return 1;
    std::vector<int> cols(k);
    for(int& j:cols){std::cin>>j;assert(j>=0 && j<m);}
    Grid mixed,plain,ar;
    std::vector<N> mixed_noise(n);
    for(int j=0;j<n;++j){
        N a,b;std::cin>>a>>b;
        plain.eps.push_back(a);plain.x.push_back({unit-a,unit+a});mixed_noise[j]=b;
        if(j<m){mixed.eps.push_back(b);mixed.x.push_back({unit-b,unit+b});}
    }
    ar=plain;
    int p,shift,t,flag;
    while(std::cin>>p>>shift>>t>>flag){
        for(int j=0;j<n;++j){
            if(!t)ar.x[j]=step(ar.x[j],ar,j,p,shift,ar.eps[j],unit);
            plain.x[j]=step(plain.x[j],t?mixed:plain,j,p,shift,t?mixed_noise[j]:plain.eps[j],unit);
        }
        for(int j=0;j<m;++j)mixed.x[j]=step(mixed.x[j],mixed,j,p,shift,mixed.eps[j],unit);
        if(flag){
            for(int j:cols)std::cout<<flag<<' '<<j<<' '<<ar.x[j].hi<<' '<<plain.x[j].lo<<'\n';
        }
    }
}

#endif
