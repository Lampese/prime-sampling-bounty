"""Finite mixed Brun recursion on a positive physical partition of the interval."""
from argparse import ArgumentParser
from bisect import bisect_right
from fractions import Fraction as F
from functools import cache
from math import comb,isqrt,prod
from pathlib import Path
import subprocess,sys

here=Path(__file__).resolve().parent
ap=ArgumentParser(description=__doc__)
ap.add_argument('--repo',type=Path,default=here.parent/'prime-sampling')
ap.add_argument('--exe',type=Path,default=here/'levels.exe')
ap.add_argument('--mesh',type=int,default=48)
ap.add_argument('--wheel',type=int,choices=range(9),default=0)
ap.add_argument('--top',type=int,nargs='+',default=[3,7,15])
ap.add_argument('--rank',type=int,choices=(37,38,39),default=38)
ap.add_argument('--window',nargs=2,type=F,help='price the ordinary reference rank uniformly on these endpoints')
ap.add_argument('--max-y',type=F,default=F(13))
ap.add_argument('--small-start',action='store_true',help='include independent initial checkpoints 6, 8 and 10')
ap.add_argument('--checkpoints',type=F,nargs='+',help='sorted arithmetic sieve endpoints for a separately priced start')
ap.add_argument('--check',type=Path)
ap.add_argument('--state-out',type=Path,help='export unconditional arithmetic upper and normalized pass lower bounds for each actual hat')
ap.add_argument('--prefix-caps',action='store_true',help='intersect states with exact wheel and coordinate prefix bounds')
ap.add_argument('--exact-ends',action='store_true',help='bound arithmetic endpoint discrepancies over a complete primorial period')
ap.add_argument('--joint-loss',action='store_true',help='use the coupled arithmetic, pass and signed-loss recursion')
ap.add_argument('--coordinate-order',type=F,default=F(1),help='multiply coordinate sort keys before merging the two sets of events')
args=ap.parse_args()
sys.path.insert(0,str(args.repo.resolve()))
from prime_sampling.budget.certificate import eu,ld,trans,ps as ordinary_primes
from prime_sampling.accounting.ledger import rank

lo,hi=args.window or (F(150),F(4801,32));assert 150<=lo<hi<=156
lam=F(1,32); mesh=args.mesh
xl=(trans(lo,'exp',False)/(lo-1)).__floor__()
inv=F(1,xl)
zh=hi-ld(hi-F('1.1'))
assert 122*(1/(lo-F('1.1'))+1/trans(lo,'exp',False))<1
unit=10**15; count=22; degree=110
if args.window:seq=ordinary_primes[:args.rank]
else:
    assert args.rank in (37,38);seq=rank(hi,'with3' if args.rank==38 else 'without3')
assert len(seq)==args.rank
g=prod(1-F(1,p) for p in seq)
def up(v,base=10**9):
    return F((base*v).__ceil__(),base)


@cache
def dirichlet(m):
    """Majorize E |1+...+exp((m-1)i theta)| using finite orthogonality."""
    moments=[1]
    for j in range(1,degree+1):
        mid=(m-1)*j
        moments.append(sum((-1)**k*comb(2*j,k)*comb(mid-m*k+2*j-1,2*j-1)
                           for k in range(mid//m+1)))
    value=F(1);c=F(1,2)
    for j in range(1,degree+1):
        raw=sum((-1)**i*comb(j,i)*moments[i]*m**(2*(j-i)) for i in range(j+1))
        assert raw>=0
        value-=c*F(raw,m**(2*j))
        c*=F(2*j-1,2*j+2)
    return up(m*value)


def grid_col(v):
    f=v**mesh
    j=max(0,f.numerator.bit_length()-f.denominator.bit_length())
    return j+int(F(2)**j<f)


def members(m):
    t=F(1,m+1)
    shapes=[(1-t,dirichlet(m))]
    for j in range(count):
        # One test combines the two half-height triangular edge weights.
        shapes.append((t/F(2)**(j+1),dirichlet(2)/2))
    return [(u,grid_col(K/(u*(1-lam)-inv))) for u,K in shapes]


ms=args.top
assert ms and all(isinstance(m,int) and m>=1 for m in ms) and mesh>=1
weights={m:members(m) for m in ms}
cols=sorted({j for ws in weights.values() for u,j in ws})
wheel=(2,3,5,7,11,13,17,19)[:args.wheel]
wheel_density=prod((1-F(1,p) for p in wheel),start=F(1))
@cache
def endpoint(primes):
    size=prod(primes);phi=prod(p-1 for p in primes)
    simple=min(2**len(primes),phi)
    if not args.exact_ends:return F(simple)
    assert size<=510510
    units=bytearray([1])*(size+1)
    for p in primes:units[p::p]=bytes(size//p)
    low=high=0;cum=0
    for t in range(1,size+1):
        cum+=size*units[t]-phi
        if cum<low:low=cum
        if cum>high:high=cum
    assert cum==0
    return min(F(simple),F(high-low+phi,size))
residue_error=endpoint(wheel)/wheel_density
error=8*(lo-1)*eu(-lo/2)/(1-inv)*2**len(wheel)+2*inv*residue_error
def iroot(v,k):
    low,high=0,1<<((v.bit_length()+k-1)//k)
    while high-low>1:
        mid=(high+low)//2
        if mid**k>=v:high=mid
        else:low=mid
    return high
frac=[iroot((1<<j)*unit**mesh,mesh) for j in range(mesh)]
data=[];mixed_count=0
for j in range(mesh*(xl.bit_length()+1)):
    tau=F(frac[j%mesh]*(1<<(j//mesh)),unit)
    a=(unit*2*inv*residue_error*tau).__ceil__();b=(unit*error*tau).__ceil__()
    if a>unit:break
    if b<=unit:mixed_count+=1
    data.append(f'{a} {min(b,3*unit)}')
small=('6','8','10') if args.small_start else ()
ys=[y for y in map(F,(*small,'11','11.5','12','12.5','13','13.5','14')) if y<=args.max_y]
if args.checkpoints:
    ys=sorted(set(args.checkpoints))
    assert min(ys)>0
assert ys
lim=[int(eu(y)) for y in ys]
assert lim==[int(trans(y,'exp',False)) for y in ys]
sieve=bytearray([1])*(lim[-1]+1);sieve[0:2]=bytes(2)
for p in range(2,isqrt(lim[-1])+1):
    if sieve[p]:sieve[p*p::p]=bytes((lim[-1]-p*p)//p+1)
primes=[p for p,v in enumerate(sieve) if v]
ids={y:i+1 for i,y in enumerate(ys)}
flags={primes[bisect_right(primes,x)-1]:ids[y] for y,x in zip(ys,lim)}
assert len(flags)==len(ys)
assert not wheel or lim[0]>=wheel[-1]
labels=sorted([(p,0) for p in primes if p not in wheel]+[(p,1) for p in seq],
              key=lambda item:(item[0]*(args.coordinate_order if item[1] else 1),item[1]))
assert args.coordinate_order>=0
last_coordinate=max(i for i,x in enumerate(labels) if x[1])
assert all(i>last_coordinate for i,(p,t) in enumerate(labels) if not t and p in flags)
cfg=[f'{unit} {len(data)} {mixed_count} {len(cols)}',' '.join(map(str,cols)),*data]
cfg.extend(f'{p} {(p**mesh-1).bit_length()} {t} {0 if t else flags.get(p,0)}' for p,t in labels)
print('top and Fourier A caps',[(m,float(dirichlet(m))) for m in ms],
      'edge-pair cap',float(dirichlet(2)/2),flush=True)
command=[str(args.exe.resolve())]
if args.joint_loss:
    # A floor of 1/g gives an upper bound for A-P/g on every physical support.
    command.extend(map(str,((10**8/g).__floor__(),10**8)))
if args.prefix_caps:
    assert not args.joint_loss and args.wheel<=7
    from tempfile import TemporaryDirectory
    from math import floor,ceil
    active=list(wheel);coords=[]
    def four(center,ea,em):
        return [floor(unit*center),ceil(unit*center),ceil(unit*ea),ceil(unit*em)]
    info=[]
    for p,t in labels:
        if p>17:break
        (coords if t else active).append(p)
        h=prod((1-F(1,v) for v in active),start=F(1))
        gc=prod((1-F(1,v) for v in coords),start=F(1))
        e=endpoint(tuple(active))/(wheel_density*residue_error)
        factor=F(2**len(active)*h,2**len(wheel)*wheel_density)
        center=h/wheel_density
        ar=four(center,e,0)
        plain=four(center*gc,e*gc,(2**len(coords)-1)*factor)
        mix=four(center*gc,e*gc,2**len(coords)*factor)
        info.append(' '.join(map(str,(p,t,*ar,*plain,*mix))))
    assert info
    with TemporaryDirectory() as td:
        caps=Path(td)/'prefix.txt';caps.write_text('\n'.join(info)+'\n',encoding='ascii')
        out=subprocess.check_output([*command,str(caps)],input='\n'.join(cfg)+'\n',text=True)
else:
    out=subprocess.check_output(command,input='\n'.join(cfg)+'\n',text=True)
rows={};results=[];separate={};state_lines=[]
if args.state_out:assert not args.joint_loss
for line in out.splitlines():
    if args.joint_loss:
        twice,j,hi=map(int,line.split())
        rows[twice,j]=F(max(0,hi),unit)
    else:
        twice,j,a,b=map(int,line.split())
        rows[twice,j]=max(F(0),F(a,unit)-F(b,unit)/g)
        if args.state_out:separate[twice,j]=wheel_density*F(a,unit),wheel_density*F(b,unit)/g
for y in ys:
    for m,shapes in weights.items():
        # The unrepresented ramps have combined continuous area t L / 2^count.
        reserve=F(1,(m+1)*2**count)*(1-lam+inv)+2*inv
        if args.state_out:
            for index,(u,j) in enumerate(shapes):
                ar,passed=separate[ids[y],j]
                state_lines.append(' '.join(map(str,(lo,hi,args.rank,y,m,index,2*zh*(u*(1-lam+inv)+inv),2*zh*reserve,ar,passed))))
        val=2*zh*(wheel_density*sum((u*(1-lam+inv)+inv)*rows[ids[y],j] for u,j in shapes)+reserve)
        nano=(val*10**12).__ceil__()
        line=f'logY {y} m {m} rank {args.rank} seed <= {nano//10**12}.{nano%10**12:012d}'
        results.append(line);print(line)
if args.check:
    assert args.check.read_text().splitlines()[1:]==results
if args.state_out:args.state_out.write_text('\n'.join(state_lines)+'\n',encoding='ascii')
