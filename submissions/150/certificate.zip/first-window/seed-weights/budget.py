"""Add the new actual starting bounds to the proved physical-mass terminal transfers."""
from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
import sys
from path import paths


here=Path(__file__).resolve().parent
ap=ArgumentParser(description=__doc__)
ap.add_argument('--repo',type=Path,default=here.parent/'prime-sampling')
ap.add_argument('--core',type=Path,default=here.parent/'cofactor-refined')
ap.add_argument('--rank38',type=Path,default=here/'price38-fine.txt')
ap.add_argument('--rank37',type=Path,default=here/'price37-fine.txt')
ap.add_argument('--out',type=Path)
ap.add_argument('--check',type=Path)
args=ap.parse_args()
sys.path.insert(0,str(args.core.resolve()))
import reprice as r
r.setup(args.repo)
starts={rk:min(paths(args.repo,file,rk))[0] for rk,file in ((38,args.rank38),(37,args.rank37))}
opts={rk:r.options(rk) for rk in starts}
physical=dict(starts)
# The previously proved rank-37 independent replacement for the first three
# complete 1/8-bands saves at least 79,887 nanounits against their stock cost.
special=starts[37]-F(79887,10**9)
out={rk:[] for rk in starts}
u=F(26)
for cut in (67,68,69,70):
    endpoint=r.zh*cut/200
    while u<endpoint:
        v=min(endpoint,u+r.SIZE)
        n=((v-u)/r.FINE).__ceil__()
        w=(v-u)/n
        a=(u*4).__floor__()/F(4)
        b=a+F(1,4)+r.SIZE
        d=r.density(a,b,F(1,2),12)[0]
        eps=r.s.eta_for(u,F('.01')/u**2)
        dx=r.s.eu(w)
        har=min(r.s.up((dx-1+(dx+1)*eps)/u),r.s.up((1+eps)*r.s.lu(1+w/u)+2*eps/u))
        W=r.s.up(2*r.zh*har*d)
        rows=r.band.params(r.LO,r.HI,u,v,n)
        new=[(min(w0,W+e),e,di,off) for w0,e,di,off in rows]
        for rk,opt in opts.items():
            old=r.band.price(rows,opt)
            best=min(old,r.band.price(new,opt))
            physical[rk]+=n*best
            if rk==37:special+=n*(old if u<F(211,8) else best)
        u=v
    for rk in starts:
        fee=min(physical[rk],special) if rk==37 else physical[rk]
        out[rk].append((fee*10**9).__ceil__())
        print('rank',rk,'cut',cut,'new budget',out[rk][-1],flush=True)
result=''.join(' '.join(map(str,(r.LO,r.HI,rk,*vals)))+'\n' for rk,vals in out.items())
print(result,end='')
if args.out:args.out.write_text(result,encoding='ascii')
if args.check:assert args.check.read_text()==result
