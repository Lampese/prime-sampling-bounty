"""Exact checks of the physical layer decomposition and the queried integer sieve grid."""
from argparse import ArgumentParser
from cmath import exp
from fractions import Fraction as F
from itertools import combinations
from math import pi,prod
from pathlib import Path
import subprocess


ap=ArgumentParser(description=__doc__)
ap.add_argument('--exe',type=Path,required=True)
args=ap.parse_args()
tests=0
for L in range(6,48):
    for m in (3,7,15):
        h=F(L,m+1)
        for t in range(L):
            x=F(2*t+1,2)
            top=min(1,x/h,(L-x)/h)
            for j in range(6):
                v=h/2**j
                hat=lambda y:max(0,1-abs(y-v/2)/(v/2))
                top+=(hat(x)+hat(L-x))/F(2)
                assert top==min(1,2*x/v,2*(L-x)/v)
                tests+=1
print('exact physical node checks',tests)

# Direct Fourier checks of a nonaligned physical interval and several ordinary
# arithmetic steps. The proof uses exact harmonic moments, not these float checks.
p=4001;L=29;h=F(L,8);a=F(23,2)
roots=[exp(2j*pi*v/p) for v in range(p)]
tests=0
for d in (1,2,3,8):
    for level in (-1,0,1):
        spectrum=[]
        for n in range(1,(a+L).__ceil__()+1):
            x=n-a
            if n%d or not 0<x<L:continue
            if level<0:
                v=min(1,x/h,(L-x)/h)
            else:
                v0=h/2**level
                hat=lambda y:max(0,1-abs(y-v0/2)/(v0/2))
                v=(hat(x)+hat(L-x))/F(2)
            if v:spectrum.append((n,float(v)))
        norm=sum(abs(sum(v*roots[(j*n)%p] for n,v in spectrum)) for j in range(p))/p
        assert norm<=(1.824785613 if level<0 else .6380617145)+1e-10
        tests+=1
print('sampled physical Fourier checks',tests)
N=901;unit=10**9
ar=[2,3,5,7,11,13,17,19,23];vs=(2,3,5)
xs={m:[int(((m*m+5*m+3)%911)%v==0) for v in vs] for m in range(1,N+1)}
subsets=[s for k in range(1,len(vs)+1) for s in combinations(range(len(vs)),k)]
E=F(0)
for d in range(1,N+1):
    for subset in subsets:
        sm=sum(prod(xs[m][i] for i in subset) for m in range(d,N+1,d))
        E=max(E,abs(sm-F(N,d*prod(vs[i] for i in subset))))
data=[];mixed=0
for j in range(N.bit_length()+1):
    a=F(unit*(1<<j),N).__ceil__()
    b=(F(unit*(1<<j),N)*E).__ceil__()
    if a>unit:break
    if b<=unit:mixed+=1
    data.append(f'{a} {min(b,3*unit)}')
cols=(0,1,2)
head=[f'{unit} {len(data)} {mixed} {len(cols)}',' '.join(map(str,cols))]
for p,tag in sorted([(p,0) for p in ar]+[(v,1) for v in vs]):
    data.append(f'{p} {(p-1).bit_length()} {tag} {p if p>=7 and not tag else 0}')
values=subprocess.check_output([str(args.exe.resolve())],input='\n'.join(head+data)+'\n',text=True)
tests=0
for row in values.splitlines():
    p,j,upper,lower=map(int,row.split())
    rem=[m for m in xs if not any(m%q==0 for q in ar if q<=p)]
    assert F(len(rem),N)<=F(upper,unit)
    assert F(sum(prod(1-x for x in xs[m]) for m in rem),N)>=F(lower,unit)
    tests+=1
print('exact finite sieve node checks',tests,'observed error',E)
