#define SEED_GRID_LIBRARY
#include "levels.cpp"
#include <array>
#include <fstream>
#include <map>
#include <tuple>
#include <utility>

using Wide=__int128_t;
struct Bound {N low,high,arithmetic,mixed;};
using Three=std::array<Bound,3>;

N ceil_scale(N a,N b,N unit){
    return (N)std::min<Wide>(2*unit,((Wide)a*b+unit-1)/unit);
}

N error(const Bound& b,N ea,N em,N unit){
    // Clipped noise is precisely the uninformative end of the mixed grid.
    if(b.mixed && em>=3*unit)return 2*unit;
    return std::min(2*unit,ceil_scale(b.arithmetic,ea,unit)+ceil_scale(b.mixed,em,unit));
}

void intersect(Grid& grid,const Bound& b,const std::vector<N>& ea,const std::vector<N>& em,N unit){
    for(size_t j=0;j<grid.x.size();++j){
        N e=error(b,ea[j],em[j],unit);
        auto& x=grid.x[j];
        x.lo=std::max(x.lo,b.low-e);x.hi=std::min(x.hi,b.high+e);
        assert(x.lo<=x.hi);
    }
}

int main(int argc,char** argv){
    assert(argc==2);
    std::ifstream cert(argv[1]);
    std::map<std::pair<int,int>,Three> bounds;
    int prime,type;
    while(cert>>prime>>type){
        Three item;
        for(auto& b:item)cert>>b.low>>b.high>>b.arithmetic>>b.mixed;
        assert(cert);bounds[{prime,type}]=item;
    }
    assert(!bounds.empty());
    int n,m,k; N unit;
    if(!(std::cin>>unit>>n>>m>>k))return 1;
    std::vector<int> cols(k);
    for(int& j:cols){std::cin>>j;assert(j>=0 && j<m);}
    Grid mixed,plain,ar;
    std::vector<N> em(n);
    for(int j=0;j<n;++j){
        N a,b;std::cin>>a>>b;
        plain.eps.push_back(a);plain.x.push_back({unit-a,unit+a});em[j]=b;
        if(j<m){mixed.eps.push_back(b);mixed.x.push_back({unit-b,unit+b});}
    }
    ar=plain;
    std::vector<Three> allowed;
    std::array<std::vector<N>,3> caps;
    int bucket=-1;
    auto refresh=[&](int p){
        int bit=0;while((1LL<<(bit+1))<=p)++bit;
        if(bit==bucket)return;
        bucket=bit;
        N div=1LL<<bit;
        for(auto& row:caps)row.assign(n,2*unit);
        for(const Three& t:allowed)for(int i=0;i<3;++i){
            auto b=t[i]; N center=(b.high+div-1)/div;
            for(int j=0;j<n;++j)caps[i][j]=std::min(caps[i][j],center+error(b,ar.eps[j],em[j],unit));
        }
    };
    auto update=[&](State x,const Grid& y,int j,int p,int shift,N noise,int type){
        if(j+shift<(int)y.x.size())return step(x,y,j,p,shift,noise,unit);
        N upper=std::min((unit+p-1)/p+noise,caps[type][j]);
        x.lo=std::max<N>(0,x.lo-upper);
        return x;
    };
    int p,shift,t,flag;
    while(std::cin>>p>>shift>>t>>flag){
        refresh(p);
        for(int j=0;j<n;++j){
            if(!t)ar.x[j]=update(ar.x[j],ar,j,p,shift,ar.eps[j],0);
            plain.x[j]=update(plain.x[j],t?mixed:plain,j,p,shift,t?em[j]:plain.eps[j],t?2:1);
        }
        for(int j=0;j<m;++j)mixed.x[j]=update(mixed.x[j],mixed,j,p,shift,mixed.eps[j],2);
        auto it=bounds.find({p,t});
        if(it!=bounds.end()){
            const auto& row=it->second;
            intersect(ar,row[0],ar.eps,em,unit);intersect(plain,row[1],ar.eps,em,unit);
            intersect(mixed,row[2],ar.eps,em,unit);
            allowed.push_back(row);bucket=-1;
        }
        if(flag)for(int j:cols)std::cout<<flag<<' '<<j<<' '<<ar.x[j].hi<<' '<<plain.x[j].lo<<'\n';
    }
}
