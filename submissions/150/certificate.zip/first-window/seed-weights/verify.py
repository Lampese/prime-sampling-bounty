"""Compile the finite sieve, verify physical supports, reproduce both branch budgets."""
from argparse import ArgumentParser
from pathlib import Path
from tempfile import TemporaryDirectory
import os
import subprocess
import sys

here=Path(__file__).resolve().parent
ap=ArgumentParser(description=__doc__)
ap.add_argument('--repo',type=Path,default=here.parent/'prime-sampling')
ap.add_argument('--core',type=Path,default=here.parent/'cofactor-refined')
ap.add_argument('--cxx',default=os.environ.get('CXX','c++'))
args=ap.parse_args()
if not __debug__:ap.error('Keep Python assertions enabled.')
repo=args.repo.resolve();core=args.core.resolve()


def run(script,*argv):
    subprocess.run([sys.executable,'-B',str(here/script),*map(str,argv)],check=True)


with TemporaryDirectory() as temp:
    suffix='.exe' if os.name=='nt' else ''
    exe=Path(temp)/('seed'+suffix)
    subprocess.run([args.cxx,'-O3','-std=c++17',str(here/'levels.cpp'),'-o',str(exe)],check=True)
    run('check.py','--exe',exe)
    for rk in (37,38):
        run('price.py','--rank',rk,'--mesh',192,'--top',7,'--max-y','12.5',
            '--exe',exe,'--repo',repo,'--check',here/f'price{rk}-fine.txt')
        supplement=here.parent/f'seed-bridge/extra-seeds{rk}.txt'
        if supplement.is_file():
            rows=[line.split() for line in supplement.read_text().splitlines() if line.startswith('logY ')]
            assert rows and all(row[3]=='7' and int(row[5])==rk for row in rows)
            run('price.py','--rank',rk,'--mesh',192,'--top',7,'--checkpoints',*[row[1] for row in rows],
                '--exe',exe,'--repo',repo,'--check',supplement)
        for wheel_file in (here.parent/'seed-bridge').glob(f'wheel-seeds*-r{rk}.txt'):
            k=int(wheel_file.stem.split('-')[1][5:])
            rows=[row.split() for row in wheel_file.read_text().splitlines() if row.startswith('logY ')]
            assert rows and all(row[3]=='7' and int(row[5])==rk for row in rows)
            run('price.py','--rank',rk,'--wheel',k,'--mesh',192,'--top',7,'--checkpoints',
                *[row[1] for row in rows],'--exe',exe,'--repo',repo,'--check',wheel_file)
    pref=list((here.parent/'seed-bridge').glob('prefix-seeds*-r*.txt'))
    if pref:
        fused=Path(temp)/('prefix'+suffix)
        subprocess.run([args.cxx,'-O3','-std=c++17',str(here/'prefix_levels.cpp'),'-o',str(fused)],check=True)
        for table in sorted(pref):
            wheel=int(table.stem.split('-')[1][5:]);rk=int(table.stem.split('-')[-1][1:])
            rr=[row.split() for row in table.read_text().splitlines() if row.startswith('logY ')]
            assert rr and all(int(row[5])==rk and row[3]=='7' for row in rr)
            run('price.py','--rank',rk,'--prefix-caps','--wheel',wheel,'--mesh',192,'--top',7,
                '--checkpoints',*[row[1] for row in rr],'--exe',fused,'--repo',repo,'--check',table)
    run('budget.py','--repo',repo,'--core',core,'--check',here/'150.dat')
print('Verified both branch budgets and all four cutoffs.')
