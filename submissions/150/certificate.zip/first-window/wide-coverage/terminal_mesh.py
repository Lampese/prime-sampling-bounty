"""Price subband counts locally in the terminal cofactor estimate."""
from argparse import ArgumentParser
from fractions import Fraction as F
from functools import cache
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
WORK=HERE.parent


def model(repo,left,right,rank):
    sys.path[:0]=[str(repo),str(WORK/'cofactor-refined')]
    import reprice as core
    core.setup(repo)
    s,band=core.s,core.band
    zl=s.dn(left-s.lu(left+1));zh=s.up(right-s.ld(right-F('1.1')))
    opts=core.options(rank)
    @cache
    def density(a,b):
        L,H=zl-b,zh-a
        jmax=(H/a).__floor__()
        if jmax<1 or jmax>4:return None
        maxpre=(jmax-1)*(H/jmax+F(1,2))
        if L+core.ldown(s.LAM)-maxpre<20:return None
        return core.density_core(a,L,H,F(1,2),12)[0]
    def price(u,v,n):
        rows=band.params(left,right,u,v,n)
        a=(u*4).__floor__()/F(4)
        # Share the quarter's cofactor envelope whenever it contains the full physical interval.
        b=max(a+F(1,4),v)
        assert a<=u<v<=b and n>=1
        dens=density(a,b)
        if dens is not None:
            w=(v-u)/n
            eps=s.eta_for(u,F('.01')/u**2);U=s.eu(w)
            har=min(s.up((U-1+(U+1)*eps)/u),s.up((1+eps)*s.lu(1+w/u)+2*eps/u))
            W=s.up(2*zh*har*dens)
            rows=[(min(w0,W+e),e,di,off) for w0,e,di,off in rows]
        return n*band.price(rows,opts)
    return zh,price


def terminal_prices(repo,left,right,rank):
    zh,price=model(repo,left,right,rank)
    size=F(1,80);u=F(26);total=F(0);result=[]
    for cut in (67,68,69,70):
        stop=zh*cut/200
        while u<stop:
            v=min(stop,u+size)
            desired=next(n for end,n in [(27,8),(29,14),(31,23),(35,38),(41,50),(45,72),(48,100),(100,240)] if u<end)
            n=max(1,((v-u)*80*desired).__ceil__())
            usual=max(1,((v-u)*1800).__ceil__())
            total+=min(price(u,v,k) for k in {n,usual})
            u=v
        result.append((total*10**12).__ceil__())
        print('terminal cutoff',cut,'units of 1e-12',result[-1],flush=True)
    return result


def main():
    ap=ArgumentParser(description=__doc__)
    ap.add_argument('--repo',required=True,type=Path)
    ap.add_argument('--window',required=True,nargs=2,type=F)
    ap.add_argument('--rank',required=True,type=int)
    ap.add_argument('--samples',nargs='+',type=F)
    ap.add_argument('--out',type=Path,help='write all four absolute terminal costs, in units of 1e-12')
    ap.add_argument('--check',type=Path)
    ap.add_argument('--size',type=F,default=F(1,80))
    ap.add_argument('--counts',nargs='+',type=int,default=[1,2,4,8,12,16,23,32,48,72,100,160,240,400,800])
    args=ap.parse_args()
    if not args.samples:
        values=terminal_prices(args.repo.resolve(),*args.window,args.rank)
        line=' '.join(map(str,(*args.window,args.rank,*values)))+'\n'
        if args.out:args.out.write_text(line,encoding='ascii')
        if args.check and args.check.read_text(encoding='ascii')!=line:raise ValueError('Terminal price mismatch')
        print(line,end='')
        return
    zh,price=model(args.repo.resolve(),*args.window,args.rank)
    for u in args.samples:
        v=u+args.size
        baseline=max(1,(args.size*1800).__ceil__())
        rates={n:price(u,v,n) for n in set([baseline,*args.counts])}
        best=min(rates,key=rates.get)
        print('u',u,'orig n',baseline,'opt n',best,'cost per unit old and new',float(rates[baseline]/args.size),
              float(rates[best]/args.size),'ratio',float(rates[best]/rates[baseline]),flush=True)


if __name__=='__main__':main()
