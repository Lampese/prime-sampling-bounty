"""Build native nine-column certificates from shared fibre envelopes and exact geometry."""
from argparse import ArgumentParser
from contextlib import redirect_stdout
from fractions import Fraction as F
from io import StringIO
from pathlib import Path
import json
import os
import sys
from math import isqrt

def main():
    parser=ArgumentParser(description=__doc__)
    work=Path(__file__).resolve().parents[1]
    parser.add_argument('input',type=Path)
    parser.add_argument('out',type=Path)
    parser.add_argument('--repo',type=Path,default=work/'prime-sampling')
    parser.add_argument('--direct',action='store_true',help='retain the upstream completed character bound in both orientations')
    args=parser.parse_args()
    if (work/'zig-cxx.cmd').is_file():
        os.environ.setdefault('CXX',str(work/'zig-cxx.cmd'))
        os.environ.setdefault('ZIG_GLOBAL_CACHE_DIR',str(work/'zig-cache'))
        os.environ.setdefault('ZIG_LOCAL_CACHE_DIR',str(work/'zig-local-cache'))
    sys.path[:0]=[str(args.repo.resolve()),str(work/'harmonic-research'),str(work/'spectral-coupling')]
    from prime_sampling.rectangles import generate,boxes
    from prime_sampling.accounting import ledger
    from prime_mass import prime_mass
    from coset_split import close_six
    data=json.loads(args.input.read_text())
    assert not data.get('hypothetical')
    left,right=F(data['left']),F(data['right'])
    grid=data['grid']
    def neutral(mode,model):
        from prime_sampling.spectrum.squarerates import root
        def estimate(a,b,v,s,k,span,pm,p):
            radius=(span+1)//2+1
            sqrtp=isqrt(p)+1
            c=min((pm-1)//2,max(2*radius,isqrt(2*sqrtp*radius*s)))
            val=min(F(1),root(F(c,c-radius)*(F(c,s)+2*sqrtp)/k)) if c>radius and 2*c<pm else F(1)
            return val,val
        model.rates=estimate if args.direct else lambda *inputs:(F(1),F(1))
    generate.install_mode=neutral
    with redirect_stdout(StringIO()) as output:
        generate.emit(left,right,'single',grid)
    base=[list(map(int,s.split())) for s in output.getvalue().splitlines()]
    refined={i:(p,s) for i,p,s in data['rows']}
    def one(row,mode):
        result=row.copy()
        if row[0] in refined:
            result[1:5]=map(min,zip(row[1:5],refined[row[0]][mode]))
        return result
    args.out.mkdir(parents=True,exist_ok=True)
    pair=[one(row,0) for row in base]
    six=[close_six(p,one(row,1)) for p,row in zip(pair,base,strict=True)]
    files=[]
    for kind,table in [('pair',pair),('six',six)]:
        dest=args.out/(kind+'.dat')
        dest.write_text(''.join(' '.join(map(str,row))+'\n' for row in table),encoding='ascii')
        ledger.check_rows(dest,grid)
        files.append(('extra',kind,left,right,grid,dest))
    lower=F(prime_mass(left,right)[0],10**12)
    cell={'left':str(left),'right':str(right),'main_lower':str(lower),'tables':[
        {'kind':kind,'grid':grid,'file':dest.name} for _,kind,l,r,g,dest in files]}
    cell['direct']=args.direct
    (args.out/'cell.json').write_text(json.dumps(cell,indent=2),encoding='ascii')
    for branch,res in ledger.probe(left,right,files,new_lower=lower).items():
        ledger.report(left,right,branch,res)
    if os.name=='nt':
        import _ctypes
        from prime_sampling.spectrum import squarerates as sr
        _ctypes.FreeLibrary(sr._lib._handle)
if __name__=='__main__':main()
