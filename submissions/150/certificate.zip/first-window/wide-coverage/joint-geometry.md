# Coupling the true mass of the inner and outer rectangles

Write \(D\) for a true prime strip and \(I\subset D\subset O\) for its fixed inner and outer rectangles. Denote their normalized masses by \(i,w,o\) in increasing order, and put \(x=w-i,\ y=o-w\). The standard geometry gives \(w\le m,\ x\le h,\ y\le e,\ i\ge m_0\).

Near the diagonal, the upper bound on the true mass includes the second prime's lower cutoff \(\max(1/32,X^{2u-1})\), evaluated at the small-prime strip's left endpoint \(u\). The second term rises to one at \(u=1/2\). Integrating the upper bound on disjoint short intervals captures this change while the Fourier inequality retains every prime in the parent rectangle. This accounts for most of the last macro's mass saving in the accompanying numerical ablation.

Obtain \(i\le I^+,\ o\le O^+\) directly. Partition the horizontal exponent interval into slices \((l,r]\). Chebyshev's theta error bounds the count of primes in the slice, divided by \(X^u\), by
\[
 X_{\rm hi}^{l-u}\frac{(1+\epsilon)X_{\rm hi}^{r-l}-(1-\epsilon)}{lZ_-}.
\]
For each vertical slice \((c,d]\) in the fixed scaled rectangle, the count divided by \(X^{1-u}\) is at most
\[
 \frac{(1+\epsilon)d-(1-\epsilon)c}{(1-u)Z_-+\log_-(c)}.
\]
Sum the slices separately on the two axes, multiply the sums by \(2Z_+\), then round up. All denominators are positive. The program checks the range of the original theta error at the smaller of the horizontal log bound \(uZ_-\) and the vertical log bound \((1-u)Z_-+\log_-(c_{\min})\), with \(c_{\min}\) the smaller of the two actual enclosing rectangle cutoffs.

Let \(S\) be the upward approximation to reciprocal density and \(f_i,f_o\) the two certified lower excluded fractions. Write \(B=S-1,\ a=S(1-f_i)-1,\ b=S(1-f_o)-1\). The sieve majorant has mean at least the true density, and the implementation checks these coefficients are nonnegative for all actual inputs. The usual inner and outer survivor estimates give two bounds for the true normalized charge,
\[
 T\le ai+Bx\le a I^++Bh,\qquad
 T\le bo+y\le b O^++e .
\]
The latter follows because every survivor in the true strip belongs to the outer rectangle.

For the same true mass,
\[
 0\le w\le W=\min(m,I^++h,O^+),\qquad
 x\le\min(h,w-m_0),\quad y\le\min(e,O^+-w).
\]
Hence the charge is at most each of the four affine functions of \(w\)
\[
 Bw-(B-a)m_0,\quad aw+(B-a)h,\quad bw+(b+1)e,\quad (1+b)O^+-w.
\]
Given one of the first three lines \(cw+d\), its minimum with the last line is at most each of \(cW+d\) and \((c(1+b)O^++d)/(1+c)\), using \(c\ge0\). Take the minimum of all these bounds, both direct rectangle charges and the existing native fee. Use exact rational arithmetic, round up once, and add compatible strip charges by dynamic programming.

The experiment in joint_geometry.py (arguments --macro 99 --panels 32) uses five grids on the first bounty window. Its JSON gives costs in units of \(10^{-12}\) and includes a refit of the individual geometry columns with the same Fourier inputs. Macro 99 denotes \(0.495<u\le0.500\).
