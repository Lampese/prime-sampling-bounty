"""Supported k=2 transfers, with two independent Selberg projections."""
from argparse import ArgumentParser
from bisect import bisect_right
from fractions import Fraction as F
from functools import cache
from math import prod
from pathlib import Path
import gc,sys

here=Path(__file__).resolve().parent
ap=ArgumentParser(description=__doc__)
ap.add_argument('--repo',type=Path,default=here.parent/'prime-sampling')
ap.add_argument('--population',type=Path,default=here.parent/'transfer-weights')
ap.add_argument('--tree',type=Path,default=here.parent/'scalar-tail')
ap.add_argument('--rank',type=int,choices=range(37,44),default=38)
ap.add_argument('--window',type=F,nargs=2,help='price the provided ordinary rank uniformly on this whole window')
ap.add_argument('--fixed',type=Path)
ap.add_argument('--out',type=Path)
ap.add_argument('--check',type=Path)
ap.add_argument('--late',action='store_true')
ap.add_argument('--early',action='store_true')
args=ap.parse_args();sys.path.insert(0,str(args.population.resolve()));import selberg as z
lo,hi=args.window or (F(150),F(4801,32));z.setup(args.repo,lo,hi);s=z.s
sys.path.insert(0,str(args.tree.resolve()));from brun import make
from prime_sampling.accounting.ledger import rank
r=args.rank
if args.window:seq=s.c.ps[:r]
else:
    assert r in (37,38)
    seq=rank(hi,'with3' if r==38 else 'without3')
g=prod(1-F(1,p) for p in seq)
px=(lo+1)*s.eu(-lo/2);edges,ps=z.boundaries();sc=10**35
euler=prod(1+F(2,p*(p-1)) for p in s.c.ps)*s.eu(F(2,250))
assert s.c.ps[-1]<=250


@cache
def prime_data(u,v):
    c,H=s.geometry(u,v)
    if v<=16:
        i,j=[bisect_right(ps,edges[int(t*z.GRID)]) for t in (u,v)]
        H=min(H,F(sum((sc+q-1)//q for q in ps[i:j]),sc))
        c=min(c,(j-i)*s.eu(-u))
        H2=F(sum((sc+q*q-1)//(q*q) for q in ps[i:j]),sc)
    else:H2=H*s.eu(-u)
    return c,H,H2


@cache
def poly(bit):
    data=make(seq,bit,with_second=True)
    gc.collect()
    return data


@cache
def weights(u,k):
    if k<u:return s.weight(k)[1:]
    rows=z.basis(F(65))[u];idx=k*z.GRID;assert idx.denominator==1
    G=F(sum(rows[:int(idx)+1]),z.SCALE);D=s.eu(k).__ceil__()
    return G,min(F(D),D*euler/G)


@cache
def geometry(u,v):
    c,H,h2=prime_data(u,v);ratio=px*s.eu(u);inv=s.eu(u-z.zl);invQ=s.eu(-u)
    width=1-s.LAM*s.trans(u-v,'exp',False)
    W=2*z.zh*z.coverage(u,v)[0]*H
    rows=z.basis(F(65))[u]
    B=min(width/F(sum(rows[:k*z.GRID+1]),z.SCALE)+s.eu(k).__ceil__()**2*inv for k in range(45,64))
    t=u;hmass=F(0)
    while t<v:
        n=min(v,t+F(1,2));hmass+=prime_data(t,n)[2];t=n
    sq=z.zh*(1/g-1)*(1+invQ)*min(h2,hmass)
    # Uniform supported Fourier cap for any interval and arithmetic progression
    # inside the common n range. N<=Y+1 and 32N<p/4 hold on the entire slab.
    assert (s.eu(-u)/(lo-F('1.1'))+s.eu(-lo))*128<1
    A=6+F('.415')*(z.zh-u+1)
    return c,H,ratio,inv,invQ,width,W,B,sq,A


def cost(u,v,bit,lin,lout,k):
    c,H,ratio,inv,invQ,width,W,B,sq,A=geometry(u,v)
    m,N,sec=poly(bit);N-=1;V=sec-m*m
    assert 0<m<=1 and V>=0 and m>=g and 0<=k<=F(1,2)
    d=N*N+2*N*(1-m);off=12*N*N+16*N*(1-m)
    G,S=weights(u,lin);G2,S2=weights(u,lout)
    E=V*(1-s.LAM)*H*invQ/G+V*c*invQ*S*S*inv
    E+=(8*d*c*invQ+off*c*c)*ratio*A*S*S
    K=width/G2+S2*S2*inv;pen=8*N*ratio*A*c*S*S2
    main=(m/g-1)*W
    corr=2*z.zh/g*(k*pen+s.root(E*((1-2*k)*B+k*k*K)))
    return main+corr+sq,main,corr,sq


def find(u,v,bits):
    levels=(F(0),F(2),F(4),F(6),F(8))
    outer=(F(10),u-F('.001'),F(14),F(16),F(18),F(20),F(22))
    best=None
    for bit in bits:
        for lin in levels:
            for lout in outer:
                for k in (F(1,2),F(1,3)):
                    val=cost(u,v,bit,lin,lout,k)[0]
                    key=val,(u,v,bit,lin,lout,k)
                    if best is None or key<best:best=key
    return best[1]


def ceiling(v):return (v*10**12).__ceil__()


def produce(par):
    u,v,*_=par;price,main,corr,sq=cost(*par)
    print('rank',r,*par,'total main correlations squares (1e-12):',*[ceiling(x) for x in (price,main,corr,sq)],flush=True)
    return ' '.join(map(str,(r,*par,ceiling(price))))


if args.fixed:
    pars=[[F(x) for x in line.split()[1:-1]] for line in args.fixed.read_text().splitlines() if int(line.split()[0])==r]
    for row in pars:row[2]=int(row[2])
else:
    jobs=[(F('12.5'),F(14),(30,32,34)),(F(14),F(16),(30,32,34)),(F(16),F('17.5'),(28,30,32)),
          (F(16),F(18),(28,30,32)),(F(12),F(14),(30,32,34)),(F(13),F(14),(30,32,34))]
    if args.late:jobs=[(F(26),F('26.125'),(24,26,28))]
    if args.early:jobs=[(F(y),F(t),(32,)) for y,t in [('11','12.5'),('11.5','12.5'),('12','12.5'),
                        ('11','12'),('11.5','13'),('12','13'),('12.5','13.5'),('13.5','14')]]
    pars=(find(u,v,bits) for u,v,bits in jobs)
result='\n'.join(produce(row) for row in pars)+'\n'
if args.out:args.out.write_text(result,encoding='ascii')
if args.check:assert args.check.read_text()==result
