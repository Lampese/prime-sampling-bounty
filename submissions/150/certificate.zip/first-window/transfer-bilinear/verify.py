"""Recompute all four direct-edge tables and the combined rank-37/38 budget."""
from argparse import ArgumentParser
from pathlib import Path
import subprocess,sys
from tempfile import TemporaryDirectory
from check import check

here=Path(__file__).resolve().parent
ap=ArgumentParser(description=__doc__)
ap.add_argument('--repo',type=Path,required=True)
ap.add_argument('--population',type=Path,default=here.parent/'transfer-weights')
ap.add_argument('--tree',type=Path,default=here.parent/'scalar-tail')
ap.add_argument('--seeds',type=Path,default=here.parent/'seed-weights')
args=ap.parse_args();check();repo=args.repo.resolve();population=args.population.resolve()
allrows=[]
with TemporaryDirectory() as tempdir:
    for r in (37,38):
        sources=[here/f'{r}.dat',here/f'{r}-early.dat'];allrows.extend(sources)
        full=Path(tempdir)/f'{r}.dat';full.write_text(''.join(p.read_text() for p in sources),encoding='ascii')
        subprocess.run([sys.executable,'-B',str(here/'price.py'),'--repo',str(repo),'--population',str(population),
                        '--tree',str(args.tree.resolve()),'--rank',str(r),'--fixed',str(full),'--check',str(full)],check=True)
subprocess.run([sys.executable,'-B',str(population/'early.py'),'--repo',str(repo),'--seeds',str(args.seeds.resolve()),
                '--direct-edges',*map(str,allrows),'--check',str(here/'150.dat')],check=True)
