"""Finite exact sanity checks for the two-projection identity and square fee."""
from fractions import Fraction as F

def check():
    X=6875;left=688;qs=(5,7,11);B={};values={};original=F(0);base=F(0);extra=F(0);squarecap=F(0)
    def value(m):return F((m*m+7*m)%19,18)-F(1,3)
    def omega(n,q):
        e=0
        while n%q==0:n//=q;e+=1
        return e
    for m in range(left+1,X+1):
        if m%2 and m%3 and any(m%q==0 for q in qs):original+=value(m)
    for q in qs:
        for n in range(left//q+1,X//q+1):
            b=F(int(n%2!=0 and n%3!=0),1+sum(omega(n,t) for t in qs))
            B[n]=b;values[n]=values.get(n,0)+value(q*n)
            base+=b*value(q*n);extra+=omega(n,q)*b*value(q*n)
            assert omega(n,q)*b<=F(int(n%q==0)+int(n%(q*q)==0),2)
    assert original==base+extra
    l1=lambda n:1-F(2,3)*int(n%2==0)-F(1,3)*int(n%3==0)
    l2=lambda n:1-F(1,5)*int(n%2==0)-F(3,5)*int(n%3==0)+F(1,7)*int(n%6==0)
    for k in (F(0),F(1,3),F(1,2)):
        w=sum((b-k*l2(n))*l1(n)*values[n] for n,b in B.items())
        projection=k*sum(l2(n)*l1(n)*values[n] for n in B)
        assert w+projection==base
        assert sum((b-k*l2(n))**2 for n,b in B.items())<=sum((1-2*k)*b+k*k*l2(n)**2 for n,b in B.items())
    print('Checked exact factor ownership, square residual, two projections and their quadratic bound on 6187 integers.')

if __name__=='__main__':check()
