"""Tagged mixed sieve with separate raw error budgets for pure arithmetic and coordinate intersections."""
from argparse import ArgumentParser
from bisect import bisect_right
from fractions import Fraction as F
from math import prod,isqrt
from pathlib import Path
import subprocess,sys

ap=ArgumentParser(description=__doc__)
ap.add_argument('--repo',type=Path,required=True); ap.add_argument('--exe',type=Path,required=True)
ap.add_argument('--mesh',type=int,default=48); ap.add_argument('--without3',action='store_true')
ap.add_argument('--sharp',action='store_true',help='use the Fourier-series norm and sieved collar')
args=ap.parse_args();sys.path.insert(0,str(args.repo.resolve()))
from prime_sampling.budget.certificate import eu,ld,lu,trans
from prime_sampling.accounting.ledger import rank

lo,hi=F(150),F(4801,32); lam=F(1,32); rho=F(1,20000) if args.sharp else F(1,10**6)
xl=(trans(lo,'exp',False)/(lo-1)).__floor__(); xh=(eu(hi)/(hi-F('1.1'))).__ceil__()
nin=(1-lam-rho)*xl-2;zh=lu(xh)
af=3+lu(2*(1/rho+3))
if args.sharp:
    pi_lo=F('3.14'); terms=32
    # On relevant subprogressions a<=p/100 and b>=1000.
    # The two short frequency end pieces cost at most 1+1.021.
    L=lu(F(1003,1000)*(1/rho+3))+F(21,1000)
    H=sum(F(1,k*(4*k*k-1)) for k in range(1,terms+1))
    af=F(2031,1000)+2/pi_lo*((2/pi_lo+2/(pi_lo*(2*terms+1)))*L+4/pi_lo*H)
    # If the progression is so sparse that b/D<1000, use its length instead.
    assert 1001*(1/rho+2)<8*trans(lo/2,'exp',False)
    assert 1/(lo-F('1.1'))+1/trans(lo,'exp',False)<F(1,100)
    assert rho*xl>10**6
error=8*eu(hi/2)*af+1
seq=rank(hi,'without3' if args.without3 else 'with3');g=prod(1-F(1,q) for q in seq)
cuts=(F(10),F(11),F(12),F(25,2),F(13),F(27,2),F(14))
limits=[eu(y).__floor__() for y in cuts]
assert limits==[trans(y,'exp',False).__floor__() for y in cuts]
limit=limits[-1];sieve=bytearray(b'\1')*(limit+1);sieve[:2]=b'\0\0'
for p in range(2,isqrt(limit)+1):
    if sieve[p]:sieve[p*p::p]=b'\0'*((limit-p*p)//p+1)
primes=[p for p,y in enumerate(sieve) if y]
collar=rho
if args.sharp:
    assert primes[119]<limits[0]
    collar=rho*prod(1-F(1,p) for p in primes[:120])+F(2**121,xl)
flags={primes[bisect_right(primes,l)-1]:int(2*y) for y,l in zip(cuts,limits)}
unit=10**15;mesh=args.mesh
def iroot(n,k):
    l,h=0,1<<((n.bit_length()+k-1)//k)
    while h-l>1:
        m=(l+h)//2
        if m**k>=n:h=m
        else:l=m
    return h
frac=[iroot((1<<j)*unit**mesh,mesh) for j in range(mesh)]
data=[];m=0
for j in range(mesh*xh.bit_length()+1):
    tau=F(frac[j%mesh]*(1<<(j//mesh)),unit)
    a=(unit*tau/nin).__ceil__();b=(unit*error*tau/nin).__ceil__()
    if a>unit:break
    if b<=unit:m+=1
    data.append(f'{a} {min(b,3*unit)}')
rows=sorted([(p,0) for p in primes]+[(q,1) for q in seq])
tagged=[f'{p} {(p**mesh-1).bit_length()} {t} {flags.get(p,0) if not t else 0}' for p,t in rows]
out=subprocess.check_output([str(args.exe.resolve())],input='\n'.join([f'{unit} {len(data)} {m}',*data,*tagged])+'\n',text=True)
for line in out.splitlines():
    twice,p,a,b=map(int,line.split())
    signed=F(a,unit)-F(b,unit)/g
    bound=2*zh*(collar+(1-lam+1/F(xl))*max(F(0),signed));n=(bound*10**12).__ceil__()
    print('logY',F(twice,2),'last prime',p,'rank',len(seq),'ar cap',a,'weighted floor',b,'R_seed <=',f'{n//10**12}.{n%10**12:012d}')
