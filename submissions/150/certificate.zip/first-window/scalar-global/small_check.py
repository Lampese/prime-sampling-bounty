"""Compare the tagged recurrence with directly enumerated finite arithmetic and coordinate sieves."""
from argparse import ArgumentParser
from fractions import Fraction as F
from itertools import combinations
from math import prod
from pathlib import Path
import subprocess


ap=ArgumentParser(description=__doc__);ap.add_argument('--exe',type=Path,required=True)
args=ap.parse_args();N=901;mesh=1;unit=10**9
ar=[2,3,5,7,11,13,17,19,23]
vs=(2,3,5)
xs={m:[int(((m*m+5*m+3)%911)%v==0) for v in vs] for m in range(1,N+1)}
subsets=[s for k in range(1,len(vs)+1) for s in combinations(range(len(vs)),k)]
E=F(0)
for D in range(1,N+1):
    for s in subsets:
        exact=sum(prod(xs[m][i] for i in s) for m in range(D,N+1,D))
        E=max(E,abs(exact-F(N,D*prod(vs[i] for i in s))))
data=[];mixed=0
for j in range(N.bit_length()+1):
    a=F(unit*(1<<j),N).__ceil__(); b=(F(unit*(1<<j),N)*E).__ceil__()
    if a>unit: break
    if b<=unit: mixed+=1
    data.append(f'{a} {min(b,3*unit)}')
for p,tag in sorted([(p,0) for p in ar]+[(v,1) for v in vs]):
    data.append(f'{p} {(p-1).bit_length()} {tag} {int(p>=7 and not tag)}')
text=f'{unit} {N.bit_length()} {mixed}\n'+'\n'.join(data)+'\n'
output=subprocess.check_output([str(args.exe.resolve())],input=text,text=True)
tests=0
for row in output.splitlines():
    _,p,ah,bl=map(int,row.split());rest=[m for m in xs if not any(m%q==0 for q in ar if q<=p)]
    ar_mass=F(len(rest),N); mix=F(sum(prod(1-x for x in xs[m]) for m in rest),N)
    assert ar_mass<=F(ah,unit) and mix>=F(bl,unit)
    tests+=1
print('small exact tagged checks:',tests,'raw intersection error',E)
