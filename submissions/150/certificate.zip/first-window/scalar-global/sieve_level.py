"""Finite rough populations and an ideal linear-sieve level check at log p=150."""
from argparse import ArgumentParser
from fractions import Fraction as F
from math import prod
from pathlib import Path
import sys


p=ArgumentParser(description=__doc__)
p.add_argument('--repo',type=Path,required=True)
args=p.parse_args()
sys.path.insert(0,str(args.repo.resolve()))
from prime_sampling.budget.certificate import eu,ld,lu,trans,ps
from prime_sampling.accounting.ledger import allowance

lo,hi=F(150),F(4801,32)
d,lam,eta=F(67,200),F(1,32),F('0.00000002149')
zl,zh=lo-lu(lo+1),hi-ld(hi-F('1.1'))
cap=F('0.23743665')


def semiprime_mass(upper):
    grid=[d*(zl if upper else zh)]
    end=(zh if upper else zl)/2
    while grid[-1]<end:
        grid.append(min(end,grid[-1]+F(1,4)))
    total=F(0)
    for a,b in zip(grid,grid[1:]):
        if upper:
            h=(1+eta)*lu(b/a)+2*eta/a
            frac=max(lam,trans(2*a-zh,'exp',False))
            total+=2*zh*h*(1+eta-(1-eta)*frac)/max(a,zl-lu(32)-b)
        else:
            h=max(F(0),(1-eta)*ld(b/a)-2*eta/a)
            frac=max(lam,eu(2*b-zl))
            total+=2*zl*h*max(F(0),1-eta-(1+eta)*frac)/(zh-a)
    return total


A=F(allowance(hi),10**12)
upper_prime=2*zh*(1+eta-lam*(1-eta))/(zl-lu(32))
low_mass=A+semiprime_mass(False)
high_mass=upper_prime+semiprime_mass(True)
assert 3*d>1
print('arithmetic rough count/M: lower >=', float(low_mass),'upper <=',float(high_mass))
print('normalized pass on rough population needed at least',float(1-cap/low_mass))
print('lower bound b/g summed over rough /M needed at least',float(low_mass-cap))


def linear_mass_main(s,upper=False):
    if s<=2:
        return F(0)
    assert s<=4
    return 4*(1-lam)*(lu(s-1) if upper else ld(s-1))/(d*s)


theory_full=linear_mass_main(1/d,True)
print('ideal linear lower main term at D=X:',float(theory_full),
      'uncovered mass versus target',float(low_mass-cap-theory_full))
left,right=F(2),F(4)
for _ in range(60):
    mid=(left+right)/2
    if linear_mass_main(mid,True)<low_mass-cap:
        left=mid
    else:
        right=mid
print('ideal s=log D/log z needed >',float(left),'D>=X exponent',float(d*left))
g=prod(1-F(1,q) for q in ps[:38])
# A best-case arithmetic budget benchmark C*D/M <= cap, with log p=150.
Z=lo-ld(lo-F('1.1'))
for name,C in [('unit monomial',8*(2+lo)),('exact normalized pass',8*(2+lo)*(2**38-1)/g),('ideal constant one',F(1))]:
    logD=Z-lo/2+lu(cap/(2*Z*C))
    print(name,'log D benchmark',float(logD),'s benchmark',float(logD/(d*Z)))
