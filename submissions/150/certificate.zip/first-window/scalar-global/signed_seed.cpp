#include <algorithm>
#include <cassert>
#include <cstdint>
#include <iostream>
#include <vector>

using Integer = std::int64_t;

Integer floor_div(Integer a, Integer b) {
    return a >= 0 ? a / b : -((-a + b - 1) / b);
}

Integer ceil_div(Integer a, Integer b) { return -floor_div(-a, b); }

struct Bounds { Integer lo, hi; };
struct Cell { Bounds arithmetic, weighted, loss; };

Bounds subtract(Bounds current, Bounds child, Integer prime) {
    return {current.lo - ceil_div(child.hi, prime), current.hi - floor_div(child.lo, prime)};
}

int main() {
    int n, queries;
    if (!(std::cin >> n >> queries)) return 1;
    std::vector<Cell> cells(n);
    for (Cell &s : cells) {
        std::cin >> s.arithmetic.lo >> s.arithmetic.hi >> s.weighted.lo >> s.weighted.hi
                 >> s.loss.lo >> s.loss.hi;
    }
    int prime, step, flag;
    while (std::cin >> prime >> step >> flag) {
        // Ascending j leaves the required larger columns at the previous stage.
        for (int j=0; j<n; ++j) {
            const Cell child=cells[std::min(n-1,j+step)], old=cells[j];
            auto a=subtract(old.arithmetic,child.arithmetic,prime);
            auto b=subtract(old.weighted,child.weighted,prime);
            auto h=subtract(old.loss,child.loss,prime);
            a.lo=std::max<Integer>(0,a.lo);
            b.lo=std::max<Integer>(0,b.lo);
            h.lo=std::max(h.lo,a.lo-b.hi);
            h.hi=std::min(h.hi,a.hi-b.lo);
            b.lo=std::max(b.lo,a.lo-h.hi);
            b.hi=std::min(b.hi,a.hi-h.lo);
            a.lo=std::max(a.lo,b.lo+h.lo);
            a.hi=std::min(a.hi,b.hi+h.hi);
            assert(a.lo<=a.hi && b.lo<=b.hi && h.lo<=h.hi);
            cells[j]={a,b,h};
        }
        if (flag) {
            const auto x=cells.front();
            std::cout << flag << ' ' << prime << ' ' << x.arithmetic.lo << ' ' << x.arithmetic.hi
                      << ' ' << x.weighted.lo << ' ' << x.weighted.hi << ' ' << x.loss.lo << ' ' << x.loss.hi << '\n';
            --queries;
        }
    }
    return queries!=0;
}
