"""Diagnostic stock-transfer path price from the newly certified strict seeds."""
from argparse import ArgumentParser
from fractions import Fraction as F
from math import prod
from pathlib import Path
import sys


ap=ArgumentParser(description=__doc__)
ap.add_argument('--repo',type=Path,required=True)
ap.add_argument('--seed-result',type=Path,required=True)
args=ap.parse_args();sys.path.insert(0,str(args.repo.resolve()))
from prime_sampling.budget import menu,tight,widerough,certificate

rows={}
for line in args.seed_result.read_text().splitlines():
    w=line.split(); rows[F(w[1])]=F(w[-1]); rank=int(w[6])
if str(rank) not in tight.patterns:
    tight.patterns[str(rank)]=[(h,n,t) for h in range(min(rank,16)+1)
                              for n in range(h,rank+1) for t in (0,2,4) if t<=n-h]
f=widerough.bound(F(150),F(4801,32),rank,F(13),0,F(1,1000),[],options_for_rank=menu.group)
nodes=[F(i,2) for i in range(24,53)]
edges={(u,a):f(u,a,u,False) for j,a in enumerate(nodes) for u in nodes[max(0,j-7):j]}
g=prod(1-F(1,p) for p in certificate.ps[:rank]); z=widerough.up(F(4801,32)-widerough.ld(F(4801,32)-F('1.1')))
for reserve in (False,True):
    best={};prev={}
    for j,a in enumerate(nodes):
        extra=2*z*(1/g-1)/(widerough.trans(a,'exp',False)-1) if reserve else F(0)
        cand=[(rows[a]+extra,a)] if a in rows else []
        cand+=[(best[u]+edges[u,a],u) for u in nodes[max(0,j-7):j]]
        best[a],prev[a]=min(cand)
    u=F(26); path=[u]
    while prev[u]!=u:
        u=prev[u]; path.append(u)
    print('cost to 26; stock reserve',reserve,float(best[F(26)]),'path',*reversed(path))
