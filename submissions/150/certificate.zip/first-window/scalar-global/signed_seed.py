"""Directed integer recursion for an explicit signed seed using only the section-4 axioms."""
from argparse import ArgumentParser
from bisect import bisect_right
from fractions import Fraction as F
from math import prod,isqrt
from pathlib import Path
import subprocess
import sys


p=ArgumentParser(description=__doc__)
p.add_argument('--repo',type=Path,required=True)
p.add_argument('--exe',type=Path,required=True)
p.add_argument('--mesh',type=int,default=16)
p.add_argument('--maxlog',type=int,default=13)
p.add_argument('--without3',action='store_true')
args=p.parse_args()
sys.path.insert(0,str(args.repo.resolve()))
from prime_sampling.budget.certificate import eu,ld,lu,trans
from prime_sampling.accounting.ledger import rank


def ceil_div(a,b):
    return -((-a)//b)


def nth_root_up(a,n):
    lo,hi=0,1<<ceil_div(a.bit_length(),n)
    while hi-lo>1:
        m=(lo+hi)//2
        if m**n>=a:
            hi=m
        else:
            lo=m
    return hi


lo,hi=F(150),F(4801,32)
xl=(trans(lo,'exp',False)/(lo-1)).__floor__(); xh=(eu(hi)/(hi-F('1.1'))).__ceil__()
zl,zh=ld(xl),lu(xh)
rho=F(1,10**6); lam=F(1,32); nin=(1-lam-rho)*xl-2
af=3+lu(2*(1/rho+3)); error=8*eu(hi/2)*af+1
seq=rank(hi,'without3' if args.without3 else 'with3')
g=prod(1-F(1,q) for q in seq)
mesh=args.mesh; unit=10**14
frac=[nth_root_up((1<<i)*unit**mesh,mesh) for i in range(mesh)]
arith_n=mesh*xh.bit_length()+1
full_n=mesh*(xh*prod(seq)).bit_length()+1
powers=[F(frac[j%mesh]*(1<<(j//mesh)),unit) for j in range(full_n)]
ratio=error/nin
lows=[max(0,unit-(unit*ratio*j).__ceil__()) for j in powers]
highs=[unit+(unit*ratio*j).__ceil__() for j in powers]
# For selected coordinate raw moments normalized by the product of all their v_i.
for q in seq:
    step=(q**mesh-1).bit_length()
    for j in range(full_n):
        k=min(full_n-1,j+step)
        lows[j],highs[j]=max(0,lows[j]-ceil_div(highs[k],q)),highs[j]-lows[k]//q

lines=[]
Eexact=(2**len(seq)-1)*(error-1)/g
for j in range(arith_n):
    D=min(powers[j],F(xh))
    # At D>X all real sums vanish. The saturation cell includes this case.
    noise=(D*unit/nin).__ceil__()
    alo=max(0,unit-noise); ahi=unit+noise
    blo=(min(ahi,lows[j])/g).__floor__(); bhi=(min(ahi,highs[j])/g).__ceil__()
    hnoise=(unit*D*Eexact/nin).__ceil__()
    hlo=max(alo-bhi,-hnoise); hhi=min(ahi-blo,hnoise)
    lines.append(' '.join(map(str,(alo,ahi,blo,bhi,hlo,hhi))))

cuts=list(range(6,args.maxlog+1))
limits=[eu(F(c)).__floor__() for c in cuts]
assert all(trans(F(c),'exp',False).__floor__()==limit for c,limit in zip(cuts,limits))
limit=limits[-1]; sieve=bytearray(b'\1')*(limit+1)
sieve[:2]=b'\0\0'
for i in range(2,isqrt(limit)+1):
    if sieve[i]:
        sieve[i*i::i]=b'\0'*((limit-i*i)//i+1)
primes=[i for i,v in enumerate(sieve) if v]
flags={primes[bisect_right(primes,x)-1]:c for c,x in zip(cuts,limits)}
lines+=[f'{q} {(q**mesh-1).bit_length()} {flags.get(q,0)}' for q in primes]
data=f'{arith_n} {len(cuts)}\n'+'\n'.join(lines)+'\n'
output=subprocess.check_output([str(args.exe.resolve())],input=data,text=True)
for line in output.splitlines():
    cut,last,al,ah,bl,bh,hl,hh=map(int,line.split())
    bound=2*zh*(rho+((1-lam)+1/F(xl))*F(hh,unit))
    n=(bound*10**12).__ceil__()
    print('logY',cut,'last prime',last,'rank',len(seq),'ar cap',ah,'weighted floor',bl,'signed cap',hh,
          'R_seed <=',f'{n//10**12}.{n%10**12:012d}')
