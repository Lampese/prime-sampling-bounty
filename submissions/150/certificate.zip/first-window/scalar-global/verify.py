"""Rebuild the tagged without3 certificate from its finite arithmetic input and the upstream package."""
from argparse import ArgumentParser
import os
from pathlib import Path
import subprocess,sys
from tempfile import TemporaryDirectory


def main():
    p=ArgumentParser(description=__doc__)
    p.add_argument('--repo',type=Path,required=True)
    p.add_argument('--cxx',default=os.environ.get('CXX','c++'))
    args=p.parse_args();here=Path(__file__).resolve().parent;repo=args.repo.resolve()
    if not __debug__: p.error('Enable assertions.')
    def py(name,*rest):
        return subprocess.check_output([sys.executable,'-B',str(here/name),*map(str,rest)],text=True)
    with TemporaryDirectory() as tmp:
        tmp=Path(tmp);exe=tmp/('mixed.exe' if os.name=='nt' else 'mixed')
        subprocess.run([args.cxx,'-O3','-std=c++17',str(here/'mixed_seed.cpp'),'-o',str(exe)],check=True)
        print(py('small_check.py','--exe',exe),end='',flush=True)
        result=py('mixed_seed.py','--repo',repo,'--exe',exe,'--without3','--sharp')
        assert result.splitlines()==(here/'sharp-without3.txt').read_text().splitlines()
        seed=tmp/'seed.txt';seed.write_text(result,encoding='ascii')
        complete=py('branch_budget.py','--repo',repo,'--seed-result',seed)
        assert complete.split()==(here/'150-without3.dat').read_text().split()
        print(complete,end='',flush=True)
    print(py('sieve_level.py','--repo',repo),end='')


if __name__=='__main__':
    main()
