#include <algorithm>
#include <cassert>
#include <cstdint>
#include <iostream>
#include <vector>
using N=std::int64_t;
struct State {N lo,hi;};
struct Grid {std::vector<State> x; std::vector<N> eps;};
State next(State x, const Grid &y, int j, int p, int step, N noise, N unit) {
    if (j+step < static_cast<int>(y.x.size())) {
        const auto v=y.x[j+step];
        x.lo=std::max<N>(0,x.lo-(v.hi+p-1)/p); x.hi-=v.lo/p;
    } else {
        // The sifted child lies between zero and the unsifted intersection.
        x.lo=std::max<N>(0,x.lo-(unit+p-1)/p-noise);
    }
    assert(0<=x.lo && x.lo<=x.hi && x.hi<=2*unit);
    return x;
}
int main() {
    int n,m; N unit;
    if(!(std::cin>>unit>>n>>m)) return 1;
    Grid mixed,plain,ar;
    std::vector<N> mixed_noise(n);
    for(int j=0;j<n;++j) {
        N a,b;std::cin>>a>>b;
        plain.eps.push_back(a);plain.x.push_back({unit-a,unit+a});
        mixed_noise[j]=b;
        if(j<m) {mixed.eps.push_back(b);mixed.x.push_back({unit-b,unit+b});}
    }
    ar=plain;
    int p,step,coordinate,flag;
    while(std::cin>>p>>step>>coordinate>>flag){
        for(int j=0;j<n;++j){
            if(!coordinate) ar.x[j]=next(ar.x[j],ar,j,p,step,ar.eps[j],unit);
            plain.x[j]=next(plain.x[j],coordinate?mixed:plain,j,p,step,
                            coordinate?mixed_noise[j]:plain.eps[j],unit);
        }
        for(int j=0;j<m;++j)
            mixed.x[j]=next(mixed.x[j],mixed,j,p,step,mixed.eps[j],unit);
        if(flag) std::cout<<flag<<' '<<p<<' '<<ar.x[0].hi<<' '<<plain.x[0].lo<<'\n';
    }
}
