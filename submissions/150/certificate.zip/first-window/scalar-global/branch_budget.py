"""Using the independently proved without3 seed, retain all original stock charges."""
from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
import sys


ap=ArgumentParser(description=__doc__)
ap.add_argument('--repo',type=Path,required=True)
ap.add_argument('--seed-result',type=Path,required=True)
args=ap.parse_args();sys.path.insert(0,str(args.repo.resolve()))
from prime_sampling.budget import band,menu,tight,widerough as s

lo,hi,rank=F(150),F(4801,32),37
rows=[line.split() for line in args.seed_result.read_text().splitlines()]
row=next(w for w in rows if F(w[1])==F(25,2) and int(w[6])==rank)
seed=F(row[-1]);assert seed==F('0.064164746964')
if str(rank) not in tight.patterns:
    tight.patterns[str(rank)]=[(h,n,t) for h in range(min(rank,16)+1) for n in range(h,rank+1) for t in (0,2,4) if t<=n-h]
density,options,_=menu.group(rank)
prices=[r[:3] for r in options];choices=prices,[tuple(map(float,r)) for r in prices]
z=s.up(hi-s.ld(hi-F('1.1')))
fine,size=F(1,1800),F(1,80)
transfer=s.bound(lo,hi,rank,F(13),0,fine,[],options_for_rank=menu.group)
path=list(map(F,('12.5','14','16','17.5','18.5','20','21','21.5','22','22.5','23','23.5','24','24.5','25','25.5','26')))
total=seed+2*z*(1/density-1)/(s.trans(path[0],'exp',False)-1)
for u,v in zip(path,path[1:]):
    assert v-u<=F(7,2)
    total+=transfer(u,v,u,False)
u=F(26);out=[]
for cut in (67,68,69,70):
    end=z*cut/200
    while u<end:
        v=min(u+size,end);count=((v-u)/fine).__ceil__()
        total+=count*band.price(band.params(lo,hi,u,v,count),choices)
        u=v
    out.append((total*10**9).__ceil__())
print(lo,hi,rank,*out)
