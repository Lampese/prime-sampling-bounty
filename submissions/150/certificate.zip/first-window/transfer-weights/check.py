"""Small exact checks for the restricted weights and the population ownership."""
from fractions import Fraction as F
from itertools import combinations
from math import gcd,lcm,prod

def check():
    ps=[2,3,5,7,11,13,17];D=60
    divs={1:(1,1)}
    for p in ps:
        divs.update({d*p:(-mu,ph*(p-1)) for d,(mu,ph) in list(divs.items()) if d*p<=D})
    G=sum(F(1,ph) for _,ph in divs.values());lam={}
    for d,(mu,ph) in divs.items():
        sub=sum(F(1,phm) for m,(_,phm) in divs.items() if m*d<=D and gcd(d,m)==1)
        lam[d]=mu*d*sub/(ph*G)
    assert lam[1]==1 and all(abs(w)<=1 for w in lam.values())
    assert sum(x*y/lcm(d,e) for d,x in lam.items() for e,y in lam.items())==1/G
    for bottom,top in ((359,2061),(128,1024),(39,78)):
        rough=sum(all(n%p for p in ps) for n in range(bottom+1,top+1))
        estimate=sum(sum(w for d,w in lam.items() if n%d==0)**2 for n in range(bottom+1,top+1))
        assert rough<=estimate<=(top-bottom)/G+sum(map(abs,lam.values()))**2
    for n in range(1,2000):
        fs=[];x=n
        for p in range(2,x+1):
            while x%p==0:fs.append(p);x//=p
            if x==1:break
        removed=bool(fs and 3<fs[0]<=13)
        owners=[q for q in set(fs) if 3<q<=13 and all(p>=q for p in fs)]
        assert len(owners)==int(removed)
        if removed:
            count=sum(p<=13 for p in fs)
            assert sum(F(1,count) for q in set(fs) if 3<q<=13)<=1
    weights=[F(1,p-1) for p in ps];H=sum(weights);m=max(weights);low=F(1)
    for k in range(1,len(ps)+1):
        low*=max(0,H-(k-1)*m)/k
        assert low<=sum(prod(v) for v in combinations(weights,k))
    print('Checked restricted Selberg minimizer, interval count, block factors, and 1999 least-factor ownerships.')

if __name__=='__main__':check()
