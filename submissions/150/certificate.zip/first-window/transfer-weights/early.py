"""Reprice only the nonnegative W population of the published pre-26 path."""
from argparse import ArgumentParser
from bisect import bisect_right
from fractions import Fraction as F
from pathlib import Path
import sys
import selberg as z

here=Path(__file__).resolve().parent
ap=ArgumentParser(description=__doc__)
ap.add_argument('--repo',type=Path,default=here.parent/'prime-sampling')
ap.add_argument('--seeds',type=Path,default=here.parent/'seed-weights')
ap.add_argument('--out',type=Path)
ap.add_argument('--check',type=Path)
ap.add_argument('--direct-edges',type=Path,nargs='*',default=[])
ap.add_argument('--extra-seeds',type=Path,nargs='*',default=[])
ap.add_argument('--terminal-absolute',type=Path,nargs='*',default=[])
ap.add_argument('--stock-row',type=Path,help='certified stock multi or terminal-only improved row on a general window')
ap.add_argument('--stock-direct',type=Path,nargs='*',default=[],help='independent ordinary-rank edges labeled by their valid covering window')
ap.add_argument('--stock-seed-bounds',type=Path,nargs='*',default=[],help='uniform lower official and upper independently proved physical seed costs')
args=ap.parse_args();lo,hi=F(150),F(4801,32)
if args.stock_row:
    source=[line.split() for line in args.stock_row.read_text().splitlines() if line.strip()]
    assert source and all(len(w)==7 and w[:2]==source[0][:2] for w in source)
    lo,hi=map(F,source[0][:2]);ranks=[int(w[2]) for w in source]
    assert not args.direct_edges and not args.extra_seeds and len(ranks)==len(set(ranks))
else:
    sys.path.insert(0,str(args.seeds.resolve()));from path import paths
    ranks=(38,37)
z.setup(args.repo,lo,hi);s=z.s
from prime_sampling.budget import menu,tight,band
zh,zl=z.zh,z.zl
invx=(lo+1)*s.eu(-lo);px=(lo+1)*s.eu(-lo/2)
edges,ps=z.boundaries(); hp=[0]
for p in ps:hp.append(hp[-1]+(z.SCALE+p-1)//p)


def harmonic(u,v):
    h=s.geometry(u,v)[1]
    if v<=16:
        i,j=[bisect_right(ps,edges[int(t*z.GRID)]) for t in (u,v)]
        h=min(h,F(hp[j]-hp[i],z.SCALE))
    return h


def fee(u,v,opt,official):
    c,H=s.geometry(u,v);cb=F('.6')/u
    assert 2*u<=zl-v and 4*u<zh-u
    original=s.up(2*zh*cb*H)
    # The constant term counts removed integers. Assign each once to its actual
    # least prime, independently of how the Cauchy estimate assigns q labels.
    # Optimize a positive cover with exact mass from every complete half step.
    masses={u:F(0)}
    t=u+F(1,2)
    while t<=v:
        masses[t]=min(value+harmonic(x,t)*z.coverage(x,t)[0] for x,value in masses.items())
        t+=F(1,2)
    W=min(original,s.up(2*zh*masses[v]))
    diag=4*zh**2*cb*H*s.eu(-u)*(1-s.LAM)
    off=4*zh**2*cb*c*c*s.eu(u)*3*(hi+2)*px
    rows=[]
    for logk in range(0,23,2):
        level=min(F(logk),u-F('.001'))
        _,g,sm=s.weight(level)
        di=diag/g+8*zh**2*cb*c*sm**2*invx
        rows.append((original,0,di,off*sm**2))
    old=band.price(rows,opt)
    assert old==official(u,v,u,False)
    return min(old,band.price([(W,e,di,of) for ww,e,di,of in rows],opt)),old


nodes=[F(j,2) for j in range(24,53)]
out=[]
for r in ranks:
    if args.stock_row:
        if str(r) not in tight.patterns:
            tight.patterns[str(r)]=[(h,n,t) for h in range(min(r,16)+1) for n in range(h,r+1) for t in (0,2,4) if t<=n-h]
    else:
        f=args.seeds/f'price{r}-fine.txt'
        old=min(paths(args.repo,f,r))[0]
    group=menu.group(r);g=group[0];raw=[x[:3] for x in group[1]]
    opt=raw,[tuple(map(float,row)) for row in raw]
    official=s.bound(lo,hi,r,F(13),0,F(1,1800),[],options_for_rank=menu.group)
    fees={(u,v):fee(u,v,opt,official) for j,v in enumerate(nodes) for u in nodes[max(0,j-7):j]}
    if args.stock_row:
        for table in args.stock_direct:
            for line in table.read_text().splitlines():
                if not line.strip():continue
                w=line.split();assert len(w)==10
                L,H=map(F,w[:2]);rr=int(w[2]);u,v=map(F,w[3:5]);val=F(int(w[-1]),10**12)
                if rr!=r:continue
                assert L<=lo<hi<=H and val>=0 and 0<u<v<=26
                if u<nodes[0]:continue
                assert (u,v) in fees
                new,old=fees[u,v];fees[u,v]=min(new,val),old
        after={nodes[-1]:(F(0),F(0))}
        for j in reversed(range(len(nodes)-1)):
            u=nodes[j];targets=nodes[j+1:j+8]
            after[u]=tuple(min(fees[u,v][i]+after[v][i] for v in targets) for i in (0,1))
        saving=(10**9*min(after[u][1]-after[u][0] for u in nodes[:5])).__floor__()
        for table in args.stock_seed_bounds:
            spans={}
            for line in table.read_text().splitlines():
                if not line.strip():continue
                w=line.split();assert len(w)==6
                L,H=map(F,w[:2]);rr=int(w[2]);y=F(w[3])
                if rr==r and L<=lo<hi<=H:
                    spans.setdefault((L,H),{})[y]=(F(int(w[4]),10**12),F(int(w[5]),10**12))
            for pair,vals in spans.items():
                assert set(vals)==set(nodes[:5])
                reserve={y:2*zh*(1/g-1)/(s.trans(y,'exp',False)-1) for y in vals}
                old_floor=min(vals[y][0]+reserve[y]+after[y][1] for y in vals)
                new_ceiling=min(vals[y][1]+reserve[y]+after[y][0] for y in vals)
                saving=max(saving,(10**9*(old_floor-new_ceiling)).__floor__())
                print('universal seed comparison old cost >=',float(old_floor),'new cost <=',float(new_ceiling),flush=True)
        assert saving>=0
        print('rank',r,'unconditional for each allowed original seed in order',
              *[(10**9*(after[u][1]-after[u][0])).__floor__() for u in nodes[:5]],'saving',saving,flush=True)
        w=next(w for w in source if int(w[2])==r)
        out.append(' '.join(w[:3]+[str(int(x)-saving) for x in w[3:]]))
        continue
    direct={}
    for table in args.direct_edges:
        for line in table.read_text().splitlines():
            w=line.split();rr,u,v=int(w[0]),F(w[1]),F(w[2]);val=F(int(w[-1]),10**12)
            assert len(w)==8 and 0<u<v<=26 and val>=0
            if rr==r:direct[u,v]=min(direct.get((u,v),val),val)
    starts={}
    for table in [f,*args.extra_seeds]:
        for line in table.read_text().splitlines():
            w=line.split()
            if w and w[0]=='logY' and int(w[5])==r and F(w[1])<=14:
                y=F(w[1]);seed=F(w[-1]);starts[y]=min(starts.get(y,10),seed)
    before={y:(seed,[y]) for y,seed in starts.items()}
    for u,v in sorted(direct,key=lambda edge:edge[::-1]):
        if v<=14 and u in before:
            price,pth=before[u]
            before[v]=min(before.get(v,(F(10),[])),(price+direct[u,v],pth+[v]))
    costs={y:(seed+2*zh*(1/g-1)/(s.trans(y,'exp',False)-1),[y])
           for y,(seed,_) in before.items() if y in nodes[:5]}
    for (u,v),val in direct.items():
        if (u,v) in fees:fees[u,v]=min(fees[u,v][0],val),fees[u,v][1]
    for j,v in enumerate(nodes):
        candidates=[(costs[u][0]+fees[u,v][0],costs[u][1]+[v]) for u in nodes[max(0,j-7):j] if u in costs]
        if v in costs:candidates.append(costs[v])
        if candidates:costs[v]=min(candidates)
    new,path=costs[F(26)];saving=((old-new)*10**9).__floor__();assert saving>=0
    if args.direct_edges:print('rank',r,'pure physical route to first permitted official start',*before[path[0]][1],'reserve at',path[0],flush=True)
    print('rank',r,'old',float(old),'new',float(new),'saving nanounits',saving,'path',*path,flush=True)
    for u,v in zip(path,path[1:]):
        new_edge,old_edge=fees[u,v]
        print(' ',u,v,'old',float(old_edge),'new',float(new_edge),'saving',float(old_edge-new_edge),flush=True)
    prev=[line.split() for line in (args.seeds/'150.dat').read_text().splitlines() if int(line.split()[2])==r]
    assert len(prev)==1 and prev[0][:3]==list(map(str,(lo,hi,r)))
    vals=[int(x)-saving for x in prev[0][3:]]
    for table in args.terminal_absolute:
        for line in table.read_text().splitlines():
            w=line.split();assert len(w)==7
            if int(w[2])!=r:continue
            assert tuple(map(F,w[:2]))==(lo,hi) and all(int(x)>=0 for x in w[3:])
            direct_total=[((new+F(int(x),10**12))*10**9).__ceil__() for x in w[3:]]
            vals=list(map(min,vals,direct_total))
    out.append(' '.join(prev[0][:3]+list(map(str,vals))))
result='\n'.join(out)+'\n';print(result,end='')
if args.out:args.out.write_text(result,encoding='ascii')
if args.check:assert args.check.read_text()==result
