"""Lower bounds for finite restricted Selberg denominators by positive log blocks."""
from bisect import bisect_right
from fractions import Fraction as F
from functools import cache
from math import isqrt
from pathlib import Path
import sys

SCALE=10**15
GRID=8


def setup(repo,lo=F(150),hi=F(4801,32)):
    global s,zl,zh
    sys.path.insert(0,str(repo.resolve()))
    from prime_sampling.budget import widerough as s
    assert 150<=lo<hi<=175
    zl=s.dn(lo-s.lu(lo+1));zh=s.up(hi-s.ld(hi-F('1.1')))
    coverage.cache_clear()


@cache
def boundaries():
    edges=[]
    for j in range(16*GRID+1):
        a=F(j,GRID)
        v=s.eu(a).__floor__()
        assert v==s.trans(a,'exp',False).__floor__()
        edges.append(v)
    n=edges[-1]; sieve=bytearray([1])*(n+1);sieve[:2]=bytes(2)
    for p in range(2,isqrt(n)+1):
        if sieve[p]:sieve[p*p::p]=bytes((n-p*p)//p+1)
    return edges,[p for p in range(n+1) if sieve[p]]


def down(x):return (x*SCALE).__floor__()


@cache
def basis(maxlog,prime_limit=26,skip=()):
    bound=maxlog*GRID;assert bound.denominator==1
    limit=int(bound); row=[0]*(limit+1);row[0]=SCALE
    caps={};edges,ps=boundaries();start=0
    for j in range(1,prime_limit*GRID+1):
        a,b=F(j-1,GRID),F(j,GRID)
        if b<=16:
            end=bisect_right(ps,edges[j],lo=start); members=ps[start:end];start=end
            if b<=5:
                for p in members:
                    if p in skip:continue
                    for l in range(limit,j-1,-1):row[l]+=row[l-j]//(p-1)
                continue
            if not members:continue
            mass=sum(SCALE//(p-1) for p in members);maximum=F(1,members[0]-1)
        else:
            # Partial summation from the published Dusart pi-bounds.
            h=1/(b-1)-1/(a-F('1.1'))+s.ld((b-1)/(a-1))
            if a>=20:
                eta=s.eta_for(a,F(1));h=max(h,(1-eta)*s.ld(b/a)-2*eta/a)
            mass=down(max(F(0),h));maximum=1/(s.trans(a,'exp',False)-1)
        # Ordered distinct choices: after r factors at most r*maximum is lost.
        coeff=[SCALE];maxcap=(SCALE*maximum).__ceil__()
        for r in range(limit//j):
            x=coeff[-1]*max(0,mass-r*maxcap)//((r+1)*SCALE)
            if not x:break
            coeff.append(x)
        for l in range(limit,j-1,-1):
            row[l]+=sum(c*row[l-i*j] for i,c in enumerate(coeff[1:min(len(coeff),l//j+1)],1))//SCALE
        if j%2==0 and j>=10*GRID:caps[b]=tuple(row)
    return caps


@cache
def coverage(u,v,prime_limit=26,min_level=45):
    # A single divisor table supplies all Selberg levels for a given u.
    rows=basis(F(65),prime_limit)[u]
    best=None
    for k in range(min_level,64):
        d=s.eu(k).__ceil__()
        G=F(sum(rows[:k*GRID+1]),SCALE)
        # All rounded bins in the prefix guarantee divisor <=exp(k)<=d.
        val=(1-s.LAM)/G+d*d*s.eu(v-zl)
        if best is None or val<best[0]:best=(val,k,G)
    return best


if __name__=='__main__':
    from argparse import ArgumentParser
    ap=ArgumentParser(description=__doc__)
    ap.add_argument('--repo',type=Path,default=Path(__file__).resolve().parents[1]/'prime-sampling')
    args=ap.parse_args();setup(args.repo)
    for u,v in ((F('12.5'),14),(F(14),16),(F(16),F('17.5')),(F('17.5'),F('18.5')),(F(20),21),(F(23),F('23.5')),(F('25.5'),26)):
        val,k,G=coverage(u,v)
        print('edge',u,v,'rough density',float(val),'level',k,'Selberg G lower',float(G),'previous',float(F('.6')/u),flush=True)
