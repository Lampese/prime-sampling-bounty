"""Verify the early transfers against an unchanged checkout and preceding seed certificate."""
from argparse import ArgumentParser
from pathlib import Path
import subprocess,sys
from check import check

here=Path(__file__).resolve().parent
ap=ArgumentParser(description=__doc__)
ap.add_argument('--repo',type=Path,required=True)
ap.add_argument('--seeds',type=Path,default=here.parent/'seed-weights')
args=ap.parse_args();check()
subprocess.run([sys.executable,'-B',str(here/'early.py'),'--repo',str(args.repo.resolve()),
                '--seeds',str(args.seeds.resolve()),'--check',str(here/'150.dat')],check=True)
