# Refining the four native mass columns while retaining the Fourier estimates

At fixed \(p,X\), write \(Z=\log X,\ M=X/(2Z)\). The small-prime strip is \(u<\log a/Z\le v\). Keep the same inner and outer rectangles and the four spectral estimates of the input row, at the same grid, window, and endpoints.

The upstream function boxes.mass gives an upper bound for the true normalized strip mass on any allowed small-prime exponent interval. Apply it to each of the disjoint half-open pieces of the \(n\)-way equal subdivision of \((u,v]\). Summing the rational upper bounds before the final upward rounding gives another upper bound \(m'\) on the same strip mass. The original boxes.collar and boxes.outer computations bound the uncovered inner collar and the excess of the outer rectangle by enclosing the section on each successive subinterval. Using their public steps parameter with \(n=32\) gives independent upper bounds \(h'\) and \(e'\) on the same quantities; their bounding rectangles are those of the parent strip throughout. The calculation works with the original row even if its earlier certificate used an independently sharper estimate of one or more of these columns.

For the inner lower mass, denote the dimensionless endpoints provided by boxes.inner by \(c,e\). When \(c\ge e\) use zero. Otherwise the actual inner rectangle is
\[
  (X^u,X^v]\ \times\ (cX^{1-u},eX^{1-u}].
\]
For any \(0<L<H\le1\), the upstream function abel.lower_count applied at \((L,H,\epsilon,z)\) lower-bounds the prime count in \((LY,HY]\) divided by \(Y\), with \(z\ge\log Y>0\) and with the uniform theta error on the relevant interval. All calls used for the refinement have \(H=1\). They implement partial summation and the first two terms in \(1/(z+\log h)\); a negative result may be replaced by zero. Endpoint comparisons below use the unchanged upstream Xlo, Xhi and outward natural logarithm. The code checks the theta range at the smallest relevant coordinates.

For a horizontal slice \(l<\log a/Z\le r\), choose \(Y=X^r\) and \(L=X_{\rm hi}^{l-r}\ge X^{l-r}\). The interval \((LY,Y]\) is contained in the desired slice. The resulting normalized lower bound times \(X_{\rm lo}^{r-u}\) is a lower bound on that slice's count divided by \(X^u\). If \(L\ge1\), zero remains a valid value. For a vertical slice \(s<t\) in the fixed interval \((c,e]\), choose \(Y=tX^{1-u},L=s/t\), and \(z=(1-u)Z_++\log_+(t)\). Multiplying the lower estimate by \(t\) converts it into a lower bound for the slice's count divided by \(X^{1-u}\). The two axes are partitioned separately. Summing each set of nonnegative lower bounds, multiplying the sums and then multiplying by \(2Z_-\) gives a new lower bound \(m_0'\) normalized by \(M\). Both the one-piece and four-piece evaluations are legitimate. Use their maximum and round down once.

On each row replace
\[
  m\gets\min(m,m'),\quad h\gets\min(h,h',m),\quad
  e\gets\min(e,e'),\quad m_0\gets\max(m_0,m_0').
\]
Uncovered mass is bounded by the actual strip mass, justifying the additional minimum for \(h\). This is a simultaneous certificate because all four inequalities hold at every permitted \(p,X\), regardless of where their individual extrema occur. The nonnegative slopes established in Section 3 of the project apply exactly as before. The transformation leaves all four original rate columns and the strip index intact, which is checked by the replay. The result is directly usable by upstream ledger.check_rows, ledger.probe and grade.

## Reproduction

The utility needs Python and the pinned upstream checkout. It does not need a C++ compiler because it computes no character bounds. It uses a constant valid bound of one for any spectral computation incidental to the public geometry functions. The returned spectral values are discarded. Use a fresh Python interpreter per window to keep the upstream window-specific caches separate.

For a lower window where either axis could fall below the supported log threshold 40, the affected rows retain all their original bounds. This gives a valid transformation even on such tables, provided that their supplied bounds already hold. For rate tables certified at a wider window but used within a smaller window, the whole-strip mass bound can always be transferred when its hypotheses hold. Transferring the other three geometry columns further requires the same inner and outer rectangles as the rates being used.

    python -B mass-geometry/refine.py --repo PATH --cell INPUT/cell.json --out OUTPUT
    python -B mass-geometry/refine.py --repo PATH --left 150 --right 4801/32 --grid 4800 --tables PAIR.dat SIX.dat --out OUTPUT

For a cell manifest the program preserves the table descriptors and copies referenced budgets. Defaults are --steps 32 and --core-steps 4. For numerical grade comparison, grade_cell.py applies the unmodified upstream grader twice, adding the same supplied budget rows in both runs and attaching the unchanged archived continuation at the exact right endpoint. Its JSON records the exit status, output, and margin difference in units of \(10^{-12}\).
