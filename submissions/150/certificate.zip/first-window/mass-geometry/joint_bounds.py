"""Mass limits of the same inscribed, true and circumscribed prime strip."""
from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
import json


def rectangle_limits(z,grid,i,parts):
    u,v=F(i,grid),F(i+1,grid)
    eps=z.thetaerr(min(u*z.zl,(1-v)*z.zl-z.ALOG))
    step=(v-u)/parts
    growth=(1+eps)*z.Xhi(step)-(1-eps)
    horizontal=sum(z.Xhi(j*step)*growth/((u+j*step)*z.zl) for j in range(parts))
    def vertical(lo,hi):
        if lo>=hi:return 0
        w=(hi-lo)/parts
        total=F(0)
        for j in range(parts):
            c=lo+j*w
            total+=((1+eps)*w+2*eps*c)/((1-u)*z.zl+z.b(c,'ln',False))
        return (2*z.zh*horizontal*total*10**12).__ceil__()
    return vertical(*z.inner(u,v)),vertical(max(z.LAM*z.Xlo(u-v),z.Xlo(2*u-1)),F(1))


def upper_fee(I,J,scale,fi,fo,geometry,limits):
    m,h,e,m0=geometry
    inner,outer=limits
    # a,b,beta in units 1/(I*J). Integer comparisons avoid rounding a slope.
    U=I*J
    a=scale*(I-fi)-U
    b=scale*(I-fo)-U
    beta=scale*I-U
    assert min(a,b,beta)>=0
    W=min(m,inner+h,outer)
    down=(U+b)*outer
    def ceil(num,den):return -(-num//den)
    best=min(ceil(a*inner+beta*h,U),ceil(b*outer+U*e,U))
    for slope,intercept in ((beta,-(beta-a)*m0),(a,(beta-a)*h),(b,(U+b)*e)):
        best=min(best,ceil(slope*W+intercept,U),ceil(slope*down+U*intercept,U*(U+slope)))
    return best


def main():
    p=ArgumentParser(description=__doc__)
    p.add_argument('--repo',type=Path,required=True)
    p.add_argument('--grid',type=int,required=True)
    p.add_argument('--panels',type=int,default=16)
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args()
    assert a.grid>=600 and a.grid%200==0 and 1<=a.panels<=256
    from refine import setup
    lo,hi=F(150),F(4801,32)
    boxes,_=setup(a.repo,lo,hi)
    rows=[[i,*rectangle_limits(boxes,a.grid,i,a.panels)] for i in range(a.grid*67//200,a.grid//2)]
    data=dict(left=str(lo),right=str(hi),grid=a.grid,panels=a.panels,rows=rows)
    a.out.write_text(json.dumps(data,separators=(',',':')),encoding='ascii')
    print(a.grid,len(rows),'pairs of directed rectangle mass bounds')


if __name__=='__main__':main()
