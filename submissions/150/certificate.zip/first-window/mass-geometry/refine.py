"""Tighten the four mass columns in a certified nine-column table, preserving all spectral columns."""
from argparse import ArgumentParser
from fractions import Fraction as F
from functools import lru_cache
from pathlib import Path
from types import ModuleType
import json,shutil,sys


def setup(repo,left,right):
    sys.path.insert(0,str(repo.resolve()))
    # The original geometry module imports a spectrum at import time. The
    # computation below only uses geometry, so its irrelevant estimate is 1.
    if 'prime_sampling.spectrum.squarerates' not in sys.modules:
        trivial=ModuleType('prime_sampling.spectrum.squarerates')
        trivial.rates=lambda *args:(F(1),F(1))
        sys.modules[trivial.__name__]=trivial
    from prime_sampling.rectangles import boxes
    from prime_sampling.accounting import ledger
    for fn in (boxes.Xlo,boxes.Xhi,boxes.params,boxes.joint):
        if hasattr(fn,'cache_clear'):fn.cache_clear()
    boxes.initialize(left,right)
    return boxes,ledger


def core_lower(boxes,u,v,cl,et,parts):
    if cl>=et:return F(0)
    eps=max(boxes.thetaerr(u*boxes.zl),boxes.thetaerr((1-u)*boxes.zl+boxes.b(cl,'ln',False)))
    first=second=F(0)
    for j in range(parts):
        l=u+(v-u)*j/parts;r=u+(v-u)*(j+1)/parts
        fraction=boxes.Xhi(l-r)
        if fraction<1:
            first+=boxes.Xlo(r-u)*max(0,boxes.abel.lower_count(fraction,F(1),eps,r*boxes.zh,boxes))
        low=cl+(et-cl)*j/parts;high=cl+(et-cl)*(j+1)/parts
        logupper=(1-u)*boxes.zh+boxes.b(high,'ln',True)
        second+=high*max(0,boxes.abel.lower_count(low/high,F(1),eps,logupper,boxes))
    return 2*boxes.zl*first*second


def factory(boxes,ledger,steps,core_steps):
    @lru_cache(None)
    def geometry(grid,i):
        u=F(i,grid);v=F(i+1,grid)
        if min(u*boxes.zl,(1-v)*boxes.zl-boxes.ALOG)<40:return None
        inner=boxes.inner(u,v)
        whole=sum(boxes.mass(u+(v-u)*j/steps,u+(v-u)*(j+1)/steps) for j in range(steps))
        collar=boxes.collar(u,v,*inner,steps=steps)
        outside=boxes.outer(u,v,steps=steps)[2]
        lower=max(core_lower(boxes,u,v,*inner,n) for n in sorted({1,core_steps}))
        return (*((v*ledger.J).__ceil__() for v in (whole,collar,outside)),(lower*ledger.J).__floor__())
    return geometry


def refit(src,dst,grid,geom,ledger):
    txt=src.read_text(encoding='utf-8-sig').splitlines()
    out=[]
    if txt and txt[0]==ledger.TABLE_HEADER:out.append(txt.pop(0))
    if src.resolve()==dst.resolve():raise ValueError('Select a separate output directory')
    changed=[0]*4
    for j,s in enumerate(txt,67*grid//200):
        r=list(map(int,s.split()))
        if len(r)!=9 or r[0]!=j:raise ValueError('Invalid native row')
        bounds=geom(grid,j)
        before=r[5:]
        if bounds is None:
            out.append(' '.join(map(str,r)))
            continue
        m=min(r[5],bounds[0]);h=min(r[6],bounds[1],m);e=min(r[7],bounds[2]);m0=max(r[8],bounds[3])
        if not 0<=m0<=m:raise ValueError(f'Conflicting mass bounds in row {j}')
        r[5:]=[m,h,e,m0]
        changed=[c+(a!=b) for c,a,b in zip(changed,before,r[5:])]
        out.append(' '.join(map(str,r)))
    if len(txt)!=33*grid//200:raise ValueError('The table must cover every native macro')
    dst.parent.mkdir(parents=True,exist_ok=True)
    dst.write_text('\n'.join(out)+'\n',encoding='ascii')
    ledger.check_rows(dst,grid)
    print(src.name,grid,'rows',len(txt),'changed m,h,e,m0',*changed,flush=True)


def main():
    cli=ArgumentParser(description=__doc__)
    cli.add_argument('--repo',required=True,type=Path)
    cli.add_argument('--cell',type=Path)
    cli.add_argument('--left',type=F);cli.add_argument('--right',type=F)
    cli.add_argument('--grid',type=int)
    cli.add_argument('--tables',nargs='+',type=Path)
    cli.add_argument('--out',type=Path,required=True)
    cli.add_argument('--steps',type=int,default=32)
    cli.add_argument('--core-steps',type=int,default=4)
    a=cli.parse_args()
    if not __debug__:raise RuntimeError('Run without -O')
    if not 1<=a.steps<=256 or not 1<=a.core_steps<=32:raise ValueError('Invalid partition counts')
    if a.cell:
        if any(v is not None for v in (a.left,a.right,a.tables,a.grid)):cli.error('Use the cell or explicit table inputs')
        record=json.loads(a.cell.read_text());left,right=F(record['left']),F(record['right'])
        tasks=[]
        for index,item in enumerate(record['tables']):
            name=Path(item['file']);src=a.cell.parent/name
            if name.is_absolute() or '..' in name.parts:name=Path(f'table-{index}')/name.name
            item['file']=name.as_posix()
            tasks.append((src,a.out/name,int(item['grid'])))
    else:
        if None in (a.left,a.right,a.grid,a.tables):cli.error('Set --cell or --left, --right, --grid and --tables')
        left,right=a.left,a.right
        tasks=[(p,a.out/p.name,a.grid) for p in a.tables]
    if not F(40)<=left<right<=175:raise ValueError('Invalid window')
    boxes,ledger=setup(a.repo,left,right)
    geom=factory(boxes,ledger,a.steps,a.core_steps)
    for src,dst,grid in tasks:
        if grid<600 or grid%200:raise ValueError('Invalid native grid')
        if not dst.resolve().is_relative_to(a.out.resolve()):raise ValueError('Output path is outside --out')
        refit(src,dst,grid,geom,ledger)
    if a.cell:
        budgets=[]
        for index,item in enumerate(record.get('budgets',[])):
            name=Path(item);src=a.cell.parent/name
            if name.is_absolute() or '..' in name.parts:name=Path(f'budget-{index}')/name.name
            dst=a.out/name
            if not dst.resolve().is_relative_to(a.out.resolve()):raise ValueError('Budget path outside --out')
            dst.parent.mkdir(parents=True,exist_ok=True)
            if src.resolve()!=dst.resolve():shutil.copyfile(src,dst)
            budgets.append(name.as_posix())
        if budgets:record['budgets']=budgets
        (a.out/'cell.json').write_text(json.dumps(record,indent=2)+'\n',encoding='ascii')


if __name__=='__main__':main()
