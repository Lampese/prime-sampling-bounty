"""Uniform exclusions for bad Dirichlet vectors, shared lambda=2t/a'."""
from fractions import Fraction as F
from math import isqrt


def bound(a,b,V,s,pm,p,h,axis_fraction):
    D=max(1,isqrt(V*pm//(2*b*h)))
    if D>=pm:return None
    U=(p+D-1)//D
    Y=b*U
    f=0;power=1
    while power<=Y//a:
        power*=a;f+=1
    du=dq=axis_fraction
    qs=(dq*D).__floor__()+1
    ways=1+((V+b*du)/D).__floor__()
    return F(2*f*qs*ways,s)


def projected(a,b,V,s,pm,p,R,cells,K=1024):
    # q=X*Q and |u|=Y*p/Q. The same physical p appears in Q and p/Q.
    Qlo=isqrt(pm*V//(4*b*R))
    Qhi=isqrt(p*V//(4*b*R))+1
    Uhi=isqrt(4*p*b*R//V)+1
    assert Qlo>0 and Qhi*2<pm and Uhi*2<pm
    total=0
    for _,lo,hi in cells:
        # One x slab of width 1/K. Both signed representatives of u contribute.
        Y=b*((hi*Uhi+K-1)//K)
        f=0;power=1
        while power<=Y//a:
            power*=a;f+=1
        qs=1+Qhi//K
        ways=1+(b*(hi-lo)+V*lo)//(K*Qlo)
        total+=2*f*qs*ways
    return F(total,s)
