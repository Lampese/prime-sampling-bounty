from argparse import ArgumentParser
from collections import Counter
from fractions import Fraction as F
from itertools import product
from math import isqrt
from pathlib import Path
import sys

ap=ArgumentParser()
ap.add_argument('--repo',type=Path,default=Path(__file__).resolve().parents[1]/'prime-sampling')
args=ap.parse_args();sys.path.insert(0,str(args.repo.resolve()))
from reflection import plus_cap,near_plus,refine,weighted_plus,line_family

case=0;ncase=0
for p in (47,101,149,211):
    for L,R in ((3,17),(9,28),(19,40)):
        U=[q for q in range(L,R+1,2) if q>=3 and all(q%d for d in range(2,isqrt(q)+1))]
        assert len(U)>=2
        S=len(U);v=R-L
        sums=Counter((pow(a,-1,p)+pow(b,-1,p))%p for a,b in product(U,repeat=2))
        assert max(sums.values())<=plus_cap(L,R,v,p)
        for H in (2,3,5):
            N=near_plus(L,R,v,H,p,p)
            for t in range(1,p):
                inv=[(t*pow(a,-1,p))%p for a in U]
                for z in range(p):
                    near=sum(min((x-z)%p,(z-x)%p)<=H for x in inv)
                    assert near<=N
                    ncase+=1
            for t,O in product((1,2,7,11),(-3,0,4)):
                for weights in ([F(1,H)]*H,[F(2*(i+1),H*(H+1)) for i in range(H)]):
                    pts=Counter();marginal=Counter()
                    for i,w in enumerate(weights):
                        for a in U:
                            x=(O+2*i+t*pow(a,-1,p))%p
                            marginal[x]+=w
                        for a,b in product(U,repeat=2):
                            if a!=b:
                                x=(O+2*i+t*pow(a,-1,p))%p
                                y=(O+2*i+t*pow(b,-1,p))%p
                                pts[(x,y,(a*a-b*b)%3)]+=w/S**2
                    reflect={(x,y,k):((-x)%p,(-y)%p,k) for x,y,k in pts}
                    self=sum(q*q for q in pts.values())
                    cross=sum(w*pts[reflect[idx]] for idx,w in pts.items())
                    peak=sum(w*w for w in weights)
                    assert sum(v*marginal[-x%p] for x,v in marginal.items())<=sum(v*v for v in marginal.values())
                    new=refine(self,L,R,v,S,H,p,p,peak)
                    assert (self+cross)/2<=new
                    case+=1
print('Exact label-sensitive cross and averaged collision checks',case,'arbitrary midpoint near caps',ncase)

# Independently enumerate the signed divisors and the smooth/rough split.
from math import gcd
crop_cases=0
for n in range(1,257):
    divisors=[d for d in range(1,n+1) if n%d==0]
    factors=[]
    rem=n
    for q in range(2,n+1):
        while rem%q==0:
            factors.append(q);rem//=q
    for d in range(5,32):
        if gcd(d,n)>1:continue
        L=(d-1)//2
        counts=Counter(x%d for u in divisors for x in (u,-u))
        for y in (2,4,8,16):
            small=1
            for q in factors:
                if q>y or small*q>L:break
                small*=q
            rest=n//small
            eligible=[q for q in factors if q<=y]
            if all(rest%q for q in eligible):
                assert all(q>y for q in factors if rest%q==0)
            else:
                assert small*y>L or all(q>y or rest%q!=0 for q in factors)
            bound=sum(rest%j==0 for j in range(1,rest+1))
            assert max(counts.values())<=bound
            crop_cases+=1
print('Signed-divisor progression and crop checks',crop_cases)

profile_cases=0
for p in (47,101):
    U=(5,7,11,13,17)
    for t in range(1,p):
        inv=[t*pow(q,-1,p)%p for q in U]
        for H,rad in ((3,3),(4,5),(8,8),(13,19),(18,27)):
            cap=weighted_plus(5,17,12,H,p,p,rad)
            for z in range(p):
                distances=[min((x-z)%p,(z-x)%p) for x in inv]
                exact=sum(F(rad-j,rad) for j in distances if j<H)
                assert exact<=cap
                profile_cases+=1
print('Exact weighted midpoint layer checks',profile_cases)

crt_cases=0
for p in (101,211,307,401):
    for low,high in ((23,70),(29,95),(37,98)):
        U=[q for q in range(low,high+1) if all(q%d for d in range(2,isqrt(q)+1))]
        pairs=Counter((pow(a,-1,p)+pow(b,-1,p))%p for a,b in product(U,repeat=2))
        assert max(pairs.values())<=plus_cap(low,high,high-low,p,True,True)
        assert max(pairs.values())<=line_family(low,high,high-low,p,p,True)
        crt_cases+=len(pairs)
print('Reciprocal-sum fibres with the CRT hull cap',crt_cases)
