"""Use the proved midpoint shape coefficient in the existing near-lines adapter."""
from fractions import Fraction as F
from functools import lru_cache


def install(model):
    @lru_cache(maxsize=65536)
    def unit(A,B,V,p0,p1,R,edge):
        if not (3<A<=B<p0 and 0<V<=B and p0<=p1 and R>=1 and
                144*B*R<p0*V and 9*V<p0*B*R):
            return None
        max2=F((6*V+12*B)**2*p1*B*R,V)
        f=0;power=A*A
        while power<=max2:
            f+=1;power*=A*A
        if not f:return F(0)
        S=model.sqrt_upper(F(B*V*R,p0))
        return (2*f-1)*(1+edge)+f*S*(F(857,1000)+edge*F(1415,1000))
    model.unit=unit
    model.cap.cache_clear()
