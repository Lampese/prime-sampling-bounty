from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
from tempfile import TemporaryDirectory
import os,sys

here=Path(__file__).resolve().parent
work=here.parent
ap=ArgumentParser()
for k,d in dict(repo='prime-sampling',selectors='operator-new',base='weighted-base',cap='residue-bridge/crt-fast').items():
    ap.add_argument('--'+k,type=Path,default=work/d)
ap.add_argument('--grid',type=int,default=3200)
ap.add_argument('--mode',choices=('pair','six'),default='six')
ap.add_argument('--no-reflection',action='store_true')
ap.add_argument('--sharp',action='store_true')
ap.add_argument('--tuned',action='store_true')
ap.add_argument('--profile',action='store_true')
ap.add_argument('--crt',action='store_true')
ap.add_argument('--family',action='store_true')
ap.add_argument('--joint',action='store_true')
ap.add_argument('--near-shape',type=Path)
ap.add_argument('--midpoint-shape',action='store_true')
ap.add_argument('--bad-centres',action='store_true')
ap.add_argument('--projection',type=Path,nargs='+')
ap.add_argument('--rows',type=F,nargs='+',default=list(map(F,('.38','.39','.40','.42','.45','.47','.49'))))
args=ap.parse_args()
regions=[] if not args.projection else [[tuple(map(int,row.split())) for row in path.read_text().splitlines()] for path in args.projection]
sys.path[:0]=[str(x.resolve()) for x in (args.selectors,args.repo,args.base,args.cap)]
if (work/'zig-cxx.cmd').exists():
    os.environ.setdefault('CXX',str(work/'zig-cxx.cmd'))
    os.environ.setdefault('ZIG_GLOBAL_CACHE_DIR',str(work/'zig-cache'))
    os.environ.setdefault('ZIG_LOCAL_CACHE_DIR',str(work/'zig-local-cache'))
from prime_sampling.rectangles import boxes as m,sieved_lift
from prime_sampling.spectrum import squarerates as sr
import weighted,reflection,crt_fibres
if args.near_shape is not None:
    sys.path.insert(0,str(args.near_shape.resolve()))
    import shape_near
    if args.midpoint_shape:
        from midpoint_shape import install
        install(shape_near)
    shape_near.install()
m.initialize(F(150),F(4801,32));sieved_lift.install(m);crt_fibres.install(corner=True,layered=True)
cache={}
def both(old,a,b,V,s,H,pm,p,r0,rad=None):
    new=old if args.no_reflection else reflection.refine(old,a,b,V,s,H,pm,p,r0,args.sharp,rad,args.crt,args.family,args.joint)
    cache['gain'].append(float(new/old))
    if args.bad_centres or regions:
        from bad_centres import bound,projected
        cache['bad_current']=[round(float(bound(a,b,V,s,pm,p,H,q)),5) for q in map(F,('1/100','1/200','1/1000'))] if args.bad_centres else []
        cache['bad_current']+=[round(float(projected(a,b,V,s,pm,p,rad,cells)),5) for cells in regions]
    return new

m.rates=lambda *args:[F(1)]*2
def trace(*candidate):
    vals=candidate[-1]
    fraction=cache['gain'][-1] if cache['gain'] else 1
    for q,x in enumerate(vals):
        if x<cache['best'][q]:
            cache['best'][q]=x;cache['stats'][q]=round(fraction,5)
            if args.bad_centres or regions:cache['bad'][q]=cache['bad_current']
from tuned import selector
extra=selector(args.selectors,args.mode,args.sharp,args.crt,args.family) if args.tuned else None
weighted.install(args.mode,m,lambda:axis,args.selectors,96,extra_choices=extra,
                 shape_menu=[(F(1,2),F(0)),(F(1,2),F(-1,4)),(F(2,3),F(-1,8))],
                 trace=trace,co_refiner=both,pass_radius=args.profile)
for u in args.rows:
    v=u+F(1,args.grid)
    final=[];ratios=[];excluded=[]
    for cl,et in (m.inner(u,v),(max(m.LAM*m.Xlo(u-v),m.Xlo(2*u-1)),F(1))):
        if cl>=et:final.extend([10**10]*2);ratios.extend([1,1]);continue
        eps,_,a,b,s,V,ylo,yhi=m.params(u,v)
        eps=max(eps,m.thetaerr((1-u)*m.zl+m.b(cl,'ln',False)))
        k=(m.abel.lower_count(cl,et,eps,(1-u)*m.zh,m)*ylo).__ceil__()
        x,y=(cl*ylo).__floor__(),(et*yhi).__ceil__()
        span=((et-cl)*yhi).__ceil__()+2
        cache={'best':[F(1)]*2,'stats':[1]*2,'gain':[],'bad':[None,None]}
        for axis,params in (((x,y),(a,b,V,s,k,span)),((a,b),(x,y,min(y-x,span),k,s,V))):
            m.rates(*params,m.pmin,m.pmax)
        final.extend(map(m.upint,cache['best']));ratios.extend(cache['stats'])
        excluded.extend(cache['bad'])
    print(u,*final,'co fractions',*ratios,flush=True)
    if args.bad_centres or regions:print('upper shares for requested corner and shape projections',excluded,flush=True)
if os.name=='nt':
    import _ctypes
    _ctypes.FreeLibrary(sr._lib._handle)
