"""Add a certified reflection cross term to the existing wide-box macro ledger."""
from argparse import ArgumentParser
from pathlib import Path
import os,sys,runpy

work=Path(__file__).resolve().parents[1]
ap=ArgumentParser(add_help=False)
ap.add_argument('--base',type=Path,default=work/'weighted-base')
ap.add_argument('--selectors',type=Path,default=work/'operator-new')
ap.add_argument('--repo',type=Path,default=work/'prime-sampling')
ap.add_argument('--sharp',action='store_true')
ap.add_argument('--tuned',action='store_true')
ap.add_argument('--profile',action='store_true')
ap.add_argument('--crt',action='store_true')
ap.add_argument('--family',action='store_true')
ap.add_argument('--joint',action='store_true')
ap.add_argument('--near-shape',type=Path)
ap.add_argument('--midpoint-shape',action='store_true')
args,rest=ap.parse_known_args()
sys.path[:0]=[str(q.resolve()) for q in (args.selectors,args.base,args.repo)]
if (work/'zig-cxx.cmd').exists():
    os.environ.setdefault('CXX',str(work/'zig-cxx.cmd'))
    os.environ.setdefault('ZIG_GLOBAL_CACHE_DIR',str(work/'zig-cache'))
    os.environ.setdefault('ZIG_LOCAL_CACHE_DIR',str(work/'zig-local-cache'))
import weighted,reflection
if args.near_shape is not None:
    sys.path.insert(0,str(args.near_shape.resolve()))
    import shape_near
    if args.midpoint_shape:
        from midpoint_shape import install
        install(shape_near)
    shape_near.install()
from functools import partial
from tuned import selector
original=weighted.install
def install(*args,**kwargs):
    def price(old,a,b,v,s,h,pm,p,r0,rad=None):
        return reflection.refine(old,a,b,v,s,h,pm,p,r0,options.sharp,rad,options.crt,options.family,options.joint)
    kwargs['co_refiner']=price
    kwargs['pass_radius']=options.profile
    if options.tuned:
        kwargs['extra_choices']=selector(options.selectors,args[0],options.sharp,options.crt,options.family)
    return original(*args,**kwargs)
weighted.install=install
options=args
sys.argv=['hyperbola.py','--repo',str(args.repo),'--selectors',str(args.selectors),*rest]
runpy.run_path(str((args.base/'hyperbola.py').resolve()),run_name='__main__')
