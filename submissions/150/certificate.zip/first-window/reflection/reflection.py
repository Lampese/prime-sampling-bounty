"""Uniform reflection of the off-diagonal labelled sampling distribution."""
from fractions import Fraction as F
from functools import lru_cache
from math import isqrt


def ceildiv(x,y):return -(-x//y)

@lru_cache(None)
def scaled_root(bits,k):
    n=2*k+1
    e=bits*k+24*n
    lo=1<<(e//(2*n));hi=lo*2
    while hi>lo+1:
        mid=(lo+hi)//2
        if mid**(2*n)<=1<<e:lo=mid
        else:hi=mid
    return lo


def crop_cap(bits,L,cap_table,baseline):
    small=baseline
    if L<2:return small
    for yr in range(4,15):
        y=1<<yr
        modded=((1<<bits)*y)//L
        cap2=next((c//2 for i,c in cap_table.items() if 1<<i>=modded),small)
        rough=1<<ceildiv(bits,yr)
        small=min(small,max(2,cap2,rough))
    return small


@lru_cache(maxsize=16384)
def prime_arc(a,V,b=None,pm=None,sharp=False):
    from prime_sampling.rectangles.old_fibre import arc
    from prime_sampling.rectangles.divisor_bounds import divisor_caps
    from prime_sampling.rectangles.sieved_det import alpha
    best=arc(V)
    cap_table=dict(zip(range(96,385,8),(c for c,_ in divisor_caps())))
    for bits,cap in cap_table.items():
        small=cap
        if b is not None and 2*V<pm:
            threshold=1<<bits
            dlo=ceildiv(pm-2*b*(isqrt(threshold)+1),(1 if sharp else 3)*b*b)
            if sharp:
                odd=crop_cap(bits,dlo-1,cap_table,cap)
                even=crop_cap(bits-2,(dlo-1)//2,cap_table,cap)
                small=max(odd,even)
            else:
                small=crop_cap(bits,(dlo-1)//2,cap_table,cap)
        if small>=best:continue
        large=V+1
        for k in (3,6,12,24,48):
            n=2*k+1
            if 2*n>=a:continue
            # 2^(bits*k/(2*n)) bounded from below on a 1/2^12 lattice.
            lo=scaled_root(bits,k)
            den=alpha(n)*lo
            large=min(large,2*(n+((n-1)*V*100*(1<<12))//den))
        best=min(best,max(small,large))
    return best


@lru_cache(None)
def crt_images():
    # The lattice coordinates are the sum and product of the half shifted
    # primes. Mod 2 all half shifted residues are admissible.
    blocks=[]
    for q,max_power in ((2,5),(3,3),(5,2),(7,1),(11,1),(13,1),(17,1),(19,1)):
        block=[(1,1)]
        for power in range(1,max_power+1):
            m=q**power
            units=[i for i in range(m) if q==2 or i%q]
            image={((i+j)%m,i*j%m) for ix,i in enumerate(units) for j in units[ix:]}
            block.append((m,len(image)))
        blocks.append(block)
    values=[(1,1)]
    for block in blocks:
        values=[(a*b,c*d) for a,c in values for b,d in block]
    return tuple(sorted(values))


@lru_cache(maxsize=16384)
def crt_cap(a,V,pm,line,original):
    # Every fibre has at most one diagonal pair (its prime is determined).
    row=max(line,2*(1+V**2//(4*pm)))
    row=(row+1)//2
    area=V**3; unit=8*pm
    best=original
    for m,count in crt_images():
        if m>=pm or a<=19:break
        if count*2>=best:continue
        base=2+area//(unit*m*m)
        best=min(best,2*count*max(base,row))
        trial=max(base,1+isqrt(area*row//(unit*m*count)))
        for t in (trial,trial+1):
            opt=max(count*t,row*(1+area//(unit*m*t)))
            best=min(best,2*opt)
    return best


def plus_cap(a,b,V,pm,sharp=False,crt=False):
    # Distinct reduced rational sums represent distinct unordered prime pairs.
    # This includes 1/q+1/q=2/q. Every reduced numerator is even.
    if V*b*b<pm:return 2
    line=prime_arc(a,V,b,pm,sharp)
    geometric=max(line,4+V**3//(4*pm))
    best=min(V+1,2*(1+V*b**4//(pm*a*(a+V))),geometric)
    return crt_cap(a,V,pm,line,best) if crt else best


@lru_cache(maxsize=50000)
def determinant_line(a,V,bits):
    from prime_sampling.rectangles.sieved_det import alpha
    best=V+1
    for k in (3,6,12,24,48):
        n=2*k+1
        if 2*n>=a:continue
        den=alpha(n)*scaled_root(bits,k)
        best=min(best,2*(n+(n-1)*V*100*(1<<12)//den))
    return best


@lru_cache(maxsize=16384)
def line_family(a,b,V,pm,p,sharp=False):
    line=prime_arc(a,V,b,pm,sharp)
    if V<=0:return 1
    best=V+1
    # Choose an odd midpoint. Then all inputs x=a'-midpoint are even.
    radius=(V+1)//2+1
    D=max(1,min(pm-1,isqrt(p//radius)))
    gmax=max(D*radius,ceildiv(p,D))
    lo=radius
    worst=0
    while lo<=gmax:
        hi=min(gmax,lo+(lo-1)//8)
        # J=dxy-g(x+y) varies over a range <=4RG and occupies one class mod 2p.
        size=1+2*radius*hi//pm
        if size*line<=worst:
            lo=hi+1;continue
        # When |g|>2dR, both factors have magnitude greater than G/2.
        threshold=max(1,lo*lo//4)
        fixed=size*min(line,determinant_line(a,V,threshold.bit_length()-1))
        # Otherwise, d>=G/(2R), and successive signed N differ by at least 2dp.
        dlow=ceildiv(lo,2*radius)
        total=line
        j=1
        while j<size:
            threshold=max(1,j*dlow*pm)
            bounds=min(line,determinant_line(a,V,threshold.bit_length()-1))
            end=min(size,j+max(1,j//4))
            total+=(end-j)*bounds
            j=end
        worst=max(worst,fixed,total)
        lo=hi+1
    return min(best,worst)


@lru_cache(maxsize=16384)
def near_plus(a,b,V,H,pm,p):
    # A Dirichlet approximation to the arbitrary centre, independent of t.
    if H==0:return 1
    best=1+V//2
    seed=max(1,isqrt(V*pm//(2*b*H)))
    for nu,de in ((1,2),(3,4),(1,1),(4,3),(2,1)):
        D=max(1,seed*nu//de)
        if D>=pm:continue
        Y=b*(ceildiv(p,D)+D*H)
        f=0;pot=1
        while pot<=Y//a:
            pot*=a;f+=1
        # The centre contribution is V/D with the same true p on both sides.
        count=1+(V*pm+2*b*D*D*H)//(D*pm)
        best=min(best,f*count)
    return best


@lru_cache(maxsize=16384)
def weighted_plus(a,b,V,H,pm,p,rad,bins=16):
    # Exact layer cake of (1-|i-i'|/rad)_+, with physical support H-1.
    # Group the first H layers and use that support on the remaining plateau.
    assert rad>=H
    total=(rad-H)*near_plus(a,b,V,H-1,pm,p)
    left=0
    for i in range(1,bins+1):
        right=H*i//bins
        if right>left:
            total+=(right-left)*near_plus(a,b,V,right-1,pm,p)
            left=right
    return F(total,rad)


def refine(old,a,b,V,s,H,pm,p,r0,sharp=False,rad=None,crt=False,family=False,joint=False):
    M=plus_cap(a,b,V,pm,sharp,crt)
    if family:M=min(M,line_family(a,b,V,pm,p,sharp))
    N=near_plus(a,b,V,H,pm,p) if rad is None else weighted_plus(a,b,V,H,pm,p,rad)
    if joint:
        assert rad is not None
        from prime_sampling.spectrum import squarerates as sr
        raw=sr.weighted_near(a,b,V,pm,p,1,rad)
        N=min(N,1+raw)
    cross=r0*F((M-1)*N,s**3)
    return min(old,(old+cross)/2)
