"""Extra candidate kernels. All costs are reevaluated by the rational verifier."""
import ctypes as ct
import os
from pathlib import Path
import subprocess
from tempfile import TemporaryDirectory

from reflection import plus_cap,line_family


def selector(source,mode,sharp,crt=False,family=False):
    text=(Path(source)/'mixed_selector.cpp').read_text()
    signature='double md,double logy,double qerr'
    original='double co=(1+md*near/s)/(h*s*s);'
    assert text.count(signature)==1 and text.count(original)==1
    text=text.replace(signature,'double md,double logy,double qerr,double plus')
    text=text.replace(original,original+'''
            double nearPlus=v/2+1;
            double seed=std::sqrt(v*pm/(2*b*h));
            for(double scale:{.5,.75,1.,4./3.,2.}){
                double D=std::max(1.,std::floor(seed*scale));
                if(D>=pm)continue;
                double f=std::floor(std::log(b*(std::ceil(p/D)+D*h))/std::log(a));
                nearPlus=std::min(nearPlus,f*(1+std::floor(v/D+2*b*D*h/pm)));
            }
            co=std::min(co,(co+(plus-1)*nearPlus/(h*s*s*s))/2);
    ''')
    tmp=TemporaryDirectory(ignore_cleanup_errors=True)
    here=Path(tmp.name)
    cpp=here/'reflection.cpp';cpp.write_text(text)
    dll=here/'reflection.so'
    subprocess.run([os.getenv('CXX','c++'),'-O3','-std=c++17','-shared','-fPIC',cpp,'-o',dll],check=True)
    lib=ct.CDLL(str(dll));choose=lib.choose
    choose.argtypes=[ct.c_double]*12+[ct.c_int,ct.c_int,ct.POINTER(ct.c_int)]
    choose.restype=None
    def extra(a,b,v,s,k,span,pm,p,md,logy,qerr,_keep=(tmp,lib)):
        cap=plus_cap(a,b,v,pm,sharp,crt)
        if family:cap=min(cap,line_family(a,b,v,pm,p,sharp))
        ids=(ct.c_int*2)()
        choose(*map(float,(a,b,v,s,k,span,pm,p,md,logy,qerr,cap)),int(mode=='six'),1,ids)
        return tuple(ids)
    return extra
