"""Dominating branches of the reciprocal-sum fibre cap on the actual input."""
from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
import os,sys

ap=ArgumentParser()
ap.add_argument('--repo',type=Path,default=Path(__file__).resolve().parents[1]/'prime-sampling')
ap.add_argument('--grid',type=int,default=3200)
opts=ap.parse_args();sys.path.insert(0,str(opts.repo))
work=Path(__file__).resolve().parents[1]
if (work/'zig-cxx.cmd').exists():
    os.environ.setdefault('CXX',str(work/'zig-cxx.cmd'))
    os.environ.setdefault('ZIG_GLOBAL_CACHE_DIR',str(work/'zig-cache'))
    os.environ.setdefault('ZIG_LOCAL_CACHE_DIR',str(work/'zig-local-cache'))
from reflection import plus_cap,prime_arc,line_family
from prime_sampling.rectangles import boxes as m

m.initialize(F(150),F(4801,32))
for u in map(F,('.38','.39','.4','.41','.42','.43','.44','.45','.47','.49')):
    eps,_,a,b,s,V,ylo,yhi=m.params(u,u+F(1,opts.grid))
    cap=plus_cap(a,b,V,m.pmin,True)
    area=4+V**3//(4*m.pmin)
    arc=prime_arc(a,V,b,m.pmin,True)
    print(u,'ordered',cap,'CRT',plus_cap(a,b,V,m.pmin,True,True),'family',line_family(a,b,V,m.pmin,m.pmax,True),'arc',arc,'noncollinear',area,'odd primes lower',s,flush=True)
if os.name=='nt':
    import _ctypes
    from prime_sampling.spectrum import squarerates as sr
    _ctypes.FreeLibrary(sr._lib._handle)
