"""Build the midpoint-quadrature variant of the supplied interval checker."""
from argparse import ArgumentParser
from pathlib import Path
import os,subprocess
from tempfile import TemporaryDirectory

root=Path(__file__).resolve().parents[1]
ap=ArgumentParser()
ap.add_argument('--source',type=Path,default=root/'near-lines/shape_verify.cpp')
ap.add_argument('--out',type=Path,default=Path(__file__).resolve().with_name('shape_midpoint.exe'))
ap.add_argument('--mod-five',action='store_true')
args=ap.parse_args()
src=args.source.read_text()
edits={
    'running=factor*v.y*N':'running=factor*v.y*(2*N)-tic',
    'running+=tic;':'running+=2*tic;',
    '3*unit*N*N':'6*unit*N*N',
    '18*j*N*unit*unit':'36*(2*j-1)*N*unit*unit',
}
for old,new in edits.items():
    count=src.count(old)
    assert count==(2 if old=='3*unit*N*N' else 1),(old,count)
    src=src.replace(old,new)
if args.mod_five:
    for old,new in (
        ('j<=3;++j)for(int i=-5;i<=4','j<=8;++j)for(int i=-16;i<=10'),
        ('state<4','state<24'),
        ('int residue=state==3?v.b:v.a+state*v.b;',
         'int c3=state%4,c5=state/4; int residue=c3==3?v.b:v.a+c3*v.b; int r5=c5==5?v.b:v.a+c5*v.b;'),
        ('I factor=residue%3==0 ? 2 : 3;',
         'I factor=(residue%3==0 ? 2 : 3)*(r5%5==0 ? 4 : 5);'),
        ('6*unit*N*N','30*unit*N*N'),
        ('baseline[j]=isqrt_upper','baseline[j]=5*isqrt_upper'),
    ):
        assert src.count(old)==(2 if old=='6*unit*N*N' else 1),old
        src=src.replace(old,new)
compiler=os.getenv('CXX')
if compiler is None and (root/'zig-cxx.cmd').exists():
    compiler=str(root/'zig-cxx.cmd')
    os.environ.setdefault('ZIG_GLOBAL_CACHE_DIR',str(root/'zig-cache'))
    os.environ.setdefault('ZIG_LOCAL_CACHE_DIR',str(root/'zig-local-cache'))
with TemporaryDirectory() as d:
    cpp=Path(d)/'midpoint.cpp';cpp.write_text(src)
    subprocess.run([compiler or 'c++','-O3','-std=c++17',cpp,'-o',args.out.resolve()],check=True)
