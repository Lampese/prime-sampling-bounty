"""Compare CRT partitions and exact window widths on four certified rectangles."""
from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
import os
import sys

here=Path(__file__).resolve().parent
work=here.parent
parser=ArgumentParser(description=__doc__)
parser.add_argument('--repo',type=Path,default=work/'prime-sampling')
args=parser.parse_args()
if 'CXX' not in os.environ and (work/'zig-cxx.cmd').is_file():
    os.environ['CXX']=str(work/'zig-cxx.cmd')
    os.environ.setdefault('ZIG_GLOBAL_CACHE_DIR',str(work/'zig-cache'))
    os.environ.setdefault('ZIG_LOCAL_CACHE_DIR',str(work/'zig-local-cache'))
sys.path.insert(0,str(args.repo.resolve()))
from prime_sampling.rectangles import boxes,sieved_lift
from prime_sampling.spectrum import squarerates as sr

from math import sqrt
boxes.initialize(F(150),F(4801,32))
print('u shorter side counts s,k; original single-eigenvalue bound; FKM2014 optimistic last-term lower; FKMS2026 optimistic exponent lower',flush=True)
for u in map(F,('.40','.45','.47','.49')):
    v=u+F(1,3200);cl,et=boxes.inner(u,v)
    eps,_,a,b,s,width,ylo,yhi=boxes.params(u,v)
    eps=max(eps,boxes.thetaerr((1-u)*boxes.zl+boxes.b(cl,'ln',False)))
    k=(boxes.abel.lower_count(cl,et,eps,(1-u)*boxes.zh,boxes)*ylo).__ceil__()
    low=(cl*ylo).__floor__(); high=(et*yhi).__ceil__(); span=((et-cl)*yhi).__ceil__()+2
    smax=((width+2*eps*b)/boxes.b(F(a),'ln',False)).__ceil__()+1
    kmax=((span+2*eps*high)/boxes.b(F(low),'ln',False)).__ceil__()+1
    pm=boxes.pmin
    assert min(a,low)>0 and smax*kmax<pm
    # M is at least a/2 for the short support in [M/2,2M]; opposite blocks
    # can be split into dyadic pieces, so this comparison is for a single support fit.
    fkm=sqrt(float(F(min(a,low)*149,2*smax*kmax)))*float(pm)**.25
    rhs=(pm/(smax*kmax))**.5
    print(float(u),s,k, f'{rhs:.7g}',f'{fkm:.7g}',f'{float(boxes.pmax)**(-1/224):.7g}')
if os.name=='nt':
    import _ctypes
    _ctypes.FreeLibrary(sr._lib._handle)
