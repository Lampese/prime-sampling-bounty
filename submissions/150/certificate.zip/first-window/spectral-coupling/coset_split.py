"""Split a six-character probability measure along its constant ternary labels."""
from argparse import ArgumentParser
from pathlib import Path


def close_six(pair,six):
    if len(pair)!=9 or len(six)!=9 or tuple(pair[:1])+tuple(pair[5:])!=tuple(six[:1])+tuple(six[5:]):
        raise ValueError('pair and six rows must describe the same rectangle and geometry')
    result=list(six)
    for g,q in ((1,2),(3,4)):
        result[g]=min(six[g],pair[g])
        result[q]=min(six[q],(2*pair[g]+pair[q]+2)//3)
    return result


def read(path):
    return [list(map(int,line.split())) for line in path.read_text().splitlines()
            if line and line[0].isdigit()]


if __name__=='__main__':
    cli=ArgumentParser(description=__doc__)
    for arg in ('pair','six','out'):cli.add_argument(arg,type=Path)
    args=cli.parse_args()
    p,s=read(args.pair),read(args.six)
    assert len(p)==len(s)
    rows=[close_six(a,b) for a,b in zip(p,s)]
    args.out.write_text(''.join(' '.join(map(str,row))+'\n' for row in rows),encoding='ascii')
