"""Exact finite-field checks of the rank-one collapse in the first FKMS moment."""
from fractions import Fraction as F
from itertools import product

for p in (31,53,101):
    chi=[0 if x==0 else (1 if pow(x,(p-1)//2,p)==1 else -1) for x in range(p)]
    def single(v):
        a,b,c,d=v
        return sum(chi[(x+a)%p]*chi[(x+b)%p]*chi[(x+c)%p]*chi[(x+d)%p] for x in range(p))
    # Affine invariance fixes v1=0, and v2=1 when it differs from v1.
    total=generic=large=0
    for b,mult in ((0,p),(1,p*(p-1))):
        for c,d in product(range(p),repeat=2):
            v=(0,b,c,d)
            val=single(v)
            total+=mult*val*val
            if len(set(v))==4:
                generic+=mult
                large+=mult*(4*val*val>=p)
    exact=p*F(p-1,p)**4+p*(p-1)*F(1,p)**4
    assert F(total,p**4)==exact
    v=(1,3,7,13);t=4
    collapsed=sum(chi[(t+s*(r+v[0]))%p]*chi[(t+s*(r+v[1]))%p]*
                  chi[(t+s*(r+v[2]))%p]*chi[(t+s*(r+v[3]))%p]
                  for r in range(p) for s in range(1,p))
    assert collapsed==(p-1)*single(v)
    print('p',p,'exact mean square',exact,'fraction of distinct tuples with |S| >= sqrt(p)/2',F(large,generic))
