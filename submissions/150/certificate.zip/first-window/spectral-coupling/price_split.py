"""Take the coset partition after the complete 150 first-window rate merges."""
from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
import json
import sys
from coset_split import close_six,read

here=Path(__file__).resolve().parent; work=here.parent
ap=ArgumentParser(description=__doc__)
for arg,name in (('repo','prime-sampling'),('prior','harmonic-research'),('bridge','residue-bridge'),('points','energy-next')):
    ap.add_argument('--'+arg,type=Path,default=work/name)
ap.add_argument('--out',type=Path,default=here/'target')
args=ap.parse_args()
args.out.mkdir(exist_ok=True,parents=True)
sys.path[:0]=[str(args.repo.resolve()),str(args.prior.resolve())]
from prime_sampling.accounting import ledger
from predecessor.tree_sieve_trial import new_bank
from prime_mass import prime_mass
ledger.bank=new_bank
lo,hi=F(150),F(4801,32)
target=args.prior/'target'
menu=json.loads((target/'tables.json').read_text())
point=[]
for name in ('point-updates-corner.json','point-updates-corner-layered.json'):
    point+=json.loads((args.points/name).read_text())
sets={}
for kind,g,name in menu:
    base=read(target/name)
    paths={1600:['target-layered-1600'],3200:['target','target-layered']}.get(g,())
    rows=[r[:] for r in base]
    for path in paths:
        other=read(args.bridge/path/(kind+'.dat'))
        assert len(rows)==len(other)
        for old,new in zip(rows,other):
            assert old[:1]+old[5:]==new[:1]+new[5:]
            old[1:5]=list(map(min,zip(old[1:5],new[1:5])))
    for u,k,g0,i,original,better in point:
        if k==kind and g0==g:
            n=i-67*g//200
            assert rows[n][0]==i and base[n][1:5]==original
            rows[n][1:5]=list(map(min,zip(rows[n][1:5],better)))
    sets[kind,g]=rows
def spectra(tag):
    arr=[]
    for kind,g,name in menu:
        rows=sets[kind,g]
        if tag=='split' and kind=='six':
            after=[close_six(a,b) for a,b in zip(sets['pair',g],rows)]
            print('grid',g,'counts of improved rates',*[sum(a[j]<b[j] for a,b in zip(after,rows)) for j in range(1,5)])
            rows=after
        path=args.out/(tag+'-'+name)
        path.write_text(''.join(' '.join(map(str,r))+'\n' for r in rows),encoding='ascii')
        arr.append(('extra',kind,lo,hi,g,path))
    return arr
for tag in ('before','split','allclasses'):
    extras=spectra('split' if tag=='allclasses' else tag)
    if tag=='allclasses':
        for group,kind,a,b,g,path in ledger.TABLES:
            if a<=lo<hi<=b and kind=='single':
                singles=read(path)
                extras.append(('extra','pair',a,b,g,path))
                after=[close_six(r,[r[0],10**10,10**10,10**10,10**10,*r[5:]]) for r in singles]
                dest=args.out/('single-to-six-'+path.name)
                dest.write_text(''.join(' '.join(map(str,x))+'\n' for x in after),encoding='ascii')
                extras.append(('extra','six',a,b,g,dest))
    for branch in ('with3','without3'):
        rr=ledger.rank(hi,branch)
        inp=[x for x in ledger.TABLES+extras if x[2]<=lo<hi<=x[3] and (x[1]!='six' or branch=='with3')]
        costs=ledger.suffix_costs(inp,rr,True)
        print(tag,branch,'T by cut',*[ledger.fmt(costs[j]) for j in sorted(costs)],flush=True)
