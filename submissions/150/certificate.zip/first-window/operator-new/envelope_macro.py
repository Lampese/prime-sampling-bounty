"""Apply the wheel Fourier hyperplane estimate on the full Abel rectangle recursion."""
from argparse import ArgumentParser
from pathlib import Path
from tempfile import TemporaryDirectory
import os,runpy,sys,subprocess

work=Path(__file__).resolve().parents[1]
ap=ArgumentParser(add_help=False)
ap.add_argument('--repo',type=Path,default=work/'prime-sampling')
ap.add_argument('--local-conductor',action='store_true')
ap.add_argument('--angular',action='store_true')
ap.add_argument('--reweight',action='store_true')
ap.add_argument('--paley-four',action='store_true')
ap.add_argument('--tetra-four',action='store_true')
args,rest=ap.parse_known_args()
sys.path[:0]=[str(d) for d in (args.repo.resolve(),work/'operator-new',work/'weighted-base',work/'gram-cycle',work/'fibre-portfolio')]
if (work/'zig-cxx.cmd').is_file():
    os.environ.setdefault('CXX',str(work/'zig-cxx.cmd'))
    os.environ.setdefault('ZIG_GLOBAL_CACHE_DIR',str(work/'zig-cache'))
    os.environ.setdefault('ZIG_LOCAL_CACHE_DIR',str(work/'zig-local-cache'))
import weighted
old=weighted.install
def install(*a,**kw):
    return old(*a,**kw,frequency_envelope=True,local_conductor=args.local_conductor,reweight=args.reweight,paley_four=args.paley_four,tetra_four=args.tetra_four)
weighted.install=install
with TemporaryDirectory() as folder:
    if args.angular:
        exe=Path(folder)/('shape.exe' if os.name=='nt' else 'shape')
        subprocess.run([os.environ.get('CXX','c++'),'-O3','-std=c++17',str(work/'fibre-lines/main_shape.cpp'),'-o',str(exe)],check=True)
        os.environ['PRIME_SHAPE_EXE']=str(exe)
        sys.argv=['macro.py','--directional','--repo',str(args.repo.resolve()),*rest]
        runpy.run_path(str(work/'fibre-portfolio/macro.py'),run_name='__main__')
    else:
        sys.argv=['hyperbola.py','--wide','--shape-bound','--repo',str(args.repo.resolve()),*rest]
        runpy.run_path(str(work/'weighted-base/hyperbola.py'),run_name='__main__')
