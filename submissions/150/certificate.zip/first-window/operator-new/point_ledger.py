"""Reprice the four changed strips at each grid with the same prior ledger."""
from fractions import Fraction as F
from argparse import ArgumentParser
from pathlib import Path
import sys
from tempfile import TemporaryDirectory

here=Path(__file__).resolve().parent
work=here.parent
prior=work/'harmonic-research'
sys.path[:0]=[str(work/'prime-sampling'),str(prior/'predecessor'),str(prior)]
from prime_sampling.accounting import ledger
from tree_sieve_trial import new_bank
from prime_mass import prime_mass


def main():
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--line-data',type=Path,help='Read MODE-final-GRID.txt from this directory')
    parser.add_argument('--line-pattern',default='{mode}-final-{grid}.txt')
    args=parser.parse_args()
    a,z=F(150),F(4801,32)
    ledger.bank=new_bank
    original=ledger.suffix_costs
    ledger.suffix_costs=lambda tables,seq,mode:original(tables,seq,True)
    allowance=F(prime_mass(a,z)[0],10**12)
    budget=work/'residue-bridge'/'150-stock-multi.dat'
    with TemporaryDirectory() as tmp:
        previous=[];updated=[]
        for grid in (1600,3200,4800):
            for mode in ('pair','six'):
                if grid==4800:source=prior/'target'/f'{mode}-4800.dat'
                else:source=work/'residue-bridge'/('target-layered' if grid==3200 else 'target-layered-1600')/f'best-{mode}.dat'
                rows=[list(map(int,line.split())) for line in source.read_text().splitlines()]
                log=here/(f'{mode}-mixture.txt' if grid==3200 else f'{mode}-mixture-{grid}.txt')
                if args.line_data:log=args.line_data/args.line_pattern.format(mode=mode,grid=grid)
                seen=set()
                for line in log.read_text(encoding='utf-8-sig').splitlines():
                    fields=line.split()
                    if len(fields)!=16 or tuple(fields[j] for j in (1,6,11))!=('old','candidate','best'):
                        raise ValueError(f'Invalid update in {log}')
                    position=F(fields[0]);offset=int(position*grid)-67*grid//200
                    row=rows[offset]
                    assert row[0]==position*grid and row[1:5]==list(map(int,fields[2:6]))
                    row[1:5]=list(map(min,row[1:5],map(int,fields[7:11])))
                    assert row[1:5]==list(map(int,fields[12:16]))
                    seen.add(position)
                assert seen==set(map(F,('.42','.45','.47','.49')))
                output=Path(tmp)/f'{mode}-{grid}.dat'
                output.write_text(''.join(' '.join(map(str,row))+'\n' for row in rows),encoding='ascii')
                previous.append(('extra',mode,a,z,grid,source));updated.append(('extra',mode,a,z,grid,output))
        for name,tables in [('original',previous),('four updated positions, all three grids',updated)]:
            print(name,flush=True)
            for branch,result in ledger.probe(a,z,tables,[budget],allowance).items():ledger.report(a,z,branch,result)


if __name__=='__main__':main()
