"""Universal shape-independent upper coefficients for the exceptional physical moments."""
from fractions import Fraction as F
from functools import cache
from math import comb

def one(mode,inner,order,a,b):
    j=a+b
    if not j:return F(1)
    if inner:
        return F(j%2==0) if mode=='pair' else F(1,6)+F(1,2)*F(-1,3)**j
    if (a-b)%order:return F(0)
    return F(1,2) if mode=='pair' else F(1,6)+F(1,3*4**j)

@cache
def masses(mode,inner,order,a,b):
    if a+b==0:return (F(1),)
    coeff=[F(0)]*((a+b)//2+1)
    for i in range(a+1):
        for j in range(b+1):
            if i+j<2 or (a and not i) or (not a and not j):continue
            v=one(mode,inner,order,i,j)
            if not v:continue
            ways=comb(a-1,i-1)*comb(b,j) if a else comb(b-1,j-1)
            for t,m in enumerate(masses(mode,inner,order,a-i,b-j)):
                if m:coeff[t+1]+=ways*v*m
    return tuple(coeff)

@cache
def remainder(mode,inner,r):
    orders=(1,) if inner else (5,7) if mode=='six' else (3,5,7)
    labels=3 if mode=='six' else 1
    return tuple(labels*max(masses(mode,inner,o,r,r)[j] for o in orders) for j in range(r))
