"""Convex mixtures of two different Fejer widths on the same reduced residues."""
import ctypes as ct
from fractions import Fraction as F
from math import isqrt
import os
from pathlib import Path
import subprocess
from tempfile import TemporaryDirectory

from fejer import generic_bound,partitions
from prime_sampling.spectrum import pair10,squarerates as sr


def coverage(x,h,m):
    def cdf(t):
        if t<=-m:return F(0)
        if t>=m-1:return F(1)
        if t<0:return F((t+m)*(t+m+1),2*m*m)
        n=m-t-1
        return 1-F(n*(n+1),2*m*m)
    return cdf(x)-cdf(x-h)


def price(mode,s,count,p,front,co,sigma,omega,l1,balanced=False,spectral_weights=None,local_min=None,centered=None,tilt=None,projective_discount=0,tetra_discount=0):
    root=sr.root
    sqrt=isqrt(p)+1
    results=[]
    for q in (0,1):
        labels=3 if mode=='six' else 1
        c=F(129,128) if mode=='six' and not q else F(1)
        mass=(F(2,9) if q else F(3,16)) if mode=='six' else (F(1) if q else F(1,2))
        head=None
        inflation=F(1)
        if tilt:
            assert mode=='six' and not balanced
            target=F(1,3) if q else F(1,2)
            head=target+tilt*((F(1,5) if q else F(1,3))-target)
            inflation=target**2/head+(1-target)**2/(1-head)
            mass=head**2/(1 if q else 2)+(1-head)**2/4
            c=1+2*((3*head-1)/2)**4
        def parity(r):
            return 3*head**(2*r) if head is not None and q else None
        lower=(12 if mode=='six' else (2 if q else 8))*p*sigma*(1+2*sigma)
        if balanced:from exceptional import remainder
        unpaired4=min(c,remainder(mode,q,2)[1]) if balanced else c
        physical4=generic_bound(mode,q,2,p,sqrt,c,True,parity(2))+unpaired4*p*p*sigma*omega**2
        if projective_discount:
            from paley_four import weight as matching_weight
            physical4-=projective_discount*matching_weight(mode,q,head)
        if tetra_discount and mode=='six' and q:
            mass0=F(1,3) if head is None else head
            physical4-=tetra_discount*24*mass0*((1-mass0)/4)**3
        power=sigma*l1**2
        if spectral_weights:power=min(power,spectral_weights[2])
        spectral4=14*c*p*p*sqrt*power
        if local_min:
            from local_conductor import fourier_parts
            generic,_,extra=fourier_parts(mode,q,2,local_min,p,sigma,head)
            spectral4=min(spectral4,generic*p*p*power+extra)
        variance=min(spectral4,physical4)+labels*(2 if q else 1)*(p*sigma*mass)**2+lower
        off=root(mass*sigma+root(co*variance))
        if centered:
            from centered_powers import second_moments,signed_rate
            pm,phi=centered
            lows,ups=second_moments(labels,mass,q,pm,p,sigma,omega,phi)
            # Here the uncentered fourth power is bounded directly by Fourier.
            lead=labels*(3 if q else 2)*mass**2
            allpairs=labels*3*((2 if q else 1)*mass)**2
            ups[2]=spectral4+lead*p**2*sigma**2+(allpairs-lead)*p*sigma
        for r,mult,factorial in ((3,15,6),(4,105,24),(5,945,120)):
            total=labels*mult*((2*mass)**r if q else mass**r)
            lead=labels*(mult if q else factorial)*mass**r
            paired=lead*p*p*sigma**r
            power=sigma*l1**(2*r-2)
            if spectral_weights:power=min(power,spectral_weights[r])
            spectral=c*(4**r-2)*sqrt*p**r*power+paired+(total-lead)*p*sigma**(r-1)
            if local_min:
                generic,pairing,_=fourier_parts(mode,q,r,local_min,p,sigma,head)
                spectral=min(spectral,generic*p**r*power+pairing)
            coefficients=(min(c*partitions(2*r,j),remainder(mode,q,r)[j]) if balanced
                          else c*partitions(2*r,j) for j in range(1,r))
            physical=generic_bound(mode,q,r,p,sqrt,c,True,parity(r))+p*p*sum(coef*sigma**j*omega**(2*r-2*j)
                                        for j,coef in enumerate(coefficients,1))+paired
            raw=min(spectral,physical)
            off=min(off,pair10.nroot(co*raw,2*r))
            if centered:
                ups[r]=raw
                off=min(off,signed_rate(r,co,lows,ups,off))
        results.append(root(inflation*front*(F(1,s)+off)))
    return results


def install(mode,model,mixture=True,shape_group=None,trapezoid=False,opposite=None,only_small=False,autotaper=False,balanced=False,envelope=False,wheel_search=False,conductor=False,centered=False,reweight=False,paley_four=False,tetra_four=False):
    tmp=TemporaryDirectory(ignore_cleanup_errors=True)
    dll=Path(tmp.name)/'mixture.so'
    subprocess.run([os.getenv('CXX','c++'),'-O3','-std=c++17','-shared','-fPIC',Path(__file__).with_name('mixed_selector.cpp'),'-o',dll],check=True)
    select=ct.CDLL(str(dll)).choose
    select.argtypes=[ct.c_double]*11+[ct.c_int,ct.c_int,ct.POINTER(ct.c_int)]
    select.restype=None
    old=model.rates
    proposals={}
    def rates(a,b,width,s,k,span,pm,p,_keep=tmp):
        best=list(old(a,b,width,s,k,span,pm,p))
        if max(best)<F(1,6000): return best
        if opposite and only_small and a>=opposite()[0]:return best
        md=min(sr.dirichlet_cap(a,b,width,pm,p),sr.previous_cap(width,b,pm),sr.square_cap(a,b,width,pm,p))
        ymin,ymax=opposite() if opposite else (model.elo(model.zl)/(64*b),2*model.eup(model.zh)/a)
        logy=model.b(ymin,'ln',False)
        error=model.thetaerr(logy)*ymax
        ids=(ct.c_int*2)()
        key=shape_group() if shape_group is not None else None
        if key is None or key not in proposals:
            choice=3 if autotaper else 2 if trapezoid else int(mixture)
            if wheel_search:
                assert envelope
                choice+=4
                if conductor:choice+=8
            select(*map(float,(a,b,width,s,k,span,pm,p,md,logy,error)),int(mode=='six'),choice,ids)
            codes=tuple(ids)
            if key is not None:proposals[key]=codes
        else:codes=proposals[key]
        for code in set(codes)-{-1}:
            code,ti=divmod(code,4);code,ni=divmod(code,33);code,mi=divmod(code,25);wi,hi=divmod(code,17)
            W,phi,divisors=((2,1,2),(6,2,4),(30,8,8),(42,12,8),(70,24,8),
                            (210,48,16),(3,2,2),(10,4,4),(15,8,4))[wi]
            d=sr.ceildiv(span,W)+7
            h,m,n=(max(1,d*i//8) for i in (hi,mi,ni))
            if trapezoid or autotaper:m,n=(2*max(1,t//2) for t in (m,n))
            if W>=a or m*phi<10**6 or 2*W*(h+2*n+d)>=pm:continue
            wt=F(ti,4)
            weights={m:F(1)} if m==n else {m:1-wt,n:wt}
            tau=(1-wt)/m+wt/n
            omega=tau/phi
            l1=tau*divisors/W
            sigma=((1-wt)**2*F(2*m*m+1,3*m**3)+wt**2*F(2*n*n+1,3*n**3)
                   +2*wt*(1-wt)*(F(1,n)-F(m*m-1,3*m*n*n)))/phi
            near=sr.weighted_near(a,b,width,pm,p,1,h)
            co=(1+F(md*near,s))/(h*s*s)
            start=(h-d)//2;peak=(h-1)//2
            def prob(x):return (1-wt)*coverage(x,h,m)+wt*coverage(x,h,n)
            if trapezoid:
                peak_width,flat_width=(m+n)//2,(n-m)//2
                omega=F(1,phi*n)
                sigma=F(3*m*n-m*m+1,3*m*n*n*phi)
                l1=F(divisors,W*isqrt(m*n))
                def prob(x):
                    difference=flat_width**2*coverage(x,h,flat_width) if flat_width else 0
                    return (peak_width**2*coverage(x,h,peak_width)-difference)/(m*n)
            if autotaper:
                from taper import kernel
                result=kernel(m,n,(F(-1,2),F(-1,4),F(1,4),F(1,2))[ti])
                if result is None:continue
                weights,tau,mass2=result
                omega,sigma,l1=tau/phi,mass2/phi,tau*divisors/W
                def prob(x):
                    return sum(z*coverage(x,h,w) for w,z in weights.items())
            last=prob(start)
            if last<=0:continue
            mean=1/prob(peak)
            for level in range(1,33):
                high=start+(peak-start)*level//32
                nextp=prob(high)
                cnt=min(k,2+(2*(high-start+4)*W+4*error)/logy)
                mean+=(1/last-1/nextp)*cnt/k
                last=nextp
            assert 0<mean and 0<sigma and omega**2<=sigma
            kwargs={}
            if paley_four:
                from paley_four import good,support_good
                if trapezoid or autotaper:
                    radius=(m+n)//2 if trapezoid and not autotaper else n
                    share=support_good(radius,W,phi,omega,pm,p)
                else:
                    share=good(weights,W,phi,pm,p)
                kwargs['projective_discount']=4*pm*share
            if tetra_four and mode=='six':
                from paley_four import tetra_share
                radius=(m+n)//2 if trapezoid and not autotaper else n
                law=None if trapezoid or autotaper else weights
                kwargs['tetra_discount']=2*pm*tetra_share(law,radius,W,phi,omega,pm,p)
            if centered:kwargs['centered']=(pm,phi)
            if balanced:kwargs['balanced']=True
            if conductor:kwargs['local_min']=pm
            if envelope:
                if trapezoid:
                    from trap_envelope import powers
                    kwargs['spectral_weights']=powers(m,n,W)
                else:
                    from frequency_envelope import powers
                    kwargs['spectral_weights']=powers(weights,W)
            answer=price(mode,s,k,p,F(phi*h,k)*mean,co,sigma,omega,l1,**kwargs)
            best=list(map(min,best,answer))
            if reweight and mode=='six':
                for tilt in (F(1,4),F(1,2),F(3,4)):
                    prices=price(mode,s,k,p,F(phi*h,k)*mean,co,sigma,omega,l1,tilt=tilt,**kwargs)
                    best=list(map(min,best,prices))
        return best
    model.rates=rates
