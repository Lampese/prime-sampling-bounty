"""Check the wheel envelope pointwise in small finite Fourier groups."""
import cmath
from fractions import Fraction as F
from itertools import product
from math import gcd,pi,prod
from taper import kernel
from frequency_envelope import powers

def main():
    cases=0
    for W,(m,n),x in product((1,2,3,6,10),((2,4),(4,6)),(F(-1,4),F(1,3))):
        result=kernel(m,n,x)
        if result is None:continue
        co,_,_=result
        p=127
        phi=sum(gcd(i,W)==1 for i in range(W))
        qs=[q for q in (2,3,5) if W%q==0]
        def val(i):return sum(c*F(max(0,w*W-abs(i)),(w*W)**2) for w,c in co.items())
        points=range(1-n*W,n*W)
        u=[val(i)*W/phi if gcd(i,W)==1 else 0 for i in points]
        env=[val(i)*prod(2 if i%q==0 else F(q-2,q-1) for q in qs) for i in points]
        assert sum(u)==1 and max(env)>0
        for h in range(p):
            e=[cmath.exp(-2j*pi*h*i/p) for i in points]
            a=sum(float(z)*v for z,v in zip(u,e))
            b=sum(float(z)*v for z,v in zip(env,e))
            assert abs(b.imag)<1e-12 and abs(a)<=b.real+1e-12
        upper=powers(co,W)
        for r in range(2,6):assert sum(v**(2*r) for v in env)<=upper[r]
        cases+=1
    print('Verified',cases,'finite Fourier envelopes and their rational moment bounds.')
if __name__=='__main__':main()
