"""Compare genuine inner and outer rectangle prices at four first-window bands."""
from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
import os
import sys

here=Path(__file__).resolve().parent
work=here.parent
parser=ArgumentParser(description=__doc__)
parser.add_argument('--repo',type=Path,default=work/'prime-sampling')
parser.add_argument('--cap',type=Path,default=work/'residue-bridge'/'crt-fast')
parser.add_argument('--mode',choices=('pair','six'),required=True)
parser.add_argument('--grid',type=int,default=3200)
parser.add_argument('--method',choices=('shared','smooth','both','mixture','single'),default='both')
parser.add_argument('--line-cap',action='store_true')
parser.add_argument('--smooth-cap',action='store_true')
parser.add_argument('--cascade',action='store_true')
parser.add_argument('--wide-cap',action='store_true')
parser.add_argument('--shaped-fibre',action='store_true')
parser.add_argument('--angular-fibre',action='store_true')
parser.add_argument('--precise-sieve',action='store_true')
parser.add_argument('--hex-near',action='store_true')
parser.add_argument('--shape-near',action='store_true')
args=parser.parse_args()
sys.path[:0]=[str(args.repo.resolve()),str(args.cap.resolve())]
if (work/'zig-cxx.cmd').is_file():
    os.environ.setdefault('CXX',str(work/'zig-cxx.cmd'))
    os.environ.setdefault('ZIG_GLOBAL_CACHE_DIR',str(work/'zig-cache'))
    os.environ.setdefault('ZIG_LOCAL_CACHE_DIR',str(work/'zig-local-cache'))
from prime_sampling.rectangles import boxes,sieved_lift
from prime_sampling.spectrum import squarerates as sr
import crt_fibres,paley,paley_flat,fejer,mixed

boxes.initialize(F(150),F(4801,32))
sieved_lift.install(boxes)
crt_fibres.install(corner=True,layered=True)
if args.line_cap:
    sys.path.insert(0,str(work/'fibre-lines'))
    import line_cap
    line_cap.install()
if args.smooth_cap:
    sys.path.insert(0,str(work/'fibre-lines'))
    import smooth_cap
    smooth_cap.install()
if args.cascade:
    sys.path.insert(0,str(work/'fibre-lines'))
    import smooth_cascade
    smooth_cascade.install()
if args.wide_cap:
    sys.path.insert(0,str(work/'fibre-lines'))
    import smooth_wide
    smooth_wide.install()
if args.shaped_fibre:
    sys.path.insert(0,str(work/'fibre-lines'))
    import shaped_fibre
    shaped_fibre.install()
if args.angular_fibre:
    sys.path.insert(0,str(work/'fibre-lines'))
    import angular_fibre
    angular_fibre.install(sieve=args.precise_sieve)
if args.hex_near:
    sys.path.insert(0,str(work/'near-lines'))
    import hex_near
    hex_near.install()
if args.shape_near:
    sys.path.insert(0,str(work/'near-lines'))
    import shape_near
    shape_near.install()
baseline=work/'residue-bridge'/('target-layered' if args.grid==3200 else 'target-layered-1600')/f'best-{args.mode}.dat'
if args.grid==4800:baseline=work/'harmonic-research'/'target'/f'{args.mode}-4800.dat'
rows={int(r.split()[0]):list(map(int,r.split())) for r in baseline.read_text().splitlines()}
boxes.rates=lambda *ignored:(F(1),F(1))
if args.method in ('shared','both'):
    paley.install(args.mode,boxes,True)
    paley_flat.install(args.mode,boxes)
if args.method in ('smooth','both'):
    fejer.install(args.mode,boxes,True)
if args.method in ('mixture','single'):
    mixed.install(args.mode,boxes,args.method=='mixture')
for u in map(F,('.42','.45','.47','.49')):
    v=u+F(1,args.grid)
    before=rows[int(u*args.grid)][1:5]
    g,q,_=boxes.joint(u,v,*boxes.inner(u,v))
    og,oq,_=boxes.outer(u,v)
    proposed=list(map(boxes.upint,(g,q,og,oq)))
    best=list(map(min,before,proposed))
    print(u,'old',*before,'candidate',*proposed,'best',*best,flush=True)
if os.name=='nt':
    import _ctypes
    _ctypes.FreeLibrary(sr._lib._handle)
