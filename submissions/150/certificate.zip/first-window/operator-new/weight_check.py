"""Recompute channel, parity, and pairing totals independently of the pricing code."""
from fractions import Fraction as F
from itertools import product


def convolve(a,b):
    out={}
    for (j,k),x in a.items():
        for (s,t),y in b.items():
            key=((j+s)%3,(k+t)%2)
            out[key]=out.get(key,0)+x*y
    return out


checks=0
for internal in (False,True):
    original=F(1,3) if internal else F(1,2)
    for mix in map(F,('0','1/4','1/2','3/4','1')):
        h=original+mix*((F(1,5) if internal else F(1,3))-original)
        w={(j,k):((h if internal else h/2) if j==0 else (1-h)/4)
           for j,k in product(range(3),range(2)) if not (internal and j==0 and k==0)}
        assert sum(w.values())==1
        assert sum(v*v for v in w.values())==h*h/(1 if internal else 2)+(1-h)**2/4
        positive={(0,0):F(1)}
        for r in range(1,6):
            positive=convolve(positive,w)
            reflected={((-j)%3,k):v for (j,k),v in positive.items()}
            totals=convolve(positive,reflected)
            mass=1+2*((3*h-1)/2)**(2*r)
            signed=3*h**(2*r) if internal else 0
            assert 3*(totals[0,0]+totals[0,1])==mass
            assert 3*totals[0,0]==(mass+signed)/2
            checks+=1
print(checks,'exact label and quadratic parity convolutions passed.')
