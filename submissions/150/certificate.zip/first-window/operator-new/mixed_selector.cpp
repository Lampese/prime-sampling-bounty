#include <algorithm>
#include <cmath>

static double coverage(double x,double h,double m){
    auto cdf=[m](double t){
        if(t<=-m)return 0.;
        if(t>=m-1)return 1.;
        if(t<0){double n=t+m;return n*(n+1)/(2*m*m);}
        double n=m-t-1;return 1.-n*(n+1)/(2*m*m);
    };
    return cdf(x)-cdf(x-h);
}
static double wheel_moment(int W,int k){
    double out=1.;
    for(int l=2;l<=W;l++)if(W%l==0){
        out*=(std::pow(2.,k)+(l-1)*std::pow(double(l-2)/(l-1),k))/std::pow(double(l),k);
        W/=l;
    }
    return out;
}
static double envelope_gain(int W,int k,double n,const double *width,const double *coef,double sigma,double l1){
    double knots[]={0,width[0],width[1],width[2],width[3]};
    std::sort(knots,knots+5);
    auto height=[&](double x){
        double u=0.;
        for(int j=0;j<4;j++)if(width[j]>0)u+=coef[j]*std::max(0.,1-x/width[j])*(n/width[j]);
        return std::max(0.,u);
    };
    double low=height(0),sum=std::pow(low,k)/n;
    for(int i=1;i<5;i++){
        if(knots[i]==knots[i-1])continue;
        double hi=height(knots[i]),area=0.;
        for(int j=0;j<=k;j++)area+=std::pow(low,k-j)*std::pow(hi,j);
        sum+=2*((knots[i]-knots[i-1])/n)*area/(k+1);
        low=hi;
    }
    return std::min(1.,sum*wheel_moment(W,k)/(sigma*n*std::pow(l1*n,k-2)));
}
static double trapezoid_gain(int wheel,int r,double m,double n,double sigma,double l1){
    double ratio=m/n;
    double integral=0.,binomial=1.;
    for(int j=0;j<=r;j++){
        integral+=binomial*std::pow(1-ratio,r-j)*std::pow(ratio,j)/(r+j+1);
        binomial=binomial*(r-j)/(j+1);
    }
    double scaled=std::pow(ratio,-r)/n+2*std::pow(ratio,1-r)*integral;
    return std::min(1.,wheel_moment(wheel,2*r)*scaled/(sigma*n*std::pow(l1*n,2*r-2)));
}
extern "C" void choose(double a,double b,double v,double s,double k,double span,double pm,double p,
                       double md,double logy,double qerr,int six,int mix,int *ids){
    bool local=mix>=8;
    if(local)mix-=8;
    bool envelope=mix>=4;
    if(envelope)mix-=4;
    int wheels[]={2,6,30,42,70,210,3,10,15},totients[]={1,2,8,12,24,48,2,4,8},divisors[]={2,4,8,8,8,16,2,4,4};
    double best[]={1.,1.};ids[0]=ids[1]=-1;
    for(int wi=0;wi<(envelope?9:3);wi++){
        double W=wheels[wi],phi=totients[wi],d=std::ceil(span/W)+7;
        double gains[25][33][4][6]={};
        for(int hi=1;hi<=16;hi++){
            double h=std::max(1.,std::floor(d*hi/8)),near=v+1;
            for(int aux=1;aux<=2;aux++){
                double den=std::floor(std::sqrt(v*pm/(2*b*h*aux)));
                if(den<1)continue;
                double U=b*(std::ceil(p/den)+std::ceil((den+1)*aux*h));
                double f=std::max(1.,std::floor(std::log(U)/std::log(a)));
                double rt=std::floor(std::sqrt(2*v*b*h/(pm*aux)))+1;
                near=std::min(near,(1+1/h)*(f-1)+f*(4./3+2/h)*rt);
            }
            double co=(1+md*near/s)/(h*s*s);
            for(int mi=1;mi<=24;mi++)for(int ni=mi;ni<=32;ni++)for(int ti=0;ti<=3;ti++){
                if(mix==0 && ni!=mi)continue;
                if(mix==2 && ti!=0)continue;
                if(mix<2 && ((ni==mi && ti>0)||(ni>mi && ti==0)))continue;
                if(mix==3 && ni==mi && ti>0)continue;
                double m=std::max(1.,std::floor(d*mi/8)),n=std::max(1.,std::floor(d*ni/8));
                if(mix>=2){m=2*std::max(1.,std::floor(m/2));n=2*std::max(1.,std::floor(n/2));}
                if(2*W*(h+2*n+d)>=pm || phi*m<1.e6)continue;
                double wt=ti/4.,tau=(1-wt)/m+wt/n;
                double omega=tau/phi;
                double sigma=((1-wt)*(1-wt)*(2+1/(m*m))/(3*m)+wt*wt*(2+1/(n*n))/(3*n)
                              +2*wt*(1-wt)*(1/n-(m*m-1)/(3*m*n*n)))/phi;
                double l1=tau*divisors[wi]/W;
                if(mix==2){omega=1/(phi*n);sigma=(n-m/3+1/(3*m))/(n*n*phi);l1=divisors[wi]/(W*std::sqrt(m*n));}
                double widths[]={m,n,(m+n)/2,(n-m)/2},coef[4]={};
                if(mix==3){
                    const double menu[]={-.5,-.25,.25,.5};
                    double a=menu[ti];
                    coef[0]=a*a;coef[1]=(1-a)*(1-a);
                    coef[2]=2*a*(1-a)*widths[2]*widths[2]/(m*n);
                    coef[3]=-2*a*(1-a)*widths[3]*widths[3]/(m*n);
                    tau=0;sigma=0;
                    bool valid=true;
                    for(int i=0;i<4;i++)if(widths[i]>0){
                        tau+=coef[i]/widths[i];
                        double slope=0;
                        for(int j=0;j<4;j++)if(widths[j]>0){
                            double lo=std::min(widths[i],widths[j]),hi=std::max(widths[i],widths[j]);
                            sigma+=coef[i]*coef[j]*(1/hi-(lo-1/lo)/(3*hi*hi));
                            if(widths[j]>=widths[i])slope+=coef[j]/(widths[j]*widths[j]);
                        }
                        if(slope< -1.e-12/(n*n))valid=false;
                    }
                    if(!valid)continue;
                    sigma/=phi;omega=tau/phi;l1=tau*divisors[wi]/W;
                }
                if(envelope && mix!=3){coef[0]=1-wt;coef[1]=wt;}
                double *gain=gains[mi][ni][ti];
                if(envelope && gain[2]==0){
                    for(int r=2;r<=5;r++)
                        gain[r]=mix==2?trapezoid_gain(wheels[wi],r,m,n,sigma,l1):
                                      envelope_gain(wheels[wi],2*r,n,widths,coef,sigma,l1);
                }
                double f4=14*p*p*std::sqrt(p)*sigma*l1*l1*(envelope?gain[2]:1.);
                double peak=std::floor((h-1)/2),start=std::floor((h-d)/2);
                auto prob=[&](double x){
                    if(mix==3){
                        double y=0;
                        for(int j=0;j<4;j++)if(widths[j]>0)y+=coef[j]*coverage(x,h,widths[j]);
                        return y;
                    }
                    if(mix!=2)return (1-wt)*coverage(x,h,m)+wt*coverage(x,h,n);
                    double s=(n+m)/2,r=(n-m)/2;
                    return (s*s*coverage(x,h,s)-(r>0?r*r*coverage(x,h,r):0))/(m*n);
                };
                double prev=prob(start),end=prob(peak);if(prev<=0 || end<=0)continue;
                double mean=1/end;
                for(int bin=1;bin<=32;bin++){
                    double high=start+std::floor((peak-start)*bin/32),value=prob(high);
                    double cnt=std::min(k,(2*(high-start+4)*W+4*qerr)/logy+2);
                    mean+=(1/prev-1/value)*cnt/k;prev=value;
                }
                double front=phi*h/k*mean;
                for(int q=0;q<2;q++){
                    double D=six?(q?2./9:3./16):(q?1:.5),labels=six?3:1,C=(six&&!q)?129./128:1.;
                    for(int r=2;r<=5;r++){
                        const int invariants[]={0,0,6,20,70,252};
                        double full=std::pow(4.,r)-2;
                        double evenWeight=(q && !six)?1.:.5;
                        double ratio=local?(full-invariants[r]-2*evenWeight)/full:1.;
                        double lead=1,mult=1;for(int z=1;z<=r;z++){lead*=D*(q?(2*z-1):z);mult*=2*z-1;}
                        double odd=((2*r-1)*(2*r-1)-1)*p,even=((2*r-2)*(2*r-2)-1)*p+2*(2*r-2)*std::sqrt(p)+1;
                        double gen=(!six&&q)?even:C*(odd+even)/2;
                        double paired=labels*lead*std::pow(sigma,r)*p*p;
                        double physical=gen+paired+C*p*p*std::pow(2.*r,2*r)*std::pow(sigma,r-1)*omega*omega;
                        double total=labels*mult*std::pow((q?2:1)*D,r);
                        double spectral=C*full*ratio*p*std::sqrt(p)*sigma*std::pow(p*l1*l1,r-1)*(envelope?gain[r]:1.)+paired+(total-labels*lead)*p*std::pow(sigma,r-1);
                        double off=std::pow(co*std::min(physical,spectral),1./(2*r));
                        if(r==2){
                            double var=std::min(gen+C*p*p*sigma*omega*omega,C*f4*ratio)+labels*(q?2.:1.)*std::pow(D*p*sigma,2)+12*p*sigma*(1+2*sigma);
                            off=std::sqrt(D*sigma+std::sqrt(co*var));
                        }
                        double rate=std::sqrt(front*(1/s+off));
                        if(rate<best[q]){best[q]=rate;ids[q]=((((wi*17+hi)*25+mi)*33+ni)*4+ti);}
                    }
                }
            }
        }
    }
}
