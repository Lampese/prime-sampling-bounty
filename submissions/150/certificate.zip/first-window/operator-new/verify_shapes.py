"""Check the local residue covers and fine Fejer identities with exact integers."""
from fractions import Fraction as F
from math import gcd


def tri(x,m):
    return F(max(0,m-abs(x)),m*m)


def main():
    primes=(5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67)
    for q in primes:
        residues={x*x%q for x in range(1,q)}
        other={(-x)%q for x in range(q) if x not in residues} if q%4==3 else set(range(1,q))-residues
        counts=[sum((b-x)%q in other for x in residues) for b in range(q)]
        assert counts[0]==0 and set(counts[1:])=={len(residues)*len(other)//(q-1)}
        # Two-transitivity gives exactly the asserted number of affine maps.
        joint=[sum(0 in {(u*x+v)%q for x in residues} and y in {(u*x+v)%q for x in residues}
                   for u in range(1,q) for v in range(q)) for y in (0,1)]
        assert joint==[len(residues)*(q-1),len(residues)*(len(residues)-1)]
    for q in (1,2,5,6,7,11,30):
        for m in (1,2,4,9):
            for r in range(q):
                exact=[q*tri(q*j+r,q*m) for j in range(-m-1,m+1)]
                assert all(weight==(1-F(r,q))*tri(j,m)+F(r,q)*tri(j+1,m)
                           for j,weight in zip(range(-m-1,m+1),exact))
                assert sum(exact)==1
        for m,n in ((1,3),(2,5),(4,4),(6,21)):
            true=sum(tri(j,m)*tri(j,n) for j in range(-n,n+1))
            assert true==F(1,n)-F(m*m-1,3*m*n*n)
    print('17 Paley wheels, affine multiplicities, all fine-slot identities, and mixed triangle products passed.')


if __name__=='__main__':main()
