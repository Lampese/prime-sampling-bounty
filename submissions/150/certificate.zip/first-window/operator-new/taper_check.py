from fractions import Fraction as F
from itertools import product
from math import gcd
from taper import kernel

def main():
    count=0
    for m in range(2,9,2):
        for n in range(m,15,2):
            for a,W in product((F(-1,2),F(-1,4),F(1,4),F(1,2)),(1,2,3,6,10)):
                got=kernel(m,n,a)
                if got is None:continue
                co,peak,sigma=got
                f=[(1-a)/(n*W)+(a/(m*W) if (n-m)*W//2<=i<(n+m)*W//2 else 0) for i in range(n*W)]
                values=[]
                phi=sum(gcd(i,W)==1 for i in range(W))
                for x in range(-n*W+1,n*W):
                    raw=sum(v*f[i+x] for i,v in enumerate(f) if 0<=i+x<len(f))
                    interpolated=sum(c*max(0,w*W-abs(x))/(w*W)**2 for w,c in co.items())
                    assert raw==interpolated>=0
                    if gcd(x,W)==1:values.append(raw*W/phi)
                assert sum(values)==1 and max(values)<=peak/phi and sum(v*v for v in values)<=sigma/phi
                count+=1
    print('Verified',count,'exact two-level aperture autocorrelations and residue restrictions.')
if __name__=='__main__':main()
