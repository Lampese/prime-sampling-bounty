"""Hyperplane bounds using the positive Fourier envelope of a reduced-residue taper."""
from fractions import Fraction as F
from functools import cache
from math import prod

@cache
def residue_moment(W,k):
    primes=[q for q in range(2,W+1) if W%q==0 and all(q%d for d in range(2,q))]
    assert prod(primes)==W
    return prod(2**k+(q-1)*F(q-2,q-1)**k for q in primes)/F(W**k)

def powers(weights,W):
    knots=sorted({0,*weights})
    values=[sum(c*max(0,w-j)/w**2 for w,c in weights.items()) for j in knots]
    assert all(l>=h>=0 for l,h in zip(values,values[1:])) and values[-1]==0
    ans={}
    for r in (2,3,4,5):
        k=2*r
        cap=values[0]**k
        for i,(left,right) in enumerate(zip(knots,knots[1:])):
            top,bottom=values[i:i+2]
            avg=(top**(k+1)-bottom**(k+1))/((k+1)*(top-bottom)) if top!=bottom else top**k
            cap+=2*(right-left)*avg
        ans[r]=cap*residue_moment(W,k)
    return ans
