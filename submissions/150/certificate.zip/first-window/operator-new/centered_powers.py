"""Signed moment polynomials for a nonnegative sampled Kummer kernel."""
from fractions import Fraction as F
from math import factorial, isqrt, prod


def nroot_upper(x, degree):
    # Binary integer scaling preserves relative precision for very small rates.
    if x == 0:
        return F(0)
    shift = max(64, 64 + (x.denominator.bit_length()-x.numerator.bit_length())//degree)
    scale = 1 << shift
    n = -(-(x.numerator << (degree*shift))//x.denominator)
    if degree == 2:
        u = isqrt(n)
    else:
        u = 1 << ((n.bit_length()+degree-1)//degree)
        while True:
            v = ((degree-1)*u+n//u**(degree-1))//degree
            if v >= u:
                break
            u = v
    return F(u + int(u**degree < n), scale)


def signed_rate(r, co, lower, upper, current):
    """Certify an upper bound for the sampled mean of |K| with one polynomial."""
    cross, previous = lower[r-1], upper[r-2]
    if not cross or not previous:
        return current
    a = cross/previous
    variance = upper[r]-a*cross
    assert variance >= 0
    threshold = nroot_upper(co*variance, 2)
    def certifies(t):
        return t*t >= a and t**(r-2)*(t*t-a) >= threshold
    if not certifies(current):
        return current
    # The endpoints stay rational and only the upper endpoint is returned.
    low, high = F(0), F(1)
    for _ in range(27):
        mid = (low+high)/2
        if certifies(current*mid):
            high = mid
        else:
            low = mid
    return current*high


def second_moments(labels, D, inside, pmin, pmax, sigma, omega, phi):
    # In each reduced residue class the kernel interpolates its two coarse values.
    lower_sigma = max(F(0), sigma - phi*omega**2/2)
    total = labels*pmax*(pmax-1)
    lower_two = max(F(0),labels*(D*(pmin-1)*(pmin*lower_sigma-1)-
                                  (pmax+1)*sigma)) if pmin*lower_sigma>=1 else F(0)
    lower = {j:lower_two**j/total**(j-1) for j in (1,2,3,4)}
    for j in (2,3,4):
        matchings = prod(range(1,2*j,2)) if inside else factorial(j)
        mass = lower_sigma**(j-1)*max(0,lower_sigma-j*(j-1)//2*omega**2)
        # Off-diagonal deficit at x=y. Sum_v |C_v|^(2j) <= labels.
        paired_lower=labels*(matchings*D**j*(pmin-j)**2*mass-pmax)
        lower[j]=max(lower[j],paired_lower)
    return lower, {1:labels*(D*pmax**2*sigma+2)}
