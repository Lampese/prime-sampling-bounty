"""Enumerate discrete convolutions to check the unequal-width kernel identities."""
from fractions import Fraction as F
from itertools import product
from math import gcd

def hat(n,x):
    return max(n-abs(x),0)

def trapezoid(m,n,x):
    return F(hat((m+n)//2,x)-hat((n-m)//2,x),m*n)

def main():
    cases=0
    for m in range(2,10,2):
        for n in range(m,16,2):
            for W in (1,2,3,6,10):
                count={}
                for i,j in product(range(m*W),range(n*W)):
                    t=i-j+(n-m)*W//2
                    count[t]=count.get(t,0)+1
                residues=sum(gcd(r,W)==1 for r in range(W))
                values=[]
                for x in range(-(m+n)*W//2,(m+n)*W//2+1):
                    k,r=divmod(x,W)
                    target=F(count.get(x,0),m*n*W)
                    value=(1-F(r,W))*trapezoid(m,n,k)+F(r,W)*trapezoid(m,n,k+1)
                    assert target==value
                    if gcd(x,W)==1:values.append(value/residues)
                assert sum(values)==1
                assert max(values)<=F(1,residues*n)
                assert sum(v*v for v in values)<=F(3*m*n-m*m+1,3*m*n*n*residues)
                cases+=1
    print(f'Checked {cases} exact unequal-width convolution and residue distributions.')
if __name__=='__main__':main()
