#include <algorithm>
#include <cmath>
#include <vector>
#include <utility>
#include "paley_wheels.h"
static double reps(double x,double h,double m) {
    double l=std::max(0.,x-h+1), r=std::min(2*m-2,x);
    double mid=std::min(r,m-1), sec=std::max(m,l);
    return std::max(0.,mid-l+1)*(l+mid+2)/2 + std::max(0.,r-sec+1)*(4*m-2-sec-r)/2;
}
extern "C" void choose(double a,double b,double width,double s,double k,double span,
                     double pm,double p,double md,double logy,double qerr,int six,int *ids){
    static const auto wheels=wheel_options(15);
    const double mr[]={1./128,1./32,1./8,1./3,.7,1.5,3,6,12,24};
    const double hr[]={1./16,1./8,.25,.4,.5,2./3,5./6,1.};
    double best[]={1.,1.};ids[0]=ids[1]=-1;
    for(int wi=0;wi<wheels.size();++wi){
        const auto &w=wheels[wi];
        if(w.w>=a)continue;
        const double d=std::ceil(span/w.w)+9, phi2=w.offsets;
        for(int j=0;j<10;++j){
        const double m=std::max(1.,std::floor(d*mr[j])), support=m*phi2;
        if(support<1.e6)continue;
        const double sigma=(2+1/(m*m))/(3*support);
        const double l1sq=std::min(1/phi2,std::pow(w.divs*(1+std::sqrt(w.ell))*w.base/w.w,2));
        const double f4=14*p*std::sqrt(p)*p*sigma*l1sq/(m*m);
        for(int bi=0;bi<8;++bi){
            const double h=std::max(1.,std::floor((d+2*m)*hr[bi]));
            if(2*w.w*(h+2*m+d)>=pm)continue;
            const double maxx=h+2*m-3, start=std::floor((maxx+1-d)/2), peak=std::floor(maxx/2);
            if(start<0 || reps(start,h,m)<=0)continue;
            double co=shared_co(w,h,a,b,width,s,pm,p,md);
            double mean=1/reps(peak,h,m);
            for(int n=1;n<=16;++n){
                double lo=start+std::floor((peak-start)*(n-1)/16), hi=start+std::floor((peak-start)*n/16);
                double cnt=std::min(k,(2*(hi-start+5)*w.w+4*qerr)/logy+2);
                mean+=(1/reps(lo,h,m)-1/reps(hi,h,m))*cnt/k;
            }
            double front=w.phi*h*m*m/k*mean;
            for(int q=0;q<2;++q){
                double D=six?(q?2./9:3./16):(q?1:.5);
                double labels=six?3:1, C=(six&&!q)?129./128:1.;
                double lead=1;
                for(int r=2;r<=5;++r){
                    double lead=1, mult=1;
                    for(int t=1;t<=r;++t){lead*=D*(q?(2*t-1):t);mult*=2*t-1;}
                    const double odd=((2*r-1)*(2*r-1)-1)*p;
                    const double even=((2*r-2)*(2*r-2)-1)*p+2*(2*r-2)*std::sqrt(p)+1;
                    const double gen=(!six&&q)?even:C*(odd+even)/2;
                    const double paired=labels*lead*std::pow(sigma,r)*p*p;
                    const double physical=gen+paired+C*p*p*std::pow(2.*r,2*r)*std::pow(sigma,r-1)/(support*support);
                    const double total=labels*mult*std::pow((q?2:1)*D,r);
                    const double spectral=C*(std::pow(4.,r)-2)*p*std::sqrt(p)*sigma*std::pow(p*l1sq/(m*m),r-1)
                        +paired+(total-labels*lead)*p*std::pow(sigma,r-1);
                    double off=std::pow(co*std::min(physical,spectral),1./(2*r));
                    if(r==2){
                        double var=std::min(gen+C*p*p*sigma/(support*support),C*f4)
                            +labels*(q?2.:1.)*std::pow(D*p*sigma,2)+12*p*sigma*(1+2*sigma);
                        off=std::sqrt(D*sigma+std::sqrt(co*var));
                    }
                    double rate=std::sqrt(front*(1/s+off));
                    if(rate<best[q]){best[q]=rate;ids[q]=(wi*10+j)*8+bi;}
                }
            }
        }}
    }
}
