"""Centered autocorrelations of a two-level aperture on an integer lattice."""
from fractions import Fraction as F

def kernel(m,n,a):
    assert 0<m<=n and (n-m)%2==0
    s,r=(n+m)//2,(n-m)//2
    weights={}
    for width,co in [(m,a*a),(n,(1-a)**2),(s,2*a*(1-a)*s*s/(m*n)),
                     (r,-2*a*(1-a)*r*r/(m*n))]:
        if width and co:weights[width]=weights.get(width,0)+co
    def value(x):
        return sum(c*max(0,w-x)/w**2 for w,c in weights.items())
    knots=sorted({0,n,*weights})
    if any(value(i)<value(j) for i,j in zip(knots,knots[1:])):return None
    assert sum(weights.values())==1 and value(n)==0
    def inner(i,j):
        lo,hi=sorted((i,j))
        return F(1,hi)-F(lo*lo-1,3*lo*hi*hi)
    return weights,value(0),sum(c*e*inner(i,j) for i,c in weights.items() for j,e in weights.items())
