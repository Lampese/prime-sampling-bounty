# 全部非零位移上的细格 Fejér 核

另一个可选位移取两个不等宽均匀盒的差，再将其平移到中心。令粗格偶数宽为 m≤n，细格宽度为 mW 和 nW。写 s=(m+n)/2，r=(n-m)/2。粗格概率为 U(j)=((s−|j|)₊−(r−|j|)₊)/(mn)。当 r=0 时第二项为零。细格概率做单位剩余类限制后乘 W/φ(W)；每个剩余类原本的概率均为 1/W。在同一细格块内，两端点之间的概率按行线性插值，因此 Jensen 给出平方和至多 (3mn−m²+1)/(3mn²φ(W))，峰值至多 1/(nφ(W))。这两个式子也可直接将粗格的两个斜边与平台分别求和得到。逐频率的绝对值是两个均匀盒 Fourier 变换绝对值之积。对每个剩余类 Fourier 调制使用 Cauchy 与 Parseval，得到一范数除以 p 至多 2^ω(W)/(W√(mn))。移位支撑守卫确保两个盒都短于 p。覆盖的累积概率可用 (s²C_s−r²C_r)/(mn) 精确计算，非负、关于中心对称且单峰。下文同一两端素数计数故继续适用。trapezoid_check.py 将有理闭式与逐点卷积作独立比对。

在题目第 2 节的一个实际矩形上，记输入素数数目为 $s_0\ge s$，采样素数数目为 $k_0\ge k$。所有以下选择允许依赖矩形，结论对每个 $t\ne0$ 和每组题设权、标签成立。沿用前一证书 `kernel/centered-tri-proof.txt` 的加权 Cauchy 和有理矩估计。对采样概率 $P$，其几何外因子为 $\sum_{b\in V}P(b)^{-1}/k_0^2$。区间和圆周上额外出现的表示均可保留为下界。

## 平滑与同余筛的 Fourier 一范数

对整数 $N\ge1$ 定义概率 $T_N(n)=(N-|n|)_+/N^2$。设 $Q\ge1$，$S\subseteq\mathbb Z/Q\mathbb Z$ 非空且大小为 $s_1$。取整数位移律

\[
w(n)=\frac Q{s_1}1_{n\bmod Q\in S} T_{mQ}(n).
\]

任一剩余类在 $T_{mQ}$ 下的质量为 $1/Q$，可以把 $T_{mQ}$ 看成两个独立的长 $mQ$ 均匀区间变量之差。因此 $w$ 的质量恰为一。对 $n=Qj+r,0\le r<Q$，有

\[
QT_{mQ}(Qj+r)=(1-r/Q)T_m(j)+(r/Q)T_m(j+1).
\]

平方两边用 Jensen 并先对 $j$ 求和即得 $\sigma=\sum_n w(n)^2\le(2m^2+1)/(3m^3s_1)$，同时 $\|w\|_\infty\le1/(ms_1)$。乘上一个可逆的模 $p$ 伸缩保持这些量和 Fourier 一范数。

写 $c_j=s_1^{-1}\sum_{x\in S}e(-jx/Q)$。整数列 $Q1_S(n)/s_1=\sum_j c_j e(jn/Q)$。$T_N$ 在实频率上的 Fourier 变换是均匀长 $N$ 指数和的平方模，故处处非负。当 $N<p$ 时，对于任何实数 $\alpha$，将这个非负变换在 $\alpha+h/p, 0\le h<p$ 相加，只有整数频率 $n=0$ 对和有贡献，和恰为 $p/N$。对各个 $j/Q$ 使用此式给出

\[
    \frac{\|\widehat w\|_1}{p}\le \frac{\sum_j|c_j|}{mQ}.
\]

对 $S=(\mathbb Z/Q)^\times$ 且 $Q$ 平方自由，单个素因子上的 $c_0=1,\ c_j=-1/(\ell-1) (j\ne0)$。由 CRT，$\sum_j|c_j|=2^{\omega(Q)}$。对任意 $s_1$ 元的单个素数模剩余类集合，由 Parseval 和非零频率上的 Cauchy，$\sum|c_j|\le1+\sqrt{(Q-1)(Q/s_1-1)}$。这些常数没有渐近记号。

## 两种宽度的联合费用

取 $1\le m\le n, 0\le\lambda\le1$，将上式中的 $T_{mQ}$ 换为 $(1-\lambda)T_{mQ}+\lambda T_{nQ}$。每个分量的剩余类分布保持相同。令 $\tau=(1-\lambda)/m+\lambda/n$。最大质量上界为 $\omega=\tau/s_1$，Fourier 费用为 $L=\tau\sum|c_j|/Q$。粗格两种三角的交叉项由有限等差求和得到

\[
\sum_jT_m(j)T_n(j)=1/n-(m^2-1)/(3mn^2).
\]

因此 $\sigma$ 的显式上界为

\[
 \frac1{s_1}\left[(1-\lambda)^2\frac{2m^2+1}{3m^3}+\lambda^2\frac{2n^2+1}{3n^3}
 +2\lambda(1-\lambda)\left(\frac1n-\frac{m^2-1}{3mn^2}\right)\right].
\]

在已报价的 `mixed.py` 中 $Q=W=2,6,30$ 且基点在 $Wi, 0\le i<h$ 上均匀分布。对格点 $x$ 令 $C_m(x)=\sum_{i=0}^{h-1}T_m(x-i)$，$C=(1-\lambda)C_m+\lambda C_n$。$C$ 关于 $(h-1)/2$ 对称，且直到中心单调不减，因为每个 $T_m$ 均为对称单峰函数。每个素数 $b$ 具有唯一的单位剩余类 $r$，其精确覆盖概率是 $((1-r/Q)C(x)+(r/Q)C(x+1))/(h\varphi(Q))$，其中 $x=(b-r)/Q$ 并包括基点的一次整块平移。

所有 $x,x+1$ 可装入连续的 $d=\lceil {\rm span}/W\rceil+7$ 个格内。使这些格从 $x_0=\lfloor(h-d)/2\rfloor$ 起始。令 $c=\lfloor(h-1)/2\rfloor$。对每个 $x_0\le j\le c$，覆盖质量低于 $C(j)/(h\varphi(Q))$ 的点只能处在两端，原因是它的某个粗格位置 $x,x+1$ 低于该水平。各端对应一个长度至多 $(j-x_0+4)W$ 的实际采样坐标区间。按前一证书相同的 $\theta$ 界，两端素数总数至多 $2+[2(j-x_0+4)W+4\varepsilon Y_+]/\log Y_-$。`mixed.py` 以 32 段单侧望远镜估计 $1/C$ 的均值，上界再乘 $h\varphi(W)/k$ 得到有效外因子。支撑条件 $2W(h+2n+d)<p_-$ 保证局部表示无模 $p$ 识别。

`price` 继承题给四、六、八、十阶物理及 Fourier 矩。其中四阶 Fourier 通用项是 $14p^{5/2}\sigma L^2$，高阶通用项是 $(4^r-2)p^{3/2}\sigma(pL^2)^{r-1}$，物理矩中每个重复块扣除两个位置后以 $\omega$ 上包。各类角色常数保留前一证书数值。各误差项在 $\sigma,L,\omega$ 中为非负系数的幂；中心化修正沿用前一证书已经对真实 $\sigma$ 证明的上界，再用这里的上估值。C++ 仅提议整数核宽度和有理混合比例，最终所有回报价与取根均向上。

## Paley 的局部构造与比较

若 $\ell\equiv3\pmod4$，取 $D$ 为二次剩余，$E=-(\mathbb F_\ell\setminus D)$。标准 Paley 差集的非零差重数为 $(\ell-3)/4$，故在 $D+E$ 中每个非零值恰有 $(\ell+1)/4$ 个表示，零没有表示。若 $\ell\equiv1\pmod4$，取 $D$ 为二次剩余，$E$ 为二次非剩余。任意非零伸缩或保持或交换两个集合，故所有非零值的重数相同，且因为 $-1$ 为平方，零无表示。每个非零值重数为 $(\ell-1)/4$。在使用的全部 17 个轮素数上，`verify_shapes.py` 以整数重新检查。Paley 差集性质亦见[差集论文](https://www.combinatorics.org/ojs/index.php/eljc/article/download/v20i1p38/pdf/)。

在共享因素 $\ell$ 上变换 $(D,E)\mapsto(uD+v,uE-v)$，$u\ne0$，不改变非零类的覆盖数。均匀选择仿射变换。设 $r=|D|$；相对于完全均匀残基的碰撞质量，两基点的残基不同时平均比值为 $\alpha=\ell(r-1)/(r(\ell-1))$，相同时为 $\beta=\ell/r$。这是仿射群在互异有序对上二重传递的直接计数。把相同残基条件留下，条件概率为 $1/\ell$。若其余基点轮为 $O$，块长为 $h$，则固定残类给旧 $O,h$ 碰撞估计，全残类基点填入 $O,\ell(h+1)$ 的上游基点块，概率密度比最多 $(h+1)/h$。确切地，以通常素数轮的单位代表 $r_O$ 和共享残基 $r_\ell$ 表示基点，忽略总步长后为 $O\ell i+\ell r_O+O r_\ell$。范围小于 $O\ell(h+1)$，且模 $O$ 为单位。当固定 $r_\ell$，除去公共平移并将系数 $\ell$ 约去即回到老基点。于是平均二阶采样质量至多

\[
 \alpha(1+1/h)^2{\rm co}_{O,\ell(h+1)}+(\beta-\alpha){\rm co}_{O,h}/\ell .
\]

对每一个非零 $t$ 都存在一组仿射变换使实际碰撞质量不超过该上界。位移用相同模数上的 Fejér 核，其 Fourier 常数在所有仿射像上相同。初步比较的四个网格 3200 带上，Paley 方法未单独胜过前一证书，此构造未计入已报告的净改善。

素数筛的 Fourier 展开亦可从 Green 和 Tao 的包络筛角度研究。其 Fourier 系数估计含尺度相关常数，本计算的同余和 Fejér 上界均从上述有限和证明。[Green 与 Tao](https://www.numdam.org/item/10.5802/jtnb.538.pdf)

## 复算

以项目 `63a2d41e8124320784c244336ff36ac5f2285418` 与上一份二层格证书为输入。`probe.py --mode six --method mixture --grid 3200` 计算四个代表带在内、外盒两个方向的真实费用。使用 `pair` 与网格 `1600`、`4800` 作同样复算。`--method single` 只许使用等宽两项，用于区分增益来源。`point_ledger.py` 将这 24 行的四列费用按列取小，保留原四个几何量，并用同一树筛和三网格逐微带覆盖重新定价。`point-ledger.txt` 保存两分支输出。
