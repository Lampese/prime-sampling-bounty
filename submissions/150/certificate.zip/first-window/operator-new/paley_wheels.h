#pragma once
#include <algorithm>
#include <cmath>
#include <utility>
#include <vector>
struct Wheel {double w,phi,base,basephi,ell,divs,offsets,plainphi; std::vector<std::pair<double,double>> near;};
inline std::vector<Wheel> wheel_options(int length){
    const int primes[]={2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67};
    std::vector<Wheel> rows; double w=1,phi=1;
    for(int d=1;d<=length;++d){
        w*=primes[d-1];phi*=primes[d-1]-1;
        for(int i=0;i<=std::min(d,4);++i)for(int j=0;j<d;++j){
            int ell=primes[j];if(ell<5)continue;
            double base=1,basephi=1,divs=1;
            std::vector<std::pair<double,double>> terms{{1,1}};
            for(int z=0;z<d;++z){
                if(z==j)continue;
                if(z>=i){divs*=2;continue;}
                int t=primes[z];base*=t;basephi*=t-1;
                std::vector<std::pair<double,double>> next;
                for(auto [div,mass]:terms){
                    if(t>2)next.push_back({div,mass*(t-2)/(t-1)});
                    next.push_back({div*t,mass/(t-1)});
                }
                terms=next;
            }
            const double plainphi=phi/(basephi*(ell-1));
            rows.push_back({w,phi,base,basephi,double(ell),divs,plainphi*(ell+(ell%4==3?1:-1))/2,plainphi,terms});
        }
    }
    return rows;
}
inline double shared_co(const Wheel &w,double h,double a,double b,double width,double s,double pm,double p,double md){
    auto ordinary=[&](double count){
        double near=0.,K=w.base*count;
        for(auto [div,mass]:w.near){
            double bestn=width+1;
            for(int aux=1;aux<=2;++aux){
                double den=std::floor(std::sqrt(width*pm*div/(2*b*K*aux)));
                if(den<1)continue;
                double U=b*(std::ceil(p/den)+std::ceil((den+1)*aux*K/div));
                double f=std::max(1.,std::floor(std::log(U)/std::log(a)));
                double rt=std::floor(std::sqrt(2*width*b*K/(pm*div*aux)))+1;
                bestn=std::min(bestn,(1+1/count)*(f-1)+f*(4./3+2/count)*rt);
            }
            near+=mass*bestn;
        }
        return (1+md*near/s)/(count*w.basephi*s*s);
    };
    const double q=w.ell,r=(q-1)/2,alpha=q*(r-1)/(r*(q-1)),beta=q/r;
    return alpha*std::pow(1+1/h,2)*ordinary(q*(h+1))+(beta-alpha)/q*ordinary(h);
}
