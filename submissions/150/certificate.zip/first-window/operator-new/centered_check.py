"""Check the exact second moment and signed polynomial against explicit finite fields."""
from cmath import exp, pi
from fractions import Fraction as F
from math import gcd
from centered_powers import second_moments, signed_rate


def log_table(p):
    for a in range(2,p):
        vals=[pow(a,i,p) for i in range(p-1)]
        if len(set(vals))==p-1:
            return dict(zip(vals,range(p-1)))


checked=0
for p in (31,61,151):
    lg=log_table(p)
    for wheel,width in ((2,3),(6,2)):
        phi=sum(gcd(i,wheel)==1 for i in range(wheel))
        N=wheel*width
        weights={z:F(wheel*(N-abs(z)),phi*N*N) for z in range(1-N,N) if gcd(z,wheel)==1}
        sigma=sum(x*x for x in weights.values())
        upper_sigma=F(2*width**2+1,3*width**3*phi)
        assert sum(weights.values())==1 and upper_sigma-phi*F(1,phi*width)**2/2<=sigma<=upper_sigma
        for six in (False,True):
            for inside in (False,True):
                D=(F(2,9) if inside else F(3,16)) if six else (F(1) if inside else F(1,2))
                tags=3 if six else 1
                chars=[]
                for j in range(tags):
                    for i in (0,1):
                        c=(0 if inside else (p-1)//5)+i*(p-1)//2+j*(p-1)//3
                        if not c:continue
                        w=(F(1,3) if not j else F(1,6)) if six and inside else (F(1,4) if not j else F(1,8)) if six else F(1) if inside else F(1,2)
                        values=[exp(2j*pi*c*lg[x]/(p-1)) if x else 0 for x in range(p)]
                        chars.append((w,j,values))
                assert sum(x[0] for x in chars)==1 and sum(x[0]**2 for x in chars)==D
                totals=[0.]*6
                for v in range(tags):
                    coeff=[float(w)*exp(2j*pi*j*v/3) for w,j,_ in chars]
                    powers=[0.]*6
                    for x in range(p):
                        for y in range(p):
                            if x==y:continue
                            val=abs(sum(c*sum(float(b)*g[(x+z)%p]*g[(y+z)%p].conjugate() for z,b in weights.items())
                                        for c,(_,_,g) in zip(coeff,chars)))
                            for j in range(1,6):powers[j]+=val**(2*j)
                    exact=float(D*(p-1)*(p*sigma-1))+abs(sum(coeff))**2*float(2-(p+1)*sigma)
                    assert abs(exact-powers[1])<1e-8*max(1,abs(exact))
                    for j in range(1,6):totals[j]+=powers[j]
                low,upper=second_moments(tags,D,inside,p,p,upper_sigma,F(1,phi*width),phi)
                assert all(float(val)<=totals[j]+1e-8*max(1,totals[j]) for j,val in low.items())
                assert totals[1]<=float(upper[1])+1e-8
                checked+=1
for values in ((0,1,2,4),(1,2,6,9),(0,0,2,3)):
    vals=[F(x,10) for x in values]
    rho=[F(1,16),F(1,4),F(1,8),F(1,2)]
    co=sum(t*t for t in rho)
    moments={j:sum(x**(2*j) for x in vals) for j in range(1,6)}
    for degree in (3,4,5):
        assert signed_rate(degree,co,moments,moments,F(1))>=sum(x*t for x,t in zip(vals,rho))
print(checked,'explicit character families, each through the tenth power; 9 signed polynomial checks passed.')
