#include <algorithm>
#include <cmath>
#include <vector>
#include <utility>
#include "paley_wheels.h"
extern "C" void flat(double a,double b,double width,double s,double k,double span,
                     double pm,double p,double md,double logy,double qerr,int six,int *ids){
    static const auto wheels=wheel_options(19);
    const double ratios[]={.015625,.0625,.25,.5,2./3,.75,1.,1.25,1.5,2.,3.,6.,12.};
    double best[]={1.,1.}; ids[0]=ids[1]=-1;
    for(int wi=0;wi<wheels.size();++wi){
        auto &w=wheels[wi];
        if(w.w>=a)continue;
        double d=std::ceil(span/w.w)+9;
        for(int side=0;side<13;++side){
            double h=std::max(1.,std::floor(d*ratios[side]));
            double co=shared_co(w,h,a,b,width,s,pm,p,md);
            for(int j=0;j<13;++j){
            double m=std::max(1.,std::floor(d*ratios[j])),peak=std::min(h,m),rep=std::min(peak,std::floor((h+m-d)/2));
            double support=m*w.offsets,rr=1/support;
            if(rep<1 || support<1.e6 || 2*(std::max(h,m)+d)*w.w>=pm)continue;
            double mean=1./peak;
            for(int n=1;n<=16;++n){
                double low=rep+std::floor((peak-rep)*(n-1)/16),high=rep+std::floor((peak-rep)*n/16);
                double cnt=std::min(k,(2*(high-rep+5)*w.w+4*qerr)/logy+2);
                mean+=(1./low-1./high)*cnt/k;
            }
            double front=w.phi*h*m/k*mean;
            for(int q=0;q<2;++q){
                double D=six?(q?2./9:3./16):(q?1:.5);
                double labels=six?3:1, C=(six&&!q)?129./128:1.;
                double lead=1;
                for(int r=2;r<=6;++r){
                    lead=1;
                    for(int t=1;t<=r;++t)lead*=D*(q?(2*t-1):t);
                    double odd=((2*r-1)*(2*r-1)-1)*p;
                    double even=((2*r-2)*(2*r-2)-1)*p+2*(2*r-2)*std::sqrt(p)+1;
                    double gen=(!six&&q)?even:(C*(odd+even)/2);
                    double paired=labels*lead*std::pow(rr,r)*p*p;
                    double half=gen+paired+C*p*p*std::pow(2.*r,2*r)*std::pow(rr,r+1);
                    double bound=std::pow(co*half,1./(2*r));
                    if(r==2){
                        double var=gen+C*p*p*rr*rr*rr+labels*(q?2.:1.)*std::pow(D*p*rr,2)+12*p*rr;
                        bound=std::min(bound,std::sqrt(D*rr+std::sqrt(co*var)));
                    }
                    double rate=std::sqrt(front*(1/s+bound));
                    if(rate<best[q]){best[q]=rate;ids[q]=(wi*13+side)*13+j;}
                }
            }
        }}
    }
}
