from fractions import Fraction as F
from math import gcd,isqrt
from pathlib import Path
from itertools import product
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'prime-sampling'))
from hex_near import cap
from shape_near import cap as shape_cap


def prime(n):return n>=2 and all(n%i for i in range(2,isqrt(n)+1))


def main():
    counts=lattices=0
    for p,A,B,H,W in product((1009,4001),(11,23),(43,53),(2,5,11),(1,2,6)):
        V=B-A
        value=shape_cap(A,B,V,p,p,W,H)
        if value is None:continue
        ps=[v for v in range(A,B+1) if prime(v)]
        base=[i for i in range(W*H) if gcd(i,W)==1]
        diffs={}
        for x,y in product(base,repeat=2):diffs[(x-y)%p]=diffs.get((x-y)%p,0)+1
        for a0 in ps:
            for t in range(1,p,29):
                real=sum(diffs.get(t*(pow(a0,-1,p)-pow(c,-1,p))%p,0) for c in ps if c!=a0)
                assert F(real,len(base))<=value,(p,A,B,H,W,a0,t)
                counts+=1
        for r in (1,H,W*H):
            if 16*B*B*r>=p*V*(2*B+V):continue
            for lam in range(1,p,29):
                found=False
                for q in range(1,1+isqrt(p*V//((2*B+V)*r))):
                    u=q*lam%p;u=min(u,p-u)
                    twice=max(4*B*q*r,2*(2*B-V)*q*r+V*u)
                    if twice**2*(2*B+V)<=16*B*B*p*r*V:
                        found=True;break
                assert found,(p,r,lam)
                lattices+=1
    print('direct ordered-prime wheel collisions:',counts)
    print('independent hexagon Minkowski witnesses:',lattices)


if __name__=='__main__':main()
