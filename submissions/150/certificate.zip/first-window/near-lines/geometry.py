from fractions import Fraction as F
from math import isqrt
from pathlib import Path
import sys
work=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(work/'fibre-lines'))
from probe import boxes
from hex_near import sqrt_upper
from brun_near import coefficient

if __name__=='__main__':
    boxes.initialize(F(150),F(4801,32))
    def collect(A,B,V,s,k,span,p0,p1):
        for W in (6,30):
            R=max(1,span//W)
            J=sqrt_upper(F(4*B*B*R*V,p0*(2*B+V)))
            U=sqrt_upper(F(16*B**4*p1*R,V*(2*B+V)))
            f=0;power=A
            while power<=U:power*=A;f+=1
            K=U//(A*A)
            # With N_j=2pj-u a0, the m restriction cuts to width at most
            # m*(2B V)/(2p) on each sign side.
            print(' ',W,'A exponent',round(A.bit_length()/p0.bit_length(),4),'f',f,'R/B',float(F(R,B)),
                  'K/J',float(K/J),'VB/p',float(F(V*B,p0)),'old dense',float(J),flush=True)
            if W==6:print('  second-prime coefficient and wheel error',float(coefficient(A,B,V,p0,p1)[0]),coefficient(A,B,V,p0,p1)[1],flush=True)
        return F(1),F(1)
    boxes.rates=collect
    for a in map(F,('.45','.47','.49')):
        print('u',a,flush=True)
        v=a+F(1,3200)
        boxes.joint(a,v,*boxes.inner(a,v))
    if sys.platform=='win32':
        import _ctypes
        from prime_sampling.spectrum import squarerates as sr
        _ctypes.FreeLibrary(sr._lib._handle)
