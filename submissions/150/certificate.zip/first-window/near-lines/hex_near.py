"""Weighted prime reciprocal neighbours from an anisotropic lattice hexagon."""
from fractions import Fraction as F
from functools import lru_cache
from math import isqrt
from prime_sampling.rectangles.near import wheel_expansion


def sqrt_upper(frac):
    scale=10**12
    n=isqrt(frac.numerator*scale**2//frac.denominator)
    if n*n*frac.denominator<frac.numerator*scale**2:n+=1
    return F(n,scale)


@lru_cache(maxsize=65536)
def unit(A,B,V,p0,p1,R,edge):
    # edge is the last incomplete CRT block, zero for a complete interval.
    if not (2<A<=B<p0 and 0<V<=B and R>=1 and p0<=p1 and
            16*B*B*R<p0*V*(2*B+V)):return None
    # 2 B T/V bounds |2jp-ua0| on the hexagon at radius R.
    umax2=F(16*B**4*p1*R,V*(2*B+V))
    power=A*A;f=0
    while power<=umax2:
        f+=1;power*=A*A
    if f==0:return F(0)
    linewidth=sqrt_upper(F(4*B*B*R*V,p0*(2*B+V)))
    return (f-1)*(1+edge)+f*linewidth*(F(2,3)+edge)


@lru_cache(maxsize=65536)
def cap(A,B,V,p0,p1,W,H):
    if H<1 or 2*W*H>=p0:return None
    terms,den=wheel_expansion(W)
    bounds=[]
    for d,mult in terms:
        assert W%d==0
        price=unit(A,B,V,p0,p1,W*H//d,F(1,H) if W>1 else F(0))
        if price is None:return None
        bounds.append(mult*price)
    return sum(bounds)/den


def install():
    from prime_sampling.spectrum import squarerates as sr
    old=sr.weighted_near
    @lru_cache(maxsize=65536)
    def joined(A,B,V,p0,p1,W,H):
        prior=old(A,B,V,p0,p1,W,H)
        extra=cap(A,B,V,p0,p1,W,H)
        return prior if extra is None else min(prior,extra)
    sr.weighted_near=joined
