# A hexagonal lattice for weighted reciprocal neighbours

Fix a prime \(p\in[p_0,p_1]\), one odd prime \(a_0\) and the other primes \(c\) in the same interval \([L,U]\subset[A,B]\) of width \(w\le V\). Fix \(t\ne0\bmod p\). We count \(c\ne a_0\) such that the signed difference \(h=t(a_0^{-1}-c^{-1})\bmod p\) has small absolute value. For a divisor \(d\) of the wheel restrict to \(d\mid h\), and put \(n=h/d\), \(\lambda=2t/(a_0 d)\bmod p\). Then
\[
 cn\equiv\lambda (c-a_0)/2\pmod p.
\]
The lattice \(\{(q,u):u\equiv q\lambda\bmod p\}\) has determinant \(p\). For a vector in this lattice write
\[
 j=[qcn-u(c-a_0)/2]/p .
\]
All the \(j\)'s are integers. Allowing \(c=a_0,n=0\) includes \(j=0\).

For \(-r\le n\le r\), the numerator is bilinear in \(c,n\). Its extrema are attained at corners of \([L,U]\times[-r,r]\). We may negate the vector so \(q\ge0\). For the two horizontal extremes the largest possible width is \(2Uqr\). The other opposite‑corner width is \(qr(L+U)+|u|(U-L)/2\). Combining the two cases gives
\[
 \operatorname{width}(p j)
 \le 2Br|q|+V(|u|/2-r|q|)_+ .
\]
Equivalently impose the two inequalities
\[
 2Br|q|\le T,\qquad (2B-V)r|q|+(V/2)|u|\le T .
\]
The resulting centrally symmetric convex hexagon has area
\[
 4\int_0^{T/(2Br)}(2/V)(T-(2B-V)rx)\,dx
      = T^2(2B+V)/(B^2 rV).
\]
By Minkowski's convex body theorem it contains a nonzero lattice point at \(T=2B\sqrt{p rV/(2B+V)}\). Equality in the area threshold follows by taking a descending sequence with strict inequality and using discreteness. For \(1\le r\le R\), both \(q<p\) and \(|u|<p\) hold under the guard \(16B^2R<p_0 V(2B+V)\). Therefore \(q\ne0,\ u\ne0\), since \(\lambda\ne0\). Dividing by their gcd is optional. All arguments hold for this vector, whatever the initial centre \(t/a_0\).

Each contributing \(c\) divides \(N_j=2jp-u a_0=c(2qn-u)\), a nonzero integer since \(p\nmid ua_0\). The largest value of \(2r|q|+|u|\) over the same hexagon is \(2T/V\) (check the axis and the sloped/vertical corner, using \(V\le B\)). Hence
\[
 |N_j|\le 2BT/V,\qquad
 |N_j|^2\le 16B^4p_1 R/[V(2B+V)].
\]
If \(f\) is the integer number of powers \(A^{2i},i\ge1\), below or equal to that last upper bound, a line contains at most \(f\) distinct prime coordinates including the possible \(a_0\). An interval of \(j\)-width \(T/p\) contains at most \(1+T/p\) integers. Subtract the single known point \(a_0\), which does not contribute to the off-diagonal near term. Thus at radius \(r\),
\[
 \#\{c\ne a_0:0<|n|\le r\}\le (f-1)+
   f\,2B\sqrt{rV/[p_0(2B+V)]}.
\]
For \(0\le r<1\) the left side is zero. For \(f=0\) existence of the known point gives a contradiction, so this case can be returned as zero. The computation uses exact powers and an upward rational square root.

For an ordinary interval of integer basepoints, the normalized intersection at difference \(n\) is the triangular weight \((1-|n|/R)_+\). Integrating the preceding counting function from 0 to \(R\) and dividing by \(R\) gives \(f-1+(2/3)f\,2B\sqrt{RV/[p_0(2B+V)]}\). With a wheel \(W\), put \(R=WH/d\). The incomplete last residue block costs at most one further full block among the \(H\) original blocks; thus multiply the endpoint count by \(1/H\) and add it when \(W>1\). To see this, in any interval of length \(WH-|h|\), each admissible residue class modulo \(W\) occurs at most \((WH-|h|)/W+1\) times. Its complete-block autocorrelation ratio equals the nonnegative expansion over \(d\mid W\) in the upstream wheel_expansion. After summing each divisor's price with these coefficients one gets a pointwise upper bound on the requisite near mass. The random complementary wheel with exact triangular weights can use the \(W=1\) case on every divisor term as usual.

For every rectangular cell satisfying the guards, this yields the valid sampling bound \(co\le(1+md\,near/s)/(Js^2)\). No averaging over the centre, frequency or prime is required.

Cilleruelo and Garaev use a rational approximation to lift translated modular hyperbolas to integer factorizations. Here one coordinate being prime bounds the number of solutions on a line by an explicit number of distinct prime divisors, and the anchored odd-coordinate relation determines the hexagon above. This proof uses explicit geometry instead of an unspecified subpower divisor factor. [Cilleruelo and Garaev, Concentration points on two and three dimensional modular hyperbolas and applications](https://arxiv.org/abs/1007.1526)
