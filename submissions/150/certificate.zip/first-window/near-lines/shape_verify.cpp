#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <numeric>
#include <vector>

using I = std::int64_t;
constexpr I K=1024, N=96, unit=K*K;
constexpr I limit=(1415*K+999)/1000;
I target=870; // target / 1000
std::array<I,N+1> baseline;
std::int64_t boxes=0, accepted=0, direct=0;
I highest=0;

I isqrt_upper(I x) {
    I lo=0,hi=1;
    while(hi<x/hi+(x%hi!=0))hi*=2;
    while(hi-lo>1){I m=(hi+lo)/2;if(m<x/m+(x%m!=0))lo=m;else hi=m;}
    return hi;
}

struct Region { I x0,x1,y0,y1,z0,z1; };
struct Vector {I x,y;int a,b;};
bool inside(Region r) {
    return r.x0+r.y0<=limit;
}

bool check(Region r) {
    if(!inside(r))return true;
    if(1000*(r.x1+2*r.y1)<=2*K*target){++direct;return true;}
    if(r.y0==0)return false;
    std::vector<Vector> vs;
    for(int j=0;j<=3;++j)for(int i=-5;i<=4;++i) {
        if(std::gcd(std::abs(i),j)!=1)continue;
        I h0=i*K+j*r.z0,h1=i*K+j*r.z1;
        I x0=std::min({r.x0*h0,r.x0*h1,r.x1*h0,r.x1*h1})+j*K*unit/r.y1;
        I x1=std::max({r.x0*h0,r.x0*h1,r.x1*h0,r.x1*h1})+(j*K*unit+r.y0-1)/r.y0;
        I x=std::max(std::abs(x0),std::abs(x1));
        I y=r.y1*std::max(std::abs(h0),std::abs(h1));
        if(x<=6*unit && y<=6*unit)vs.push_back({x,y,i,j});
    }
    I maxbill=0;
    for(int state=0;state<4;++state) {
        auto prices=baseline;
        for(auto v:vs) {
            int residue=state==3?v.b:v.a+state*v.b;
            I factor=residue%3==0 ? 2 : 3;
            I tic=factor*v.x,running=factor*v.y*N;
            for(int j=1;j<=N;++j){running+=tic;prices[j]=std::min(prices[j],running);}
        }
        I bill=std::accumulate(prices.begin()+1,prices.end(),I{0});
        maxbill=std::max(maxbill,bill);
        if(1000*bill>target*(3*unit*N*N))return false;
    }
    highest=std::max(highest,maxbill);
    ++accepted;return true;
}

bool cover(Region r) {
    ++boxes;
    if(check(r))return true;
    std::array<I,3> length={r.x1-r.x0,r.y1-r.y0,r.z1-r.z0};
    int dim=std::max_element(length.begin(),length.end())-length.begin();
    if(length[dim]<=1) {
        std::cout<<"unclosed "<<r.x0<<" "<<r.y0<<" "<<r.z0<<"\n";
        return false;
    }
    Region l=r,h=r;
    if(dim==0){l.x1=h.x0=(r.x0+r.x1)/2;}
    if(dim==1){l.y1=h.y0=(r.y0+r.y1)/2;}
    if(dim==2){l.z1=h.z0=(r.z0+r.z1)/2;}
    return cover(l)&&cover(h);
}

int main(int argc,char**argv) {
    if(argc>1)target=std::atoi(argv[1]);
    if(target<1 || target>1000)return 2;
    for(I j=1;j<=N;++j)baseline[j]=isqrt_upper(18*j*N*unit*unit);
    bool ok=cover({0,limit,0,limit,0,K});
    std::cout<<"ok "<<ok<<" target over 1000 "<<target<<" visited "<<boxes<<" bounded "<<accepted<<" direct "<<direct
             <<" maximum checked numerator "<<highest<<" denominator "<<3*unit*N*N<<"\n";
    return ok?0:1;
}
