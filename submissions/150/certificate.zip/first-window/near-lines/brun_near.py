"""Price a second distinct prime factor on the same lifted neighbour line."""
from fractions import Fraction as F
from functools import cache
from math import gcd
from hex_near import sqrt_upper


@cache
def periodic(W):
    prefix=[0]
    for k in range(2*W):
        prefix.append(prefix[-1]+(gcd(k,W)==1))
    return prefix


@cache
def maximum(W,n):
    q,r=divmod(n,W);p=periodic(W)
    return q*p[W]+max(p[i+r]-p[i] for i in range(W))


def sieve_width(width,odd_only,A):
    n=width.__floor__()+1
    primes=(3,5,7,11,13) if odd_only else (2,3,5,7,11,13)
    W=1;best=n
    for q in primes:
        if q>=A:break
        W*=q;best=min(best,maximum(W,n))
    return best


@cache
def coefficient(A,B,V,p0,p1):
    D=F(2*B*V-V*V,2*p0)
    # odd u: N is odd and its cofactor runs through odd numbers.
    # even u: divide out 2 and let the cofactor run through all integers.
    sieve=max(sieve_width(D,True,A),sieve_width(2*D,False,A))
    return F(B*p1*sieve,V*A*A),sieve


def unit(A,B,V,p0,p1,R,edge=0):
    if not (3<A<=B<p0 and 0<V<=B and p0<=p1 and R>=1 and
            16*B*B*R<p0*V*(2*B+V)):return None
    k,rest=coefficient(A,B,V,p0,p1)
    width=sqrt_upper(F(4*B*B*R*V,p0*(2*B+V)))
    return (1+edge)*rest+(F(2,3)+edge)*(1+k)*width
