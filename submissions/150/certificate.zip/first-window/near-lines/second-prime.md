# Counting the extra large prime on a line

This alternative investigates an explicit prime sieve for the possible excess on the same lifted integer line. It is not enabled by the installed near hook.

Use the vector of proof.md with width scale \(T\), and set \(N_j=2pj-u a_0\). Each distinct \(c\) on line \(j\) is a prime divisor of \(N_j\). If there are \(s_j\) such primes then \(s_j\le1+\binom{s_j}{2}\). Each pair gives a distinct positive cofactor \(m=|N_j|/(c_1c_2)\). When \(u\) is even, use \(N_j/2\) in place of \(N_j\) and its associated cofactors to keep the linear form primitive.

Across the real label interval, the sum of the positive and negative extrema in absolute value of \(N_j\), counting a missing sign as zero, is at most \(2BT/V\). If both signs occur this sum is the range width, at most \(2p(T/p)=2T\); if only one sign occurs use the largest absolute value from proof.md. Every prime product is at least \(A^2\). If \(u\) is odd all \(m\) are odd and the total number of sign/cofactor possibilities is therefore at most \(BT/(VA^2)+1\). If \(u\) is even, division by 2 gives the same bound with all cofactors allowed.

On fixing a sign and a cofactor not divisible by \(p\), its divisibility condition is one residue class in \(j\). Cases divisible by \(p\) are empty. Write \(j=j_m+mt\). In the odd case the pair-product condition imposes a real interval of width at most \(D=(2BV-V^2)/(2p_0)\) in \(t\), since both primes lie in the same interval of width at most \(V\) and upper endpoint at most \(B\). The quotient giving the prime product is a linear form of slope \(\pm2p\). For an odd squarefree wheel \(W\) with all its primes \(<A\), its coprimality to \(W\) says that \(t\) lies in a translate of the units modulo \(W\). Bound their number by the greatest number of units in any cyclic interval of \(\lfloor D\rfloor+1\) successive integers, counting whole periods first. In the even case the width bound is \(2D\), slope \(\pm p\), and the wheel may include 2. Let \(\Psi\) be the larger of the two resulting bounds, choosing the wheel separately.

The ordinary label bound \(1+T/p\), plus this surplus estimate and minus the anchor, gives a count at most
\[
 \Psi+\frac{T}{p}\left(1+\frac{B p_1\Psi}{V A^2}\right).
\]
It may be integrated against the triangular weight as in proof.md. The same proof works for lines with more than two primes since it charged all unordered pairs.

The first-window grid-3200 inner rectangles give surplus coefficients \(Bp_1\Psi/(VA^2)\) of \(6.88\cdot10^9\) and \(198.30\) in the two directions at \(u=.45\); \(2.08\cdot10^7\) and \(298.28\) at \(u=.47\); \(63049.36\) and \(2715.24\) at \(u=.49\). Each determinant currently caps the total at \(f=2\). This direct cofactor sieve does not improve any of these prices. The independent residue-class exclusions in shape-proof.md do improve them. Files brun_near.py and geometry-brun.txt record the comparison.
