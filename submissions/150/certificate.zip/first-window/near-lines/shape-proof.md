# Simultaneous scales and the missing line modulo three

Use all the conventions of proof.md. For radius \(R\) set \(S=\sqrt{BVR/p}\). Work with the lattice in normalized coordinates
\[
 X=\frac{2BRq}{pS},\qquad Y=\frac{Vu}{2pS}.
\]
Its covolume equals 1. At a fractional radius \(\tau R\), the ordinary upper bound for the interval of \(j\)'s is \(S(|X|\tau+|Y|)\). The hexagon argument, or Minkowski in the simpler diamond, also supplies an unconditional upper bound \(S\sqrt{2\tau}\), with its own direction for each \(\tau\).

If \(3\mid q\) for a primitive lattice vector and \(p\ne3\), then \(3\nmid u\). As \(c\) is a prime greater than 3, the quantity \(e=(c-a_0)/2\) misses one residue class modulo 3. Thus \(j=(qcn-ue)/p\) misses one of its three classes. An interval of width \(L\) contains at most \(2L/3+2\) permitted integers. For \(3\nmid q\) use \(L+1\). In the element-independent absolute term it is safe to use 2 in both cases.

At the top radius Minkowski's diamond theorem produces a primitive normalized lattice vector of norm \(|X|+|Y|\le\sqrt2\). Independent reflections in the two coordinate axes allow us to write it \(v=(x,y)\), \(x,y\ge0\); the normalized norms used for pricing are invariant under these reflections. Complete it to a lattice basis \((v,w)\) with \(\det(w,v)=1\). In the physical regions \(y>0\); our covering also includes its limiting edge. Adding an integral multiple of \(v\) gives
\[
  w=(1/y+x z,y z),\qquad 0\le z\le1 .
\]
The vector \(i v+jw\) is primitive in the lattice whenever \(\gcd(i,j)=1\), and its two normalized coördinates are \(j/y+x(i+jz),\ y(i+jz)\). The denormalized original basis has determinant \(\pm p\) and thus is invertible modulo 3. The condition for divisibility of its first coördinate by 3 must be one of the four projective conditions
\[
 j\equiv0,\qquad i+\kappa j\equiv0\quad(\kappa=0,1,2).
\]
This includes all possibilities even for unknown \(t\). For each vector let \(d_{ij}=2/3\) in its distinguished residue class, and \(d_{ij}=1\) otherwise.

The finite lemma checked by shape_verify.cpp states that the integral over \(0\le\tau\le1\) of
\[
 \min\big\{\sqrt{2\tau},\ \min_{i,j} d_{ij} (|j/y+x(i+jz)|\tau+|y(i+jz)|)\big\}
\]
is at most the rational target printed by the checker divided by 1000. Only primitive combinations with \(0\le j\le3,\ -5\le i\le4\) and both coordinates of absolute value at most 6 are used; the upper bound consequently applies to the true optimum over all usable directions.

Here is the integer certificate mechanism, included to permit independent reproduction. Cover \((x,y,z)\) by recursively subdividing integer lattice boxes in units of \(1/1024\) with \(0\le x,y\le\lceil1.415\cdot1024\rceil/1024,\ x+y\le\sqrt2,\ 0\le z\le1\). A box with the lower sum \(> \lceil1.415\cdot1024\rceil/1024\) is disjoint. If \(x_{\max}/2+y_{\max}\) is below the target then \(v\) alone proves the integral bound. For a remaining box with \(y_{\min}>0\), bound the products \(x(i+jz)\) by all four corners of their factor intervals, bound \(j/y\) by its two extrema and round outward to units \(1/1024^2\). Bound \(|y(i+jz)|\) by \(y_{\max}\max|i+jz|\). Discard any direction whose upper coordinate bounds exceed 6. Each of the 96 equal intervals in \(\tau\) is priced at its right endpoint, since all candidate bounds increase. At each right endpoint take the smaller of an upward integer square root for \(\sqrt{2\tau}\) and each candidate line price, using the supplied two coordinate upper bounds and the projective state. The common denominator for the final integral is \(3\cdot1024^2\cdot96^2\). A box succeeds only if every projective state succeeds. Uncovered boxes are bisected, and failure to subdivide is an explicit nonzero exit. Integer intermediates are below \(2^{63}\); the largest square-root operand is \(18\cdot96^2\cdot1024^4\).

Restrict to \(144BR<p_0V,\ 9V<p_0BR\). Then all retained directions have \(q,u\) of absolute value \(<p\), so neither coördinate vanishes. For them the numerator \(c(2qn-u)\) has absolute value at most \((6+12B/V)pS\) at all radii. For the additional ordinary-Minkowski direction at \(\tau R\), its own diamond gives \(|q|<p\) whenever \(\tau R\ge1\), \(|u|<p\) by the same guards, and its numerator satisfies the same upper bound. Radii below 1 have zero neighbours. Thus a common possible-prime-factor count \(f\) follows from \((6+12B/V)^2p_1BVR\), as in proof.md. The certified integral near is bounded by
\[
 (2f-1)+ f\,S_0 C,\qquad S_0=\sqrt{BVR/p_0},
\]
with \(C\) the certified rational target. One uses \(2f-1+1.415 fS_0\) for any incomplete-wheel endpoint contribution, together with the complete-block CRT expansion. The minimum with the original hexagon and upstream estimates protects cases with a larger common factor count \(f\).

Using target 865 gives \(C=173/200\). The checker visited 14,323 regions, with largest nontrivial accepted numerator 25,077,232,195 over denominator 28,991,029,248. Compile shape_verify.cpp as C++17, then run the binary with argument 865. The output in shape-865.txt is the successful complete certificate.
