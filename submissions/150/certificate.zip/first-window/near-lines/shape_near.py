"""Certified mod-3 lattice shape bound for a triangular near kernel."""
from fractions import Fraction as F
from functools import lru_cache
from hex_near import sqrt_upper,cap as hex_cap
from prime_sampling.rectangles.near import wheel_expansion


@lru_cache(maxsize=65536)
def unit(A,B,V,p0,p1,R,edge):
    if not (3<A<=B<p0 and 0<V<=B and p0<=p1 and R>=1 and
            144*B*R<p0*V and 9*V<p0*B*R):return None
    # All retained vectors have both normalized coordinates <=6.
    max2=F((6*V+12*B)**2*p1*B*R,V)
    f=0;power=A*A
    while power<=max2:f+=1;power*=A*A
    if not f:return F(0)
    S=sqrt_upper(F(B*V*R,p0))
    # 865/1000 is certified in shape-865.txt by the finite integer checker.
    return (2*f-1)*(1+edge)+f*S*(F(173,200)+edge*F(1415,1000))


@lru_cache(maxsize=65536)
def cap(A,B,V,p0,p1,W,H):
    first=hex_cap(A,B,V,p0,p1,W,H)
    if first is None:return None
    terms,den=wheel_expansion(W);prices=[]
    for d,mult in terms:
        out=unit(A,B,V,p0,p1,W*H//d,F(1,H) if W>1 else F(0))
        if out is None:return first
        prices.append(mult*out)
    return min(first,sum(prices)/den)


def install():
    from prime_sampling.spectrum import squarerates as sr
    old=sr.weighted_near
    @lru_cache(maxsize=65536)
    def joined(A,B,V,p0,p1,W,H):
        prior=old(A,B,V,p0,p1,W,H);extra=cap(A,B,V,p0,p1,W,H)
        return prior if extra is None else min(prior,extra)
    sr.weighted_near=joined
