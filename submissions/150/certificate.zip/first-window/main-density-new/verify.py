"""Mass of the prime interval, including an actual upper witness in both p mod 3 branches."""
from argparse import ArgumentParser
from decimal import Context, Decimal
from fractions import Fraction as F
from math import factorial


LAM=F(1,32)
ETA=F(18663,10**16)
UNIT=10**12


def bounds(v,op):
    v=F(v)
    c=Context(prec=90)
    x=c.divide(Decimal(v.numerator),Decimal(v.denominator))
    f=getattr(c,op)
    return F(c.next_minus(f(c.next_minus(x)))),F(c.next_plus(f(c.next_plus(x))))


def display(x,up=False,digits=15):
    scale=10**digits
    units=(x*scale).__ceil__() if up else (x*scale).__floor__()
    return f'{units//scale}.{units%scale:0{digits}d}'


def mass(zlo,zhi):
    a0,a1=bounds(32,'ln')
    assert zlo<=zhi and zlo-a1>=141
    def moment(j,a):
        return factorial(j)*(1-LAM*sum(a**k/factorial(k) for k in range(j+1)))
    order=14
    low=sum(moment(j,a1)/zhi**j for j in range(order+1))
    high=sum(moment(j,a0)/zlo**j for j in range(order+1))
    ratio=a1/zlo
    high+=(1-LAM)*ratio**(order+1)/(1-ratio)
    end=2*ETA*LAM/(1-ratio)
    return 2*((1-ETA)*low-end),2*((1+ETA)*high+end)


def witness(left,right,branch):
    # N=1+k*2^n with 2^n>sqrt(N) and k odd; one modular power certifies primality.
    limit=bounds(right,'exp')[0].__floor__()
    n=(limit.bit_length()+1)//2+1
    power=1<<n
    k=(limit-1)//power
    k-=(k+1)%2
    limit_low=bounds(left,'exp')[1]
    while True:
        p=1+k*power
        assert p>limit_low and k<power and k%2==1
        if p%3==branch and all(p%v for v in (5,7,11,13,17,19,23,29,31)):
            for b in (2,3,5,7,11,13,17,19,23,29,31,37,41,43):
                if pow(b,(p-1)//2,p)==p-1:
                    loglo,loghi=bounds(p,'ln')
                    assert left<loglo<=loghi<right
                    X=(p/(right-F('1.1'))).__floor__()
                    assert p/(loglo-1)<=X<=p/(loghi-F('1.1'))
                    return p,n,k,b,X
        k-=2


def window_bounds(l,h):
    assert 150<=l<h<=175
    xlo=(bounds(l,'exp')[0]/(l-1)).__floor__()
    return mass(bounds(xlo,'ln')[0],h-bounds(h-F('1.1'),'ln')[0])


def main():
    ap=ArgumentParser(description=__doc__)
    ap.add_argument('left',nargs='?',type=F,default=F(150))
    ap.add_argument('right',nargs='?',type=F,default=F(4801,32))
    args=ap.parse_args()
    l,h=args.left,args.right
    assert 150<=l<h<=175
    lower,upper_all=window_bounds(l,h)
    print('window',l,h,'certified A',display(lower,digits=12),
          'unrounded lower >=',display(lower,digits=18),
          'mass at every admissible p,X <=',display(upper_all,True,18))
    for branch in (1,2):
        p,n,k,b,X=witness(l,h,branch)
        _,upper=mass(*bounds(X,'ln'))
        print('p mod 3',branch,'p',p,'n',n,'k',k,'base',b,'X',X)
        print('upper on any uniform A <=',display(upper,True,18),
              'largest possible 12-decimal A <=',display(upper,digits=12),
              'gap above new quoted A <=',
              display(upper-F((lower*UNIT).__floor__(),UNIT),True,18))


if __name__=='__main__':
    main()
