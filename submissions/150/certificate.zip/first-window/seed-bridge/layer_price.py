"""Price the ordered-prime lower populations in the two physical projections."""
from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
from buchstab_layers import builder
from smooth_transfer import load_model,make_pricer
from zones import make_zones


def main():
    here=Path(__file__).resolve().parent
    ap=ArgumentParser(description=__doc__)
    ap.add_argument('--repo',type=Path,default=here.parent/'prime-sampling')
    ap.add_argument('--rank',type=int,default=38)
    ap.add_argument('--check',action='store_true')
    ap.add_argument('--records',type=Path)
    ap.add_argument('--out',type=Path)
    args=ap.parse_args()
    m=load_model(args.repo,args.rank);price=make_pricer(m);zone=make_zones(m,price,builder(m))
    target=args.out or here/f'layers{args.rank}.dat'
    source=target if args.check else (args.records or here/f'zones{args.rank}.dat')
    best={};seen=set()
    for line in source.read_text().splitlines():
        w=line.split();rank=int(w[0]);u,v=map(F,w[1:3]);bit=int(w[3])
        lin,out,k,rho=map(F,w[4:8]);soft=int(w[8]);a,b=map(F,w[9:11])
        assert rank==args.rank and len(w)==12 and (u,v) not in seen
        seen.add((u,v))
        if args.check:menu=[(k,out,lin)]
        else:menu=[(F(t,16),oo,ii) for t in range(8,23) for oo in (out,out+1,out+2) for ii in (lin,)]
        cost,kk,oo,ii=min(((zone(u,v,bit,ii,oo,kk,rho,soft,a,b)*10**12).__ceil__(),kk,oo,ii)
                          for kk,oo,ii in menu)
        if args.check:assert cost==int(w[-1]),(line,cost)
        else:
            best[u,v]=' '.join(map(str,[rank,u,v,bit,ii,oo,kk,rho,soft,a,b,cost]))
            target.write_text('\n'.join(best.values())+'\n',encoding='ascii')
        print(u,v,'ordered lower populations',cost,'previous',w[-1],flush=True)

if __name__=='__main__':main()
