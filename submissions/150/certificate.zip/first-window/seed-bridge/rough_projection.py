"""Positive lower counts of distinct levels of the Ramaré cofactor weight."""
from bisect import bisect_right
from fractions import Fraction as F
from functools import cache
from itertools import product
from math import comb,factorial,prod


def setup(model):
    z,s=model['z'],model['s']
    edges,ps=z.boundaries()
    sc=10**18
    @cache
    def aggregate(v):
        assert 11<=v<=51 and int(v*8)==v*8
        stops=[31,edges[5*8],edges[8*8],edges[11*8],edges[int(min(v,16)*8)]]
        prefix=prod(1-F(1,p) for p in ps[:bisect_right(ps,31)])
        size0=2**bisect_right(ps,31)
        groups=[]
        for a,b in zip(stops,stops[1:]):
            block=ps[bisect_right(ps,a):bisect_right(ps,b)]
            if not block:continue
            upper=F(sum((sc+p-2)//(p-1) for p in block),sc)
            groups.append((len(block),upper,s.trans(-upper,'exp',False)))
        if v>16:
            cnt,h=s.geometry(F(16),v)
            upper=h/(1-1/F(stops[-1]))
            groups.append(((cnt*s.eu(16)).__ceil__(),upper,s.trans(-upper,'exp',False)))
        return prefix,size0,groups
    @cache
    def law(v):
        prefix,size0,groups=aggregate(v)
        base=prefix*prod(z[2] for z in groups)
        options=[]
        for orders in product((2,4,6,8),repeat=len(groups)):
            error=sum(h**d/(factorial(d)*vv) for (n,h,vv),d in zip(groups,orders))
            if error>=1:continue
            mean=base*(1-error)
            size=size0*(len(groups)+1)*prod(sum(comb(n,j) for j in range(min(d,n)+1))
                                             for (n,h,vv),d in zip(groups,orders))
            options.append((size,mean))
        frontier=[]
        for size,mean in sorted(options):
            if not frontier or mean>frontier[-1][1]:frontier.append((size,mean))
        return frontier
    @cache
    def harmonic(u,v):
        cuts=sorted({u,min(16,v),v})
        h=F(0)
        for a,b in zip(cuts,cuts[1:]):
            if b<=a or a<u:continue
            if b<=16:
                start,end=bisect_right(ps,edges[int(a*8)]),bisect_right(ps,edges[int(b*8)])
                h+=F(sum(sc//p for p in ps[start:end]),sc)
            else:
                h+=max(F(0),1/(b-1)-1/(a-F('1.1'))+s.ld((b-1)/(a-1)))
        return h
    @cache
    def levels(u,v,weighted_length=None):
        width=1-s.LAM*s.eu(u-v) if weighted_length is None else weighted_length
        h=harmonic(u,v)
        sym=F(1);caps=[]
        for j in range(4):
            inv=s.eu(u+j*v-z.zl)
            lower=max(F(0),max(width*mean-size*inv for size,mean in law(v)))
            caps.append(sym*lower)
            sym=sym*max(F(0),h-j*s.eu(-u))/(j+1)
        assert 0<=sum(caps)<=1
        return caps
    return levels
