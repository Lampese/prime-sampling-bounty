"""Lower bound the positive rough-cofactor layers by strictly ordered prime blocks."""
from bisect import bisect_right
from fractions import Fraction as F
from functools import cache


def builder(model):
    s,z=model['s'],model['z'];edges,ps=z.boundaries();scale=10**22
    @cache
    def lower_mass(a,b):
        if b<=16:
            i,j=[bisect_right(ps,edges[int(t*8)]) for t in (a,b)]
            return sum(scale//p for p in ps[i:j])
        if a<16:return lower_mass(a,F(16))+lower_mass(F(16),b)
        val=1/(b-1)-1/(a-F('1.1'))+s.ld((b-1)/(a-1))
        if a>=20:
            eta=s.eta_for(a,F(1))
            val=max(val,(1-eta)*s.ld(b/a)-2*eta/a)
        return max(0,(val*scale).__floor__())

    @cache
    def population(u,v,j):
        # For each population, uniformly enclose log(Y/marked_product).
        L=z.zl-u-j*v;H=z.zh-u-j*u
        cut=s.LAM*s.eu(u-v)
        limits=sorted({cut,*[F(1,2**k) for k in range(1,9) if F(1,2**k)>cut],F(3,4),F(7,8)})
        lows=[L+s.ld(c) for c in limits]
        # Tally separately the coefficients of the interval mass and its endpoint error.
        main=[0]*len(limits);error=[0]*len(limits);step=F(1,4) if (4*v).denominator==1 else F(1,8)
        @cache
        def terminal(last,sumhi,count):
            # Each prefix factor is taken from a different bin of the same width.
            sumlo=sumhi-count*step
            for i,lc in enumerate(lows):
                floor=lc-sumhi
                if floor>=max(last,F(20)):
                    inv=1/(H-sumlo)
                    return i,(scale*inv).__floor__(),(2*scale*inv*s.eta_for(floor,F(1))).__ceil__()
            return None
        def add(row,weight):
            if row is not None:
                i,m,e=row
                main[i]+=weight*m//scale
                error[i]+=(weight*e+scale-1)//scale
        add(terminal(v,F(0),0),scale)
        # Each state is the sum of reciprocals of prefixes grouped by sum of
        # their upper log endpoints and length. The current largest bin is implicit.
        active={(0,0):scale};hi=v+step
        while 2*hi<=L:
            hi_units=int(hi/step)
            assert hi_units*step==hi
            mass=lower_mass(hi-step,hi)
            new={}
            for (total,count),weight in active.items():
                nxt=total+hi_units
                if (nxt+hi_units)*step>L:continue
                value=weight*mass//scale
                if value:
                    key=nxt,count+1
                    new[key]=new.get(key,0)+value
            for (total,count),weight in new.items():
                add(terminal(hi,total*step,count),weight)
                active[total,count]=active.get((total,count),0)+weight
            hi+=step
        return limits,main,error

    def levels(u,v,integral):
        sym=F(1);caps=[];harm=F(lower_mass(u,v),scale)
        for j in range(4):
            limits,main,error=population(u,v,j)
            # A floor on the positive prefix multiplier may be used for the
            # full nonnegative lower bound, including its negative error.
            density=sum(max(F(0),m*integral(c)-e) for c,m,e in zip(limits,main,error))/scale
            caps.append(sym*density)
            sym=sym*max(F(0),harm-j*s.eu(-u))/(j+1)
        return caps
    return levels
