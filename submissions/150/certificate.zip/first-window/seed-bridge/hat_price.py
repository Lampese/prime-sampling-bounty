"""Separate local arithmetic and coordinate projections on a linear partition of unity."""
from argparse import ArgumentParser
from bisect import bisect_right
from fractions import Fraction as F
from functools import cache
from pathlib import Path
from buchstab_layers import builder
from smooth_transfer import load_model,make_pricer


class Hat:
    def __init__(self,nodes,index):
        self.nodes=nodes
        self.m=nodes[index]
        self.a=nodes[max(0,index-1)]
        self.b=nodes[min(index+1,len(nodes)-1)]
    def h(self,x):
        if x==self.m:return F(1)
        if x<self.m==self.a or x>self.m==self.b:return F(1)
        if x<=self.a or x>=self.b:return F(0)
        return (x-self.a)/(self.m-self.a) if x<self.m else (self.b-x)/(self.b-self.m)
    def peak(self,x,y):
        if x>=y:return F(0)
        return self.h(min(y,max(x,self.m)))
    def area(self,x,y):
        knots=sorted(set([x,y,*[p for p in (self.a,self.m,self.b) if x<p<y]]))
        return sum((hi-lo)*(self.h(lo)+self.h(hi))/2 for lo,hi in zip(knots,knots[1:]))


def make(model,sharp=False):
    price=make_pricer(model);z,s,g=model['z'],model['s'],model['g']
    edges,ps=z.boundaries();pop=builder(model)
    @cache
    def boxes(u,v):
        box=[];t=u
        while t<v:
            r=min(t+F(1,8),v)
            low=s.LAM*s.trans(u-r,'exp',False);hi=s.eu(u-t)
            if r<=16:
                n=bisect_right(ps,edges[int(8*r)])-bisect_right(ps,edges[int(8*t)])
                c=n*s.eu(-u)
            else:c=s.geometry(t,r)[0]*s.eu(t-u)
            box.append((low,hi,c));t=r
        return box
    @cache
    def term(u,v,rho,hat):
        assert all(b-a>=rho for a,b in zip(hat.nodes,hat.nodes[1:]))
        @cache
        def A(h):
            if not h:return F(0)
            log=s.lu(6/(h*rho))
            usual=F(1,50)+2/F('3.14159')*(2+log)
            if sharp:
                assert s.eu(-u)/(model['lo']-F('1.1'))<F(1,10**6)
                usual=min(usual,F('1.8')+F('.41')*log)
            return h*usual
        cc=di=lin=off=F(0)
        group=boxes(u,v)
        for l,h,n in group:
            height=hat.peak(l,h)
            if not height:continue
            cc+=n;di+=n*hat.area(l,h);lin+=n*A(height)
            for l2,h2,n2 in group:
                off+=n*n2*A(hat.peak(max(l,l2),min(h,h2)))
        gl=s.LAM*s.trans(u-v,'exp',False);gh=s.LAM*s.eu(u-v)
        width=hat.area(gl,F(1));lowwidth=hat.area(gh,F(1))
        caps=price.levels(u,v,lowwidth)
        caps=list(map(max,caps,pop(u,v,lambda c:hat.area(c,F(1)))))
        return cc,di,lin,off,width,caps
    def fixed(u,v,bit,rho):
        _,H,_,_,_,_,W,_,sq,_=price.geometry(u,v)
        _,collar=price.shape(u,v,rho);m=model['poly'](bit)[0]
        return (m/g-1)*W+sq+2*z.zh*(1/g-1)*H*collar
    def side(u,v,bit,rho,hat,lin,out,k,soft):
        c,H,ratio,inv,invQ,*_=price.geometry(u,v)
        cc,di,l1,off,width,caps=term(u,v,rho,hat)
        if not cc:return F(0)
        m,N,sec=model['poly'](bit);N-=1;V=sec-m*m
        d=N*N+2*N*(1-m);freq=12*N*N+16*N*(1-m)
        G,S2,G2,endpoint,norm,cross=price.norms(u,lin,out,soft)
        K=width/G2+S2*S2*inv
        res=k*k*K+sum((F(1,j*j)-2*k/j)*y for j,y in enumerate(caps,1))
        assert res>=0
        E=V*min(di,(1-s.LAM)*H)*invQ/G+V*min(c,cc)*invQ*endpoint*inv
        E+=(8*d*l1*invQ+freq*off)*ratio*norm
        return 2*z.zh*(k*8*N*ratio*l1*cross+s.root(E*res))/g
    side.terms=term
    return fixed,side


def main():
    here=Path(__file__).resolve().parent
    ap=ArgumentParser(description=__doc__)
    ap.add_argument('--repo',type=Path,default=here.parent/'prime-sampling')
    ap.add_argument('--rank',type=int,default=38)
    ap.add_argument('--edges',nargs='+',default=['11.5,14','14,18','18,22','22,26'])
    ap.add_argument('--out',type=Path,required=True)
    args=ap.parse_args();model=load_model(args.repo,args.rank);fixed,side=make(model)
    for pair in args.edges:
        u,v=map(F,pair.split(','));rho=F(1,100000);soft=1
        nodes=tuple(map(F,['0','1/32','1/8','1/3','2/3','1']))
        hats=[Hat(nodes,i) for i in range(len(nodes))]
        best=None
        for bit in ((30,32,34) if u<16 else (26,28,30)):
            total=fixed(u,v,bit,rho);pars=[]
            ii=max(0,17-int(u));out=24 if u<16 else 21
            for hat in hats:
                choices=[(F(i),F(o),F(k,8)) for i in {max(0,ii-2),ii,ii+2}
                        for o in (out-2,out,out+2,out+4) for k in (4,5,6,7,8,9)]
                val,p=min((side(u,v,bit,rho,hat,*p,soft),p) for p in choices)
                total+=val;pars.extend(p)
            key=(total,bit,pars)
            if best is None or key<best:best=key
        val,bit,pars=best
        print(u,v,'piecewise selection:',bit,float(val),flush=True)
        with args.out.open('a',encoding='ascii') as f:
            print(args.rank,u,v,bit,rho,soft,','.join(map(str,nodes)),*pars,(val*10**12).__ceil__(),file=f)

if __name__=='__main__':main()
