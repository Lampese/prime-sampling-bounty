"""Interpolate the Selberg divisors on both sides of a Ramaré prime band."""
from argparse import ArgumentParser
from bisect import bisect_right
from fractions import Fraction as F
from functools import cache
from pathlib import Path
from lcm_weights import count_support
from smooth_transfer import load_model,make_pricer
from joint_projection import create


def setup(m):
    z,s=m['z'],m['s'];edges,ps=z.boundaries()
    support=count_support(m);price=make_pricer(m);unit=10**18
    def ceil(x):return (unit*x).__ceil__()
    @cache
    def upper_bins(v,cap):
        row=[unit]+[0]*cap
        for j in range(1,int(8*v)+1):
            a,b=F(j-1,8),F(j,8);d=j-1
            if b<=16:
                members=ps[bisect_right(ps,edges[j-1]):bisect_right(ps,edges[j])]
                if b<=5:
                    for p in members:
                        for t in range(cap,d-1,-1):row[t]+=(row[t-d]+p-2)//(p-1)
                    continue
                mass=sum((unit+p-2)//(p-1) for p in members)
            else:mass=ceil(s.geometry(a,b)[1]/(1-s.eu(-a)))
            if d>cap or not mass:continue
            powers=[unit]
            for h in range(1,cap//d+1):
                q=h*unit;powers.append((powers[-1]*mass+q-1)//q)
            for t in range(cap,d-1,-1):
                row[t]+=sum((w*row[t-k*d]+unit-1)//unit for k,w in enumerate(powers[1:t//d+1],1))
        return F(sum(row),unit)

    @cache
    def common(u,v,out):
        assert out>=v and out+F(1,8)<3*u and F(int(v*4),4)==v
        D=s.eu(out).__ceil__();G,raw=m['weights'](v,out)
        angular=F(support(D,out,v))/G
        H=price.geometry(u,v)[1];cut=F((2*u).__floor__(),2)
        rows=z.basis(F(65))[cut]
        pop=[(F(sum(rows[:k*8+1]),z.SCALE),s.eu(k).__ceil__()**2*s.eu(u+v-z.zl)) for k in range(30,58)]
        # Bound |lambda_r| using the exact Selberg formula and positive log bins.
        upper=upper_bins(v,((out-u)*8).__ceil__()+1)
        lam=min(F(1),upper/((1-s.eu(-u))*G))
        return G,raw,angular,H,lam,pop

    class Outer:
        def __init__(self,u,v,out,t):
            self.G,self.raw,self.angular,self.H,self.lam,self.pop=common(u,v,out)
            self.t=t
        def cross(self,old,inner):
            return (1-self.t)*old+self.t*self.angular*inner
        def space(self,width,old_G,old_raw,inv):
            t=self.t
            return width*((1-t)**2/old_G+t*(2-t)/self.G)+((1-t)*old_raw+t*self.raw)**2*inv
        def difference(self,width):
            return self.t*self.lam*self.H*min(width/G+er for G,er in self.pop)
    return Outer


def main():
    here=Path(__file__).resolve().parent;ap=ArgumentParser(description=__doc__)
    ap.add_argument('--repo',type=Path,default=here.parent/'prime-sampling')
    ap.add_argument('--rank',type=int,default=38)
    ap.add_argument('--records',type=Path,required=True)
    ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--walsh',action='store_true')
    ap.add_argument('--check',action='store_true')
    args=ap.parse_args();m=load_model(args.repo,args.rank);joint=create(m);outer=setup(m)
    if args.walsh:
        from walsh_projection import make_components
        get=make_components(m,joint.split)
    for line in args.records.read_text().splitlines():
        w=line.split();assert int(w[0])==args.rank;u,v=map(F,w[1:3])
        if args.walsh:
            hi=int(w[3]);rho,a,b=map(F,w[4:7])
            cuts=tuple(map(int,w[7].split(',')));logs=tuple(map(F,w[8].split(',')))
            comps=get(hi,cuts);prefix=w[:9];o,k=map(F,w[9:11])
        else:
            lo,hi=map(int,w[3:5]);rho,a,b,i1,i2,o,k=map(F,w[5:12])
            comps=joint.components(lo,hi);prefix=w[:10];logs=(i1,i2)
        if o<v:
            assert not args.check
            continue
        if args.check:
            assert len(w)==len(prefix)+4
            t=F(w[-2]);assert 0<=t<=1 and k>=F(1,2)
            val=joint.weighted(u,v,hi,rho,a,b,comps,logs,o,k,outer(u,v,o,t))
            assert (val*10**12).__ceil__()==int(w[-1]),line
            continue
        options=[(oo,kk,t) for oo in (o-1,o,o+1) if oo>=v and oo+F(1,8)<3*u
                 for kk in (k,min(F(1),k+F(1,16))) for t in (F(0),F(1,4),F(1,2),F(3,4),F(1))]
        if not options:continue
        val,par=min((joint.weighted(u,v,hi,rho,a,b,comps,logs,oo,kk,outer(u,v,oo,t)),(oo,kk,t))
                    for oo,kk,t in options)
        with args.out.open('a',encoding='ascii') as f:print(*prefix,*par,(val*10**12).__ceil__(),file=f)
        print(u,v,float(val),'mix',par[-1],'previous',w[-1],flush=True)

if __name__=='__main__':main()
