"""Project a Brun majorant on orthogonal biased Walsh components ordered by arithmetic cost."""
from argparse import ArgumentParser
from fractions import Fraction as F
from functools import cache
from math import prod
from pathlib import Path
from smooth_transfer import load_model
from joint_projection import create


def make_components(model,split,overlap=False):
    ps=model['seq'];g=model['g'];mesh=8
    prices=[((p+1)**mesh-1).bit_length() for p in ps]
    total=[0]
    for p in prices:total.append(total[-1]+p)
    den=[1]
    for p in ps:den.append(den[-1]*p)
    # Integer states for sums of products with shared denominator prod(p-1).
    qs=[1]
    for p in ps:qs.append(qs[-1]*(p-1))
    @cache
    def moments(k,h):
        if h<0:return 0,0,0
        if not k:return 1,1,1
        p=ps[k-1]
        x,y,z=moments(k-1,h);a,b,c=moments(k-1,h-prices[k-1])
        # Respectively squared norm, absolute raw coefficients, raw constant at x=0.
        return (p-1)*x+a,(p-1)*y+(p+1)*b,(p-1)*z+c
    @cache
    def column(bit,cut):
        _,steps,decide,visit,_,_=split.tree(bit)
        @cache
        def at_zero(k,j,up):
            if (k,j,up) not in decide:return visit(k,j,up)[0]//den[k]
            return at_zero(k-1,j,up)
        @cache
        def mix(k,j,up,h):
            if h<0:return 0
            if (k,j,up) not in decide:return visit(k,j,up)[0]
            if h<prices[0]:return visit(k,j,up)[0]
            if h>=total[k]:return den[k]*at_zero(k,j,up)
            p=ps[k-1];d=steps[k-1]
            return (p*mix(k-1,j,up,h)-mix(k-1,j+d,not up,h)
                    +mix(k-1,j+d,not up,h-prices[k-1]))
        k=len(ps);h=cut*mesh;mu=model['poly'](bit)[0]
        cov=g*(F(mix(k,0,True,h),den[-1])-mu)
        mix.cache_clear()
        v,n,c=moments(k,h)
        return g*g*(F(v,qs[-1])-1),g*F(n-c,qs[-1]),g*(F(c,qs[-1])-1),cov
    @cache
    def matching(bit,cut):
        _,steps,decide,visit,_,_=split.tree(bit)
        @cache
        def raw(k,j,up,h):
            if h<0:return 0
            if (k,j,up) not in decide:
                return (visit(k,j,up)[0]//den[k])*moments(k,h)[2]
            p=ps[k-1];q=h-prices[k-1]
            return ((p-1)*raw(k-1,j,up,h)+raw(k-1,j,up,q)
                    +p*raw(k-1,j+steps[k-1],not up,q))
        v=raw(len(ps),0,True,mesh*cut)-moments(len(ps),mesh*cut)[2]
        raw.cache_clear()
        return g*F(v,qs[-1])
    @cache
    def components(hi,cuts):
        mu,N,sec=model['poly'](hi)
        previous=(F(0),)*4;parts=[];n_rem=N-1;c_rem=1-mu;v_rem=sec-mu*mu
        shared=previous_shared=F(0);max_positive=F(1)
        for cut in cuts:
            current=column(hi,cut)
            var,norm,c0,cov=[a-b for a,b in zip(current,previous)];previous=current
            if not var:continue
            t=cov/var
            if overlap:
                current_shared=matching(hi,cut)
                if t>0:
                    shared+=t*(current_shared-previous_shared)
                    max_positive=max(t,max_positive)
                previous_shared=current_shared
            parts.append((abs(t)*norm,t*t*var,abs(t*c0)))
            n_rem+=abs(t)*norm;c_rem-=t*c0;v_rem-=t*t*var
        n_rem-=2*shared/max_positive
        assert v_rem>=0 and n_rem>=0
        parts.append((n_rem,v_rem,abs(c_rem)))
        return parts
    return components


def main():
    here=Path(__file__).resolve().parent;ap=ArgumentParser(description=__doc__)
    ap.add_argument('--repo',type=Path,default=here.parent/'prime-sampling')
    ap.add_argument('--rank',type=int,default=38)
    ap.add_argument('--records',type=Path,required=True)
    ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--check',action='store_true')
    args=ap.parse_args();m=load_model(args.repo,args.rank);joint=create(m)
    get=make_components(m,joint.split)
    if args.check:
        for line in args.records.read_text().splitlines():
            w=line.split();assert len(w)==12 and int(w[0])==args.rank
            u,v=map(F,w[1:3]);bit=int(w[3]);rho,a,b=map(F,w[4:7])
            cuts=tuple(map(int,w[7].split(',')));logs=tuple(map(F,w[8].split(',')));out,k=map(F,w[9:11])
            assert sorted(set(cuts))==list(cuts) and len(logs)==len(cuts)+1
            val=joint.weighted(u,v,bit,rho,a,b,get(bit,cuts),logs,out,k)
            assert (val*10**12).__ceil__()==int(w[-1]),line
        return
    for line in args.records.read_text().splitlines():
        w=line.split();u,v=map(F,w[1:3]);lo,hi=map(int,w[3:5])
        rho,a,b,i1,i2,o,k=map(F,w[5:-1])
        best=None
        for bit in (hi,hi+2):
            for cuts in [(8,16),(10,19),(12,22),(8,15,22)]:
                parts=get(bit,cuts)
                for top in {i1,i1+1}:
                    if 5*m['s'].eu(top).__ceil__()>=m['s'].trans(u,'exp',False):continue
                    for bot in {i2,max(F(0),i2-2)}:
                        logs=[top,max(bot,top-3),bot] if len(cuts)==2 else [top,top-2,max(bot,top-4),bot]
                        for out in (o,o+2):
                            val=joint.weighted(u,v,bit,rho,a,b,parts,logs,out,k)
                            par=bit,cuts,logs,out
                            if best is None or val<best[0]:best=val,par
        val,(bit,cuts,logs,out)=best
        with args.out.open('a',encoding='ascii') as f:
            print(args.rank,u,v,bit,rho,a,b,','.join(map(str,cuts)),','.join(map(str,logs)),out,k,(val*10**12).__ceil__(),file=f)
        print(u,v,float(val),'previous',w[-1],flush=True)

if __name__=='__main__':main()
