"""Compare exact signed support intersections and Gram entries against Boolean enumeration."""
from fractions import Fraction as F
from functools import cache
from itertools import combinations
from math import prod
from pathlib import Path
import sys
from coordinate_split import split_data


def check():
    sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scalar-tail'))
    from brun import make
    count=0
    for primes in ((2,3,5,7,11,13,17),(2,5,7,11,13,17,19,23)):
        @cache
        def poly(bit):return make(primes,bit,with_second=True)
        @cache
        def expand(bit):return dict(make(primes,bit,with_second=True,raw=True)[3])
        calc=split_data({'seq':primes,'make':make,'poly':poly})
        for lo,hi in combinations((6,9,12,15),2):
            v1,v2,c,n1,n2,overlap,m1,m2=calc.covariances(lo,hi)
            L,H=expand(lo),expand(hi)
            assert overlap==len(L.keys()&H.keys())
            mixed=F(0)
            for mask in range(1<<len(primes)):
                factors=prod(p for i,p in enumerate(primes) if mask>>i&1)
                p=prod(F(1,q) if mask>>i&1 else 1-F(1,q) for i,q in enumerate(primes))
                y=sum(c for d,c in L.items() if factors%d==0);z=sum(c for d,c in H.items() if factors%d==0)
                mixed+=p*y*z
            assert c==mixed-m1*m2
            if not v1:continue
            t=c/v1;parts=calc(lo,hi,t)
            assert t>=0 and abs(sum(x[1] for x in parts)-v2)==0
            direct=sum(abs(H.get(d,0)-t*L.get(d,0)) for d in H.keys()|L.keys() if d!=1)
            assert parts[1][0]==direct
            count+=1
        from walsh_projection import make_components
        g=prod(1-F(1,q) for q in primes)
        model={'seq':primes,'make':make,'poly':poly,'g':g}
        comp=make_components(model,calc)
        bit=12; cuts=(4,8);parts=comp(bit,cuts)
        costs=[((q+1)**8-1).bit_length() for q in primes];moments=[F(0)]*2;variances=[F(0)]*2
        H=expand(bit);mu=poly(bit)[0]
        lists=[[] for _ in cuts]
        for support in range(1,1<<len(primes)):
            l=sum(costs[i] for i in range(len(primes)) if support>>i&1)
            if l<=8*cuts[-1]:lists[int(l>8*cuts[0])].append(support)
        for mask in range(1<<len(primes)):
            factors=prod(q for i,q in enumerate(primes) if mask>>i&1)
            prob=prod(F(1,q) if mask>>i&1 else 1-F(1,q) for i,q in enumerate(primes))
            V=sum(c for d,c in H.items() if factors%d==0)-mu
            for j,ss in enumerate(lists):
                val=g*sum(prod(-1 if mask>>i&1 else F(1,q-1) for i,q in enumerate(primes)
                               if S>>i&1) for S in ss)
                moments[j]+=prob*val*V;variances[j]+=prob*val*val
        assert all(parts[j][1]==moments[j]**2/variances[j] for j in range(2))
        assert sum(q[1] for q in parts)==poly(bit)[2]-mu*mu
        tight=make_components(model,calc,overlap=True)(bit,cuts)
        rawcols=[]
        for j,supports in enumerate(lists):
            col={}
            for S in supports:
                denom=prod(p-1 for i,p in enumerate(primes) if S>>i&1)
                T=S
                while True:
                    mon=prod(p for i,p in enumerate(primes) if T>>i&1)
                    coeff=F((-1)**T.bit_count()*mon,denom)*g*moments[j]/variances[j]
                    col[mon]=col.get(mon,0)+coeff
                    if not T:break
                    T=(T-1)&S
            rawcols.append(col)
        remain=H.copy();remain[1]-=mu
        for col in rawcols:
            for key,value in col.items():remain[key]=remain.get(key,0)-value
        rawcols.append(remain)
        actual=sum(abs(t) for key,t in remain.items() if key!=1)
        assert actual<=tight[-1][0]<=parts[-1][0]
        from frequency_components import norms
        from math import gcd
        levels=(8,3,1)
        # Enumerate actual squarefree denominators independently of the phi histogram.
        ds=[d for d in range(1,41) if all(d%(p*p) for p in (2,3,5))]
        phi={d:sum(gcd(d,k)==1 for k in range(1,d+1)) for d in ds}
        weight=lambda T,d:max(T-phi[d],0) if T>1 else int(d==1)
        den=[sum(F(weight(T,d),phi[d]) for d in ds) for T in levels]
        n=c0=F(0)
        for d in ds:
            total={}
            for T,gg,col in zip(levels,den,rawcols):
                for key,x in col.items():total[key]=total.get(key,0)+weight(T,d)*x/gg
            n+=sum(abs(x) for key,x in total.items() if key!=1)
            c0+=abs(total.get(1,0))
        nn,cc=norms(levels,tuple(tight),poly(bit)[1]-1,mu)
        assert nn>=n and cc>=c0
        count+=3
    print(count,'exact Boolean support, covariance, projected variance and frequency checks passed.')

if __name__=='__main__':check()
