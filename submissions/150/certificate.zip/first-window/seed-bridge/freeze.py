"""Reprice physical edges, recompute their signed projection, and join to the original graph."""
from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
from tempfile import TemporaryDirectory
import subprocess,sys
from smooth_transfer import load_model,make_pricer


def main():
    here=Path(__file__).resolve().parent;work=here.parent
    ap=ArgumentParser(description=__doc__)
    ap.add_argument('--repo',type=Path,default=work/'prime-sampling')
    ap.add_argument('--sources',type=Path,nargs='+')
    ap.add_argument('--output',type=Path)
    ap.add_argument('--check',action='store_true')
    ap.add_argument('--rank',type=int,choices=(37,38))
    ap.add_argument('--route',action='store_true')
    args=ap.parse_args()
    if args.route:
        old=work/'transfer-bilinear'
        with TemporaryDirectory() as td:
            temp=Path(td)/'direct.dat';rows=[]
            for r in (37,38):
                credit={}
                credit_file=here/f'square-credit{r}.dat'
                if credit_file.is_file():
                    for line in credit_file.read_text().splitlines():
                        u,v,c=line.split();credit[F(u),F(v)]=int(c)
                def insert(w):
                    fee=int(w[-1])-credit.get((F(w[1]),F(w[2])),0)
                    assert fee>=0
                    rows.append(' '.join([*w[:-1],str(fee)]))
                for src in [here/f'chosen{r}.dat',here/f'zones{r}.dat',here/f'layers{r}.dat']:
                    if not src.is_file():continue
                    for line in src.read_text().splitlines():
                        w=line.split()
                        assert len(w)==(10 if src.name.startswith('chosen') else 12) and int(w[0])==r
                        if F(w[2])<=26:
                            insert([*w[:7],w[-1]])
                src=here/f'joint-certified{r}.dat'
                if src.is_file():
                    for line in src.read_text().splitlines():
                        w=line.split()
                        assert len(w)==13 and int(w[0])==r and F(w[2])<=26
                        insert([w[i] for i in (0,1,2,4,8,10,11,12)])
                for stem,size in [('three',15),('walsh',12),('marked',14),('hybrid',13),('fit',12),('sinc',12),('tight',12),('spectral',12),('local',12)]:
                    src=here/f'{stem}-certified{r}.dat'
                    if not src.is_file():continue
                    for line in src.read_text().splitlines():
                        w=line.split();assert len(w)==size and int(w[0])==r and F(w[2])<=26
                        # early.py takes the edge endpoints and its complete certified upper cost.
                        insert([*w[:3],'0','0','0','0',w[-1]])
            temp.write_text('\n'.join(rows)+'\n')
            flags=['--check' if args.check else '--out',str(here/'150.dat')]
            cmd=[sys.executable,'-B',str(work/'transfer-weights/early.py'),'--repo',str(args.repo.resolve()),
                 '--direct-edges',*[str(old/name) for name in ('37.dat','38.dat','37-early.dat','38-early.dat')],
                 str(temp),*flags]
            more=[p for p in here.glob('extra-seeds*.txt') if p.is_file()]
            more+=sorted(here.glob('wheel-seeds*-r*.txt'))
            more+=sorted(here.glob('prefix-seeds*-r*.txt'))
            if more:cmd.extend(['--extra-seeds',*map(str,more)])
            tails=sorted((work/'wide-coverage').glob('terminal150r*.dat'))
            tails+=sorted((work/'analytic-coverage').glob('log-terminal150r*.dat'))
            if tails:cmd.extend(['--terminal-absolute',*map(str,tails)])
            subprocess.run(cmd,check=True)
        return
    assert args.rank
    rank=args.rank;chosen=here/f'chosen{rank}.dat'
    model=load_model(args.repo,rank);price=make_pricer(model);bank={}
    for source in ([chosen] if args.check else args.sources):
        for line in source.read_text().splitlines():
            w=line.split();assert int(w[0])==rank and len(w) in (8,9,10)
            u,v=map(F,w[1:3]);bit=int(w[3]);lin,out,k=map(F,w[4:7])
            if not args.check and v>26:continue
            if args.check:assert (u,v) not in bank
            rho=F(w[7]) if len(w)>=9 else F(1,100000)
            soft=int(w[8]) if len(w)==10 else 0
            if args.check:menu=[(lin,out,k,soft)]
            else:
                menu=[(ii,oo,kk,ss) for ss in (0,1)
                      for ii in {lin,max(F(0),lin-1),lin+1,lin+2}
                      for oo in {out-1,out,out+1}
                      for kk in {max(F(1,2),k-F(1,16)),k,min(F(1),k+F(1,16)),F(3,4),F(7,8)}]
            for ii,oo,kk,ss in menu:
                if 5*model['s'].eu(ii)>=model['s'].trans(u,'exp',False):continue
                total=(price(u,v,bit,ii,oo,kk,rho,ss)[0]*10**12).__ceil__()
                record=(total,bit,ii,oo,kk,rho,ss)
                if args.check:assert total==int(w[-1]),(line,total)
                bank[u,v]=min(bank.get((u,v),record),record)
    if not args.check:
        result=[]
        for (u,v),(cost,bit,ii,oo,kk,rho,ss) in sorted(bank.items()):
            result.append(' '.join(map(str,(rank,u,v,bit,ii,oo,kk,rho,ss,cost))))
        (args.output or chosen).write_text('\n'.join(result)+'\n',encoding='ascii')
    elif (here/f'zones{rank}.dat').is_file():
        from zones import make_zones
        zone=make_zones(model,price);seen=set()
        for line in (here/f'zones{rank}.dat').read_text().splitlines():
            w=line.split();assert len(w)==12 and int(w[0])==rank
            u,v=map(F,w[1:3]);assert (u,v) not in seen;seen.add((u,v))
            value=zone(u,v,int(w[3]),*map(F,w[4:8]),int(w[8]),*map(F,w[9:11]))
            assert (value*10**12).__ceil__()==int(w[-1]),line
        print('Verified',len(seen),'partitioned physical rank',rank,'edges.')
    print('Verified' if args.check else 'Priced',len(bank),'physical rank',rank,'edges.')

if __name__=='__main__':main()
