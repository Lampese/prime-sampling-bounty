"""Bound the repeated-prime part on its actual rough cofactor support."""
from fractions import Fraction as F
from functools import cache
from smooth_transfer import make_pricer
from smooth_transfer import load_model
from pathlib import Path
from argparse import ArgumentParser


def setup(model):
    s,z=model['s'],model['z'];geometry=make_pricer(model).geometry
    @cache
    def credit(u,v):
        old=geometry(u,v)[8]
        cutoff=min(F(26),F((2*u).__floor__(),2))
        table=z.basis(F(65))[cutoff]
        d2=[]
        for k in range(15,62):
            G=F(sum(table[:k*z.GRID+1]),z.SCALE)
            D=s.eu(k).__ceil__()
            d2.append(1/G+D*D*s.eu(3*v-z.zl))
        fraction=min([F(1),*d2])
        return (10**12*old*(1-fraction)).__floor__()
    return credit


def main():
    here=Path(__file__).resolve().parent;ap=ArgumentParser(description=__doc__)
    ap.add_argument('--repo',type=Path,default=here.parent/'prime-sampling')
    ap.add_argument('--rank',type=int,choices=(37,38),required=True)
    ap.add_argument('--check',action='store_true')
    args=ap.parse_args();r=args.rank
    target=here/f'square-credit{r}.dat'
    if args.check:
        pairs=[tuple(map(F,w.split()[:2])) for w in target.read_text().splitlines() if w.strip()]
    else:
        pairs=set()
        for stem in ('chosen','zones','layers','joint-certified','three-certified','walsh-certified','marked-certified','hybrid-certified','fit-certified','sinc-certified','tight-certified','spectral-certified','local-certified'):
            f=here/f'{stem}{r}.dat'
            if f.is_file():pairs.update(tuple(map(F,w.split()[1:3])) for w in f.read_text().splitlines() if w.strip())
        pairs=sorted(pairs)
    assert len(pairs)==len(set(pairs))
    cost=setup(load_model(args.repo,r))
    result=''.join(f'{u} {v} {cost(u,v)}\n' for u,v in pairs)
    if args.check:assert result==target.read_text()
    else:target.write_text(result,encoding='ascii')
    print('Verified rough square savings for',len(pairs),'edges of rank',r)

if __name__=='__main__':main()
