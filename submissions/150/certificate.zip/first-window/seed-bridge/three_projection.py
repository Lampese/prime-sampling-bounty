"""Exact Gram-Schmidt decomposition and arithmetic projections at three Brun resolutions."""
from argparse import ArgumentParser
from fractions import Fraction as F
from functools import cache
from pathlib import Path
from smooth_transfer import load_model
from joint_projection import create


def setup(model):
    joint=create(model);split=joint.split
    @cache
    def get(i,j,k):
        bits=(i,j,k)
        v0,v1,c01,n0,n1,n01,m0,m1=split.covariances(i,j)
        _,v2,c02,_,n2,n02,_,m2=split.covariances(i,k)
        _,_,c12,_,_,n12,_,_=split.covariances(j,k)
        ts=[split.tree(bit) for bit in bits];step=ts[0][1]
        @cache
        def const(k,s,up,h):
            _,_,ds,V,_,_=ts[h]
            if (k,s,up) not in ds:return int(V(k,s,up)[0]!=0)
            return const(k-1,s,up,h)
        @cache
        def overlap(k,s,up):
            if any((k,s,up) not in t[2] for t in ts):
                return int(all(const(k,s,up,h) for h in range(3)))
            return overlap(k-1,s,up)+overlap(k-1,s+step[k-1],not up)
        abc=overlap(len(model['seq']),0,True);const.cache_clear();overlap.cache_clear()
        # All trees contain the constant term, which is charged separately.
        cnt={7:abc-1,3:n01-abc,5:n02-abc,6:n12-abc,
             1:n0-n01-n02+abc,2:n1-n01-n12+abc,4:n2-n02-n12+abc}
        assert min(cnt.values())>=0
        a=c01/v0;b=c02/v0;w=v1-c01*a
        assert w>0
        c=(c12-a*c02)/w
        rows=[((b,0,0),b*b*v0),((-c*a,c,0),c*c*w),((c*a-b,-c,1),v2-b*b*v0-c*c*w)]
        out=[]
        for coeff,var in rows:
            N=sum(n*abs(sum(q for h,q in enumerate(coeff) if mask>>h&1)) for mask,n in cnt.items())
            C=abs(sum(q*(1-mean) for q,mean in zip(coeff,(m0,m1,m2))))
            assert var>=0
            out.append((N,var,C))
        assert sum(x[1] for x in out)==v2
        return out
    def charge(u,v,bits,rho,a,b,logs,out,k):
        return joint.weighted(u,v,bits[-1],rho,a,b,get(*bits),logs,out,k)
    return charge


def main():
    here=Path(__file__).resolve().parent;ap=ArgumentParser(description=__doc__)
    ap.add_argument('--repo',type=Path,default=here.parent/'prime-sampling')
    ap.add_argument('--rank',type=int,default=38)
    ap.add_argument('--records',type=Path,required=True)
    ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--check',action='store_true')
    args=ap.parse_args();m=load_model(args.repo,args.rank);charge=setup(m)
    if args.check:
        for line in args.records.read_text().splitlines():
            w=line.split();assert len(w)==15 and int(w[0])==args.rank
            u,v=map(F,w[1:3]);bits=tuple(map(int,w[3:6]));rho,a,b=map(F,w[6:9])
            logs=tuple(map(F,w[9:12]));out,k=map(F,w[12:14])
            val=charge(u,v,bits,rho,a,b,logs,out,k)
            assert (val*10**12).__ceil__()==int(w[-1]),line
        return
    for line in args.records.read_text().splitlines():
        w=line.split();u,v=map(F,w[1:3]);lo,hi=map(int,w[3:5])
        rho,a,b,i1,i2,o,k=map(F,w[5:-1])
        pars=[]
        for mid in {lo+4,lo+6}:
            for high in {hi,hi+2}:
                for ll in (lo,lo-4):
                    for logs in ((i1,i2+2,i2),(i1+1,i2+2,max(F(0),i2-1)),(i1,i2+3,max(F(0),i2-2))):
                        if max(5*m['s'].eu(i).__ceil__() for i in logs)>=m['s'].trans(u,'exp',False):continue
                        for out in {o,o+1}:
                            pars.append(((ll,mid,high),logs,out))
        val,p=min((charge(u,v,bits,rho,a,b,logs,out,k),(bits,logs,out)) for bits,logs,out in pars)
        bits,logs,out=p
        with args.out.open('a',encoding='ascii') as f:
            print(args.rank,u,v,*bits,rho,a,b,*logs,out,k,(val*10**12).__ceil__(),file=f)
        print(u,v,float(val),'previous',w[-1],flush=True)

if __name__=='__main__':main()
