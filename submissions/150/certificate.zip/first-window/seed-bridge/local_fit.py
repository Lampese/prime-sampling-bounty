"""Fit a common coordinate test on a partition with three or more physical nodes."""
from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
from outer_fit import create_price
from smooth_transfer import load_model

here=Path(__file__).resolve().parent
ap=ArgumentParser(description=__doc__)
ap.add_argument('--repo',type=Path,default=here.parent/'prime-sampling')
ap.add_argument('--rank',type=int,default=38);ap.add_argument('--records',type=Path,required=True)
ap.add_argument('--out',type=Path,required=True);ap.add_argument('--check',action='store_true')
args=ap.parse_args();edge=create_price(load_model(args.repo,args.rank),sharp=True,overlap=True,spectral=True)
for line in args.records.read_text().splitlines():
    w=line.split();assert len(w)==12 and int(w[0])==args.rank
    u,v=map(F,w[1:3]);bit=int(w[3]);rho,a,b=map(F,w[4:7])
    cuts=tuple(map(int,w[7].split(',')));logs=tuple(map(F,w[8].split(',')))
    if args.check:
        nodes=tuple(map(F,w[10].split(',')))
        groups=[[(F(l),int(f),F(x)) for l,f,x in [t.split(':') for t in s.split(',')]] if s!='-' else []
                for s in w[9].split('|')]
        val,_=edge(u,v,bit,rho,a,b,cuts,logs,nodes=nodes,groups=groups)
        assert (val*10**12).__ceil__()==int(w[-1]),line
    else:
        o,k=map(F,w[9:11])
        best=None
        for stops in (('1/8','1/3','2/3'),('1/16','1/4','1/2','7/8'),('1/10','1/5','2/5','2/3','9/10')):
            nodes=tuple(map(F,stops))
            val,groups=edge(u,v,bit,rho,a,b,cuts,logs,nodes=nodes,proposal=(o,k))
            fee=(val*10**12).__ceil__()
            if best is not None and fee>=best:continue
            best=fee
            tags=[','.join(f'{l}:{f}:{x}' for l,f,x in row) or '-' for row in groups]
            with args.out.open('a',encoding='ascii') as f:print(*w[:9],'|'.join(tags),','.join(stops),fee,file=f)
        print(u,v,'localized price',best,flush=True)
