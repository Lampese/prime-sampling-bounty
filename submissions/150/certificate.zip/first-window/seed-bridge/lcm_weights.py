"""Group Selberg products on the lcm semilattice before charging Fourier norms."""
from fractions import Fraction as F
from functools import cache
from math import gcd,prod

SCALE=10**12
PHI_SCALE=10**17
SMALL=(2,3,5,7,11,13)


@cache
def inner(D):
    phi=list(range(D+1));mu=[1]*(D+1)
    for p in range(2,D+1):
        if phi[p]!=p:continue
        for k in range(p,D+1,p):
            phi[k]-=phi[k]//p;mu[k]*=-1
        for k in range(p*p,D+1,p*p):mu[k]=0
    low=[0]+[PHI_SCALE//phi[n] if mu[n] else 0 for n in range(1,D+1)]
    high=[0]+[(PHI_SCALE+phi[n]-1)//phi[n] if mu[n] else 0 for n in range(1,D+1)]
    Glo,Ghi=sum(low),sum(high)
    coeff={};slack=0
    for d in range(1,D+1):
        if not mu[d]:continue
        small=d*SCALE*sum(low[d::d])//Ghi
        large=(d*SCALE*sum(high[d::d])+Glo-1)//Glo
        coeff[d]=mu[d]*small;slack+=large-small
    size=sum(map(abs,coeff.values()))
    # Exact collisions among a finite prefix. All omitted pairs pay their
    # full absolute mass, keeping storage bounded at higher levels.
    prefix=[(d,v) for d,v in coeff.items() if d<=600]
    parts={}
    for j,(d,v) in enumerate(prefix):
        parts[d]=parts.get(d,0)+v*v
        for e,w in prefix[:j]:
            l=d//gcd(d,e)*e
            parts[l]=parts.get(l,0)+2*v*w
    gain=sum(abs(w) for d,w in prefix)**2-sum(map(abs,parts.values()))
    squares=F((size+slack)**2-gain,SCALE**2)
    assert gain>=0
    divisors=[1]
    for p in SMALL:divisors+= [d*p for d in divisors]
    caps={}
    for e in divisors:
        collected={}
        for d,v in coeff.items():
            j=d//gcd(d,e)
            collected[j]=collected.get(j,0)+v
        caps[e]=F(sum(map(abs,collected.values()))+slack,SCALE)
    return F(Glo,PHI_SCALE),caps[1],squares,caps


@cache
def split_constants(D):
    # sigma(n)/phi(n) for squarefree n supplies a fixed positive envelope.
    *_,caps=inner(D)
    major=rem=F(0)
    wheel=prod(SMALL)
    for a in caps:
        phi=prod(q-1 for q in SMALL if not a%q)
        val=sum(d*cap for d,cap in caps.items() if not a%d)/phi
        rem+=val
        major+=val/a
    density=F(prod(p-1 for p in SMALL),wheel)
    missing=prod(1+F(2,p*(p-1)) for p in SMALL)
    return major*density/missing,rem*(2**len(SMALL))


def coupled_norm(d1,d2,log_upper,G2,euler):
    major,rem=split_constants(d1)
    return euler*(major*d2+rem*(1+log_upper)**2)/G2


@cache
def soft_inner(T):
    # Diagonalize both the divisor quadratic form and the additive frequency norm.
    # y_b = mu(b) (T-phi(b))_+ /(phi(b) G); the omitted larger moduli have y_b=0.
    bound=5*max(T,2)
    phi=list(range(bound+1));sq=[True]*(bound+1);sigma=[1]*(bound+1)
    for p in range(2,bound+1):
        if phi[p]!=p:continue
        for n in range(p,bound+1,p):
            phi[n]-=phi[n]//p;sigma[n]*=1+p
        for n in range(p*p,bound+1,p*p):sq[n]=False
    G=var=total=raw=F(0)
    for n in range(1,bound+1):
        t=max(0,T-phi[n]) if T>1 else int(n==1)
        if t and sq[n]:
            f=F(t,phi[n])
            G+=f;var+=t*f;total+=t;raw+=f*sigma[n]
    return G*G/var,raw/G,total/G


@cache
def squarefree_count(n):
    from math import isqrt
    if n<1:return 0
    # Mobius inversion only visits the square root of the cofactor limit.
    m=isqrt(n);mu=[1]*(m+1);primes=[True]*(m+1)
    for p in range(2,m+1):
        if not primes[p]:continue
        for h in range(p+p,m+1,p):primes[h]=False
        for h in range(p,m+1,p):mu[h]*=-1
        for h in range(p*p,m+1,p*p):mu[h]=0
    return sum(mu[j]*(n//(j*j)) for j in range(1,m+1))


def count_support(model):
    from bisect import bisect_right
    z,s=model['z'],model['s'];edges,ps=z.boundaries()
    @cache
    def bounds(x):
        if x<=16:
            at=bisect_right(ps,s.trans(x,'exp',False).__floor__())
            assert s.eu(x).__floor__()==s.trans(x,'exp',False).__floor__()
            return at,at
        return (s.trans(x,'exp',False)/(x-1)).__ceil__(),(s.eu(x)/(x-F('1.1'))).__floor__()
    @cache
    def upper(D,level,u):
        if D<=200000:return squarefree_count(D)
        # Exclude the first six prime squares exactly by inclusion-exclusion.
        choices=[(1,1)]
        for p in SMALL:choices += [(n*p*p,-sign) for n,sign in choices]
        count=sum(sign*(D//m) for m,sign in choices)
        # Subtract disjoint squarefree multiples of one prime greater than
        # both the accepted cutoff and sqrt(D). In every bin count only
        # cofactors coprime to that prime, automatically true by their size.
        t=F((8*max(u,level/2+F(1,8))).__ceil__(),8)
        while t<level:
            v=min(level,t+F(1,4))
            a=s.trans(t,'exp',False)
            assert a*a>D
            nq=max(0,bounds(v)[0]-bounds(t)[1])
            cof=(D/s.eu(v)).__floor__()
            count-=nq*squarefree_count(cof)
            t=v
        assert count>0
        return count
    return upper
