"""A supported trapezoid in a doubly projected Buchstab transfer."""
from argparse import ArgumentParser
from fractions import Fraction as F
from functools import cache
from pathlib import Path
import runpy,sys


def load_model(repo,rank,window=None):
    work=Path(__file__).resolve().parents[1]
    # The existing model exposes its checked raw moments, exact prime masses
    # and Selberg denominators. An empty fixed menu suppresses its own search.
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as name:
        fixed=Path(name)/'empty';fixed.write_text('')
        old=sys.argv
        # selberg.setup sets the physical window on its module. Keep each explicit
        # model bound to its own module if callers retain multiple price functions.
        previous_selberg=sys.modules.pop('selberg',None) if window is not None else None
        try:
            sys.argv=['price.py','--repo',str(repo),'--rank',str(rank),'--fixed',str(fixed)]
            if window is not None:
                assert len(window)==2 and window[0]<window[1]
                sys.argv.extend(['--window',*(str(x) for x in window)])
            model=runpy.run_path(str(work/'transfer-bilinear/price.py'))
        finally:
            sys.argv=old
            if window is not None:
                sys.modules.pop('selberg',None)
                if previous_selberg is not None:sys.modules['selberg']=previous_selberg
    return model


def make_pricer(model):
    z=model['z'];s=model['s'];g=model['g']
    from rough_projection import setup
    from lcm_weights import inner,coupled_norm,squarefree_count,count_support
    levels=setup(model)
    support=count_support(model)
    def floor_cut(u):return min(F(26),F((2*u).__floor__(),2))
    @cache
    def geometry(u,v):
        if u<=26 and 2*u==int(2*u):return model['geometry'](u,v)
        c,H,h2=model['prime_data'](u,v)
        ratio=model['px']*s.eu(u);inv=s.eu(u-z.zl);invQ=s.eu(-u)
        width=1-s.LAM*s.trans(u-v,'exp',False)
        W=2*z.zh*z.coverage(floor_cut(u),v)[0]*H
        sq=z.zh*(1/g-1)*(1+invQ)*h2
        return c,H,ratio,inv,invQ,width,W,None,sq,None
    @cache
    def norms(u,lin,lout,soft=0):
        assert lin<u
        outer_cut=u if lout<u else floor_cut(u)
        G2,S2=model['weights'](outer_cut,lout)
        D2=s.weight(lout)[0] if lout<u else s.eu(lout).__ceil__()
        a2=F(support(D2,lout,outer_cut))/G2
        if soft:
            from lcm_weights import soft_inner
            be=s.eu(lin).__ceil__()
            assert 5*be<s.trans(u,'exp',False)
            eff,absolute,harmonic=soft_inner(be)
            return eff,S2,G2,absolute**2,harmonic**2,harmonic*a2
        D,G,S=s.weight(lin)
        gl,sl,sq,_=inner(D)
        G=max(G,gl);S=min(S,sl)
        cross=coupled_norm(D,D2,lout+1,G2,model['euler'])
        a1=F(squarefree_count(D))/G
        return G,S2,G2,min(S*S,sq),min(S*S,sq,a1*a1),min(S*S2,cross,a1*a2)
    @cache
    def shape(u,v,rho):
        # A continuous upper bound controls the discrete norm at every D.
        A=F(1,50)+F(2,1)/F('3.14159')*(2+s.lu(3/rho))
        assert s.eu(-u)/(model['lo']-F('1.1'))<F(1,100)
        # The incoherent boundary layers have combined area rho X; two
        # components mean two possible endpoint errors per lcm in Selberg.
        rows=z.basis(F(65))[floor_cut(u)]
        collar=min(rho/F(sum(rows[:k*z.GRID+1]),z.SCALE)+2*s.eu(k).__ceil__()**2*s.eu(v-z.zl)
                   for k in range(36,64))
        return A,collar
    def price(u,v,bit,lin,lout,k,rho,soft=0):
        c,H,ratio,inv,invQ,width,W,B,sq,_=geometry(u,v)
        A,collar=shape(u,v,rho)
        m,N,sec=model['poly'](bit);N-=1;V=sec-m*m
        assert 0<rho<(1-s.LAM)/2 and k>=F(1,2)
        d=N*N+2*N*(1-m);off=12*N*N+16*N*(1-m)
        G,S2,G2,endpoint_norm,inner_norm,cross_norm=norms(u,lin,lout,soft)
        E=V*(1-s.LAM)*H*invQ/G+V*c*invQ*endpoint_norm*inv
        E+=(8*d*c*invQ+off*c*c)*ratio*A*inner_norm
        K=width/G2+S2*S2*inv;pen=8*N*ratio*A*c*cross_norm
        edge=2*z.zh*(1/g-1)*H*collar
        caps=levels(u,v)
        residual=k*k*K+sum((F(1,j*j)-2*k/j)*pop for j,pop in enumerate(caps,1))
        assert residual>=0
        corr=2*z.zh/g*(k*pen+s.root(E*residual))
        return (m/g-1)*W+corr+sq+edge,edge,A
    price.geometry=geometry
    price.norms=norms
    price.shape=shape
    price.levels=levels
    return price


def main():
    here=Path(__file__).resolve().parent
    cli=ArgumentParser(description=__doc__)
    cli.add_argument('--repo',type=Path,default=here.parent/'prime-sampling')
    cli.add_argument('--rank',type=int,default=38)
    cli.add_argument('--edges',nargs='+',default=['12,14','12.5,14','14,16','16,18'])
    cli.add_argument('--out',type=Path,required=True)
    args=cli.parse_args();model=load_model(args.repo,args.rank)
    price=make_pricer(model);records=[]
    for pair in args.edges:
        u,v=map(F,pair.split(','))
        # Only the best few proposals are re-evaluated at varied projection scales.
        bits=(22,24,26,28,30,32) if u>=18 else (28,30,32,34,36)
        outer=(F(12),F(15),F(18),F(20),F(22),F(24)) if u>=18 else (F(19),F(21),F(22),F(23),F(24),F(25),F(26))
        best=min((val,bit,lin,out,rho,edge,A)
            for bit in bits
            for lin in (F(0),F(2),F(4),F(6),F(8))
            for out in outer
            for rho in (F(1,10**k) for k in (4,5,6,7,8,9))
            for val,edge,A in [price(u,v,bit,lin,out,F(1,2),rho)])
        val,bit,lin,out,rho,edge,A=best
        val,lin,out,k,edge,A=min((val,ii,oo,kk,edge,A)
            for ii in (lin+F(j,2) for j in range(-2,3) if lin+F(j,2)>=0)
            for oo in (out+F(j,2) for j in range(-2,3))
            for kk in (F(j,32) for j in range(16,37))
            for val,edge,A in [price(u,v,bit,ii,oo,kk,rho)])
        stock=model['cost'](u,v,bit,lin,out,F(1,2))[0] if u<=26 and 2*u==int(2*u) else None
        charge=(val*10**12).__ceil__()
        print(u,v,bit,lin,out,k,rho,'physical transfer',float(val),'collar',float(edge),
              'Fourier',float(A),'sharp same parameters',float(stock) if stock is not None else None,flush=True)
        records.append(' '.join(map(str,(args.rank,u,v,bit,lin,out,k,rho,charge))))
        args.out.write_text('\n'.join(records)+'\n')

if __name__=='__main__':main()
