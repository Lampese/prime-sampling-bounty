"""Two coordinate resolutions with separate arithmetic projections and exact mixed moments."""
from argparse import ArgumentParser
from fractions import Fraction as F
from functools import cache
from pathlib import Path
from smooth_transfer import load_model,make_pricer
from zones import make_zones


def split_data(model):
    ps=model['seq']
    @cache
    def tree(bit):return model['make'](ps,bit,return_tree=True)
    @cache
    def compare(lo,hi):
        den,step,ds1,t1,m1,n1=tree(lo)
        _,_,ds2,t2,m2,n2=tree(hi)
        @cache
        def overlap(k,l,r,up):
            # Both trees have the same parity after selecting a fixed monomial.
            a=(k,l,up) in ds1;b=(k,r,up) in ds2
            if not a and t1(k,l,up)[0]==0 or not b and t2(k,r,up)[0]==0:return 0
            if not a and not b:return 1
            if not a:return one(k,r,up,2)
            if not b:return one(k,l,up,1)
            st=step[k-1]
            return overlap(k-1,l,r,up)+overlap(k-1,l+st,r+st,not up)
        @cache
        def one(k,j,up,which):
            ds,t=(ds1,t1) if which==1 else (ds2,t2)
            if (k,j,up) not in ds:return int(t(k,j,up)[0]!=0)
            return one(k-1,j,up,which)
        @cache
        def mixed(k,l,lu,r,ru):
            if (k,l,lu) not in ds1:return (t1(k,l,lu)[0]//den[k])*t2(k,r,ru)[0]
            if (k,r,ru) not in ds2:return (t2(k,r,ru)[0]//den[k])*t1(k,l,lu)[0]
            q=ps[k-1];st=step[k-1]
            return (q*mixed(k-1,l,lu,r,ru)-mixed(k-1,l+st,not lu,r,ru)
                    -mixed(k-1,l,lu,r+st,not ru)+mixed(k-1,l+st,not lu,r+st,not ru))
        a,_,a2=model['poly'](lo);b,_,b2=model['poly'](hi)
        cov=F(mixed(len(ps),0,True,0,True),den[-1])-a*b
        V1=a2-a*a;V2=b2-b*b
        common=overlap(len(ps),0,0,True)
        assert 1<=common<=min(n1,n2) and cov*cov<=V1*V2
        mixed.cache_clear();overlap.cache_clear();one.cache_clear()
        return V1,V2,cov,n1,n2,common,a,b
    def get(lo,hi,t=F(1)):
        v1,v2,c,n1,n2,common,a,b=compare(lo,hi)
        return [(t*(n1-1),t*t*v1,t*abs(1-a)),
                ((n2-common)+t*(n1-common)+abs(1-t)*(common-1),v2+t*t*v1-2*t*c,abs((1-b)-t*(1-a)))]
    get.covariances=compare
    get.tree=tree
    return get


def main():
    here=Path(__file__).resolve().parent
    ap=ArgumentParser(description=__doc__)
    ap.add_argument('--repo',type=Path,default=here.parent/'prime-sampling')
    ap.add_argument('--rank',type=int,default=38)
    ap.add_argument('--edges',nargs='+',default=['11.5,12.5','12.5,14','14,16','16,18','18,20','20,22','22,24'])
    ap.add_argument('--out',type=Path,required=True)
    args=ap.parse_args();m=load_model(args.repo,args.rank);price=make_pricer(m);zone=make_zones(m,price)
    splits=split_data(m)
    rows={tuple(map(F,w[1:3])):w for w in (line.split() for line in
        (here/f'zones{args.rank}.dat').read_text().splitlines())}
    for entry in args.edges:
        u,v=map(F,entry.split(','));w=rows[u,v]
        _,_,_,bit,ii,oo,kk,rho,soft,a,b,old=w
        hi=int(bit);ii,oo,kk,rho,a,b=map(F,[ii,oo,kk,rho,a,b])
        _,_,_,_,_,_,W,_,sq,_=price.geometry(u,v)
        _,collar=price.shape(u,v,rho);H=price.geometry(u,v)[1]
        fixed=(m['poly'](hi)[0]/m['g']-1)*W+sq+2*m['z'].zh*(1/m['g']-1)*H*collar
        best=None
        for lo in range(max(10,hi-18),hi,4):
            for t in (F(1),F(3,4)):
                co=splits(lo,hi,t);choices=[]
                for component in co:
                    fee,pars=min((zone(u,v,hi,i,o,k,rho,int(soft),a,b,component),(i,o,k))
                        for i in {max(F(0),ii-2),ii,ii+2,ii+4}
                        for o in (oo-2,oo,oo+2,oo+4)
                        for k in {kk,F(1,2),F(3,4),F(1)}
                        if 5*m['s'].eu(i)<m['s'].trans(u,'exp',False))
                    choices.append((fee,pars))
                result=fixed+sum(x[0] for x in choices)
                key=result,lo,t,choices
                if best is None or key<best:best=key
        val,lo,t,choices=best
        pars=[q for fee,par in choices for q in par]
        line=' '.join(map(str,[args.rank,u,v,lo,hi,t,rho,soft,a,b,*pars,(val*10**12).__ceil__()]))
        with args.out.open('a',encoding='ascii') as f:print(line,file=f)
        print(u,v,'two resolutions',float(val),'old',old,flush=True)

if __name__=='__main__':main()
