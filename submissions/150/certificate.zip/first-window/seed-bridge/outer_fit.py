"""Fit several outer Selberg weights. Fixed fractions are repriced without numerical libraries."""
from argparse import ArgumentParser
from fractions import Fraction as F
from functools import cache
from pathlib import Path
import sys
from smooth_transfer import load_model, make_pricer
from joint_projection import create
from walsh_projection import make_components
from marked_projection import setup
from buchstab_layers import builder
from zones import make_zones
from lcm_weights import soft_inner


def propose(matrix, linear, constant, penalty, energy, start):
    # This phase exclusively suggests nonnegative rational parameters.
    sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'lp-vendor'))
    import numpy as np
    from scipy.optimize import minimize
    M=np.asarray(matrix,float); b=np.asarray(linear,float)
    p=np.asarray(penalty,float)/float(energy)**0.5
    c=float(constant)
    def values(x):
        mx=M@x
        r=max(1.e-24,float(x@(mx+b))+c)**0.5
        return x@p+r,p+(mx+0.5*b)/r
    constr=({'type':'ineq','fun':lambda x:x.sum()-.500001,'jac':lambda x:np.ones(len(x))},
            {'type':'ineq','fun':lambda x:1.6-x.sum(),'jac':lambda x:-np.ones(len(x))})
    best=min(start,key=lambda x:values(np.asarray(x,float))[0])
    result=minimize(values,np.asarray(best,float),jac=True,method='SLSQP',
                    bounds=[(0,1.6)]*len(b),constraints=constr,
                    options={'maxiter':160,'ftol':1.e-13})
    ret=[]
    for raw in (best,result.x):
        x=[F(round(max(0,float(t))*10**6),10**6) for t in raw]
        if sum(x)<F(1,2):x[max(range(len(x)),key=x.__getitem__)]+=F(1,2)-sum(x)
        ret.append(x)
    return ret


def create_price(m,sharp=False,overlap=False,spectral=False):
    s,z,g=m['s'],m['z'],m['g']
    price=make_pricer(m);joint=create(m);get=make_components(m,joint.split,overlap=overlap)
    terms=make_zones(m,price,builder(m),sharp=sharp).terms;marked=setup(m)
    from divisor_basis import builder as fine_basis
    denominator=fine_basis(m) if sharp else None
    @cache
    def arithmetic(u,v,level,flag):
        if flag:
            assert flag==1 and v<=level and level+F(1,8)<3*u
            obj=marked(u,v,level,F(1))
            G=max(obj.G,denominator(v,level)) if sharp else obj.G
            return G,obj.raw,obj.angular*obj.G/G,obj
        _,raw,G,_,_,angular=price.norms(u,F(0),level,1)
        assert soft_inner(1)[2]==1
        fine=max(G,denominator(min(F(26),F((2*u).__floor__(),2)),level)) if sharp and level>=u else G
        return fine,raw,angular*G/fine,None
    @cache
    def hats(nodes):
        from hat_price import Hat
        assert 2<=len(nodes) and 0<=nodes[0]<nodes[-1]<=1 and sorted(set(nodes))==list(nodes)
        return [Hat(nodes,j) for j in range(len(nodes))]
    @cache
    def side_moments():
        from hat_price import make
        return make(m,sharp=sharp)[1].terms
    def edge(u,v,bit,rho,a,b,cuts,logs,groups=None,proposal=None,nodes=None):
        c,H,ratio,inv,invQ,_,W,_,sq,_=price.geometry(u,v)
        assert 0<rho<(1-s.LAM)/2 and sorted(set(cuts))==list(cuts) and len(logs)==len(cuts)+1
        _,collar=price.shape(u,v,rho)
        primal=(m['poly'](bit)[0]/g-1)*W+sq+2*z.zh*(1/g-1)*H*collar
        V=endpoint=N=C=F(0)
        for (n,var,c0),lin in zip(get(bit,cuts),logs,strict=True):
            G,_,_,err,_,_=price.norms(u,lin,F(1),1)
            harmonic=soft_inner(s.eu(lin).__ceil__())[2]
            V+=var/G;endpoint+=var*err;N+=n*harmonic;C+=c0*harmonic
        if spectral:
            from frequency_components import norms
            mu,raw,_=m['poly'](bit)
            N,C=norms(tuple(s.eu(lin).__ceil__() for lin in logs),tuple(get(bit,cuts)),raw-1,mu)
        d=N*N+2*N*C;freq=12*N*N+16*N*C
        corr=F(0);result=[]
        if groups is not None:assert len(groups)==(len(nodes) if nodes else 2)
        for side in range(len(nodes) if nodes else 2):
            if nodes:cc,di,l1,off,width,caps=side_moments()(u,v,rho,hats(nodes)[side])
            else:cc,di,l1,off,width,caps=terms(u,v,rho,a,b,bool(side))
            if not cc:
                if groups is not None:assert not groups[side]
                result.append([]);continue
            E=V*min(di,(1-s.LAM)*H)*invQ+endpoint*min(c,cc)*invQ*inv
            E+=(8*d*l1*invQ+freq*off)*ratio
            if proposal is not None:
                o,k=proposal
                keys=[(o+j,f) for j in (-4,-2,-1,0,1,2,4) for f in (0,1)
                      if o+j>=1 and (not f or v<=o+j and o+j+F(1,8)<3*u)]
            else:
                keys=[(l,f) for l,f,x in groups[side]]
            weights=[arithmetic(u,v,lev,flag) for lev,flag in keys]
            A=[[width/max(G,J)+inv*raw*rr for J,rr,_,_ in weights] for G,raw,_,_ in weights]
            const=sum(h/j**2 for j,h in enumerate(caps,1))
            mean=sum(h/j for j,h in enumerate(caps,1))
            linear=[(obj.difference(width) if obj else 0)-2*mean for _,_,_,obj in weights]
            penalty=[8*ratio*l1*N*angular for _,_,angular,_ in weights]
            def exact(x):
                assert all(t>=0 for t in x) and sum(x)>=F(1,2)
                active=[i for i,t in enumerate(x) if t]
                res=const+sum(x[i]*linear[i] for i in active)
                res+=sum(x[i]*x[j]*A[i][j] for i in active for j in active)
                assert res>=0
                return s.root(E*res)+sum(x[i]*penalty[i] for i in active)
            if proposal is not None:
                start=[[k if j==i else 0 for j in range(len(keys))] for i in range(len(keys))]
                xs=propose(A,linear,const,penalty,E,start)
            else:xs=[[x for _,_,x in groups[side]]]
            cost,x=min((exact(x),x) for x in xs)
            corr+=cost;result.append([(lev,flag,t) for (lev,flag),t in zip(keys,x) if t])
        return primal+2*z.zh*corr/g,result
    return edge


def main():
    here=Path(__file__).resolve().parent;ap=ArgumentParser(description=__doc__)
    ap.add_argument('--repo',type=Path,default=here.parent/'prime-sampling')
    ap.add_argument('--rank',type=int,default=38)
    ap.add_argument('--records',type=Path,required=True);ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--check',action='store_true');ap.add_argument('--sharp',action='store_true');ap.add_argument('--tight',action='store_true');ap.add_argument('--spectral',action='store_true')
    args=ap.parse_args();edge=create_price(load_model(args.repo,args.rank),args.sharp or args.tight or args.spectral,args.tight or args.spectral,args.spectral)
    for line in args.records.read_text().splitlines():
        w=line.split();assert len(w)==12 and int(w[0])==args.rank
        u,v=map(F,w[1:3]);bit=int(w[3]);rho,a,b=map(F,w[4:7])
        cuts=tuple(map(int,w[7].split(',')));logs=tuple(map(F,w[8].split(',')))
        if args.check:
            groups=[]
            for word in w[9:11]:
                rows=[] if word=='-' else [x.split(':') for x in word.split(',')]
                groups.append([(F(l),int(flag),F(x)) for l,flag,x in rows])
            val,_=edge(u,v,bit,rho,a,b,cuts,logs,groups=groups)
            assert (val*10**12).__ceil__()==int(w[-1]),line
        else:
            val,groups=edge(u,v,bit,rho,a,b,cuts,logs,proposal=tuple(map(F,w[9:11])))
            groups=[','.join(f'{l}:{f}:{x}' for l,f,x in rows) or '-' for rows in groups]
            fee=(val*10**12).__ceil__()
            with args.out.open('a',encoding='ascii') as f:print(*w[:9],*groups,fee,file=f)
            print(u,v,fee,'previous',w[-1],flush=True)


if __name__=='__main__':main()
