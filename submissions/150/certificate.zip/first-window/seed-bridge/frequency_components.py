"""Combine the coordinate polynomials at each reduced arithmetic denominator."""
from fractions import Fraction as F
from functools import cache
from collections import Counter


@cache
def phi_classes(top):
    end=5*max(top,2)
    phi=list(range(end+1));sq=bytearray([1])*(end+1)
    for p in range(2,end+1):
        if phi[p]!=p:continue
        for n in range(p,end+1,p):phi[n]-=phi[n]//p
        sq[p*p::p*p]=bytes(len(sq[p*p::p*p]))
    return [(1,True,1)]+[(k,False,n) for k,n in Counter(phi[b] for b in range(2,end+1) if sq[b]).items()]


@cache
def norms(levels,parts,raw,mu):
    classes=phi_classes(max(levels))
    def height(k,one,T):
        return max(T-k,0) if T>1 else int(one)
    G=[sum(F(n*height(k,one,T),k) for k,one,n in classes) for T in levels]
    N=C=F(0)
    for k,one,count in classes:
        ws=[height(k,one,T)/gg for T,gg in zip(levels,G)]
        if not any(ws):continue
        usual=sum(w*n for w,(n,_,_) in zip(ws,parts))
        simple=ws[-1]*raw+sum(abs(w-ws[-1])*p[0] for w,p in zip(ws[:-1],parts))
        N+=count*min(usual,simple)
        # Column zero in the polynomial basis. The remainder's constant can have
        # either sign. The absolute coefficients give two valid triangle bounds.
        known=sum(w*p[2] for w,p in zip(ws,parts))
        shifted=ws[-1]*abs(1-mu)+sum(abs(w-ws[-1])*p[2] for w,p in zip(ws[:-1],parts))
        C+=count*min(known,shifted)
    return N,C
