"""Partition a cofactor projection in physical space while keeping the q and r ranges."""
from fractions import Fraction as F
from functools import cache
from bisect import bisect_right
from pathlib import Path
import argparse
from smooth_transfer import load_model,make_pricer


def ramp(x,a,b):
    return min(F(1),max(F(0),(b-x)/(b-a)))


def integral(lo,hi,a,b,right):
    if hi<=lo:return F(0)
    # Primitive of a plateau, descending ramp, zero; use endpoint differences.
    def f(x):
        return min(x,a)+((b-a)**2-max(0,b-min(b,max(x,a)))**2)/(2*(b-a))
    val=f(hi)-f(lo)
    return hi-lo-val if right else val


def make_zones(model,price,ordered=None,sharp=False):
    z=model['z'];s=model['s'];g=model['g'];edges,ps=z.boundaries()
    @cache
    def boxes(u,v):
        rows=[];t=u
        while t<v:
            t2=min(v,t+F(1,8))
            low=s.LAM*s.trans(u-t2,'exp',False);high=s.eu(u-t)
            if t2<=16:
                cnt=bisect_right(ps,edges[int(8*t2)])-bisect_right(ps,edges[int(8*t)])
                c=cnt*s.eu(-u)
            else:
                c=s.geometry(t,t2)[0]*s.eu(t-u)
            rows.append((low,high,c));t=t2
        return rows
    @cache
    def terms(u,v,rho,a,b,right):
        assert 0<a<b<1 and b-a>=rho
        def height(lo,hi):
            if lo>=hi:return F(0)
            return 1-ramp(hi,a,b) if right else ramp(lo,a,b)
        @cache
        def A(h):
            if not h:return F(0)
            log=s.lu(6/(h*rho))
            usual=F(1,50)+2/F('3.14159')*(2+log)
            if sharp:
                assert s.eu(-u)/(model['lo']-F('1.1'))<F(1,10**6)
                usual=min(usual,F('1.8')+F('.41')*log)
            return h*usual
        listed=boxes(u,v)
        c=diag=linear=off=F(0)
        for l,h,n in listed:
            current=height(l,h)
            if current<=0:continue
            c+=n
            linear+=n*A(current)
            diag+=n*integral(l,h,a,b,right)
            for l2,h2,n2 in listed:
                off+=n*n2*A(height(max(l,l2),min(h,h2)))
        gl=s.LAM*s.trans(u-v,'exp',False);gh=s.LAM*s.eu(u-v)
        width=integral(gl,F(1),a,b,right)
        lowwidth=integral(gh,F(1),a,b,right)
        caps=price.levels(u,v,lowwidth)
        if ordered is not None:
            improved=ordered(u,v,lambda c:integral(c,F(1),a,b,right))
            caps=list(map(max,caps,improved))
        return c,diag,linear,off,width,caps
    def zone(u,v,bit,lin,lout,k,rho,soft,a,b,component=None):
        c,H,ratio,inv,invQ,width,W,B,sq,_=price.geometry(u,v)
        _,collar=price.shape(u,v,rho);edge=2*z.zh*(1/g-1)*H*collar
        if component is None:
            m,N,sec=model['poly'](bit);N-=1;V=sec-m*m;c0=abs(1-m)
        else:N,V,c0=component
        d=N*N+2*N*c0;freq=12*N*N+16*N*c0
        corr=F(0)
        G,S2,G2,endpoint,norm,cross=price.norms(u,lin,lout,soft)
        for side in (False,True):
            cc,diag,linear,off,width,caps=terms(u,v,rho,a,b,side)
            if not cc:continue
            K=width/G2+S2*S2*inv
            residual=k*k*K+sum((F(1,j*j)-2*k/j)*pop for j,pop in enumerate(caps,1))
            assert residual>=0
            E=V*min(diag,(1-s.LAM)*H)*invQ/G+V*min(c,cc)*invQ*endpoint*inv
            E+=(8*d*linear*invQ+freq*off)*ratio*norm
            pen=8*N*ratio*linear*cross
            corr+=k*pen+s.root(E*residual)
        if component is not None:return 2*z.zh*corr/g
        return (m/g-1)*W+sq+edge+2*z.zh*corr/g
    zone.terms=terms
    return zone


def main():
    here=Path(__file__).resolve().parent
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--repo',type=Path,default=here.parent/'prime-sampling')
    cli.add_argument('--rank',type=int,default=38)
    cli.add_argument('--records',type=Path,required=True)
    cli.add_argument('--out',type=Path,required=True)
    args=cli.parse_args();model=load_model(args.repo,args.rank)
    price=make_pricer(model);zone=make_zones(model,price)
    results=[]
    for line in args.records.read_text().splitlines():
        w=line.split();rank=int(w[0]);u,v=map(F,w[1:3]);bit=int(w[3]);lin,out,k,rho=map(F,w[4:8]);soft=int(w[8])
        assert rank==args.rank
        old=int(w[-1]);winner=(F(old,10**12),None,None)
        for a,b in ((F(1,8),F(3,8)),(F(1,4),F(1,2)),(F(2,5),F(3,5)),(F(1,2),F(3,4)),(F(1,8),F(3,4))):
            cost=zone(u,v,bit,lin,out,k,rho,soft,a,b)
            if cost<winner[0]:winner=(cost,a,b)
        if winner[1] is not None:
            val=(winner[0]*10**12).__ceil__()
            results.append(' '.join(w[:-1]+[str(winner[1]),str(winner[2]),str(val)]))
            print(u,v,'covered cofactor zones',winner[1:],val,'old',old,flush=True)
        args.out.write_text('\n'.join(results)+'\n' if results else '',encoding='ascii')

if __name__=='__main__':main()
