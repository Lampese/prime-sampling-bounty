"""Orthogonal Brun resolutions inside one Cauchy square, each with its own arithmetic weight."""
from argparse import ArgumentParser
from fractions import Fraction as F
from functools import cache
from pathlib import Path
from coordinate_split import split_data
from smooth_transfer import load_model,make_pricer
from zones import make_zones
from buchstab_layers import builder
from lcm_weights import soft_inner


def create(m):
    price=make_pricer(m);s,z,g=m['s'],m['z'],m['g']
    terms=make_zones(m,price,builder(m)).terms
    split=split_data(m)
    @cache
    def components(lo,hi):
        a,b,c,*_=split.covariances(lo,hi)
        assert 0<c and c*c<=a*b
        return split(lo,hi,c/a)
    @cache
    def inner(lin):
        return soft_inner(s.eu(lin).__ceil__())[2]
    @cache
    def primal(u,v,hi,rho):
        _,H,_,_,_,_,W,_,sq,_=price.geometry(u,v)
        _,collar=price.shape(u,v,rho)
        return (m['poly'](hi)[0]/g-1)*W+sq+2*z.zh*(1/g-1)*H*collar
    def weighted(u,v,hi,rho,a,b,comps,logs,out,k,outer=None):
        c,H,ratio,inv,invQ,*_=price.geometry(u,v)
        var=ep=N=C=pen=F(0)
        for (n,V,c0),lin in zip(comps,logs,strict=True):
            G,S2,G2,endpoint,norm,cross=price.norms(u,lin,out,1)
            assert 5*s.eu(lin).__ceil__()<s.trans(u,'exp',False)
            var+=V/G;ep+=V*endpoint
            N+=n*inner(lin);C+=c0*inner(lin)
            if outer is not None:cross=outer.cross(cross,inner(lin))
            pen+=n*cross
        d=N*N+2*N*C;freq=12*N*N+16*N*C;corr=F(0)
        for side in (False,True):
            cc,di,l1,off,width,caps=terms(u,v,rho,a,b,side)
            if not cc:continue
            space=width/G2+S2*S2*inv if outer is None else outer.space(width,G2,S2,inv)
            res=k*k*space+sum((F(1,j*j)-2*k/j)*t for j,t in enumerate(caps,1))
            if outer is not None:res+=outer.difference(width)*k
            assert res>=0
            E=var*min(di,(1-s.LAM)*H)*invQ+ep*min(c,cc)*invQ*inv
            E+=(8*d*l1*invQ+freq*off)*ratio
            corr+=8*k*ratio*l1*pen+s.root(E*res)
        return primal(u,v,hi,rho)+2*z.zh*corr/g
    def joint(u,v,lo,hi,rho,a,b,lin1,lin2,out,k):
        return weighted(u,v,hi,rho,a,b,components(lo,hi),(lin1,lin2),out,k)
    joint.weighted=weighted
    joint.split=split
    joint.components=components
    return joint


def main():
    here=Path(__file__).resolve().parent
    ap=ArgumentParser(description=__doc__)
    ap.add_argument('--repo',type=Path,default=here.parent/'prime-sampling')
    ap.add_argument('--rank',type=int,default=38)
    ap.add_argument('--edges',nargs='+',default=['11.5,12.5','12.5,14','14,16','16,18','18,20','20,22','22,24','24,26'])
    ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--check',action='store_true')
    ap.add_argument('--proposals',type=Path)
    args=ap.parse_args();m=load_model(args.repo,args.rank);joint=create(m)
    if args.check:
        for line in args.out.read_text().splitlines():
            w=line.split();assert len(w)==13 and int(w[0])==args.rank
            u,v=map(F,w[1:3]);lo,hi=map(int,w[3:5])
            cost=joint(u,v,lo,hi,*map(F,w[5:-1]))
            assert (cost*10**12).__ceil__()==int(w[-1]),line
        return
    rows={tuple(map(F,w[1:3])):w for w in (line.split() for line in
          (args.proposals or here/f'layers{args.rank}.dat').read_text().splitlines())}
    for edge in args.edges:
        u,v=map(F,edge.split(','));w=rows[u,v];hi=int(w[3]);lin,out,k,rho=map(F,w[4:8]);a,b=map(F,w[9:11])
        menu=[(lo,h,i1,i2,o,kk) for h in (hi,hi+2) for lo in {h-8,h-14}
              for i1 in (lin+2,lin+4) for i2 in {F(0),max(F(0),lin-2)}
              for o in (out,out+2) for kk in {k,F(3,4),F(7,8),F(1)} if 5*m['s'].eu(i1).__ceil__()<m['s'].trans(u,'exp',False)]
        val,params=min((joint(u,v,lo,h,rho,a,b,i1,i2,o,kk),(lo,h,rho,a,b,i1,i2,o,kk))
                       for lo,h,i1,i2,o,kk in menu)
        with args.out.open('a',encoding='ascii') as f:print(args.rank,u,v,*params,(val*10**12).__ceil__(),file=f)
        print(u,v,'orthogonal projection',float(val),'previous',w[-1],flush=True)

if __name__=='__main__':main()
