"""Positive log-block sums for the exact Selberg denominator at several cutoffs."""
from bisect import bisect_right
from fractions import Fraction as F
from functools import cache


def builder(model, mesh=64, maxlog=40):
    s,z=model['s'],model['z'];_,primes=z.boundaries()
    scale=10**20; end=maxlog*mesh
    row=[scale]+[0]*end
    state=[0,0];tables={}
    def add_steps(last):
        while state[0]<last:
            left=state[0];step=1 if left<16*mesh else mesh//8
            right=left+step
            a,b=F(left,mesh),F(right,mesh)
            if b<=16:
                pmax=s.trans(b,'exp',False).__floor__()
                assert pmax==s.eu(b).__floor__()
                k=bisect_right(primes,pmax,lo=state[1])
                members=primes[state[1]:k];state[1]=k
                if b<=5:
                    for p in members:
                        for j in range(end,right-1,-1):row[j]+=row[j-right]//(p-1)
                    members=[]
                mass=sum(scale//(p-1) for p in members)
                cap=(scale+members[0]-2)//(members[0]-1) if members else 0
            else:
                h=1/(b-1)-1/(a-F('1.1'))+s.ld((b-1)/(a-1))
                if a>=20:
                    eta=s.eta_for(a,F(1))
                    h=max(h,(1-eta)*s.ld(b/a)-2*eta/a)
                mass=max(0,(scale*h).__floor__())
                cap=(scale/(s.trans(a,'exp',False)-1)).__ceil__()
            if mass:
                powers=[]
                coeff=scale
                for n in range(end//right):
                    coeff=coeff*max(0,mass-n*cap)//((n+1)*scale)
                    if not coeff:break
                    powers.append((right*(n+1),coeff))
                for j in range(end,right-1,-1):
                    total=0
                    for i,c in powers:
                        if i>j:break
                        total+=c*row[j-i]
                    row[j]+=total//scale
            state[0]=right
            if right%(mesh//4)==0:
                from itertools import accumulate
                tables[right]=tuple(accumulate(row))
    @cache
    def denom(cut,level):
        index=cut*mesh
        assert index.denominator==1 and index%(mesh//4)==0 and cut<=26 and level<=maxlog
        add_steps(int(index))
        return F(tables[int(index)][(level*mesh).__floor__()],scale)
    return denom
