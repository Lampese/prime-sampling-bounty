"""Finite verification of the arithmetic spectrum, projection layers and smoothing bounds."""
from fractions import Fraction as F
from itertools import product
from math import gcd,prod,lcm,pi
from cmath import exp
from lcm_weights import inner,squarefree_count,soft_inner


def small(D):
    ph={n:sum(gcd(n,j)==1 for j in range(1,n+1)) for n in range(1,D+1)}
    primes=[n for n in ph if ph[n]==n-1 and n>1]
    ds=[n for n in ph if all(n%(p*p) for p in primes)]
    mu={d:(-1)**sum(d%p==0 for p in primes) for d in ds}
    return ph,ds,mu


def check():
    ncheck=0
    for D in range(1,25):
        ph,ds,mu=small(D);G=sum(F(1,ph[d]) for d in ds)
        assert squarefree_count(D)==len(ds)
        coeff={d:mu[d]*d/G*sum(F(1,ph[n]) for n in ds if n%d==0) for d in ds}
        assert coeff[1]==1
        assert all(sum(w/d for d,w in coeff.items() if d%b==0)==F(mu[b],ph[b])/G for b in ds)
        raw={}
        for d,x in coeff.items():
            for e,y in coeff.items():raw[lcm(d,e)]=raw.get(lcm(d,e),F(0))+x*y
        gl,t,extra,caps=inner(D)
        assert G>=gl and sum(map(abs,coeff.values()))<=t and sum(map(abs,raw.values()))<=extra
        for e,cap in caps.items():
            parts={}
            for d,w in coeff.items():j=lcm(d,e);parts[j]=parts.get(j,F(0))+w
            assert sum(map(abs,parts.values()))<=cap
        ncheck+=1
    for T in range(2,15):
        ph,ds,mu=small(5*T)
        t={d:max(0,T-ph[d]) for d in ds}
        G=sum(F(w,ph[d]) for d,w in t.items())
        y={d:F(mu[d]*w,ph[d])/G for d,w in t.items()}
        co={d:d*sum(mu[b//d]*v for b,v in y.items() if b%d==0) for d in ds}
        eff,raw,norm=soft_inner(T)
        assert co[1]==1 and sum(map(abs,co.values()))==raw
        assert sum(ph[d]*abs(v) for d,v in y.items())==norm
        assert sum(v*w/lcm(d,e) for d,v in co.items() for e,w in co.items())==1/eff
        ncheck+=1
    for p in (101,163):
        for D in (1,3):
            for q,r in ((2,2),(2,3),(3,5)):
                def f(x):return max(0,min(1,(x-4)/3,(45-x)/3))
                for alpha in (0,.071,.25):
                    a=[f(q*D*j)*f(r*D*j)*exp(2j*pi*alpha*j) for j in range(p)]
                    actual=sum(abs(sum(c*exp(2j*pi*k*j/p) for j,c in enumerate(a))) for k in range(p))/p
                    from math import log
                    N=45/(max(q,r)*D)
                    assert actual<=2*N/p+2/pi*(2+log(45))+1e-10
                    ncheck+=1
    for q,u in ((3,11),(7,17)):
        primes=[k for k in range(2,201) if all(k%d for d in range(2,int(k**.5)+1))]
        values=[];lows=[0]*4
        for n in range(65,950):
            if any(n%p==0 for p in primes if p<=q):values.append(F(0));continue
            m=n;cnt=0;distinct=0
            for p in primes:
                if q<p<=u and not m%p:
                    distinct+=1
                    while not m%p:m//=p;cnt+=1
            values.append(F(1,1+cnt))
            if distinct==cnt<4:lows[cnt]+=1
        for k in (F(1,2),F(9,10),F(5,4)):
            assert sum(x*x-2*k*x for x in values)<=sum((F(1,j*j)-2*k/j)*n for j,n in enumerate(lows,1))
            ncheck+=1
    print(ncheck,'finite arithmetic spectrum, smoothing, and disjoint population checks passed.')

if __name__=='__main__':check()
