# 固定倒数差的同余类平方筛

此证明适用于首个素数区间中的所有素数。输入整数为 $A,B,V,p_-,p_+$，其中 $p_-\le p\le p_+$，实际素数区间 $I=[L,H]\subset[A,B]\subset(194,p)$，$H-L\le V\le B$。同一参数必须覆盖该窗所有 $p$ 以及所有非零倒数差。以下统一计有序对。

## 从素数对到格点

固定差 $a^{-1}-c^{-1}=\nu\pmod p$。设 $(e,P)=(c-a,ac)$，$\beta=\nu^{-1}$。因而 $P\equiv\beta e\pmod p$。映射从有序正素数对到 $(e,P)$ 为单射，因为 $a+c=\sqrt{e^2+4P}$。取 $D=\lfloor\sqrt{p_+/B}\rfloor\in[1,p_--1]$。Dirichlet 逼近给出 $1\le d\le D, |u|\le\lceil p_+/D\rceil, u\equiv d\beta\pmod p$。例如，将 $0,\beta,\ldots,D\beta$ 的最小非负代表元分入 $D$ 个等长区间后相减即可。还可将 $d,u$ 同除以公因子，因 $d<p$。

定义 $G=\max(Bd,|u|)$。若此差有解，则

$$
G_0=\max(B,\min(A^2,\lceil p_-/(B+V)\rceil))\le G
\le G_1=\max(BD,\lceil p_+/D\rceil).
$$

否则 $G<B$ 不可能，或同时有 $G<A^2, G(B+V)<p$。后者意味着整除 $p\mid dP-u e$ 实际上为等式 $dP=u e$。不同素数保证 $\gcd(e,P)=1$，故 $P\mid u$。由于 $P\ge A^2>|u|$ 且 $u\ne 0$，矛盾。

由 Bézout 取整数向量 $w=(w_e,w_P)$，使 $d w_P-u w_e=p$。因 $d\beta\equiv u\pmod p$，$w$ 同属格子。它与 $(d,u)$ 构成行列式绝对值为 $p$ 的格基，故每个解可唯一写成

$$
(e,P)=j w+k(d,u),\qquad j=(dP-u e)/p.
$$

所有解的 $(e,P)\equiv(0,1)\bmod 2$。因为基矩阵模 2 可逆，$j,k$ 具有分别固定的奇偶性。先选择下面的约化格基，再用 $J=(j-j_*)/2, K=(k-k_*)/2$ 作整数坐标。

## 矩形和面积的显式上界

写 $v=H-L$。$dac-u(c-a)$ 是双仿射函数，极值在正方形 $[L,H]^2$ 的角上。相邻角之差的绝对值至多 $v(dB+|u|)\le 2vG$。一对对角顶点之差是 $d(H^2-L^2)\le2vG$，另一对之差是 $2|u|v\le2vG$。因此 $J$ 的真实宽度 $j_w\le VG/p_-$。已定价的版本采用稍大的 $cG$，其中 $c=V(2B+V)/(2Bp_-)$。两式均可使用。

若 $G=Bd$，调节 $w\mapsto w+t(d,u)$ 使 $|w_e|\le d/2$，由 $k=(e-w_e j)/d$ 和 $\operatorname{width}(e)\le 2V$ 得 $k_w\le VB/G+j_w/2$。若 $G=|u|$，改调 $|w_P|\le |u|/2$。因为 $\operatorname{width}(P)\le 2BV$，使用 $k=(P-w_P j)/u$ 得同一结论。这里 $k_w$ 是归一化坐标 $K$ 的宽度，原坐标宽度已除以 2。

在 $G\in[g,h]$ 区间，设 $U=ch, W=VB/g+U/2, Z=cVB+U^2/2$。则 $j_w\le U, k_w\le W$，并且 $j_wk_w\le Z$。末式在放宽到 $U,W$ 之前先相乘，保留抵消 $G\cdot G^{-1}=1$。

## 每个模数只需为出现的剩余类付费

选 $n$ 为仅含素因子 2、3 的正整数。求下列有限集合的基数

$$
C_n=|\{(y-x,xy)\bmod 2n:\ x,y\in(\mathbb Z/(2n))^\times\}|.
$$

因为 $p$ 与 $2n$ 互素，格基模 $2n$ 可逆。固定 $(j,k)$ 的奇偶后，$(J,K)\bmod n$ 与固定奇偶的 $(e,P)\bmod 2n$ 双射。因此实际 $(J,K)$ 至多落在 $C_n$ 个类中。素数 $a,c>3$ 是此处单位条件的来源。直接枚举给出 $C_1,C_2,C_3,C_6,C_{18}=1,2,3,6,30$。例如模 12 的 $(e,P)$ 恰为 $(0,1),(2,11),(4,5),(6,7),(8,5),(10,11)$。

在每个类内把两坐标分别平移、除以 $n$。沿用项目平方筛的矩形外扩约定，每个新盒可取

$$
j_{\max}=\lceil U/n+3\rceil,\quad k_{\max}=\lceil W/n+3\rceil,\quad
\mathcal A=\lceil Z/n^2+3(U+W)/n+9\rceil.
$$

面积由 $(j_w/n+3)(k_w/n+3)$ 展开后上取整。它独立控制每个实际扩展盒的面积，不能用 $mathcal A$ 代替来自不同实际盒的 $j_{\max}k_{\max}$。

筛多项式是 $Q=(e/2)^2+P=((a+c)/2)^2$。在 $J,K$ 上，仿射变换 $(J,K)\mapsto(e/2,P)$ 线性部分行列式绝对值为 $2p$。在一个模 $n$ 剩余类上行列式变为 $2pn^2$。项目 `allsquarecap.bill` 使用的辅助素数均大于 3 并避开 $p$，其 `allmods` 复合模数亦预筛掉 2、3，辅助模数均小于 $p$。因此这些变换均可逆，完全傅里叶系数的界与初始 $x^2+y$ 相同。正整数平方根仍为 $(a+c)/2\le B$，逐根坏素数预算保持有效。项目 `allsquarecap.cap` 已对模 3 类作同一平方筛重标定。故每个区间的有效上界为各 $n$ 的

$$
C_n\,\mathrm{bill}(j_{\max},k_{\max},\mathcal A,B,p_-)
$$

的最小值；再与既有行列式法取小。对于固定阶 $k$，项目未取整的行列式上界为 $(1+cG)(C+D_k G^{-\theta_k})$，各项为正系数的 $G$ 幂，故关于 $log G$ 凸。取两个端点的既有向上舍入界之大者即覆盖整个闭区间，再在阶数间取小。最后对覆盖 $[G_0,G_1]$ 的全部相邻二分区间取**最大**，并与原项目完整上界取小。

## 已定价的代表带

使用 `python point_price.py`，在首窗内只重新生成起点 $9/20,49/100$ 的 pair、six 各三网格行，共 12 行。各行重算内外盒和正反方向，再由原账本重新择路。`point-price.txt` 和 `point-updates.json` 记录输出。历史三盒基线的 with3 $T_{67}$ 从 1.718918398665 降至 1.718889751750，without3 从 1.434164226141 降至 1.434153002015。该数字只计这两条代表带。
