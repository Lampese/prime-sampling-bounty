"""Refine the lifted discriminant square sieve on reciprocal differences."""
from fractions import Fraction as F
from functools import lru_cache
from math import gcd,isqrt
from prime_sampling.rectangles import allsquarecap as av

@lru_cache(None)
def occupancy(n):
    if n<=0:
        raise ValueError("modulus must be positive")
    reduced=n
    for prime in (2,3):
        while reduced%prime==0:
            reduced//=prime
    if reduced!=1:
        raise ValueError("modulus must be positive and have prime factors 2 or 3")
    modulus=2*n
    units=[x for x in range(modulus) if gcd(x,modulus)==1]
    return len({((y-x)%modulus,x*y%modulus) for x in units for y in units})


@lru_cache(maxsize=32768)
def partition(a,b,V,p0,p1,moduli=(1,2,3,6,18),corner=False,layered=False):
    ceil=av.ceildiv
    D=isqrt(p1//b)
    hi=max(b*D,ceil(p1,D))
    g0=max(b,min(a*a,ceil(p0,b+V)))
    slope=F(V,p0) if corner else F((2*b+V)*V,2*b*p0)
    worst=0
    while hi>=g0:
        lo=max(g0,hi//2)
        row=min(max(x,y) for x,y in zip(av.row_bound(a,b,V,p0,lo),
                                        av.row_bound(a,b,V,p0,hi)))
        if row<=worst:
            if lo==g0:break
            hi=lo
            continue
        jm=slope*hi
        best=row
        def sieved(jscale,kscale,parity):
            upper=jm/jscale
            kw=F(V*b,lo*kscale)+upper/2
            area0=slope*V*b/(jscale*kscale)+upper*upper/2
            candidate=row
            for n in moduli:
                classes=occupancy(2*n)//2 if parity else occupancy(n)
                jbound=(upper/n+3).__ceil__()
                kbound=(kw/n+3).__ceil__()
                area=(area0/(n*n)+3*(upper+kw)/n+9).__ceil__()
                value=av.bill(jbound,kbound,area,b,p0)
                if value is not None:
                    candidate=min(candidate,classes*value)
                if candidate<=worst:break
            return candidate
        best=sieved(1,1,False)
        if layered and best>worst:
            first=sieved(1,2,True)
            if first<best:
                best=min(best,max(first,sieved(2,1,True)))
        worst=max(worst,best)
        if lo==g0: break
        hi=lo
    return worst

def install(corner=False,layered=False):
    """Call immediately after upstream sieved_lift.install(boxes)."""
    from prime_sampling.spectrum import squarerates as sr
    old=sr.square_cap
    @lru_cache(maxsize=32768)
    def combined(a,b,v,p0,p1):
        first=old(a,b,v,p0,p1)
        if a<=194 or b<=a or v<=0 or v>b:
            return first
        return min(first,partition(a,b,v,p0,p1,corner=corner,layered=layered))
    sr.square_cap=combined
