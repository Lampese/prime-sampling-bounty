"""Check the max-min pruning against the full integer cap on actual boxes."""
import sys
import os
from argparse import ArgumentParser
from fractions import Fraction as F
from importlib.util import module_from_spec,spec_from_file_location
from pathlib import Path

here=Path(__file__).resolve().parent
parser=ArgumentParser(description=__doc__)
parser.add_argument('--repo',required=True,type=Path)
args=parser.parse_args()
sys.path.insert(0,str(args.repo.resolve()))
from prime_sampling.rectangles import boxes,sieved_lift
import crt_fibres as fast

spec=spec_from_file_location('full_cap',here.parent/'crt-v2'/'crt_fibres.py')
full=module_from_spec(spec)
spec.loader.exec_module(full)
boxes.initialize(F(639,4),F(1279,8))
sieved_lift.install(boxes)
for u in map(F,('.40','.45','.47','.49')):
    _,_,a,b,_,v,_,_=boxes.params(u,u+F(1,3200))
    params=a,b,v,boxes.pmin,boxes.pmax
    exact=full.partition(*params,corner=True,layered=True)
    assert exact==fast.partition(*params,corner=True,layered=True)
    print(u,exact,flush=True)
if os.name=='nt':
    import _ctypes
    from prime_sampling.spectrum import squarerates
    _ctypes.FreeLibrary(squarerates._lib._handle)
