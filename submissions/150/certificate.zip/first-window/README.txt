150 首窗研究记录

本包给出 150 ≤ log p ≤ 4801/32 的分支预算、矩形质量、谱率与逐带价格。验收要求两支都满足 A−R−T>0，并连续接到已证区间。各项当前余量的精确整数见 hyperbola-next/margins.json，单位 10^-12。

上游提交 63a2d41e8124320784c244336ff36ac5f2285418。解压后，在任意目录使用 Python 3.10 或更高版本运行

    python -B hyperbola-next/replay.py --repo D:/path/to/prime-sampling-bounty

快速入口从附带的谱表、逐带价格和分支预算复算四个截点，另外运行小素域抽查、分割边界测试并重建一维筛后段。可附加 --rebuild-scalar 重编整数核和重建起始筛。可附加 --rebuild-geometry 重建 recipes.json 的全部二维费用。重建需要接受 GCC 命令行选项的 C++17 编译器，环境变量 CXX 可指定其路径。

使用 --omit-trace 可以独立复核去掉本包新增的四次伸缩矩估计后的两支余量。near-lines/proof.md 给出任意非零伸缩下的六边形格点近邻界。reflection/proof.md 给出对称位移下的交叉项。native-first 内的九列谱表沿用上游的质量归一和取整，source.json 记录生成它们的短带包络。共享形状仅复用核参数，每个矩形仍以自身端点和有理数重新证明其谱率。

hyperbola-next/geometry-proof.md 解释矩形分割、θ 部分积分、平方边界和向外取整。operator-new/proof.md 与 spectral-coupling/cosets-and-trace.md 说明加权采样和谱分组。scalar-global/README.md 和 scalar-tail/README.md 给出各自的模型量词、投影不等式和分支条件。fibre-lines/smooth-proof.md 给出更新的倒数差界，trace-dilate/quartic.md 给出早段完成核。random-wheel 记录随机互补剩余类的精确平均。

cofactor-refined/proof.md 说明如何把余因子按重复素因子以及一到四个互异素因子分开计数。用 --rebuild-scalar 可复算两个分支的四项预算。验证日志另给出仅引用原版生成的标量预算、同时舍去新增四次伸缩矩时的结果。连续覆盖证书及其原版 grade 日志随首窗包单独提供。

operator-new/frequency-envelope.md 证明了单位剩余类轮权的 Fourier 超平面上界。gram-cycle/conductor.md 说明高矩的局部常数。fibre-portfolio/verify.py 可独立重建后段素数矩形的几何界和宏带费用。coordinate-lp/research.txt 记录了布尔坐标线性规划与树筛的对照结果。

直接参考文献

Broadbent、Kadiri、Lumley、Ng、Wilk，Sharper Bounds for the Chebyshev function θ(x)，https://arxiv.org/abs/2002.11068 。
Kerr、Shparlinski、Yau，A refinement of the Burgess bound for character sums，https://arxiv.org/abs/1711.10582 。
Ford、Maynard，On the theory of prime producing sieves，https://arxiv.org/abs/2407.14368 。本包自行证明所用有限投影预算。

seed-weights/proof.md 给出梯形与边缘三角形的平滑起始筛。transfer-weights/proof.md 给出按真实最小素因子切分余因子、用有限 Selberg 平方权重估人口的证明。--rebuild-scalar 会依次重算两者。gram-cycle/joint-completion.md 与 aperture.md 给出固定标签的联合 Gram 完成，以及素数奇格上的正 Fourier 样条。mass-geometry/joint_bounds.py 同时使用内外接矩形质量的单侧界。

transfer-bilinear/proof.md 从题面 (1a) 建立真实算术区间上的双 Selberg 投影。seed-bridge/proof.md 给出物理梯形、平方自由除数权的加性 Fourier 展开、余因子人口下界和分区费用。seed-bridge/freeze.py 的 --rank 38 --check 和 --rank 37 --check 分别重算两支的固定参数，再用 --route --check 核对与原始预算的拼接。这三步也由 --rebuild-scalar 执行。
