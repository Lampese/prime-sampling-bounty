from argparse import ArgumentParser
from fractions import Fraction as F
from functools import cache
from math import prod
from pathlib import Path

from prime_sampling.accounting import ledger


def tree(primes, penalty, raw=False):
    inverse = [1/p for p in primes]
    norms = [1 if raw else 1-2/p for p in primes]

    def even(start, mean, norm, mask):
        value = mean + penalty*norm
        terms = [(mask,1)]
        for i in range(start,len(primes)):
            q = mean*inverse[i]
            cost = norm*norms[i]
            if q <= penalty*cost:
                continue
            node = mask | 1<<i
            score = -q + penalty*cost
            tail = [(node,-1)]
            for j in range(i+1,len(primes)):
                bill, children = even(j+1,q*inverse[j],cost*norms[j],node | 1<<j)
                score += bill
                tail.extend(children)
            if score < 0:
                value += score
                terms.extend(tail)
        return value,terms

    return tuple(even(0,1,1,0)[1])


@cache
def exact(primes, terms):
    @cache
    def weight(mask, kind):
        if mask == 0:
            return F(1)
        bit = mask & -mask
        p = primes[bit.bit_length()-1]
        return weight(mask^bit,kind) * (F(1,p) if kind == 0 else p-1)

    coeff = {}
    for mask, sign in terms:
        value = sign*weight(mask,0)
        sub = mask
        while True:
            coeff[sub] = coeff.get(sub,0)+value
            if sub == 0:
                break
            sub = mask & (sub-1)
    return coeff[0],sum(abs(val)*weight(mask,1) for mask,val in coeff.items())


original_bank = ledger.bank


@cache
def new_bank(seq, kind):
    options, scale = original_bank(seq,kind)
    import os
    folder=os.environ.get('PRIME_TREE_DIR')
    capture=os.environ.get('PRIME_TREE_CAPTURE')
    if folder or capture:
        import tree_catalog
    if folder and not capture:
        path=Path(folder)/tree_catalog.name(seq,kind)
        if path.is_file():
            return tree_catalog.load(path,seq,kind,options,scale,exact,ledger.I)
    witnesses={}
    cap = {"single":1,"pair":2,"six":4}[kind]
    extra = set()
    for h in range(max(cap.bit_length()-1,1),min(14,len(seq))):
        prefix = prod(1-F(1,p) for p in seq[:h])
        for end in (len(seq),max(h+1,len(seq)-8),max(h+1,len(seq)-16)):
            if h >= end:
                continue
            for rev in (False,True):
                tail = seq[h:end][::-1] if rev else seq[h:end]
                termsets = set()
                for i in range(40):
                    g = .00006 * 1.17**i
                    if g >= .4:
                        break
                    for raw in (False,True):
                        penalty = 2**h*g/(1-g)
                        termsets.add(tree(tail,penalty,raw))
                for terms in termsets:
                    avg,total = exact(tail,terms)
                    mean, norm = avg*prefix,total*prefix*2**h
                    if mean > 1:
                        continue
                    unit = ledger.I
                    q = (cap-1)*mean
                    row=(((1-mean)*unit).__floor__(),((norm-mean-q)*unit).__ceil__(),(q*unit).__ceil__())
                    extra.add(row)
                    if capture:
                        odd=sorted(mask for mask,sign in terms if sign<0)
                        candidate=(h,end,int(rev),odd)
                        if row not in witnesses or candidate<witnesses[row]:witnesses[row]=candidate
    frontier = []
    for row in sorted(set(options)|extra,key=lambda r:(-r[0],r[1],r[2])):
        if not any(old[0]>=row[0] and old[1]<=row[1] and old[2]<=row[2] for old in frontier):
            frontier.append(row)
    print("tree",len(seq),kind,len(extra),len(frontier),flush=True)
    if capture:tree_catalog.save(capture,seq,kind,witnesses,frontier,options)
    return tuple(frontier),scale


def main():
    parser = ArgumentParser()
    parser.add_argument("left",type=F)
    parser.add_argument("right",type=F)
    parser.add_argument("pair",type=Path)
    parser.add_argument("six",type=Path)
    parser.add_argument("budget",type=Path)
    parser.add_argument("--add",nargs=3,action="append",default=[],metavar=("KIND","GRID","FILE"))
    parser.add_argument("--tiles",action="store_true")
    args = parser.parse_args()
    ledger.bank = new_bank
    tables = [("extra",kind,args.left,args.right,3200,getattr(args,kind))
              for kind in ("pair","six")]
    tables.extend(("extra",kind,args.left,args.right,int(grid),Path(file))
                  for kind,grid,file in args.add)
    if args.tiles:
        costs = ledger.suffix_costs
        ledger.suffix_costs = lambda selected, seq, mode: costs(selected,seq,True)
    for branch, result in ledger.probe(args.left,args.right,tables,[args.budget]).items():
        ledger.report(args.left,args.right,branch,result)


if __name__ == "__main__":
    main()
