"""Independent pointwise verification of a sparse alternating sieve tree."""
from fractions import Fraction as F
from math import prod
from pathlib import Path
import json


def name(seq,kind):
    return f'{kind}-'+('-'.join(map(str,(len(seq),*seq[:2],seq[-1]))))+'.json'


def reconstruct(length,odd):
    negatives=set(odd);visited=set();terms=[]
    if len(negatives)!=len(odd):raise ValueError('Duplicate odd node')
    def even(start,mask):
        terms.append((mask,1))
        for i in range(start,length):
            bit=mask|1<<i
            if bit not in negatives:continue
            visited.add(bit);terms.append((bit,-1))
            for j in range(i+1,length):even(j+1,bit|1<<j)
    even(0,0)
    assert negatives==visited
    return tuple(terms)


def load(path,seq,kind,old,scale,exact,I):
    data=json.loads(path.read_text())
    assert data['seq']==list(seq) and data['kind']==kind
    cap={'single':1,'pair':2,'six':4}[kind]
    rows=set(old)
    for h,end,rev,odd,expected in data['trees']:
        assert max(1,cap.bit_length()-1)<=h<end<=len(seq) and rev in (0,1)
        prefix=prod(1-F(1,p) for p in seq[:h])
        tail=seq[h:end][::-1] if rev else seq[h:end]
        mean,norm=exact(tail,reconstruct(len(tail),odd))
        mean*=prefix;norm*=prefix*2**h;q=(cap-1)*mean
        assert 0<mean<=1 and norm>=mean+q
        row=(((1-mean)*I).__floor__(),((norm-mean-q)*I).__ceil__(),(q*I).__ceil__())
        assert tuple(expected)==row
        rows.add(row)
    result=[]
    for m,n,q in sorted(rows,key=lambda r:(-r[0],r[1],r[2])):
        if not any(a>=m and b<=n and c<=q for a,b,c in result):result.append((m,n,q))
    return tuple(result),scale


def save(folder,seq,kind,witnesses,frontier,old):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    rows=[[*witnesses[row],list(row)] for row in frontier if row not in old]
    data={'seq':list(seq),'kind':kind,'trees':rows}
    path=folder/name(seq,kind)
    stage=path.with_suffix('.pending')
    stage.write_text(json.dumps(data,separators=(',',':')),encoding='ascii')
    stage.replace(path)
