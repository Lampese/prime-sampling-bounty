"""Two-sided, directed certificate for the prime mass in the bounty window."""
from argparse import ArgumentParser
from decimal import Context, Decimal
from fractions import Fraction as F
from math import factorial


def bounds(value, operation):
    # Decimal ln/exp are correctly rounded to nearest. Enclose the argument as
    # well, then use monotonicity and take one extra ulp at each output endpoint.
    c = Context(prec=64)
    v = c.divide(Decimal(value.numerator), Decimal(value.denominator))
    evaluate = getattr(c, operation)
    return F(c.next_minus(evaluate(c.next_minus(v)))), F(c.next_plus(evaluate(c.next_plus(v))))


def prime_mass(left, right):
    assert 150 <= left <= right <= 175
    lo = bounds((bounds(left, 'exp')[0] / (left-1)).__floor__(), 'ln')[0]
    hi = right - bounds(right-F('1.1'), 'ln')[0]
    low_a, high_a = bounds(32, 'ln')
    assert lo-high_a > 100
    lam, err = F(1,32), F(2454,10**15)
    order = 9

    def moment(j,a):
        return factorial(j)*(1-lam*sum(a**k/factorial(k) for k in range(j+1)))
    lower = sum(moment(j,high_a)/hi**j for j in range(order+1))
    upper = sum(moment(j,low_a)/lo**j for j in range(order+1))
    ratio = high_a/lo
    upper += (1-lam)*ratio**(order+1)/(1-ratio)
    endpoint = 2*err*lam/(1-ratio)
    return ((2*((1-err)*lower-endpoint)*10**12).__floor__(),
            (2*((1+err)*upper+endpoint)*10**12).__ceil__())


def fmt(number):
    return f'{number//10**12}.{number%10**12:012d}'


if __name__=='__main__':
    ap=ArgumentParser(description=__doc__)
    ap.add_argument('left', type=F, nargs='?', default=F(150))
    ap.add_argument('right', type=F, nargs='?', default=F(4801,32))
    args=ap.parse_args()
    print(' <= normalized prime mass <= '.join(map(fmt,prime_mass(args.left,args.right))))
