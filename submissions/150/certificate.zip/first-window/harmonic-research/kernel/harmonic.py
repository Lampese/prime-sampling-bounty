"""Flat CRT displacement kernel with direct even moments through order twelve."""
from argparse import ArgumentParser
import ctypes as ct
from fractions import Fraction as F
from math import factorial, isqrt, prod
from pathlib import Path
import os
import subprocess
from tempfile import TemporaryDirectory

from prime_sampling.rectangles import generate
from prime_sampling.spectrum import pair10
from physical_moments_trial import generic_bound,partitions

PRIMES=(2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67)
WHEELS=[(prod(PRIMES[:d]),prod(p-1 for p in PRIMES[:d]),prod(PRIMES[:i]),prod(p-1 for p in PRIMES[:i]))
        for d in range(len(PRIMES)+1) for i in range(min(d,4)+1)]
RATIOS=tuple(map(F,('1/64','1/16','1/4','1/2','2/3','3/4','1','5/4','3/2','2','3','6','12')))


def install(mode,model,opposite_interval=None):
    from prime_sampling.spectrum import squarerates as sr
    tmp=TemporaryDirectory(ignore_cleanup_errors=True)
    lib=Path(tmp.name)/'flat.so'
    subprocess.run([os.getenv('CXX','c++'),'-O3','-std=c++17','-shared','-fPIC',
                    Path(__file__).with_name('harmonic_selector.cpp'),'-o',lib],check=True)
    selector=ct.CDLL(str(lib)).flat
    selector.argtypes=[ct.c_double]*11+[ct.c_int,ct.POINTER(ct.c_int)]
    selector.restype=None
    old=model.rates
    def rates(a,b,width,s,k,span,pm,p,_lifetime=tmp):
        best=list(old(a,b,width,s,k,span,pm,p))
        if max(best)<F(1,6000):return best
        md=min(sr.dirichlet_cap(a,b,width,pm,p),sr.previous_cap(width,b,pm),sr.square_cap(a,b,width,pm,p))
        ids=(ct.c_int*2)()
        # Bounds on the opposite side follow from X/64 < a*b < 2X.
        if opposite_interval:
            ymin,ymax=opposite_interval()
        else:
            ymin=model.elo(model.zl)/(64*b); ymax=2*model.eup(model.zh)/a
        logy=model.b(ymin,'ln',False)
        assert logy>=40
        err=model.thetaerr(logy)
        selector(*map(float,(a,b,width,s,k,span,pm,p,md,logy,err*ymax)),int(mode=='six'),ids)
        sqrt=isqrt(p)+1
        for code in set(ids)-{-1}:
            i,sj=divmod(code,len(RATIOS)**2);sj,j=divmod(sj,len(RATIOS));W,phi,w1,p1=WHEELS[i]
            d=sr.ceildiv(span,W)+5;h=max(1,int(d*RATIOS[sj]));m=max(1,int(d*RATIOS[j]))
            peak=min(h,m); rep=min(peak,(h+m-d)//2)
            if rep<=0:continue
            support=m*(phi//p1)
            if W>=a or support<10**6 or 2*W*(max(h,m)+d)>=pm:continue
            near=sr.weighted_near(a,b,width,pm,p,w1,h)
            co=(1+F(md*near,s))/(h*p1*s*s);sigma=F(1,support)
            mean=F(1,peak)
            for n in range(1,17):
                low=rep+(peak-rep)*(n-1)//16; high=rep+(peak-rep)*n//16
                if high==low:continue
                cnt=min(k,(2*(high-rep+3)*W+4*err*ymax)/logy+2)
                mean+=(F(1,low)-F(1,high))*cnt/k
            front=F(phi*h*m,k)*mean
            for q in (0,1):
                D=(F(2,9) if q else F(3,16)) if mode=='six' else (F(1) if q else F(1,2))
                labels=3 if mode=='six' else 1
                C=F(129,128) if mode=='six' and not q else F(1)
                for r in range(2,7):
                    gen=generic_bound(mode,q,r,p,sqrt,C,True)
                    ex=C*p*p*sum(partitions(2*r,j)*sigma**(2*r-j) for j in range(1,r))
                    lead=labels*(prod(range(1,2*r,2)) if q else factorial(r))*D**r
                    mom=gen+ex+lead*p*p*sigma**r
                    off=pair10.nroot(co*mom,2*r)
                    if r==2:
                        fix=12*p*sigma*(1+2*sigma)
                        var=gen+ex+labels*(2 if q else 1)*(D*p*sigma)**2+fix
                        off=min(off,sr.root(D*sigma+sr.root(co*var)))
                    best[q]=min(best[q],sr.root(front*(F(1,s)+off)))
        return best
    model.rates=rates


if __name__=='__main__':
    p=ArgumentParser(description=__doc__);p.add_argument('left',type=F);p.add_argument('right',type=F)
    p.add_argument('mode',choices=('pair','six'));p.add_argument('--grid',type=int,default=3200)
    p.add_argument('--also-triangular',action='store_true')
    args=p.parse_args()
    assert 150<=args.left<args.right<=175 and args.grid>=600 and args.grid%200==0
    if args.also_triangular:
        from physical_moments_trial import install as triangular
        def both(mode,model):
            triangular(mode,model,True)
            install(mode,model)
        generate.install_mode=both
    else:generate.install_mode=install
    generate.emit(args.left,args.right,args.mode,args.grid)
