"""Three center translations on three target rectangles, with exact final pricing."""
from fractions import Fraction as F
from functools import cache
import sys

import centered_tri as tri
from prime_sampling.rectangles import boxes as box
from prime_sampling.rectangles.sieved_lift import install as install_collisions


original = tri.harmonic_coverage
fractions = (F(1,8),F(1,4),F(3,8),F(1,2),F(3,4),F(1))
weights = (F(1,4),F(1,2),F(3,4),F(1))


def charge(rows, exact):
    one = F(1) if exact else 1.
    remaining = one
    total = 0
    for mass, capacity in sorted(rows, key=lambda pair:pair[0]):
        if mass <= 0:
            return None
        amount = min(remaining,capacity)
        total += amount/mass
        remaining -= amount
        if remaining <= 0:
            return total
    return None


@cache
def policies(d,h,m,wheel,k,logy,error):
    old = original(d,h,m,wheel,k,logy,error)
    if old is None:
        return (None,)*4
    high = h+2*m-3
    left = (high+1-d)//2
    intervals = []
    for i in range(64):
        start = left + d*i//64
        stop = left + d*(i+1)//64-1
        if start<=stop:
            count = min(F(1),(1+((stop-start+3)*wheel+2*error)/logy)/k)
            intervals.append((start,stop,count))
    def mass(x,shift):
        return tri.representations(x+shift,h,m) if 0<=x+shift<=high else 0
    def coverage(shift):
        return [min(mass(a,shift),mass(b,shift)) for a,b,_ in intervals]
    zero = coverage(0)
    capacities = [c for _,_,c in intervals]
    base = charge(list(zip(zero,capacities)),True)
    baseline = min(old,base) if base is not None else old
    best = float(baseline)
    choice = None
    for frac in fractions:
        shift = int(d*frac)
        low, highside = coverage(-shift),coverage(shift)
        summed = [x+y for x,y in zip(low, highside)]
        for weight in weights:
            f = float(weight)
            rows = [((1-f)*a+f*b/2,float(c)) for a,b,c in zip(zero,summed,capacities)]
            value = charge(rows,False)
            if value is not None and value<best:
                best = value
                choice = (weight,summed)
    mixture = baseline
    if choice is not None:
        weight, summed = choice
        rows = [((1-weight)*a+weight*b/2,c) for a,b,c in zip(zero,summed,capacities)]
        value = charge(rows,True)
        if value is not None:
            mixture = min(mixture,value)
    ideal = F(1,tri.representations(high//2,h,m))
    return old,baseline,mixture,ideal


def main():
    mode = sys.argv[1]
    box.initialize(F(150),F(4801,32))
    install_collisions(box)
    tri.install(mode,box,True)
    for n, name in enumerate(('original','64-bin','mixture','ideal-peak')):
        tri.harmonic_coverage = lambda *args: policies(*args)[n]
        box.joint.cache_clear()
        for numerator in (40,45,49):
            u=F(numerator,100)
            v=u+F(1,3200)
            gc,qc,_=box.joint(u,v,*box.inner(u,v))
            print(mode,numerator,name,box.upint(gc),box.upint(qc),flush=True)


if __name__=='__main__':
    main()
