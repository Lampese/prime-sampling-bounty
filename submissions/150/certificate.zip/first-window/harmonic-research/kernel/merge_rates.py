"""Take the better rate for each class on identical certified rectangles."""
from pathlib import Path
import sys

def merge(output,files):
    sources=[[tuple(map(int,line.split())) for line in path.read_text().splitlines()] for path in files]
    if not sources or not sources[0] or any(len(s)!=len(sources[0]) for s in sources):
        raise ValueError('Table sizes differ or no rows supplied')
    with output.open('w',encoding='ascii') as dest:
        for variants in zip(*sources):
            row=variants[0]
            if any(len(v)!=9 or v[0]!=row[0] or v[5:]!=row[5:] for v in variants):
                raise ValueError('Rectangle quantities differ')
            print(row[0],*(min(v[i] for v in variants) for i in range(1,5)),*row[5:],file=dest)

if __name__=='__main__':
    merge(Path(sys.argv[1]),list(map(Path,sys.argv[2:])))
