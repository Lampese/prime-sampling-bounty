from argparse import ArgumentParser
import ctypes as ct
from fractions import Fraction as F
from functools import cache
from math import comb, isqrt, prod
import os
from pathlib import Path
import subprocess
from tempfile import TemporaryDirectory

from prime_sampling.rectangles import generate
from prime_sampling.spectrum import pair10


PRIMES = (2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47)
WHEELS = [
    (prod(PRIMES[:d]), prod(p-1 for p in PRIMES[:d]), prod(PRIMES[:i]),
     prod(p-1 for p in PRIMES[:i]), 2**(d-i))
    for d in range(1, len(PRIMES)+1) for i in range(min(d, 5)+1)
]
RATIOS = tuple(map(F, ("1/128", "1/32", "1/8", "1/3", ".7", "1.5", "3", "6", "12", "24")))


@cache
def partitions(slots, blocks):
    if blocks == 0:
        return int(slots == 0)
    return sum(comb(slots-1, size-1) * partitions(slots-size, blocks-1)
               for size in range(2, slots-2*(blocks-1)+1))


def generic_bound(mode, q, r, p, sqrt, label_norm, parity):
    odd = ((2*r-1)**2-1)*p + 2*r
    if not parity:
        return label_norm*odd
    even = ((2*r-2)**2-1)*p + 2*(2*r-2)*sqrt + 1 + 2*r
    if mode == "pair" and q:
        return even
    signed_weight = F(3,3**(2*r)) if mode == "six" and q else F(0)
    return (label_norm*(odd+even) + signed_weight*(even-odd))/2


BASE_FRACTIONS = tuple(map(F, ('1/16', '1/8', '1/4', '2/5', '1/2', '2/3', '5/6', '1')))


def representations(x, h, m):
    left = max(0, x - h + 1)
    right = min(2*m - 2, x)
    mid = min(m-1, right)
    total = max(0, mid-left+1) * (left+mid+2)//2
    second = max(m, left)
    return total + max(0, right-second+1) * (4*m-2-second-right)//2


def harmonic_coverage(d, h, m, wheel, k, logy, error):
    last = h + 2*m - 3
    left = (last + 1 - d)//2
    peak = last//2
    if left < 0:
        return None
    worst = representations(left, h, m)
    assert worst >= 1
    mean = F(1, representations(peak, h, m))
    for i in range(1,17):
        low = left + (peak-left)*(i-1)//16
        high = left + (peak-left)*i//16
        if high == low:
            continue
        count = min(k, 2 + (2*(high-left+3)*wheel + 4*error)/logy)
        mean += (F(1,representations(low,h,m)) - F(1,representations(high,h,m)))*count/k
    return mean


def prepare_selector(tmp):
    dll = tmp / 'centered.so'
    subprocess.run([os.getenv('CXX','c++'), '-O3', '-std=c++17', '-shared', '-fPIC',
                    Path(__file__).with_name('centered_tri_selector.cpp'), '-o', dll], check=True)
    select = ct.CDLL(str(dll)).choose
    select.argtypes = [ct.c_double]*11 + [ct.c_int, ct.POINTER(ct.c_int)]
    select.restype = None
    return select


def install(mode, model, parity=False, opposite_interval=None):
    from prime_sampling.spectrum import squarerates as sr

    temporary = TemporaryDirectory(ignore_cleanup_errors=True)
    select = prepare_selector(Path(temporary.name))
    old = model.rates

    def rates(a, b, width, s, count, span, p_min, p, _keep_alive=temporary):
        orig = old(a,b,width,s,count,span,p_min,p)
        if max(orig) < F(1,3000):
            return orig
        md = min(sr.dirichlet_cap(a,b,width,p_min,p), sr.previous_cap(width,b,p_min),
                 sr.square_cap(a,b,width,p_min,p))
        best = list(orig)
        ids = (ct.c_int*2)()
        if opposite_interval:
            ymin,ymax=opposite_interval()
        else:
            ymin = model.elo(model.zl)/(64*b)
            ymax = 2*model.eup(model.zh)/a
        logy = model.b(ymin, 'ln', False)
        assert logy>=40
        error = model.thetaerr(logy)*ymax
        select(*map(float,(a,b,width,s,count,span,p_min,p,md,logy,error)),int(mode=='six'),ids)
        root = sr.root
        sqrt = isqrt(p)+1
        for code in set(ids)-{-1}:
            setting, base = divmod(code, len(BASE_FRACTIONS))
            index, ratio = divmod(setting, len(RATIOS))
            wheel, phi, w1, phi1, divisor_count = WHEELS[index]
            assert wheel < a and wheel % w1 == 0
            phi2 = phi//phi1
            blocks = sr.ceildiv(span,wheel)+5
            shifts = max(1, (blocks*RATIOS[ratio]).__floor__())
            height = max(1, int((blocks+2*shifts)*BASE_FRACTIONS[base]))
            support = shifts*phi2
            if support < 10**6 or 2*wheel*(height+2*shifts+blocks) >= p_min:
                continue
            near = sr.weighted_near(a,b,width,p_min,p,w1,height)
            co = (1+F(md*near,s))/(height*phi1*s*s)
            sigma = F(2*shifts*shifts+1,3*support*shifts*shifts)
            harmonic = harmonic_coverage(blocks,height,shifts,wheel,count,logy,error)
            if harmonic is None:
                continue
            front = F(phi*height*shifts**2,count)*harmonic
            l1sq = min(F(1,phi2), (F(divisor_count,phi2)*
                       (1+root(F(2*(wheel//w1),shifts))))**2)
            generic4 = 14*F(p*p*sqrt,shifts*shifts)*sigma*l1sq
            assert F(1,support*support) <= sigma
            for q in (0,1):
                if mode == "six":
                    mass = F(2,9) if q else F(3,16)
                    label_norm, labels = (F(1) if q else F(129,128)), 3
                    lower_correction = 12*p*sigma*(1+2*sigma)
                else:
                    mass = F(1) if q else F(1,2)
                    label_norm, labels = F(1), 1
                    lower_correction = (2 if q else 8)*p*sigma*(1+2*sigma)
                physical4 = (generic_bound(mode,q,2,p,sqrt,label_norm,parity)
                             +label_norm*F(p*p,support*support)*sigma)
                variance = (min(label_norm*generic4,physical4)
                            +labels*(2 if q else 1)*(p*sigma*mass)**2+lower_correction)
                best[q] = min(best[q],root(front*(F(1,s)+root(mass*sigma+root(co*variance)))))
                for r, mult, factorial in ((3,15,6),(4,105,24),(5,945,120)):
                    total = labels*mult*((2*mass)**r if q else mass**r)
                    lead = labels*(mult if q else factorial)*mass**r
                    paired = lead*p*p*sigma**r
                    spectral = (label_norm*(4**r-2)*p*sqrt*sigma*
                                (F(p,shifts*shifts)*l1sq)**(r-1)
                                +paired+(total-lead)*p*sigma**(r-1))
                    physical = (generic_bound(mode,q,r,p,sqrt,label_norm,parity)
                                +label_norm*p*p*sum(partitions(2*r,j)*sigma**j/
                                   support**(2*r-2*j) for j in range(1,r))+paired)
                    exact = min(spectral,physical)
                    best[q] = min(best[q],root(front*(F(1,s)+pair10.nroot(co*exact,2*r))))
        return best

    model.rates = rates


def main():
    parser = ArgumentParser()
    parser.add_argument("left", type=F)
    parser.add_argument("right", type=F)
    parser.add_argument("mode", choices=("pair","six"))
    parser.add_argument("--grid", type=int, default=3200)
    parser.add_argument("--parity", action="store_true")
    args = parser.parse_args()
    assert 150 <= args.left < args.right <= 175 and args.grid >= 600 and args.grid % 200 == 0
    generate.install_mode = lambda mode, model: install(mode,model,args.parity)
    generate.emit(args.left,args.right,args.mode,args.grid)


if __name__ == "__main__":
    main()
