from argparse import ArgumentParser
from pathlib import Path
import json

here=Path(__file__).resolve().parent
parser=ArgumentParser(description='Compare the same macro recursion with and without the weighted-base kernel.')
parser.add_argument('--prior',type=Path,default=here.parent/'hyperbola-next')
parser.add_argument('--input',type=Path,default=here)
parser.add_argument('--out',type=Path,default=here/'hyper-combined.json')
args=parser.parse_args()
combined={}
for kind in ('six','pair'):
    before=json.loads((args.prior/f'abel-{kind}.json').read_text())
    for file in sorted(args.input.glob(f'hyper-{kind}*.json')):
        data=json.loads(file.read_text())
        for macro,new in data.items():
            for branch,price in new.items():
                target=combined.setdefault(macro,{})
                target[branch]=min(price,target.get(branch,price))
                if branch in before.get(macro,{}):
                    old=before[macro][branch]
                    assert old>=price,(macro,kind,branch,old,price)
                    print(kind,macro,branch,'old',old,'new',price,'saving',old-price)
args.out.write_text(json.dumps(combined,indent=2)+'\n',encoding='ascii')
