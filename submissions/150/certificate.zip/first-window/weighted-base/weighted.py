"""Two-level symmetric base laws with matched triangular collision bounds."""
from fractions import Fraction as F
from functools import lru_cache
from math import ceil,isqrt
import ctypes as ct
import os
from pathlib import Path
import subprocess
from tempfile import TemporaryDirectory

from mixed import coverage,price
from prime_sampling.spectrum import squarerates as sr


def base(h,l,z):
    # Physical weights are (A 1_h - B 1_l)/h on concentric intervals.
    assert 0<l<h and (h-l)%2==0
    B=z*h/(h-l)
    return 1+B*l/h,B


def corr(h,l,A,B,j):
    def tail(H):return max(0,H-abs(j))
    return (A*A*tail(h)+B*B*tail(l)-2*A*B*(tail((h+l)//2)-tail((h-l)//2)))/(h*h)


def coll_radius(h,l,A,B):
    r0=corr(h,l,A,B,0)
    H=max(j*r0/(r0-corr(h,l,A,B,j)) for j in (h,l,(h+l)//2,(h-l)//2))
    return r0,ceil(H)


def delta(x,m,h):
    return F(max(0,m-abs(x+1))-max(0,m-abs(x+1-h)),m*m)


def unimodal(h,l,A,B,m,n,wt,start,peak):
    if not B or start>=peak:return True
    shift=(h-l)//2
    cuts={start,peak-1}
    for L,off in ((h,0),(l,shift)):
        for M in (m,n):
            for center in (0,L):
                for v in (-M,0,M):
                    pos=off+center+v-1
                    if start<=pos<peak:cuts.add(pos)
    for x in cuts:
        D=sum(w*(A*delta(x,M,h)-B*delta(x-shift,M,l)) for M,w in ((m,1-wt),(n,wt)))
        if D<0:return False
    return True


def floating_coverage(x,h,m):
    def cdf(t):
        if t<=-m:return 0.
        if t>=m-1:return 1.
        if t<0:return (t+m)*(t+m+1)/(2*m*m)
        return 1-(m-t-1)*(m-t)/(2*m*m)
    return cdf(x)-cdf(x-h)


def proposals(h,m,n,wt,d):
    H=float(h); M=float(m); N=float(n); w=float(wt); D=float(d)
    scores=[]
    for ell in (F(1,3),F(1,2),F(2,3),F(4,5)):
        l=max(1,int(h*ell));l-=(h-l)%2
        if l<1 or l>=h:continue
        for z in map(F,('-3/4','-1/2','-3/8','-1/4','-1/8','-1/16','0','1/16','1/8','1/4','3/8','1/2','3/4','1')):
            A,B=base(h,l,z)
            if A<0:continue
            r,Hrad=coll_radius(h,l,A,B)
            lf=float(l); Af=float(A); Bf=float(B);off=(H-lf)/2
            def axis(x,width):
                return Af*floating_coverage(x,H,width)-Bf*floating_coverage(x-off,lf,width)
            points=((H-D)/2+D*(j+.5)/96 for j in range(48))
            vals=[(1-w)*axis(x,M)+w*axis(x,N) for x in points]
            if min(vals)<=0 or any(a>b+1e-12 for a,b in zip(vals,vals[1:])):continue
            front=sum(map(lambda a:1/a,vals))/len(vals)
            scores.append((l,z,front,float(h*r),float(F(Hrad,h))))
    winners={(h//2-(h-h//2)%2,F(0))}
    for ratio in (F(1,2),F(2,3)):
        l=int(h*ratio);l-=(h-l)%2
        if l>0:
            winners.update((l,z) for z in map(F,('-1/2','-1/4','-1/8','-1/16','1/8')))
    for gamma in (.10,.17,.25):
        candidates=sorted(scores,key=lambda t:t[2]*(t[3]*t[4]**.4)**gamma)
        winners.update((q[0],q[1]) for q in candidates[:2])
    return sorted(winners)


def install(mode,model,opposite,selectors,bins=128,base_weights=True,trace=None,include=None,shape_menu=None,co_refiner=None,extra_choices=None,pass_radius=False,frequency_envelope=False,local_conductor=False,reweight=False,paley_four=False,tetra_four=False):
    tmp=TemporaryDirectory(ignore_cleanup_errors=True)
    dll=os.getenv('PRIME_MIXED_SELECTOR_DLL')
    if dll is None:
        dll=Path(tmp.name)/'weighted.so'
        subprocess.run([os.getenv('CXX','c++'),'-O3','-std=c++17','-shared','-fPIC',Path(selectors)/'mixed_selector.cpp','-o',dll],check=True)
    select=ct.CDLL(str(dll)).choose
    select.argtypes=[ct.c_double]*11+[ct.c_int,ct.c_int,ct.POINTER(ct.c_int)]
    select.restype=None
    old=model.rates
    @lru_cache(maxsize=50000)
    def invlog(n):
        return F(1,model.b(n,'ln',False))
    def rates(a,b,width,s,k,span,pm,p,_keep=tmp):
        best=list(old(a,b,width,s,k,span,pm,p))
        if include is not None and not include(a,b,width,s,k,span,opposite()):return best
        md=min(sr.dirichlet_cap(a,b,width,pm,p),sr.previous_cap(width,b,pm),sr.square_cap(a,b,width,pm,p))
        ymin,ymax=opposite()
        ymin=ymin.__floor__(); ymax=ymax.__ceil__()
        logy=model.b(ymin,'ln',False); eps=model.thetaerr(logy)
        ids=(ct.c_int*2)()
        select(*map(float,(a,b,width,s,k,span,pm,p,md,logy,eps*ymax)),int(mode=='six'),1,ids)
        choices=set(ids)
        if extra_choices is not None:
            choices.update(extra_choices(a,b,width,s,k,span,pm,p,md,logy,eps*ymax))
        for code in choices-{-1}:
            code,ti=divmod(code,4);code,ni=divmod(code,33);code,mi=divmod(code,25);wi,hi=divmod(code,17)
            W,phi,divisors=((2,1,2),(6,2,4),(30,8,8))[wi]
            d=sr.ceildiv(span,W)+7
            h,m,n=(max(1,d*i//8) for i in (hi,mi,ni))
            if W>=a or m*phi<10**6 or 2*W*(h+2*n+d)>=pm:continue
            wt=F(ti,4);tau=(1-wt)/m+wt/n;omega=tau/phi;l1=tau*divisors/W
            sigma=((1-wt)**2*F(2*m*m+1,3*m**3)+wt**2*F(2*n*n+1,3*n**3)
                   +2*wt*(1-wt)*(F(1,n)-F(m*m-1,3*m*n*n)))/phi
            start=(h-d)//2;peak=(h-1)//2
            projective_discount=0
            tetra_discount=0
            if paley_four:
                from paley_four import good
                weights={m:F(1)} if m==n else {m:1-wt,n:wt}
                projective_discount=4*pm*good(weights,W,phi,pm,p)
            if tetra_four and mode=='six':
                from paley_four import tetra_share
                weights={m:F(1)} if m==n else {m:1-wt,n:wt}
                tetra_discount=2*pm*tetra_share(weights,n,W,phi,omega,pm,p)
            def count_piece(y,N):
                if N<=0:return F(0)
                # Integrate 1/log(x) using its secant, then apply theta error.
                return N*(invlog(y)+invlog(y+N))/2+2*eps*ymax*invlog(y)
            highs=[];caps=[]
            for j in range(1,bins+1):
                H=start+(peak-start)*j//bins
                N=(H-start+2)*W
                right=max(ymin,ymin+(h-3-H-start)*W)
                cap=count_piece(ymin,N)+count_piece(right,N)+2
                highs.append(H);caps.append(min(1,cap/k))
            if shape_menu is not None:
                shapes=[(int(h*ratio)-(h-int(h*ratio))%2,z) for ratio,z in shape_menu]
            else:
                shapes=proposals(h,m,n,wt,d) if base_weights else [(h//2-(h-h//2)%2,F(0))]
            for l,z in shapes:
                A,B=base(h,l,z)
                if min(A,1-z)<0:continue
                if not unimodal(h,l,A,B,m,n,wt,start,peak):continue
                def prob(x):
                    def piece(M):
                        return A*coverage(x,h,M)-B*coverage(x-(h-l)//2,l,M)
                    return (1-wt)*piece(m)+wt*piece(n)
                first=prob(start)
                if first<=0:continue
                mean=1/prob(peak);prev=1/first; scale=10**17
                for H,cap in zip(highs,caps):
                    other=1/prob(H)
                    assert prev>=other
                    mean+=F(ceil((prev-other)*cap*scale),scale);prev=other
                r0,rad=coll_radius(h,l,A,B)
                if 2*rad>=pm:continue
                near=sr.weighted_near(a,b,width,pm,p,1,rad)
                co=r0*(1+F(md*near,s))/(s*s)
                if co_refiner is not None:
                    extra=(rad,) if pass_radius else ()
                    co=co_refiner(co,a,b,width,s,h,pm,p,r0,*extra)
                front=F(phi*h,k)*mean
                kwargs={}
                if projective_discount:kwargs['projective_discount']=projective_discount
                if tetra_discount:kwargs['tetra_discount']=tetra_discount
                if frequency_envelope:
                    from frequency_envelope import powers
                    weights={m:F(1)} if n==m else {m:1-wt,n:wt}
                    kwargs['spectral_weights']=powers(weights,W)
                if local_conductor:kwargs['local_min']=pm
                ans=price(mode,s,k,p,front,co,sigma,omega,l1,**kwargs)
                if reweight and mode=='six':
                    ans=list(map(min,ans,price(mode,s,k,p,front,co,sigma,omega,l1,tilt=F(1,4),**kwargs)))
                if trace is not None:trace(a,wi,hi,mi,ni,ti,l,h,z,ans)
                best=list(map(min,best,ans))
        return best
    model.rates=rates
