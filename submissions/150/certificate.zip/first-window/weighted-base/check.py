from fractions import Fraction as F
from itertools import product
from math import gcd
from pathlib import Path
from argparse import ArgumentParser
import os,sys

work=Path(__file__).resolve().parents[1]
parser=ArgumentParser()
parser.add_argument('--repo',type=Path,default=work/'prime-sampling')
parser.add_argument('--selectors',type=Path,default=work/'operator-new')
args=parser.parse_args()
sys.path[:0]=[str(args.repo.resolve()),str(args.selectors.resolve())]
if (work/'zig-cxx.cmd').exists():
    os.environ.setdefault('CXX',str(work/'zig-cxx.cmd'))
    os.environ.setdefault('ZIG_GLOBAL_CACHE_DIR',str(work/'zig-cache'))
    os.environ.setdefault('ZIG_LOCAL_CACHE_DIR',str(work/'zig-local-cache'))
from mixed import coverage
from weighted import base,corr,coll_radius,unimodal


cases=0
for h in range(4,13):
    for l in range(h-2,0,-2):
        for z in map(F,('-1/2','0','1/4','3/4','1')):
            A,B=base(h,l,z)
            if A<0:continue
            start=(h-l)//2
            weights=[(A-(B if start<=i<start+l else 0))/h for i in range(h)]
            assert sum(weights)==1 and min(weights)>=0
            zero,H=coll_radius(h,l,A,B)
            for j in range(h+1):
                actual=sum(x*y for x,y in zip(weights,weights[j:]))
                assert actual==corr(h,l,A,B,j)<=zero*max(F(0),1-F(j,H))
            for m,n,wt in ((2,4,F(1,4)),(h,h,F(0)),(5,9,F(3,4))):
                def P(x):
                    return sum(w*(A*coverage(x,h,M)-B*coverage(x-start,l,M))
                               for M,w in ((m,1-wt),(n,wt)))
                def triangle(x,M):return F(max(0,M-abs(x)),M*M)
                for x in range(-n,h+n):
                    brute=sum(weights[i]*((1-wt)*triangle(x-i,m)+wt*triangle(x-i,n)) for i in range(h))
                    assert h*brute==P(x)==P(h-1-x)
                for D in (h//2,h,2*h):
                    left=(h-D)//2;peak=(h-1)//2
                    assert unimodal(h,l,A,B,m,n,wt,left,peak)==all(P(j)<=P(j+1) for j in range(left,peak))
                cases+=1
print('exact two-level laws, autocorrelation envelopes, coverage and monotonicity',cases)

total=0
for W in (2,6,30):
    for L in (1001,1029,1031):
        for span in (38,91):
            d=(span+W-1)//W+7
            for h in (d//2,d,d+5):
                start=(h-d)//2;peak=(h-1)//2
                for v in range(start,peak+1):
                    for y in range(L+1,L+span+1):
                        if gcd(y,W)!=1:continue
                        x=y//W-L//W+start+1
                        assert start<=x<=x+1<=h-1-start
                        if x<v:assert y<=L+(v-start+2)*W
                        if x+1>h-1-v:
                            assert y>=L+(h-3-v-start)*W
                            assert y<=L+(h-3-v-start)*W+(v-start+2)*W
                        total+=1
print('exact endpoint coverage memberships',total)
if os.name=='nt':
    import _ctypes
    from prime_sampling.spectrum import squarerates
    _ctypes.FreeLibrary(squarerates._lib._handle)
