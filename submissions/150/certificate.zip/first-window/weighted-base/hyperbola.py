"""Reprice the ordinary Abel macro recursion with the actual sampled endpoints."""
from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
import sys,os,runpy

work=Path(__file__).resolve().parents[1]
cli=ArgumentParser()
cli.add_argument('--hyperbola',type=Path,default=work/'hyperbola-next')
cli.add_argument('--selectors',type=Path,default=work/'operator-new')
cli.add_argument('--bins',type=int,default=96)
cli.add_argument('--repo',type=Path,default=work/'prime-sampling')
cli.add_argument('--prior',type=Path,default=work/'harmonic-research')
cli.add_argument('--cap',type=Path,default=work/'residue-bridge/crt-fast')
cli.add_argument('--mode',choices=('six','pair'),default='six')
cli.add_argument('--macros',type=int,nargs='+',default=[84])
cli.add_argument('--out',required=True,type=Path)
cli.add_argument('--wide',action='store_true')
cli.add_argument('--shape-bound',action='store_true')
cli.add_argument('--left',type=F,default=F(150))
cli.add_argument('--right',type=F,default=F(4801,32))
args=cli.parse_args()
sys.path[:0]=[str(x.resolve()) for x in (args.selectors,args.repo,args.prior/'predecessor',args.prior/'kernel',args.hyperbola)]
if (work/'zig-cxx.cmd').exists():
    os.environ.setdefault('CXX',str(work/'zig-cxx.cmd'))
    os.environ.setdefault('ZIG_GLOBAL_CACHE_DIR',str(work/'zig-cache'))
    os.environ.setdefault('ZIG_LOCAL_CACHE_DIR',str(work/'zig-local-cache'))
import weighted,harmonic
original=harmonic.install
def improved(mode,model,opposite):
    original(mode,model,opposite)
    assert opposite is not None
    # The old rate is evaluated on all boxes. For the extra kernel only,
    # retain the short-input direction and its broad opposite interval.
    include=lambda a,b,width,s,k,span,ys: a<ys[0] and 3*span>ys[1]
    menu=[(F(1,2),F(0)),(F(2,3),F(-1,8)),(F(1,2),F(-1,4))]
    weighted.install(mode,model,opposite,args.selectors,args.bins,include=include,shape_menu=menu)
harmonic.install=improved
sys.argv=['rectangles.py','--repo',str(args.repo),'--prior',str(args.prior),'--cap',str(args.cap),
          '--left',str(args.left),'--right',str(args.right),
          *(['--wide'] if args.wide else []),*(['--near-shape'] if args.shape_bound else []),
          '--mode',args.mode,'--local-axis','--abel','--active-grid','200','--depth','4',
          '--macros',*map(str,args.macros),'--out',str(args.out)]
runpy.run_path(str((args.hyperbola/'rectangles.py').resolve()),run_name='__main__')
