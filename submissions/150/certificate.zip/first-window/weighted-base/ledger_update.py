"""Compute macro costs from the weighted-base updates on three grids."""
from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
from tempfile import TemporaryDirectory
from math import lcm
import json,sys

here=Path(__file__).resolve().parent
work=here.parent
parser=ArgumentParser()
for key,default in dict(repo='prime-sampling',prior='harmonic-research',tables='spectral-coupling/target',selectors='operator-new',coupling='spectral-coupling').items():
    parser.add_argument('--'+key,type=Path,default=work/default)
parser.add_argument('--out',type=Path,default=here/'macros.json')
args=parser.parse_args()
sys.path[:0]=[str(args.repo.resolve()),str(args.prior.resolve()),str(args.coupling.resolve())]
from predecessor.tree_sieve_trial import new_bank
from prime_sampling.accounting import ledger
from coset_split import close_six
ledger.bank=new_bank
lo,hi=F(150),F(4801,32)


def costs(mode,tmp):
    rows_all={}
    for grid in (1600,3200,4800):
        for kind in ('pair','six'):
            suffix='' if grid==3200 else f'-{grid}'
            source=args.tables/f'split-{kind}{suffix}.dat'
            rows=[list(map(int,line.split())) for line in source.read_text().splitlines()]
            proposals=[]
            for line in (args.selectors/f'{kind}-mixture{suffix}.txt').read_text(encoding='utf-8-sig').splitlines():
                f=line.split()
                assert f[6]=='candidate'
                proposals.append((F(f[0]),list(map(int,f[7:11]))))
            if mode!='previous':
                for line in (here/f'{kind}-{grid}-final.txt').read_text(encoding='utf-8-sig').splitlines():
                    f=line.split()
                    if len(f)==11 and f[1]=='flat' and f[6]=='shaped':
                        ix=2 if mode=='flat' else 7
                        proposals.append((F(f[0]),list(map(int,f[ix:ix+4]))))
                assert len(proposals)==8
            for u,values in proposals:
                i=int(u*grid);row=rows[i-67*grid//200];assert row[0]==i
                row[1:5]=list(map(min,row[1:5],values))
            if kind=='six':
                rows=[close_six(pair,six) for pair,six in zip(rows_all['pair',grid],rows,strict=True)]
            rows_all[kind,grid]=rows
    tables=[t for t in ledger.TABLES if t[2]<=lo<hi<=t[3]]
    for (kind,grid),rows in rows_all.items():
        dest=tmp/f'{mode}-{kind}-{grid}.dat'
        dest.write_text(''.join(' '.join(map(str,row))+'\n' for row in rows),encoding='ascii')
        tables.append(('extra',kind,lo,hi,grid,dest))
    results={}
    for branch in ('with3','without3'):
        tariffs=[(t[4],ledger.strip_costs(t[-1],t[4],t[1],ledger.rank(hi,branch))) for t in tables if t[1]!='six' or branch=='with3']
        unit=lcm(*(g for g,_ in tariffs));agg=0
        for j in range(67,100):
            start,end=(j*unit)//200,((j+1)*unit)//200;dist={end:0}
            for a in range(end-1,start-1,-1):
                options=[fees[a*g//unit-67*g//200]+dist[a+unit//g] for g,fees in tariffs if a%(unit//g)==0 and a+unit//g in dist]
                if options:dist[a]=min(options)
            agg+=dist[start]
            if j in (84,90,94,98):results.setdefault(str(j),{})[branch]=dist[start]
        print(mode,branch,'T67',agg,flush=True)
    return results


with TemporaryDirectory() as tmp:
    tab={mode:costs(mode,Path(tmp)) for mode in ('previous','flat','shaped')}
for i,row in tab['shaped'].items():
    for branch,val in row.items():
        print(i,branch,'saved by endpoint pricing',tab['previous'][i][branch]-tab['flat'][i][branch],
              'additional saving by shaped base',tab['flat'][i][branch]-val)
args.out.write_text(json.dumps(tab['shaped'],indent=2)+'\n',encoding='ascii')
