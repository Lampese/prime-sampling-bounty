from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
import os,sys

work=Path(__file__).resolve().parents[1]
parser=ArgumentParser()
for key,default in dict(repo='prime-sampling',selectors='operator-new',cap='residue-bridge/crt-fast').items():
    parser.add_argument('--'+key,type=Path,default=work/default)
parser.add_argument('--mode',choices=('pair','six'),default='six')
parser.add_argument('--grid',type=int,default=3200)
parser.add_argument('--bins',type=int,default=128)
parser.add_argument('--rows',nargs='+',type=F,default=list(map(F,('.42','.45','.47','.49'))))
parser.add_argument('--trace',action='store_true')
parser.add_argument('--line-cap',action='store_true')
args=parser.parse_args()
sys.path[:0]=[str(q.resolve()) for q in (args.repo,args.selectors,args.cap)]
if (work/'zig-cxx.cmd').exists():
    os.environ.setdefault('CXX',str(work/'zig-cxx.cmd'))
    os.environ.setdefault('ZIG_GLOBAL_CACHE_DIR',str(work/'zig-cache'))
    os.environ.setdefault('ZIG_LOCAL_CACHE_DIR',str(work/'zig-local-cache'))
from prime_sampling.rectangles import boxes as m,sieved_lift
from prime_sampling.spectrum import squarerates as sr
import crt_fibres,weighted
m.initialize(F(150),F(4801,32))
sieved_lift.install(m);crt_fibres.install(corner=True,layered=True)
if args.line_cap:
    sys.path.insert(0,str(work/'fibre-lines'));import line_cap
    line_cap.install()
m.rates=lambda *args:[F(1)]*2
stats={}
def trace(a,wi,hi,mi,ni,ti,l,h,z,ans):
    for q,val in enumerate(ans):
        for kind in (('flat','all') if z==0 else ('all',)):
            key=kind,q
            if key not in stats or val<stats[key][0]:
                stats[key]=val,(side,wi,hi,mi,ni,ti,str(F(l,h).limit_denominator(100)),str(z))
weighted.install(args.mode,m,lambda:opposite,args.selectors,args.bins,trace=trace)
for u in args.rows:
    v=u+F(1,args.grid)
    if v>F(1,2):continue
    values={'flat':[],'all':[]}
    for name,(cl,et) in (('inner',m.inner(u,v)),('outer',(max(m.LAM*m.Xlo(u-v),m.Xlo(2*u-1)),F(1)))):
        if cl>=et:
            for k0 in values:values[k0].extend([10**10]*2)
            continue
        eps,_,a,b,s,width,ylo,yhi=m.params(u,v)
        eps=max(eps,m.thetaerr((1-u)*m.zl+m.b(cl,'ln',False)))
        k=(m.abel.lower_count(cl,et,eps,(1-u)*m.zh,m)*ylo).__ceil__()
        x,y=(cl*ylo).__floor__(),(et*yhi).__ceil__()
        span=((et-cl)*yhi).__ceil__()+2
        stats.clear()
        for side,opposite,data in (('short-input',(x,y),(a,b,width,s,k,span)),('long-input',(a,b),(x,y,min(y-x,span),k,s,width))):
            m.rates(*data,m.pmin,m.pmax)
        for kind in values:
            for q in (0,1):
                val,choice=stats.get((kind,q),(F(1),None))
                values[kind].append(m.upint(min(1,val)))
                if args.trace:print(u,name,kind,q,m.upint(val),choice,flush=True)
    print(str(u),'flat',*values['flat'],'shaped',*values['all'],flush=True)
if os.name=='nt':
    import _ctypes
    _ctypes.FreeLibrary(sr._lib._handle)
