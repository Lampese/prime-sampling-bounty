"""One certified fibre bound per group of prime strips, shared by both spectra."""
from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
import json,os,sys

def main():
    work=Path(__file__).resolve().parents[1]
    cli=ArgumentParser(description=__doc__)
    cli.add_argument('--repo',type=Path,default=work/'prime-sampling')
    cli.add_argument('--left',type=F,default=F(150))
    cli.add_argument('--right',type=F,default=F(4801,32))
    cli.add_argument('--geometry-window',nargs=2,type=F,help='retain the enclosing window’s original rectangle endpoints while restricting the prime parameter')
    cli.add_argument('--grid',type=int,default=3200)
    cli.add_argument('--macro',type=int,nargs='+',required=True)
    cli.add_argument('--groups',type=int,default=2)
    cli.add_argument('--cascade',action='store_true')
    cli.add_argument('--wide',action='store_true')
    cli.add_argument('--shape-fibre',action='store_true',help='use the mod-two and mod-three lattice directions for the fibre')
    cli.add_argument('--near-hex',action='store_true',help='use the hexagonal lattice bound for near neighbours')
    cli.add_argument('--near-shape',action='store_true',help='use the mod-three lattice shape certificate')
    cli.add_argument('--shared-shapes',action='store_true',help='sample kernel shapes once per group and certify each row independently')
    cli.add_argument('--trapezoid',action='store_true',help='use the convolution of two boxes of unequal width')
    cli.add_argument('--autotaper',action='store_true',help='use the centered autocorrelation of a two-level aperture')
    cli.add_argument('--balanced',action='store_true',help='charge only balanced character labels on each exceptional shift block')
    cli.add_argument('--frequency-envelope',action='store_true',help='use the exact frequency hyperplane for the positive wheel envelope')
    cli.add_argument('--wheel-search',action='store_true',help='propose wheel and shape using the hyperplane estimate')
    cli.add_argument('--local-conductor',action='store_true',help='retain low-weight local invariants in the complete Fourier moment')
    cli.add_argument('--centered-powers',action='store_true',help='use signed polynomials of the sampled kernel magnitude')
    cli.add_argument('--reweight',action='store_true',help='use weighted Cauchy across the six fixed target characters')
    cli.add_argument('--paley-four',action='store_true',help='retain the nonsplit involution in the physical fourth moment')
    cli.add_argument('--tetra-four',action='store_true',help='use the tetrahedral sextic-character fourth moment')
    cli.add_argument('--caps',type=Path,help='reuse geometrically identical caps from a previously certified table')
    cli.add_argument('--out',type=Path,required=True)
    args=cli.parse_args()
    sys.path[:0]=list(map(str,(args.repo.resolve(),work/'operator-new',work/'fibre-lines',work/'gram-cycle')))
    if (work/'zig-cxx.cmd').is_file():
        os.environ.setdefault('CXX',str(work/'zig-cxx.cmd'))
        os.environ.setdefault('ZIG_GLOBAL_CACHE_DIR',str(work/'zig-cache'))
        os.environ.setdefault('ZIG_LOCAL_CACHE_DIR',str(work/'zig-local-cache'))
    from prime_sampling.rectangles import boxes as m
    from prime_sampling.spectrum import squarerates as sr
    import mixed
    if args.near_hex or args.near_shape:
        sys.path.insert(0,str(work/'near-lines'))
        if args.near_shape:import shape_near as near
        else:import hex_near as near
        near.install()
    if args.shape_fibre:import shaped_fibre as smooth_cap
    elif args.wide:import smooth_wide as smooth_cap
    elif args.cascade:import smooth_cascade as smooth_cap
    else:import smooth_cap
    assert F(150)<=args.left<args.right<=F(175) and args.right-args.left<=F(1,2)
    fixed={}
    if args.geometry_window:
        gl,gh=args.geometry_window
        assert 150<=gl<=args.left<args.right<=gh<=175
        m.initialize(gl,gh)
        for macro in args.macro:
            for i in range(macro*args.grid//200,(macro+1)*args.grid//200):
                u,v=F(i,args.grid),F(i+1,args.grid)
                fixed[i]=(m.inner(u,v),(max(m.LAM*m.Xlo(u-v),m.Xlo(2*u-1)),F(1)))
        for cached in (m.Xlo,m.Xhi,m.params,m.joint):cached.cache_clear()
    m.initialize(args.left,args.right)
    rates={}
    for mode in ('pair','six'):
        m.rates=lambda *args:(F(1),F(1))
        mixed.install(mode,m,shape_group=(lambda:(first,side)) if args.shared_shapes else None,trapezoid=args.trapezoid,autotaper=args.autotaper,balanced=args.balanced,envelope=args.frequency_envelope,wheel_search=args.wheel_search,conductor=args.local_conductor,centered=args.centered_powers,reweight=args.reweight,paley_four=args.paley_four,tetra_four=args.tetra_four)
        rates[mode]=m.rates
    grid=args.grid
    interval=grid//200//args.groups
    assert interval and interval*200*args.groups==grid
    def fibre(a,b,width,pm,p):
        assert A<=a<=b<=B and 0<width<=V and (pm,p)==(m.pmin,m.pmax)
        return cap
    sr.square_cap=fibre
    report={'left':str(args.left),'right':str(args.right),'grid':grid,'cascade':args.cascade,'wide':args.wide,'near_hex':args.near_hex,'near_shape':args.near_shape,'shared_shapes':args.shared_shapes,'rows':[],'envelopes':[]}
    prior={}
    report['trapezoid']=args.trapezoid
    report['autotaper']=args.autotaper
    report['balanced']=args.balanced
    report['frequency_envelope']=args.frequency_envelope
    report['wheel_search']=args.wheel_search
    report['local_conductor']=args.local_conductor
    if args.centered_powers:report['centered_powers']=True
    if args.reweight:report['reweight']=True
    if args.paley_four:report['paley_four']=True
    if args.tetra_four:report['tetra_four']=True
    if fixed:report['geometry_window']=list(map(str,args.geometry_window))
    report['shape_fibre']=args.shape_fibre
    if args.caps:
        source=json.loads(args.caps.read_text())
        assert not source.get('hypothetical')
        assert F(source.get('left',150))<=args.left<args.right<=F(source.get('right','4801/32'))
        assert (source['grid'],source['cascade'],source['wide'])==(grid,args.cascade,args.wide)
        assert bool(source.get('shape_fibre'))==args.shape_fibre
        prior={(x[0],x[1]):x[2:] for x in source['envelopes']}
        if args.caps.resolve()==(work/'fibre-portfolio'/f'strip-{grid}.json').resolve():
            report['fibre_portfolio_caps']=args.caps.name
    for macro in args.macro:
        start=macro*grid//200
        for first in range(start,start+grid//200,interval):
            end=first+interval
            A=m.Xlo(F(first,grid)).__floor__();B=m.Xhi(F(end,grid)).__ceil__()
            V=(B*(1-m.Xlo(F(-1,grid)))).__ceil__()
            assert 194<A<B<m.pmin<=m.pmax<2*m.pmin and 0<V<=B
            enclosing=prior.get((first,end))
            if args.caps and enclosing is None:
                raise ValueError(f'Missing enclosing fibre certificate for rows {first} through {end-1}.')
            if enclosing is not None:
                a0,b0,v0,cap=enclosing
                assert a0<=A<=B<=b0 and V<=v0
            else:cap=smooth_cap.calculate(A,B,V,m.pmin,m.pmax)
            report['envelopes'].append([first,end,A,B,V,cap])
            for i in range(first,end):
                u,v=F(i,grid),F(i+1,grid)
                eps,na,a,b,s,width,ylo,yhi=m.params(u,v)
                columns=[[],[]]
                vertical=fixed[i] if fixed else (m.inner(u,v),(max(m.LAM*m.Xlo(u-v),m.Xlo(2*u-1)),F(1)))
                for side,(low,high) in enumerate(vertical):
                    if high<=low:
                        for c in columns:c.extend((10**10,10**10))
                        continue
                    ep=max(eps,m.thetaerr((1-u)*m.zl+m.b(low,'ln',False)))
                    k=(m.abel.lower_count(low,high,ep,(1-u)*m.zh,m)*ylo).__ceil__()
                    span=((high-low)*yhi).__ceil__()+2
                    assert min(s,k)>=2
                    for col,kind in zip(columns,('pair','six')):
                        g,q=rates[kind](a,b,width,s,k,span,m.pmin,m.pmax)
                        col.extend((m.upint(g),m.upint(q)))
                report['rows'].append([i,*columns])
        staged=args.out.with_suffix('.part')
        staged.write_text(json.dumps(report),encoding='ascii')
        staged.replace(args.out)
        print(grid,macro,'rows',len(report['rows']),flush=True)
    if os.name=='nt':
        import _ctypes
        _ctypes.FreeLibrary(sr._lib._handle)
if __name__=='__main__':main()
