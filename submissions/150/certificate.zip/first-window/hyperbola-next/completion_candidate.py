"""Price the proposed dilation-correlation inequality using the real rectangle parameters."""
from fractions import Fraction as F
from math import isqrt
from pathlib import Path
import os,sys
work=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(work/'prime-sampling'),str(work/'residue-bridge/crt-fast')]
if (work/'zig-cxx.cmd').exists():
    os.environ.setdefault('CXX',str(work/'zig-cxx.cmd'))
    os.environ.setdefault('ZIG_GLOBAL_CACHE_DIR',str(work/'zig-cache'))
    os.environ.setdefault('ZIG_LOCAL_CACHE_DIR',str(work/'zig-local-cache'))
from prime_sampling.rectangles import boxes,sieved_lift
from prime_sampling.spectrum import squarerates as sr
import crt_fibres

def candidate(a,b,width,s,k,span,pm,p):
    R=(span+1)//2+1
    md=min(sr.dirichlet_cap(a,b,width,pm,p),sr.previous_cap(width,b,pm),sr.square_cap(a,b,width,pm,p))
    rt=isqrt(p)+1
    factor=F(md,s*(s-1))
    upper=(pm-1)//2
    options={min(upper,max(R+1,int(R*rat))) for rat in map(F,('1.1','1.25','1.5','2','3','4','6','8','12','16','32','64','128','256','512'))}
    options.add(min(upper,max(2*R,isqrt(2*rt*R*s))))
    result=F(1);ideal=F(1);fourth_result=F(1)
    for C in options:
        if C<=R:continue
        fourth=F(2*(2*C*C+1),C)+16*rt+9
        generic=rt*sr.root(1+sr.root(factor*fourth))
        price=lambda x:sr.root(F(C,(C-R)*k)*(F(C,s)+x))
        result=min(result,price(generic));ideal=min(ideal,price(rt))
        # Conditional sensitivity only. Constants below require a separate
        # four-fold correlation theorem and cannot be entered in the ledger.
        sigma=F(2*C*C+1,3*C*pm)
        err4=sr.root(sr.root(factor*(200*rt+5000*p*sigma**2)))
        fourth_result=min(fourth_result,price(rt*sr.root(1+err4)))
    return result,ideal,fourth_result

if __name__=='__main__':
    boxes.initialize(F(150),F(4801,32))
    sieved_lift.install(boxes);crt_fibres.install(corner=True,layered=True)
    for x in ('.335','.35','.36','.375','.38','.39','.40','.42','.45'):
        u=F(x);v=u+F(1,3200)
        _,_,a,b,s,w,yl,yh=boxes.params(u,v)
        low,top=boxes.inner(u,v);eps=boxes.thetaerr(u*boxes.zl)
        k=(boxes.abel.lower_count(low,top,eps,(1-u)*boxes.zh,boxes)*yl).__ceil__()
        span=((top-low)*yh).__ceil__()+2
        res,ideal,four=candidate(a,b,w,s,k,span,boxes.pmin,boxes.pmax)
        table=(work/'residue-bridge/target-layered/best-six.dat').read_text().splitlines()
        row=table[int(u*3200)-67*16].split()
        print(x,'stock',float(row[1])/1e10,'second',float(res),'conditional-fourth',float(four),'ideal',float(ideal),flush=True)
    if os.name=='nt':
        import _ctypes
        _ctypes.FreeLibrary(sr._lib._handle)
