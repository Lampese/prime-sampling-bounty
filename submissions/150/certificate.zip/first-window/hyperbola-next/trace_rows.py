"""Bound the cheap end of the original strip tables, retaining their geometry."""
from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
import json,os,sys

def main():
    work=Path(__file__).resolve().parents[1]
    cli=ArgumentParser(description=__doc__)
    cli.add_argument('--repo',type=Path,default=work/'prime-sampling')
    cli.add_argument('--out',type=Path,required=True)
    cli.add_argument('--refined',action='store_true')
    cli.add_argument('--local',action='store_true',help='use the seventh-degree adjoint envelope and the local conductor')
    cli.add_argument('--paired',action='store_true',help='complete same-label character pairs before taking absolute values')
    cli.add_argument('--aperture',action='store_true',help='complete on the odd-prime lattice with a positive Fourier spline')
    cli.add_argument('--fold-wheel',action='store_true',help='sum the reduced residue phases before the absolute value in direct completion')
    args=cli.parse_args()
    sys.path[:0]=[str(args.repo.resolve()),str(work/'residue-bridge/crt-fast')]
    if (work/'zig-cxx.cmd').exists():
        os.environ.setdefault('CXX',str(work/'zig-cxx.cmd'))
        os.environ.setdefault('ZIG_GLOBAL_CACHE_DIR',str(work/'zig-cache'))
        os.environ.setdefault('ZIG_LOCAL_CACHE_DIR',str(work/'zig-local-cache'))
    from prime_sampling.rectangles import boxes as m,sieved_lift
    from prime_sampling.spectrum import squarerates as sr
    from trace_completion import price
    if args.refined:
        sys.path.insert(0,str(work/'trace-dilate'))
        from scale import completion,prime_fibre
        if args.local:
            sys.path.insert(0,str(work/'gram-cycle'))
            from adjoint_local import completion
        def price(a,b,width,s,k,span,pm,p):
            md=min(sr.dirichlet_cap(a,b,width,pm,p),sr.previous_cap(width,b,pm),sr.square_cap(a,b,width,pm,p))
            return completion(s,k,span,pm,p,prime_fibre(a,b,width,pm,md),degree=7 if args.local else 3)
    import crt_fibres
    m.initialize(F(150),F(4801,32));sieved_lift.install(m);crt_fibres.install(corner=True,layered=True)
    out={}
    if args.paired:
        assert args.local and args.refined
        from paired_completion import rates as pair_rates
    if args.aperture:
        assert args.paired
        from aperture_completion import price as aperture
    for grid in ((1600,2400,3200,4800,6400) if args.paired else (1600,3200,4800)):
        records=[]
        for i in range(67*grid//200,72*grid//200):
            u,v=F(i,grid),F(i+1,grid)
            _,na,a,b,s,width,ylo,yhi=m.params(u,v)
            vals=[]
            channels=[[],[]]
            if args.paired:
                md=min(sr.dirichlet_cap(a,b,width,m.pmin,m.pmax),sr.previous_cap(width,b,m.pmin),sr.square_cap(a,b,width,m.pmin,m.pmax))
                fibre=prime_fibre(a,b,width,m.pmin,md)
            for low,high in (m.inner(u,v),(max(m.LAM*m.Xlo(u-v),m.Xlo(2*u-1)),F(1))):
                eps=max(m.thetaerr(u*m.zl),m.thetaerr((1-u)*m.zl+m.b(low,'ln',False)))
                k=(m.abel.lower_count(low,high,eps,(1-u)*m.zh,m)*ylo).__ceil__()
                span=((high-low)*yhi).__ceil__()+2
                if args.paired:
                    if args.aperture:
                        loglo=(1-u)*m.zl+m.b(low,'ln',False)
                        assert loglo>=40
                        wheels=(6,10,14) if args.fold_wheel else (2,)
                        gp,qp,gs,qs=map(min,zip(*(aperture(s,k,span,m.pmin,m.pmax,fibre,loglo,eps*high*yhi,wheel=W) for W in wheels)))
                    else:
                        gp,qp=pair_rates('pair',s,k,span,m.pmin,m.pmax,fibre)
                        gs,qs=gp,(2*gp+qp)/3
                    channels[0].extend(map(m.upint,(gp,qp)))
                    channels[1].extend(map(m.upint,(gs,qs)))
                else:vals.append(m.upint(price(a,b,width,s,k,span,m.pmin,m.pmax)))
            records.append([i,*(channels if args.paired else vals)])
        out[str(grid)]=records
        print(grid,len(records),records[0],flush=True)
        staged=args.out.with_suffix('.part')
        staged.write_text(json.dumps(out),encoding='ascii')
        staged.replace(args.out)
    if os.name=='nt':
        import _ctypes
        _ctypes.FreeLibrary(sr._lib._handle)
if __name__=='__main__':main()
