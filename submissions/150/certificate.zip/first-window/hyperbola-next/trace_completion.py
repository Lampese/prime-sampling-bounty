"""Fejer completion with a fourth dilation moment for the Kummer transform."""
from fractions import Fraction as F
from math import isqrt
from prime_sampling.spectrum import squarerates as sr

def price(a,b,width,s,k,span,pm,p):
    rad=(span+1)//2+1
    md=min(sr.dirichlet_cap(a,b,width,pm,p),sr.previous_cap(width,b,pm),sr.square_cap(a,b,width,pm,p))
    sq=isqrt(p)+1
    upper=(pm-1)//2
    options={min(upper,max(rad+1,int(rad*rat))) for rat in (F(5,4),F(3,2),2,3,4,8,16,32,128,512)}
    options.add(min(upper,max(2*rad,isqrt(2*sq*rad*s))))
    best=F(1)
    for c in options:
        if c<=rad:continue
        sigma=F(2*c*c+1,3*c*pm)
        fourth=sr.root(sr.root(F(md,s*(s-1))*min(80*sq+972*p*sigma**2,83*sq+36*p*sigma**2)))
        bound=sr.root(F(c,(c-rad)*k)*(F(c,s)+sq*sr.root(1+fourth)))
        best=min(best,bound)
    return best
