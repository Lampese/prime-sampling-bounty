"""Compare new rectangle partitions with the previous verified macro costs."""
from fractions import Fraction as F
from pathlib import Path
from tempfile import TemporaryDirectory
from argparse import ArgumentParser
import json
import sys

HERE=Path(__file__).resolve().parent
WORK=HERE.parent


def main():
    cli=ArgumentParser(description=__doc__)
    cli.add_argument('records',type=Path,nargs='*')
    cli.add_argument('--repo',type=Path,default=WORK/'prime-sampling')
    cli.add_argument('--prior',type=Path,default=WORK/'harmonic-research')
    cli.add_argument('--residue',type=Path,default=WORK/'residue-bridge')
    cli.add_argument('--arithmetic',type=Path,default=WORK/'energy-next')
    cli.add_argument('--out',type=Path)
    cli.add_argument('--combined',action='store_true',help='also use mixed-shift spectra, pair-to-six conversion, and the branch-specific budget')
    cli.add_argument('--omit-trace',action='store_true',help='omit the four-moment dilation rate columns')
    cli.add_argument('--stock-scalar',action='store_true',help='retain only the unmodified upstream scalar budget rows')
    cli.add_argument('--omit-local',action='store_true',help='exclude the new conductor estimate')
    cli.add_argument('--hypothetical',type=Path,help='study an explicitly uncertified sensitivity scenario')
    args=cli.parse_args()
    hypothetical=None
    if args.hypothetical:
        hypothetical=json.loads(args.hypothetical.read_text())
        assert hypothetical.get('hypothetical') is True and args.combined and not args.out
        print('HYPOTHETICAL sensitivity experiment. These prices are not bounds for the bounty.')
    sys.path[:0]=[str(args.repo.resolve()),str((args.prior/'predecessor').resolve()),str(args.prior.resolve()),str(WORK/'spectral-coupling')]
    from prime_sampling.accounting import ledger
    from tree_sieve_trial import new_bank
    ledger.bank=new_bank
    from prime_mass import prime_mass
    from coset_split import close_six
    lo,hi=F(150),F(4801,32)
    A=prime_mass(lo,hi)[0]
    improved_main=WORK/'main-density-new/verify.py'
    if args.combined and improved_main.is_file():
        from runpy import run_path
        new_lower,_=run_path(str(improved_main))['window_bounds'](lo,hi)
        A=max(A,(new_lower*ledger.J).__floor__())
    reports=[json.loads(p.read_text()) for p in args.records]
    target=args.prior/'target'
    def read(path):
        return [list(map(int,line.split())) for line in path.read_text().splitlines() if line and line[0].isdigit()]
    points=[]
    for p in ('point-updates-corner.json','point-updates-corner-layered.json'):
        points.extend(json.loads((args.arithmetic/p).read_text()))
    # These five ordinary grids use the same first-window inner and outer boxes.
    # Apply independent one-sided geometric bounds before pricing each spectrum.
    extras_by_grid={}
    ordinary_mass={}
    rectangle_bounds={}
    if args.combined:
        sys.path.insert(0,str(WORK/'mass-geometry'))
        from joint_bounds import upper_fee
        for path in (WORK/'mass-geometry').glob('rectangle-limits-*.json'):
            data=json.loads(path.read_text())
            assert F(data['left'])==lo and F(data['right'])==hi
            rectangle_bounds[data['grid']]={i:(inside,outside) for i,inside,outside in data['rows']}
        for path in (WORK/'fibre-portfolio').glob('strip-*.json'):
            if not path.stem.removeprefix('strip-').isdigit():continue
            data=json.loads(path.read_text())
            assert F(data['left'])==lo and F(data['right'])==hi and not data.get('hypothetical')
            extras_by_grid[data['grid']]={i:(pa,si) for i,pa,si in data['rows']}
        for directory in (WORK/'mass-geometry').glob('150g*'):
            grid=int(directory.name.removeprefix('150g'))
            sources=list(directory.glob('pair*.dat'))
            assert len(sources)==1
            rows=read(sources[0])
            assert len(rows)==33*grid//200 and rows[0][0]==67*grid//200
            ordinary_mass[grid]=rows
    def geometry_and_angular(table,kind,grid):
        for j,row in enumerate(table):
            if grid in ordinary_mass:
                m=ordinary_mass[grid][j]
                assert m[0]==row[0]
                row[5:8]=map(min,zip(row[5:8],m[5:8]))
                row[8]=max(row[8],m[8])
            update=extras_by_grid.get(grid,{}).get(row[0])
            if update:row[1:5]=map(min,zip(row[1:5],update[int(kind=='six')]))
        return table
    with TemporaryDirectory() as tmp:
        inputs=[row for row in ledger.TABLES if row[2]<=lo<hi<=row[3]]
        merged={}
        menu=json.loads((target/'tables.json').read_text())
        for kind,grid,name in menu:
            table=read(target/name)
            for folder in {1600:['target-layered-1600'],3200:['target','target-layered']}.get(grid,[]):
                for row,other in zip(table,read(args.residue/folder/(kind+'.dat')),strict=True):
                    assert row[0]==other[0] and row[5:]==other[5:]
                    row[1:5]=map(min,zip(row[1:5],other[1:5]))
            for u,k,g,i,_,improved in points:
                if (kind,grid)==(k,g):
                    row=table[i-67*grid//200]
                    row[1:5]=map(min,zip(row[1:5],improved))
            if args.combined:
                if hypothetical and hypothetical['grid']==grid:
                    for i,pair,six in hypothetical['rows']:
                        row=table[i-67*grid//200]
                        assert row[0]==i
                        row[1:5]=map(min,zip(row[1:5],pair if kind=='pair' else six))
                if not args.omit_trace:
                    for trace_file in HERE.glob('trace-rates*.json'):
                        if 'paired' in trace_file.stem:continue
                        if args.omit_local and 'local' in trace_file.stem:continue
                        for i,inside,outside in json.loads(trace_file.read_text()).get(str(grid),()):
                            row=table[i-67*grid//200]
                            assert row[0]==i
                            row[1:5]=map(min,zip(row[1:5],(inside,inside,outside,outside)))
                for dataset in HERE.glob('smooth-grid-*.json'):
                    data=json.loads(dataset.read_text())
                    if data['grid']!=grid:continue
                    if args.omit_local and data.get('local_conductor'):continue
                    for i,pair,six in data['rows']:
                        row=table[i-67*grid//200]
                        assert row[0]==i
                        row[1:5]=map(min,zip(row[1:5],pair if kind=='pair' else six))
                path=WORK/'operator-new'/(f'{kind}-mixture.txt' if grid==3200 else f'{kind}-mixture-{grid}.txt')
                for source in (path,WORK/'fibre-lines'/f'{kind}-final-{grid}.txt',WORK/'weighted-base'/f'{kind}-{grid}-final.txt'):
                    lines=[s.split() for s in source.read_text(encoding='utf-8-sig').splitlines()]
                    if source.parent.name=='weighted-base':
                        updates=[(s[0],s[7:11]) for s in lines if len(s)==11 and s[1]=='flat' and s[6]=='shaped']
                    else:
                        updates=[(s[0],s[7:11]) for s in lines if len(s)==16 and [s[i] for i in (1,6,11)]==['old','candidate','best']]
                    assert len(updates)==4,source
                    for coordinate,prices in updates:
                        i=F(coordinate)*grid
                        assert i.denominator==1
                        row=table[int(i)-67*grid//200]
                        assert row[0]==i
                        row[1:5]=map(min,zip(row[1:5],map(int,prices)))
            merged[kind,grid]=geometry_and_angular(table,kind,grid)
        for descriptor in sorted((WORK/'native-first').glob('*/cell.json')) if args.combined else ():
            cell=json.loads(descriptor.read_text())
            if args.omit_local and descriptor.with_name('source.json').is_file() and json.loads(descriptor.with_name('source.json').read_text()).get('local_conductor'):continue
            assert F(cell['left'])==lo and F(cell['right'])==hi
            for item in cell['tables']:
                kind,grid=item['kind'],item['grid']
                table=geometry_and_angular(read(descriptor.parent/item['file']),kind,grid)
                if (kind,grid) in merged:
                    for row,new in zip(merged[kind,grid],table,strict=True):
                        assert row[0]==new[0]
                        row[1:8]=map(min,zip(row[1:8],new[1:8]))
                        row[8]=max(row[8],new[8])
                else:merged[kind,grid]=table
        if args.combined and not args.omit_local and not args.omit_trace:
            for paired in HERE.glob('trace-rates*paired*.json'):
                for g,records in json.loads(paired.read_text()).items():
                    grid=int(g)
                    for kind,idx in [('pair',1),('six',2)]:
                        table=merged.get((kind,grid))
                        if table is None:continue
                        for row in records:
                            old=table[row[0]-67*grid//200]
                            assert old[0]==row[0] and len(row[idx])==4
                            old[1:5]=map(min,zip(old[1:5],row[idx]))
        for (kind,grid),table in merged.items():
            if args.combined and kind=='six':
                table=[close_six(p,s) for p,s in zip(merged['pair',grid],table,strict=True)]
            dest=Path(tmp)/f'combined-{kind}-{grid}.dat'
            dest.write_text(''.join(' '.join(map(str,row))+'\n' for row in table),encoding='ascii')
            inputs.append(('extra',kind,lo,hi,grid,dest))
        baseline={}
        for branch in ('with3','without3'):
            fees_best=[]
            seq=ledger.rank(hi,branch)
            tables=[row for row in inputs if row[1]!='six' or branch=='with3']
            from math import lcm
            unit=lcm(*(row[4] for row in tables))
            costs=[]
            for t in tables:
                k,grid,file=t[1],t[4],t[-1]
                native=ledger.strip_costs(file,grid,k,seq)
                if grid in rectangle_bounds and file.parent==Path(tmp):
                    bank,scale=ledger.bank(seq,k)
                    def exclude(g,q):
                        return max(0,max(m-ledger.ceil(n*g+inner*q,ledger.I) for m,n,inner in bank))
                    candidate=[]
                    for row,old in zip(ledger.check_rows(file,grid),native,strict=True):
                        i=len(candidate)+67*grid//200
                        f=exclude(*row[:2]);fo=exclude(*row[2:4])
                        fee=upper_fee(ledger.I,ledger.J,scale,f,fo,row[4:],rectangle_bounds[grid][i])
                        candidate.append(min(old,fee))
                    native=candidate
                costs.append((grid,native))
            previous=improved=0
            for macro in range(67,100):
                start,end=macro*unit//200,(macro+1)*unit//200
                graph={end:0}
                for a in range(end-1,start-1,-1):
                    opts=[]
                    for grid,fees in costs:
                        step=unit//grid
                        if a%step==0 and a+step in graph:
                            opts.append(fees[a//step-67*grid//200]+graph[a+step])
                    if opts:graph[a]=min(opts)
                fee=graph[start]
                baseline.setdefault(str(macro),{})[branch]=fee
                options=[r[str(macro)][branch] for r in reports if branch in r.get(str(macro),{})]
                better=min([fee]+options)
                previous+=fee
                improved+=better
                fees_best.append(better)
                if options:
                    print(macro,branch,'old',fee,'trial',min(options),'saving',fee-better)
            print(branch,'previous',previous,'improved',improved,'saved',previous-improved)
            if not args.combined:
                assert previous=={'with3':1712059061315,'without3':1429803585840}[branch]
            rb=[]
            for line in (args.residue/'150-extra-stock.dat').read_text().splitlines():
                low,high,rank,*values=line.split()
                if int(rank)==len(seq) and F(low)<=lo<hi<=F(high):rb.append(list(map(int,values)))
            if args.combined and not args.stock_scalar:
                values=[line.split() for line in (WORK/'cofactor-refined/150.dat').read_text().splitlines()]
                chosen=[list(map(int,row[3:])) for row in values if F(row[0])==lo and F(row[1])==hi and int(row[2])==len(seq)]
                assert len(chosen)==1 and len(chosen[0])==4 and min(chosen[0])>=0
                rb+=chosen
                for newer in (WORK/'seed-weights/150.dat',WORK/'transfer-weights/150.dat',WORK/'transfer-bilinear/150.dat',WORK/'seed-bridge/150.dat'):
                    if not newer.is_file():continue
                    data=[s.split() for s in newer.read_text().splitlines()]
                    valid=[list(map(int,row[3:])) for row in data if F(row[0])==lo and F(row[1])==hi and int(row[2])==len(seq)]
                    assert len(valid)==1 and len(valid[0])==4 and min(valid[0])>=0
                    rb+=valid
            if args.combined and not args.stock_scalar and branch=='without3':
                low,high,rank,*values=(WORK/'scalar-global/150-without3.dat').read_text().split()
                assert F(low)==lo and F(high)==hi and int(rank)==len(seq)
                rb.append(list(map(int,values)))
                low,high,rank,*values=(WORK/'scalar-tail/150-without3.dat').read_text().split()
                assert F(low)==lo and F(high)==hi and int(rank)==len(seq)
                rb.append(list(map(int,values)))
            scores=[]
            for j in range(4):
                R=min(row[j] for row in rb)*1000
                T=sum(fees_best[j:])
                scores.append(A-R-T)
                print('cutoff',branch,67+j,'A',A,'R',R,'T',T,'margin',A-R-T)
            print('best',branch,67+scores.index(max(scores)),max(scores))
        if args.out:args.out.write_text(json.dumps(baseline,indent=2),encoding='ascii')


if __name__=='__main__':main()
