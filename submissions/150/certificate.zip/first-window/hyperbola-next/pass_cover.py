"""Combine upper bounds on the same pass counts from overlapping prime rectangles."""
from fractions import Fraction as F
from itertools import combinations
from pathlib import Path
import os,sys

def optimize(u,v,n,bounds,mid_band,box,mass,banks,I,J):
    for name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS'):os.environ[name]='1'
    sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'math-libs'))
    import numpy as np
    from scipy.optimize import linprog
    from prime_sampling.accounting import ledger
    xs=[u+(v-u)*j/n for j in range(n+1)]
    bottom,top=bounds(u,v,False)
    ys=sorted({bottom,top,(bottom+top)/2,*[z for x in xs for z in mid_band(x,x) if bottom<z<top]})
    def overlap(a,b):return max(a[0],b[0]),min(a[1],b[1])
    T=[];E=[];full=[]
    for a,b in zip(xs,xs[1:]):
        for c,d in zip(ys,ys[1:]):
            t=e=F(0)
            for j in range(12):
                x,y=a+(b-a)*j/12,a+(b-a)*(j+1)/12
                t+=mass(x,y,*overlap((c,d),bounds(x,y,False)))
                lo,hi=overlap((c,d),bounds(x,y,True))
                if hi<=lo:e+=mass(x,y,c,d)
                else:e+=mass(x,y,c,lo)+mass(x,y,hi,d)
            total=(mass(a,b,c,d)*J).__ceil__()
            T.append(min(total,(J*t).__ceil__()));E.append(min(total,(J*e).__ceil__()));full.append(total)
    ny=len(ys)-1
    fees={br:[] for br in banks}
    covers=[]
    for a,b in combinations(range(n+1),2):
        for c,d in combinations(range(ny+1),2):
            atoms=[i*ny+j for i in range(a,b) for j in range(c,d)]
            if not any(T[i] for i in atoms):continue
            g,q=box(xs[a],xs[b],ys[c],ys[d])
            covers.append(atoms)
            for br,(options,scale) in banks.items():
                exclusion=max(0,max(f-ledger.ceil(ng*g+nq*q,I) for f,ng,nq in options))
                fees[br].append(I-exclusion)
    H=np.zeros((len(T),len(covers)))
    for j,rows in enumerate(covers):H[rows,j]=1
    mscale=max(full);eye=np.eye(len(T));answers=[]
    for br,(options,scale) in banks.items():
        a=np.array(fees[br])/I
        b=H*a
        constraints=np.block([[b,-eye],[b-H,-eye]])
        answer=linprog(np.r_[np.array(E)@b/mscale,np.array(T)/mscale],
            A_ub=constraints,b_ub=np.r_[np.ones(len(T)),np.full(len(T),1-scale/J)],method='highs')
        assert answer.success
        den=10**8
        weights=[max(0,round(den*float(x))) for x in answer.x[:len(covers)]]
        AA=[0]*len(T);BB=[0]*len(T)
        for cols,h,fee in zip(covers,weights,fees[br]):
            if h:
                for i in cols:AA[i]+=h;BB[i]+=h*fee
        total=F(0)
        for ca,cb,t,e,f in zip(AA,BB,T,E,full):
            a0,b0=F(ca,den),F(cb,den*I)
            p=max(0,b0-1+max(0,F(scale,J)-a0))
            total+=min(t*p+e*b0,f*b0+t*max(0,p-b0),f*p+e*max(0,b0-p))
        answers.append(total.__ceil__())
    return tuple(answers)
