"""Exact repricing of a signed combination of rectangle indicators."""
from fractions import Fraction as F
from itertools import combinations
from pathlib import Path
import os,sys

def optimize(u,v,n,bounds,middle,box,mass,banks,strip_mass,I,J,phases=False):
    for name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS'):os.environ[name]='1'
    sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'math-libs'))
    import numpy as np
    from scipy.optimize import linprog
    xs=[u+(v-u)*j/n for j in range(n+1)]
    low,high=bounds(u,v,False)
    ys=sorted({low,high,*[t for x in xs for t in middle(x,x) if low<t<high]})
    ny=len(ys)-1
    def clip(x,y):return max(x[0],y[0]),min(x[1],y[1])
    def outside(band,inner):
        l,r=band
        if inner[0]>=inner[1]:return [band]
        return [(l,min(r,inner[0])),(max(l,inner[1]),r)]
    true=[];excess=[]
    for a,b in zip(xs,xs[1:]):
        for w,z in zip(ys,ys[1:]):
            D=E=F(0)
            for k in range(8):
                l,r=a+(b-a)*k/8,a+(b-a)*(k+1)/8
                D+=mass(l,r,*clip((w,z),bounds(l,r,False)))
                for L,R in outside((w,z),bounds(l,r,True)):E+=mass(l,r,L,R)
            true.append((J*D).__ceil__());excess.append((J*E).__ceil__())
    rectangles=[(a,b,c,d) for a,b in combinations(range(n+1),2)
                for c,d in combinations(range(ny+1),2)]
    G=[];Q=[]
    cellsets=[]
    for a,b,c,d in rectangles:
        rect=(xs[a],xs[b],ys[c],ys[d])
        g,q=box(*rect)
        mm=mass(*rect)
        gprice,qprice=(mm*J*g/I).__ceil__(),(mm*J*q/I).__ceil__()
        xcuts=range(a+1,b+1) if phases else (b,)
        ycuts=range(c+1,d+1) if phases else (d,)
        for cut in xcuts:
            for split in ycuts:
                if (a,b,c,d,cut,split)==(0,n,0,ny,n,ny):order0=len(cellsets)
                cellsets.append(tuple((i*ny+j,1 if (i<cut)==(j<split) else -1)
                                      for i in range(a,b) for j in range(c,d)))
                G.append(gprice);Q.append(qprice)
    H=np.zeros((n*ny,len(cellsets)))
    for i,rows in enumerate(cellsets):
        for j,s in rows:H[j,i]=s
    M=float(strip_mass)
    e=np.array(excess,dtype=float)/M
    t=np.array(true,dtype=float)/M
    ar=np.array(G,dtype=float)/M
    br=np.array(Q,dtype=float)/M
    A=np.block([[H,-H],[-H,H]])
    rhs=np.r_[np.ones(len(H)),np.zeros(len(H))]
    result=[]
    for branch,(options,scale) in banks.items():
        # Candidate screening can be approximate. Include the best few
        # polynomials for a range of plausible rates on this band.
        pick=set()
        for z in (0.12,.25,.4,.7,1.,1.5,2.5):
            g=float(ar[order0])*z;q=float(br[order0])*z
            pick.update(sorted(options,key=lambda row: I-row[0]+row[1]*g+row[2]*q)[:2])
        best=None
        for f,ng,nq in pick:
            mu=(I-f)/I
            err=(ng*ar+nq*br)/I
            linear=(mu*e-(1-mu)*t)@H
            res=linprog(np.r_[err+linear,err-linear],A_ub=A,b_ub=rhs,method='highs')
            if not res.success:continue
            count=len(cellsets)
            c=[int(round(v*10**7)) for v in res.x[:count]-res.x[count:]]
            weights=[0]*len(H)
            for coeff,rows in zip(c,cellsets):
                if coeff:
                    for j,sign in rows:weights[j]+=coeff*sign
            low=min(0,min(weights));high=max(10**7,max(weights))
            c[order0]-=low
            weights=[v-low for v in weights]
            den=high-low
            assert all(0<=v<=den for v in weights)
            E=sum(x*v for x,v in zip(excess,weights))
            D=sum(x*(den-v) for x,v in zip(true,weights))
            cost=sum(abs(x)*(ng*g+nq*q) for x,g,q in zip(c,G,Q))
            # mu_up applies to x and E, while 1-mu_lo prices the deficit.
            numerator=(I-f)*(strip_mass*den+E)+(f+1)*D+cost
            fee=F(scale*numerator,I*J*den).__ceil__()-strip_mass
            best=fee if best is None else min(best,fee)
        assert best is not None
        result.append(best)
    return tuple(result)
