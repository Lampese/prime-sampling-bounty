"""Price dyadic inscribed cores and their two hyperbola boundary strips."""
from argparse import ArgumentParser
from fractions import Fraction as F
from functools import cache
from pathlib import Path
import json
import os
import sys

HERE=Path(__file__).resolve().parent
WORK=HERE.parent


def subtract(interval, inner):
    l,r=interval
    if l>=r:
        return ()
    if inner is None or inner[0]>=inner[1]:
        return ((l,r),)
    a,b=inner
    return tuple((x,y) for x,y in ((l,min(a,r)),(max(b,l),r)) if x<y)


def main():
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,default=WORK/'prime-sampling')
    parser.add_argument('--prior',type=Path,default=WORK/'harmonic-research')
    parser.add_argument('--cap',type=Path,default=WORK/'residue-bridge/crt-fast')
    parser.add_argument('--left',type=F,default=F(150))
    parser.add_argument('--right',type=F,default=F(4801,32))
    parser.add_argument('--mode',choices=('six','pair'),default='six')
    parser.add_argument('--macros',type=int,nargs='+',default=[84,90,97])
    parser.add_argument('--depth',type=int,default=2)
    parser.add_argument('--active-grid',type=int,default=200)
    parser.add_argument('--out',type=Path)
    parser.add_argument('--rates-probe',action='store_true')
    parser.add_argument('--signed',action='store_true')
    parser.add_argument('--triangular',action='store_true')
    parser.add_argument('--local-axis',action='store_true',help='use actual opposite prime endpoints in partial summation')
    parser.add_argument('--panels',action='store_true',help='partition upper and lower panels independently on either axis')
    parser.add_argument('--abel',action='store_true',help='integrate the logarithmic prime-counting weight on each rectangular axis')
    parser.add_argument('--mask',type=int,help='optimize a signed cover on a finite grid of this many rows')
    parser.add_argument('--mask-phases',action='store_true',help='include separable row and column sign changes in the signed cover')
    parser.add_argument('--lines',action='store_true',help='also bound inverse differences by linewise prime congruences')
    parser.add_argument('--smooth-lines',action='store_true',help='split each lattice line at the largest prime divisor')
    parser.add_argument('--cascade',action='store_true',help='combine multiple smooth-divisor cutoffs on the small input axis')
    parser.add_argument('--wide',action='store_true',help='include grouped large-prime cutoffs on the small input axis')
    parser.add_argument('--shape-fibre',action='store_true',help='use local mod-two and mod-three fibre geometry')
    parser.add_argument('--near-hex',action='store_true',help='use the shared hexagonal near-neighbour bound')
    parser.add_argument('--near-shape',action='store_true',help='use the mod-three shape certificate')
    parser.add_argument('--square-triangle',action='store_true',help='decompose the near-diagonal square counted on one side')
    parser.add_argument('--overlap',type=int,default=0,help='combine overlapping rectangle inequalities on a cell complex')
    parser.add_argument('--unequal',action='store_true',help='add the unequal-width convolution on the short input side')
    parser.add_argument('--trace-four',action='store_true',help='use the fourth dilation moment for completed Kummer sums')
    parser.add_argument('--extended-core',action='store_true',help='allow a central rectangle to cover a priced part of a boundary')
    parser.add_argument('--cheap',action='store_true',help='omit the layered congruence refinement')
    args=parser.parse_args()
    sys.path[:0]=[str(p.resolve()) for p in
                 (args.repo,args.prior/'predecessor',args.prior/'kernel',args.cap)]
    if (WORK/'zig-cxx.cmd').is_file() and 'CXX' not in os.environ:
        os.environ['CXX']=str(WORK/'zig-cxx.cmd')
        os.environ.setdefault('ZIG_GLOBAL_CACHE_DIR',str(WORK/'zig-cache'))
        os.environ.setdefault('ZIG_LOCAL_CACHE_DIR',str(WORK/'zig-local-cache'))
    import harmonic
    import centered_tri
    from prime_sampling.rectangles import boxes as m, sieved_lift
    from prime_sampling.accounting import ledger
    from tree_sieve_trial import new_bank
    m.initialize(args.left,args.right)
    sieved_lift.install(m)
    if not args.cheap:
        import crt_fibres
        crt_fibres.install(corner=True,layered=True)
    if args.near_hex or args.near_shape:
        sys.path.insert(0,str(WORK/'near-lines'))
        if args.near_shape:import shape_near as near
        else:import hex_near as near
        near.install()
    if args.lines or args.smooth_lines or args.cascade or args.wide or args.shape_fibre:
        sys.path.insert(0,str(WORK/'fibre-lines'))
    if args.lines:
        import line_cap
        line_cap.install()
    if args.smooth_lines:
        import smooth_cap
        smooth_cap.install()
    if args.cascade or args.wide or args.shape_fibre:
        from prime_sampling.spectrum import squarerates as sr
        if args.shape_fibre:import shaped_fibre as smooth_cascade
        elif args.wide:import smooth_wide as smooth_cascade
        else:import smooth_cascade
        original_cap=sr.square_cap
        cascade_cap=cache(smooth_cascade.calculate)
        def selected_cap(a,b,width,pm,p):
            prev=original_cap(a,b,width,pm,p)
            if sampled_axis is not None and a<sampled_axis[0] and 194<a<b<pm<=p<2*pm and 0<width<=b:
                return min(prev,cascade_cap(a,b,width,pm,p))
            return prev
        sr.square_cap=selected_cap
    # Both of these kernels use only results proved for this specific rate class.
    m.rates=lambda *unused:(F(1),F(1))
    sampled_axis=None
    endpoint_provider=(lambda:sampled_axis) if args.local_axis else None
    centered_tri.install(args.mode,m,True,endpoint_provider)
    harmonic.install(args.mode,m,endpoint_provider)
    if args.unequal:
        sys.path.insert(0,str(WORK/'operator-new'))
        import mixed
        assert endpoint_provider
        mixed.install(args.mode,m,trapezoid=True,opposite=endpoint_provider,only_small=True)
    branches=('with3',) if args.mode=='six' else ('with3','without3')
    banks={branch:new_bank(ledger.rank(args.right,branch),args.mode) for branch in branches}
    eps=F(2149,10**11)
    B=m.b(32,'ln',False)/m.zh
    C=m.b(32,'ln',True)/m.zl
    J=ledger.J
    I=ledger.I
    grid=args.active_grid
    assert grid%200==0 and args.depth>=0

    @cache
    def axis_factors(l,r):
        low,high=m.Xlo(r-l),m.Xhi(r-l)
        upper=((1+eps)*high-(1-eps))/l
        lower=((1-eps)*low-(1+eps))/r
        if args.abel:
            delta=r-l
            # Chord and endpoint tangent of 1/t on the exponent interval.
            high_moment=max(0,delta*(1-eps)*low-(1+eps)*(high-1)/m.zl)
            low_moment=max(0,(1-eps)*(low-1)/m.zh-(1+eps)*delta)
            upper-=high_moment/(l*r)
            lower+=low_moment/r**2
        return lower,upper

    @cache
    def counts(l,r):
        assert l<r and l*m.zl>=40
        small=m.Xlo(l)
        big=m.Xhi(r)
        num=(small*axis_factors(l,r)[0]/m.zh).__ceil__()
        width=(big*(1-m.Xlo(l-r))).__ceil__()
        return small.__floor__(),big.__ceil__(),num,width

    @cache
    def mass(u,v,w,z):
        if v<=u or z<=w:return F(0)
        return (2*m.Xhi(u+w-1)*axis_factors(u,v)[1]*axis_factors(w,z)[1]/m.zl)

    @cache
    def box(u,v,w,z):
        nonlocal sampled_axis
        assert u<v and w<z
        a,b,s,va=counts(u,v)
        x,y,k,vb=counts(w,z)
        if not args.local_axis and (m.Xhi(v+z-1)>=2 or m.Xlo(u+w-1)<=F(1,64)):
            return I,I
        if min(s,k)<2:
            return I,I
        sampled_axis=(x,y)
        g1,q1=m.rates(a,b,va,s,k,vb,m.pmin,m.pmax)
        sampled_axis=(a,b)
        g2,q2=m.rates(x,y,vb,k,s,va,m.pmin,m.pmax)
        # Project's complete second moment is valid independently of the rate class.
        # Use an enclosing enlarged interval of length C as in squarerates.rates.
        from math import isqrt
        def completion(n,opposite,span):
            radius=(span+1)//2+1
            c=min((m.pmin-1)//2,max(2*radius,isqrt(2*(isqrt(m.pmax)+1)*radius*n)))
            return (m.nthroot(F(c,c-radius)*(F(c,n)+2*(isqrt(m.pmax)+1))/opposite)
                    if c>radius and 2*c<m.pmin else F(1))
        old=min(completion(s,k,vb),completion(k,s,va),F(1))
        if args.trace_four:
            from trace_completion import price as trace_price
            old=min(old,trace_price(a,b,va,s,k,vb,m.pmin,m.pmax),
                    trace_price(x,y,vb,k,s,va,m.pmin,m.pmax))
        return m.upint(min(old,g1,g2)),m.upint(min(old,q1,q2))

    @cache
    def price(u,v,w,z):
        g,q=box(u,v,w,z)
        result=[]
        for branch in branches:
            options,scale=banks[branch]
            excluded=max(0,max(f-ledger.ceil(n*g+inner*q,I) for f,n,inner in options))
            coef=F(scale*(I-excluded),I*J)-1
            assert coef>=0
            result.append((J*mass(u,v,w,z)*coef).__ceil__())
        return tuple(result)

    def bounds(u,v,inside):
        if inside:
            return max(v,1-u-B),1-v
        return max(u,1-v-C),1-u

    @cache
    def boundary(u,v):
        w,z=bounds(u,v,False)
        extra=F(0)
        for j in range(8):
            left=u+(v-u)*j/8
            right=u+(v-u)*(j+1)/8
            extra+=mass(left,right,max(w,1-right),z)
            extra+=mass(left,right,w,min(z,max(right,1-left-B)))
        return (J*extra).__ceil__()

    def mid_band(u,v):
        center=(u+v)/2
        return max(center,1-center-(B+C)/2),1-center

    def positive_difference(first, second):
        return subtract(first,second)

    @cache
    def mismatch(u,v,band):
        extra=missing=F(0)
        for j in range(8):
            l=u+(v-u)*j/8
            r=u+(v-u)*(j+1)/8
            for a,b in positive_difference(band,bounds(l,r,True)):
                extra+=mass(l,r,a,b)
            for a,b in positive_difference(bounds(l,r,False),band):
                missing+=mass(l,r,a,b)
        return (extra*J).__ceil__(),(missing*J).__ceil__()

    @cache
    def frequencies(u,v,l,r):
        g,q=box(u,v,l,r)
        m0=mass(u,v,l,r)
        return ((m0*g*J/I).__ceil__(),(m0*q*J/I).__ceil__())

    @cache
    def triangle_multiplier(n):
        # DFT of the half interval in Z/(2n), normalized to have inverse
        # inversion without a denominator. Taylor's degree-seven truncation
        # bounds sin from below at 0 <= x < pi/2.
        from math import factorial
        def sin_lower(h):
            x=F(333,106)*min(h,2*n-h)/(2*n)
            return sum((-1)**k*x**(2*k+1)/factorial(2*k+1) for k in range(4))
        return F(1,2)+sum(1/sin_lower(h) for h in range(1,2*n,2))/(2*n)

    def intersect(first,second):
        return max(first[0],second[0]),min(first[1],second[1])

    @cache
    def panel(u,v,w,z,top,n):
        if w>=z:return (0,)*len(branches)
        g,q=box(u,v,w,z)
        # The Fourier characters only multiply the two axes by unit phases.
        # The majorant's constant term is instead integrated on the staircase.
        norm=triangle_multiplier(n)
        spectral=mass(u,v,w,z)*norm
        G=(spectral*g*J/I).__ceil__()
        Q=(spectral*q*J/I).__ceil__()
        best=[None]*len(branches)
        for spec in ('inner','middle','outer'):
            domain=excess=missing=F(0)
            endpoints=[]
            for i in range(n):
                a,b=u+(v-u)*i/n,u+(v-u)*(i+1)/n
                chosen=mid_band(a,b) if spec=='middle' else bounds(a,b,spec=='inner')
                edge=chosen[1 if top else 0]
                endpoints.append(edge)
                band=intersect((w,z),(w,edge) if top else (edge,z))
                for j in range(3):
                    l,r=a+(b-a)*j/3,a+(b-a)*(j+1)/3
                    inside=intersect((w,z),bounds(l,r,True))
                    outside=intersect((w,z),bounds(l,r,False))
                    domain+=mass(l,r,*outside)
                    for lo,hi in subtract(band,inside):excess+=mass(l,r,lo,hi)
                    for lo,hi in subtract(outside,band):missing+=mass(l,r,lo,hi)
            if endpoints!=sorted(endpoints) and endpoints!=sorted(endpoints,reverse=True):continue
            x,e,m0=[(val*J).__ceil__() for val in (domain,excess,missing)]
            assert x+e>=m0
            for j,branch in enumerate(branches):
                options,scale=banks[branch]
                fee=ledger.ceil(scale*min((I-f)*(x+e-m0)+I*m0+ng*G+nq*Q
                                           for f,ng,nq in options),I*J)-x
                best[j]=fee if best[j] is None else min(best[j],fee)
        return None if best[0] is None else tuple(best)

    def triangle_fee(u,v):
        w,z=bounds(u,v,False)
        a,b=bounds(u,v,True)
        if a>b:return evaluate(u,v,None,0)
        core=price(u,v,a,b) if a<b else (0,)*len(branches)
        fees=[]
        for lo,hi,top in ((w,a,False),(b,z,True)):
            choices=[panel(u,v,lo,hi,top,n) for n in (4,8,16,32)]
            good=[cost for cost in choices if cost is not None]
            if not good:return evaluate(u,v,None,0)
            fees.append(tuple(map(min,zip(*good))))
        return tuple(map(sum,zip(core,*fees)))

    zero=(0,)*len(branches)

    def panel_enclosure(u,v,w,z):
        # Project the two product inequalities and a <= b onto each axis.
        u,v=max(u,1-z-C),min(v,1-w,z)
        w,z=intersect((w,z),bounds(u,v,False))
        return u,v,w,z

    @cache
    def partial(u,v,w,z):
        if w>=z:return zero
        if u+w>=1-B and v+z<=1 and v<=w:return price(u,v,w,z)
        D=E=F(0)
        for j in range(8):
            a,b=u+(v-u)*j/8,u+(v-u)*(j+1)/8
            D+=mass(a,b,*intersect((w,z),bounds(a,b,False)))
            for l,r in subtract((w,z),bounds(a,b,True)):E+=mass(a,b,l,r)
        D,E=(D*J).__ceil__(),(E*J).__ceil__()
        if not D:return zero
        g,q=box(u,v,w,z)
        result=[]
        for j,branch in enumerate(branches):
            options,scale=banks[branch]
            fraction=max(0,max(f-ledger.ceil(ng*g+nq*q,I) for f,ng,nq in options))
            result.append(min(price(u,v,w,z)[j]+E,
                              ledger.ceil(scale*(I-fraction)*(D+E),I*J)-D,
                              ledger.ceil(scale*D,J)-D))
        return tuple(result)

    @cache
    def extended(u,v,parent,depth):
        outer=bounds(u,v,False)
        if parent:
            parent=intersect(outer,parent)
            if parent[0]>=parent[1]:parent=None
        def pay(interval):
            if not interval:return zero
            segments=subtract(interval,parent)
            return tuple(map(sum,zip(*(partial(u,v,w,z) for w,z in segments)))) if segments else zero
        result=pay(outer)
        if not depth:return result
        a,b=bounds(u,v,True);w,z=outer
        candidates={parent}
        if a<b:
            shifts=((0,0),(F(1,2),0),(1,0),(0,F(1,2)),(F(1,2),F(1,2))) if depth>=args.depth-1 else ((0,0),)
            for low,high in shifts:
                left,right=a+low*(w-a),b+high*(z-b)
                if parent:left,right=min(parent[0],left),max(parent[1],right)
                candidates.add((left,right))
        mid=(u+v)/2
        for candidate in candidates:
            fees=pay(candidate)
            l=extended(u,mid,candidate,depth-1)
            r=extended(mid,v,candidate,depth-1)
            result=tuple(map(min,result,map(sum,zip(fees,l,r))))
        return result

    @cache
    def panel_cover(u,v,w,z,depth):
        if u>=v or w>=z:return zero
        if u+w>=1-B and v+z<=1 and v<=w:
            return price(u,v,w,z)
        result=list(partial(u,v,w,z))
        if depth==0:return tuple(result)
        for vertical in (True,False):
            # Isolate the whole-height core strip, then price each residual
            # side independently. Split in the other coordinate in its absence.
            if vertical:
                low,high=max(u,1-w-B),min(v,w,1-z)
                cuts=[u,low,high,v] if low<high else [u,(u+v)/2,v]
                parts=[(a,b,w,z) for a,b in zip(cuts,cuts[1:]) if a<b]
            else:
                low,high=intersect((w,z),bounds(u,v,True))
                cuts=[w,low,high,z] if low<high else [w,(w+z)/2,z]
                parts=[(u,v,a,b) for a,b in zip(cuts,cuts[1:]) if a<b]
            cost=tuple(map(sum,zip(*(panel_cover(*panel_enclosure(*r),depth-1) for r in parts))))
            result=list(map(min,result,cost))
        return tuple(result)

    @cache
    def signed_walk(u,v,parent,depth,leaf):
        band=mid_band(u,v) if depth or leaf=='middle' else bounds(u,v,leaf=='inner')
        intervals=subtract(band,parent)
        if parent is not None:
            intervals+=subtract(parent,band)
        g=q=0
        for l,r in intervals:
            dg,dq=frequencies(u,v,l,r)
            g+=dg
            q+=dq
        if depth:
            mid=(u+v)/2
            left=signed_walk(u,mid,band,depth-1,leaf)
            right=signed_walk(mid,v,band,depth-1,leaf)
            return tuple(x+y+z for x,y,z in zip((g,q,0,0),left,right))
        return (g,q,*mismatch(u,v,band))

    def signed_fee(u,v):
        answer=[None]*len(branches)
        selected=[None]*len(branches)
        # Mass is needed only once, independently of the signed decomposition.
        cuts=16
        strip_mass=sum((J*m.mass(u+(v-u)*j/cuts,u+(v-u)*(j+1)/cuts)).__ceil__() for j in range(cuts))
        for depth in range(args.depth+1):
            for leaf in ('outer','middle','inner'):
                G,Q,E,M=signed_walk(u,v,None,depth,leaf)
                for j,branch in enumerate(branches):
                    options,scale=banks[branch]
                    # Positive-coefficient implementation: the deficit is
                    # expressed relative to the approximation A, so no lower
                    # approximation for mu is needed below.  Since mu <=
                    # mu_up, maximize mu*(m+E-M)+M at that upper endpoint.
                    assert strip_mass+E>=M
                    fee=ledger.ceil(scale*min((I-f)*(strip_mass+E-M)+I*M+n*G+inner*Q
                                               for f,n,inner in options),I*J)-strip_mass
                    if answer[j] is None or fee<answer[j]:
                        answer[j]=fee
                        selected[j]=(depth,leaf)
        return tuple(answer),selected

    @cache
    def ordered_triangle(u,v,depth):
        # Every pair in this square satisfies the product constraints; only a<=b remains.
        assert 2*u>=1-B and 2*v<=1
        full=mass(u,v,u,v)
        diagonal_half=m.zh*m.Xhi(v-1)
        rectangular=price(u,v,u,v)
        fees=[]
        for n,branch in enumerate(branches):
            _,scale=banks[branch]
            trivial=((F(scale,J)-1)*(full/2+diagonal_half)*J).__ceil__()
            fees.append(min(trivial,rectangular[n]+(full*J/2).__ceil__()))
        if depth:
            mid=(u+v)/2
            split=zip(ordered_triangle(u,mid,depth-1),price(u,mid,mid,v),ordered_triangle(mid,v,depth-1))
            fees=[min(x,sum(parts)) for x,parts in zip(fees,split)]
        return tuple(fees)

    def pieces(u,v,interval,parent):
        return [sum(x) for x in zip(*[price(u,v,l,r) for l,r in subtract(interval,parent)])] if subtract(interval,parent) else [0]*len(branches)

    @cache
    def evaluate(u,v,parent,depth):
        outer=bounds(u,v,False)
        value=[s+boundary(u,v) for s in pieces(u,v,outer,parent)]
        if capture:
            for branch in range(len(branches)):selected[u,v,parent,depth,branch]=0
        if depth:
            mid=(u+v)/2
            inner=bounds(u,v,True)
            for credit in (parent,inner) if inner[0]<inner[1] and inner!=parent else (parent,):
                fixed=pieces(u,v,credit,parent) if credit is not None else [0]*len(branches)
                a=evaluate(u,mid,credit,depth-1)
                b=evaluate(mid,v,credit,depth-1)
                for branch,(x,y,z) in enumerate(zip(fixed,a,b)):
                    cand=x+y+z
                    if cand<value[branch]:
                        value[branch]=cand
                        if capture:selected[u,v,parent,depth,branch]=1 if credit==parent else 2
        return tuple(value)
    def template(u,v,parent,depth,branch):
        tag=selected[u,v,parent,depth,branch]
        if tag==0:return 0
        core=parent if tag==1 else bounds(u,v,True)
        mid=(u+v)/2
        return [tag,template(u,mid,core,depth-1,branch),template(mid,v,core,depth-1,branch)]

    def from_template(u,v,parent,tree,depth,branch):
        if tree==0:
            return pieces(u,v,bounds(u,v,False),parent)[branch]+boundary(u,v)
        assert depth>0 and len(tree)==3 and tree[0] in (1,2)
        core=parent if tree[0]==1 else bounds(u,v,True)
        if core is not None and core[0]>=core[1]:core=parent
        fixed=pieces(u,v,core,parent)[branch] if core is not None else 0
        mid=(u+v)/2
        return fixed+from_template(u,mid,core,tree[1],depth-1,branch)+from_template(mid,v,core,tree[2],depth-1,branch)

    selected={};templates={}
    capture=os.environ.get('PRIME_MACRO_CAPTURE')
    hint=os.environ.get('PRIME_MACRO_TEMPLATE')
    loaded=json.loads(Path(hint).read_text()) if hint else {}
    records={}
    for j in args.macros:
        assert 67<=j<100
        if args.rates_probe:
            for n in (1,2,4,8,16,32):
                u=F(j,200);v=u+F(1,200*n)
                w,z=bounds(u,v,True)
                if w<z:
                    print('core',j,n,box(u,v,w,z),'unit-cost',
                          round(price(u,v,w,z)[0]/float(J*mass(u,v,w,z)),6),flush=True)
            continue
        estimates=[]
        for i in range(j*grid//200,(j+1)*grid//200):
            if args.overlap:
                from pass_cover import optimize
                u,v=F(i,grid),F(i+1,grid)
                estimates.append(optimize(u,v,args.overlap,bounds,mid_band,box,mass,banks,I,J))
            elif args.square_triangle:
                u,v=F(i,grid),F(i+1,grid)
                assert 2*u>=1-B and 2*v<=1
                a=ordered_triangle(u,v,args.depth)
                b=panel_cover(u,v,v,1-u,args.depth)
                estimates.append(tuple(map(sum,zip(a,b))))
            elif args.extended_core:
                u,v=F(i,grid),F(i+1,grid)
                estimates.append(extended(u,v,None,args.depth))
            elif args.mask:
                from mask_lp import optimize
                u,v=F(i,grid),F(i+1,grid)
                strip_mass=sum((J*m.mass(u+(v-u)*j/16,u+(v-u)*(j+1)/16)).__ceil__() for j in range(16))
                estimates.append(optimize(u,v,args.mask,bounds,mid_band,box,mass,banks,strip_mass,I,J,args.mask_phases))
            elif args.panels:
                u,v=F(i,grid),F(i+1,grid)
                estimates.append(panel_cover(u,v,*bounds(u,v,False),args.depth))
            elif args.triangular:
                estimates.append(triangle_fee(F(i,grid),F(i+1,grid)))
            elif args.signed:
                result,choice=signed_fee(F(i,grid),F(i+1,grid))
                estimates.append(result)
                print('signed choice',i,choice,flush=True)
            else:
                u,v=F(i,grid),F(i+1,grid)
                if hint:
                    ts=loaded[str(i)]
                    estimates.append(tuple(from_template(u,v,None,ts[b],args.depth,n) for n,b in enumerate(branches)))
                else:
                    estimates.append(evaluate(u,v,None,args.depth))
                    if capture:templates[str(i)]={b:template(u,v,None,args.depth,n) for n,b in enumerate(branches)}
        records[str(j)]=dict(zip(branches,map(sum,zip(*estimates))))
        print(j,records[str(j)],'rectangles',box.cache_info().currsize,flush=True)
        if capture:Path(capture).write_text(json.dumps(templates),encoding='ascii')
        if args.out:
            args.out.write_text(json.dumps(records,indent=2),encoding='ascii')
    if os.name=='nt':
        import _ctypes
        from prime_sampling.spectrum import squarerates
        _ctypes.FreeLibrary(squarerates._lib._handle)


if __name__=='__main__':
    main()
