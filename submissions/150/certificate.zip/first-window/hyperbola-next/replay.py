"""Reprice the first window, or regenerate the recorded geometry."""
from argparse import ArgumentParser
from pathlib import Path
import json,os,subprocess,sys
from tempfile import TemporaryDirectory

def main():
    cli=ArgumentParser(description=__doc__)
    cli.add_argument('--repo',type=Path,required=True)
    cli.add_argument('--rebuild-geometry',action='store_true')
    cli.add_argument('--rebuild-scalar',action='store_true')
    cli.add_argument('--omit-trace',action='store_true',help='independently reprice after dropping the new fourth dilation moment')
    args=cli.parse_args()
    here=Path(__file__).resolve().parent
    work=here.parent;repo=args.repo.resolve()
    if not __debug__:raise RuntimeError('Run without Python -O')
    env=dict(os.environ,PYTHONPATH=str(repo),PYTHONIOENCODING='utf-8')
    env.pop('PYTHONOPTIMIZE',None)
    def run(script,*options,ret=False):
        args=[sys.executable,'-B',str(script),*map(str,options)]
        if ret:return subprocess.check_output(args,env=env,encoding='utf-8')
        subprocess.run(args,env=env,check=True)
    run(here/'check_partition.py')
    run(work/'random-wheel/check_near_random.py','--repo',repo)
    run(work/'operator-new/verify_shapes.py')
    run(work/'operator-new/trapezoid_check.py')
    run(work/'operator-new/taper_check.py')
    run(work/'operator-new/frequency_check.py')
    run(work/'operator-new/centered_check.py')
    run(work/'gram-cycle/trap_check.py')
    run(work/'gram-cycle/joint_check.py')
    run(work/'gram-cycle/aperture_check.py')
    run(work/'gram-cycle/paley_four_check.py')
    run(work/'gram-cycle/tetrahedral_check.py')
    run(work/'operator-new/weight_check.py')
    recipes=json.loads((here/'recipes.json').read_text())
    if args.rebuild_scalar:
        run(work/'scalar-global/verify.py','--repo',repo)
        run(work/'cofactor-refined/verify.py','--repo',repo)
        run(work/'seed-weights/verify.py','--repo',repo)
        run(work/'transfer-weights/verify.py','--repo',repo)
        run(work/'transfer-bilinear/verify.py','--repo',repo)
        if (work/'seed-bridge/150.dat').is_file():
            run(work/'seed-bridge/check.py')
            run(work/'seed-bridge/projection_check.py')
            for r in (37,38):run(work/'seed-bridge/freeze.py','--repo',repo,'--rank',r,'--check')
            for r in (37,38):
                if (work/f'seed-bridge/layers{r}.dat').is_file():
                    run(work/'seed-bridge/layer_price.py','--repo',repo,'--rank',r,'--check')
                fixed=work/f'seed-bridge/joint-certified{r}.dat'
                if fixed.is_file():
                    run(work/'seed-bridge/joint_projection.py','--repo',repo,'--rank',r,'--out',fixed,'--check')
                if (work/f'seed-bridge/square-credit{r}.dat').is_file():
                    run(work/'seed-bridge/rough_squares.py','--repo',repo,'--rank',r,'--check')
                for name in ('three','walsh'):
                    table=work/f'seed-bridge/{name}-certified{r}.dat'
                    if table.is_file():
                        run(work/f'seed-bridge/{name}_projection.py','--repo',repo,'--rank',r,
                            '--records',table,'--out',table,'--check')
                for label in ('marked','hybrid','fit','sinc','tight','spectral','local'):
                    table=work/f'seed-bridge/{label}-certified{r}.dat'
                    if table.is_file():
                        script='outer_fit.py' if label in ('fit','sinc','tight','spectral') else 'marked_projection.py'
                        if label=='local':script='local_fit.py'
                        flags={'hybrid':['--walsh'],'sinc':['--sharp'],'tight':['--tight'],'spectral':['--spectral']}.get(label,[])
                        run(work/f'seed-bridge/{script}','--repo',repo,'--rank',r,
                            '--records',table,'--out',table,'--check',*flags)
            for tail in sorted((work/'wide-coverage').glob('terminal150r*.dat')):
                l,h,r,*_=tail.read_text().split()
                run(work/'wide-coverage/terminal_mesh.py','--repo',repo,'--window',l,h,'--rank',r,'--check',tail)
            for tail in sorted((work/'analytic-coverage').glob('log-terminal150r*.dat')):
                l,h,r,*_=tail.read_text().split()
                run(work/'analytic-coverage/weighted_terminal.py','--repo',repo,'--window',l,h,'--rank',r,'--check',tail)
            run(work/'seed-bridge/freeze.py','--repo',repo,'--route','--check')
    run(work/'scalar-tail/verify.py','--repo',repo,'--base-row',work/'scalar-global/150-without3.dat')
    with TemporaryDirectory() as tmp:
        if args.rebuild_geometry:
            for limits in (work/'mass-geometry').glob('rectangle-limits-*.json'):
                data=json.loads(limits.read_text())
                rebuilt=Path(tmp)/limits.name
                run(work/'mass-geometry/joint_bounds.py','--repo',repo,'--grid',data['grid'],'--panels',data['panels'],'--out',rebuilt)
                assert json.loads(rebuilt.read_text())==data
            for recipe in json.loads((work/'mass-geometry/recipes.json').read_text()):
                if recipe['left']!='150':continue
                target=Path(tmp)/recipe['out']
                if recipe.get('from_strip'):
                    input_cell=Path(tmp)/'native-mass-geometry'
                    run(work/'wide-coverage/native.py',work/recipe['from_strip'],input_cell,'--repo',repo)
                    opts=['--cell',input_cell/'cell.json']
                elif recipe.get('cell'):
                    opts=['--cell',work/recipe['cell']]
                else:
                    opts=['--left',recipe['left'],'--right',recipe['right'],'--grid',recipe['grid'],'--tables',*[work/p for p in recipe['tables']]]
                run(work/'mass-geometry/refine.py','--repo',repo,*opts,'--steps',recipe['steps'],'--core-steps',recipe['core_steps'],'--out',target)
                for expected in (work/'mass-geometry'/recipe['out']).glob('*.dat'):
                    assert [r.split()[5:] for r in expected.read_text().splitlines()]==[r.split()[5:] for r in (target/expected.name).read_text().splitlines()]
        for spec in recipes:
            if not args.rebuild_geometry:continue
            output=Path(tmp)/spec['file']
            options=[str(work/s[1:]) if s.startswith('@') else s for s in spec['options']]
            subset=[] if spec.get('batch') else ['--macros',*spec['macros']]
            run(work/spec.get('program','hyperbola-next/rectangles.py'),'--repo',repo,*options,*subset,'--out',output)
            rebuilt=json.loads(output.read_text())
            expected=json.loads((here/spec['file']).read_text())
            assert rebuilt.keys()==expected.keys()
            assert all(rebuilt[m].keys()==expected[m].keys() and
                       all(rebuilt[m][b]<=n for b,n in expected[m].items()) for m in expected),spec['file']
        if args.rebuild_geometry:
            for saved in here.glob('trace-rates*.json'):
                path=Path(tmp)/saved.name
                flag=['--refined'] if 'refined' in saved.name else []
                if 'local' in saved.name:flag.append('--local')
                if 'paired' in saved.name:flag.append('--paired')
                if 'aperture' in saved.name:flag.append('--aperture')
                if 'fold' in saved.name:flag.append('--fold-wheel')
                run(here/'trace_rows.py','--repo',repo,*flag,'--out',path)
                records=json.loads(saved.read_text())
                assert all(json.loads(path.read_text())[g]==rows for g,rows in records.items())
        if args.rebuild_geometry:
            for saved in [*here.glob('smooth-grid-*.json'),*(work/'native-first').glob('*/source.json')]:
                data=json.loads(saved.read_text())
                grid=data['grid']
                macros=sorted({i*200//grid for i,pair,six in data['rows']})
                groups=grid//200//(data['envelopes'][0][1]-data['envelopes'][0][0])
                path=Path(tmp)/saved.name
                flag=['--wide'] if data.get('wide') else ['--cascade'] if data.get('cascade') else []
                if data.get('near_hex'):flag.append('--near-hex')
                if data.get('near_shape'):flag.append('--near-shape')
                if data.get('shared_shapes'):flag.append('--shared-shapes')
                if data.get('trapezoid'):flag.append('--trapezoid')
                if data.get('autotaper'):flag.append('--autotaper')
                if data.get('balanced'):flag.append('--balanced')
                if data.get('frequency_envelope'):flag.append('--frequency-envelope')
                if data.get('wheel_search'):flag.append('--wheel-search')
                if data.get('local_conductor'):flag.append('--local-conductor')
                if data.get('centered_powers'):flag.append('--centered-powers')
                if data.get('reweight'):flag.append('--reweight')
                if data.get('paley_four'):flag.append('--paley-four')
                if data.get('tetra_four'):flag.append('--tetra-four')
                if data.get('fibre_portfolio_caps'):
                    base=work/'fibre-portfolio'/data['fibre_portfolio_caps']
                    assert base.parent==work/'fibre-portfolio' and base.is_file()
                    flag.extend(['--caps',base])
                if data.get('shape_fibre'):flag.append('--shape-fibre')
                run(here/'smooth_rows.py','--repo',repo,'--grid',grid,'--groups',groups,*flag,'--macro',*macros,'--out',path)
                check=json.loads(path.read_text())
                assert sorted(check['rows'])==sorted(data['rows'])
                assert sorted(check['envelopes'])==sorted(data['envelopes'])
                if saved.name=='source.json':
                    native=Path(tmp)/'native'/saved.parent.name
                    info=json.loads((saved.parent/'cell.json').read_text())
                    flags=['--direct'] if info.get('direct') else []
                    run(work/'wide-coverage/native.py',path,native,'--repo',repo,*flags)
                    assert all((native/f).read_bytes()==(saved.parent/f).read_bytes() for f in ('pair.dat','six.dat'))
    files=[here/s['file'] for s in recipes if not args.omit_trace or s['file']!='trace-pair.json']
    flag=['--omit-trace'] if args.omit_trace else []
    text=run(here/'compare.py','--repo',repo,'--combined',*flag,*files,ret=True)
    print(text,end='')
    best={row.split()[1]:int(row.split()[-1]) for row in text.splitlines() if row.startswith('best ')}
    if args.omit_trace:
        assert best['without3']>0
        print('The without3 branch stays positive without the new fourth dilation moment.')
    else:assert best==json.loads((here/'margins.json').read_text()),best
    print('Exact first-window ledger reproduced.')
if __name__=='__main__':main()
