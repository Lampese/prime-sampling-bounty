"""Check inclusions, boundary conventions, and two-dimensional additive accounting."""
from fractions import Fraction as F
from random import Random
from rectangles import subtract

def check():
    rng=Random(150)
    B,C=F(238,10000),F(241,10000)
    def bounds(u,v,inner):
        return (max(v,1-u-B),1-v) if inner else (max(u,1-v-C),1-u)
    def owns(band,y):return band[0]<y<=band[1]
    def tile(u,v,parent,level):
        outer=bounds(u,v,False)
        if not level:
            return [(u,v,a,b) for a,b in subtract(outer,parent)]
        inner=bounds(u,v,True)
        if inner[0]>=inner[1] or rng.randrange(4)==0:inner=parent
        pieces=[] if inner is None else [(u,v,a,b) for a,b in subtract(inner,parent)]
        mid=(u+v)/2
        return pieces+tile(u,mid,inner,level-1)+tile(mid,v,inner,level-1)
    total=0
    for j in (67,84,90,97,98,99):
        u,v=F(j,200),F(j+1,200)
        patches=tile(u,v,None,4)
        for i in range(1,65):
            x=u+(v-u)*i/64
            ys={x,1-x,1-x-B,1-x-C}
            for a,b,l,r in patches:
                if a<x<=b:ys.update((l,r))
            for y in sorted(ys):
                for dy in (F(0),F(-1,100000),F(1,100000)):
                    z=y+dy
                    cover=sum(a<x<=b and l<z<=r for a,b,l,r in patches)
                    assert cover<=1
                    # Left-open intervals in the large coordinate omit a=b if
                    # it is exactly on a lower boundary, except a itself > u.
                    for L in (B,(B+C)/2,C):
                        target=(z>=x and 1-L<x+z<=1)
                        if target:assert cover==1,(j,x,z,L)
                    total+=1
    print('fractional boundary and cover tests',total)
if __name__=='__main__':check()
