"""Boundary contribution to the completed-dilation moments of the adjoint sheaf."""
from fractions import Fraction as F
from math import isqrt


def completion(s, k, span, pm, p, M, degree=2, nonquadratic=False):
    """Drop-in replacement for trace-dilate.scale.completion, using its candidate scales."""
    from scale import _trials, QUADRATICS, CUBICS, DOUBLE_QUADRATICS, DOUBLE_CUBICS, root
    radius = (span+1)//2+1
    rt = isqrt(p)+1
    widths = [c for c in _trials(radius, s, rt) if radius < c and 2*c < pm]
    if not widths:
        return F(1)
    weight = F(M, s*s)
    paired = 1+F(2*rt,pm)
    sign_classes = 1 if nonquadratic else 2
    extended = ()
    floats = ()
    if degree > 3:
        from adjoint_envelopes import menu
        extended = menu(degree)
        floats = tuple(tuple(map(float, p)) for p in extended)

    def score(c, approx):
        cap = (2*float(c)+1/float(c))/3 if approx else F(2*c*c+1,3*c)
        v = float(weight) if approx else weight
        mult = float(paired) if approx else paired
        den = float(pm) if approx else pm
        sq = (lambda x:x**.5) if approx else root
        qroots = DOUBLE_QUADRATICS if approx else QUADRATICS
        croots = DOUBLE_CUBICS if approx else CUBICS
        pair4 = cap*cap*mult/den
        def fourth(j):
            izero = j*(2*j*j+1)//3
            generic = (j**4-2-izero)*rt+izero+1
            return sq(sq(v*(generic+sign_classes**2*j*pair4)))
        e2 = sq(v*(4*rt+4+sign_classes*cap*mult))
        e3,e5 = fourth(3),fourth(5)
        envelope = min(a+b*e3+d*e5 for a,b,d in qroots)
        if degree >= 3:
            e7 = fourth(7)
            envelope = min(envelope,min(a+b*e3+d*e5+e*e7 for a,b,d,e in croots))
        if extended:
            errs = [1,e3,e5,e7]+[fourth(2*j+1) for j in range(4,degree+1)]
            opts = floats if approx else extended
            if not approx:
                # Only the final proposal needs the relatively large rational coefficients.
                ef = list(map(float,errs))
                best = min(range(len(floats)),key=lambda i:sum(x*y for x,y in zip(ef,floats[i])))
                opts = [extended[best]]
            envelope = min(envelope,min(sum(x*y for x,y in zip(errs,poly)) for poly in opts))
        factor = min(2,sq(1+e2),sq(1+e3),envelope)
        if approx:
            return float(c)/(c-radius)*(float(c)/s+rt*factor)
        return root(F(c,c-radius)*(F(c,s)+rt*factor)/k)

    return min([F(1)]+[score(c,False) for c in sorted(widths,key=lambda w:score(w,True))[:3]])


def menu_rates(mode, s, k, span, pm, p, M, degree=3):
    """Return external and internal channel prices, both valid in this direction."""
    nq = completion(s, k, span, pm, p, M, degree, nonquadratic=True)
    quad = completion(s, k, span, pm, p, M, degree)
    return nq, (quad+2*nq)/3 if mode=="six" else quad
