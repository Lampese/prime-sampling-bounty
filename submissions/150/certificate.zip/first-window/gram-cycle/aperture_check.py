"""Finite checks of the prime parity change, spline normalizations and edge counts."""
from aperture_completion import coefficient,wheel_l1
from cmath import exp,pi
from collections import Counter
from fractions import Fraction as F
from math import gcd


def convolve(x,y):
    acc=Counter()
    for a,v in x.items():
        for b,w in y.items():
            acc[a+b]+=v*w
    return acc


checks=0
for n in range(2,12):
    for h in (1,2,3):
        aperture={i:1 for i in range(n)}
        dist={0:1}
        for _ in range(2*h):dist=convolve(dist,aperture)
        b=h*(n-1)
        for x in range(-b-1,b+2):assert coefficient(n,h,x)==dist[x+b]
        center=dist[b];W={i-b:F(v,center) for i,v in dist.items()}
        assert sum(W.values())==F(n**(2*h),center)
        assert sum(v*v for v in W.values())==F(coefficient(n,2*h,0),center**2)
        assert all(W[x]>=W[x+1] for x in range(b))
        p=101
        freq=[sum(float(v)*exp(2j*pi*k*x/p) for x,v in W.items()).real/p for k in range(p)]
        assert min(freq)>-1e-12 and abs(sum(freq)-1)<1e-12
        checks+=1
for p,g in ((61,2),(101,2)):
    lg={pow(g,i,p):i for i in range(p-1)}
    assert len(lg)==p-1
    for order in (1,2,3):
        chi=lambda i: exp(2j*pi*order*lg[i%p]/(p-1)) if i%p else 0
        for t in (1,2,p-3):
            for b in (5,7,11,13):
                k=(b-1)//2
                for a in (3,5,7):
                    u=t*pow(a,-1,p)
                    assert abs(chi(b+u)-chi(2)*chi(k+(1+u)*pow(2,-1,p)))<1e-12
            checks+=1
print(checks,'parity and spline cases passed, including full finite Fourier sums.')

p=1009
for wheel in (6,10,14):
    residues=[i for i in range(wheel) if gcd(i,wheel)==1]
    for h,n in ((1,4),(2,4),(3,5)):
        center=coefficient(n,h,0)
        V={x:F(coefficient(n,h,x),center) for x in range(-h*(n-1),h*(n-1)+1)}
        raw=[sum(float(v)*exp(2j*pi*x*k/p) for x,v in V.items()).real/p for k in range(p)]
        mod=[abs(sum(exp(2j*pi*((k*r*pow(wheel,-1,p))%p)/p) for r in residues)) for k in range(p)]
        d=len(residues)
        assert abs(sum(w*z*z for w,z in zip(raw,mod))-d)<1e-9
        assert abs(sum((w*z)**2 for w,z in zip(raw,mod))-d*sum(w*w for w in raw))<1e-9
        assert sum(w*z for w,z in zip(raw,mod))<=float(wheel_l1(d,V[1]))+1e-9
print('9 complete-field reduced-residue moment and norm checks passed.')
