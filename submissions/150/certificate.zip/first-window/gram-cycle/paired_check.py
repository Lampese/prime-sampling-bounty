"""Small-field verification of the centered pair, signs, and pairing dimensions."""
from cmath import exp,pi
from itertools import product
from math import sqrt
from collections import Counter
from paired_envelopes import moments


def check(p):
    log={}
    for gen in range(2,p):
        log={pow(gen,k,p):k for k in range(p-1)}
        if len(log)==p-1:break
    ps=[exp(2j*pi*h/p) for h in range(p)]
    chi=[exp(2j*pi*j/(p-1)) for j in range(p-1)]
    def rho(k,v):return chi[k*log[v]%(p-1)] if v else 0
    def rational(v):return (v-1)*pow(v+1,-1,p)%p if (v+1)%p else 0
    inv2=pow(2,-1,p)
    pairs=[(k,(k+(p-1)//2)%(p-1)) for k in range(1,p-1)]
    pairs=[(k,l) for k,l in pairs if min(k,l)>0 and k!=l and (k+l)%(p-1) and 2*k%(p-1) and 2*l%(p-1)]
    H={k:[sum(rho(k,rational(v))*ps[v*h%p] for v in range(p))/sqrt(p) for h in range(p)]
       for k in set(i for pair in pairs for i in pair)}
    for arr in H.values():
        assert abs(arr[0]+1/sqrt(p))<1e-9 and max(abs(z.imag) for z in arr)<1e-9
    for C in (2,4):
        w=[abs(sum(ps[j*h%p] for j in range(C)))**2/(p*C) for h in range(p)]
        sig=sum(x*x for x in w)
        assert abs(sig-(2*C*C+1)/(3*p*C))<1e-10
        for k,l in pairs:
            for b0,x,y in ((1,0,1),(3,4,7),(p-1,2,p-2)):
                lhs=0
                for b in range(p):
                    T=max(0,1-min((b-b0)%p,(b0-b)%p)/C)
                    v=(2*b+x+y)*pow((y-x)%p,-1,p)%p
                    lhs+=T*(rho(k,rational(v))+rho(l,rational(v)))/2
                rhs=0
                for h,z in enumerate(w):
                    f=-h*(y-x)*inv2%p
                    rhs+=z*ps[h*(b0+(x+y)*inv2)%p]*(H[k][f]+H[l][f])/2
                assert abs(lhs-sqrt(p)*rhs)<1e-8
            fourth=sum(abs(sum(w[h]*H[k][d*h%p]*H[l][d*h%p] for h in range(1,p)))**4
                       for d in range(1,p))
            assert fourth <= 170*sqrt(p)+70+4*(p+2*sqrt(p))*sig**2
    return len(pairs)


for i,j in ((0,2),(1,1),(2,2),(4,2)):
    g,b,m=moments(i,j)
    local=Counter(i+j-2*(x+y) for x in range(i+1) for y in range(j+1))
    count=sum(a*b*c*local[-x-y-z] for x,a in local.items() for y,b in local.items() for z,c in local.items())
    assert count==b and g+b+local[0]**4==((i+1)*(j+1))**4
assert moments(1,1)==(170,70,4)
print('centered Fourier identity, zero frequency, real-valuedness and cross fourth moment',
      [(p,check(p)) for p in (13,19,31,43)])
