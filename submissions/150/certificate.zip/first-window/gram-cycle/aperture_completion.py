"""Complete an odd-prime sample with a positive Fourier spline and harmonic coverage."""
from fractions import Fraction as F
from functools import lru_cache
from math import comb,isqrt


def coefficient(n,h,x):
    """Central coefficient at offset x of the 2h-fold integer box convolution."""
    s=h*(n-1)-abs(x)
    if s<0:return 0
    return sum((-1)**j*comb(2*h,j)*comb(s-j*n+2*h-1,2*h-1)
               for j in range(min(2*h,s//n)+1))


def profile(h,x):
    """Continuous cardinal spline; used only to nominate integer apertures."""
    return sum((-1)**j*comb(2*h,j)*max(0.,h-abs(x)-j)**(2*h-1)
               for j in range(h+1))


def wheel_l1(phi,first):
    if phi==1:return 1
    # W=2*ell, phi=ell-1. Orthogonality in the reduced residue classes.
    fourth=(phi**4+phi)//(phi+1)
    return 1+(phi-1)*F(1,2)-max(0,fourth*first-2*phi+1)/(2*(phi+1)**2)


def price(s,k,span,pmin,p,M,loglo,theta_error,panels=16,wheel=2):
    from scale import root,_trials
    from math import factorial
    # All sampling primes exceed 2. Write b=1+2j and use an integer centre for j.
    assert wheel in (2,6,10,14,22)
    phi=1 if wheel==2 else wheel//2-1
    R=(span+2*wheel-1)//(2*wheel)+(1 if wheel==2 else 2)
    rt=isqrt(p)+1
    edges=[R*i//panels for i in range(panels+1)]
    tails=[min(F(1),(2+(2*wheel*(R-x+2)+4*theta_error)/loglo)/k) for x in edges[:-1]]
    float_tails=list(map(float,tails))
    thresholds=_trials(R,s,rt)
    def candidate(h,n,exact):
        # The current window is supported on [-h(n-1),h(n-1)].
        if not (R<h*(n-1) and 2*wheel*(h*(n-1)+2)<pmin):return None
        if exact:
            mid=coefficient(n,h,0)
            window=[F(coefficient(n,h,x),mid) for x in edges]
            mass=F(n**(2*h),mid)
            l2=F(coefficient(n,2*h,0),mid**2)
            weights=tails;num=F;sq=root
            norm=wheel_l1(phi,F(coefficient(n,h,1),mid))
        else:
            mid=profile(h,0)/factorial(2*h-1)
            window=[profile(h,x/n)/(mid*factorial(2*h-1)) for x in edges]
            mass=n/mid
            l2=n*profile(2*h,0)/(factorial(4*h-1)*mid**2)
            weights=float_tails;num=float;sq=lambda x:x**.5
            norm=float(wheel_l1(phi,1))
        if min(window)<=0:return None
        inv=[1/x for x in window]
        coverage=1+sum(t*(b-a) for t,a,b in zip(weights,inv,inv[1:]))
        err=(1+num(2*rt)/pmin)*(phi*l2)**2/pmin
        weight=num(M)/(s*s)
        def moment(A,B,C):return sq(sq(weight*((A*rt+B)*norm**4+C*err)))
        adj=moment(60,20,3);quad=moment(60,20,12)
        cross=moment(170,70,4);inner=moment(170,70,16)
        results=[]
        for q,quadratic,e in ((F(1,2),0,cross),(F(1),1,inner),
                              (F(3,16),0,cross),(F(2,9),F(1,9),inner)):
            factor=min(2*norm,sq(norm*(num(q)*norm+num(q-quadratic)*adj+num(quadratic)*quad+num(1-q)*e)))
            results.append(sq(coverage*(phi*mass/s+rt*factor)/k))
        return results
    options={}
    # One smooth spline has a larger support for a comparable effective width.
    for h in (1,2,3):
        for c in thresholds:
            n=max(2,c//h)
            if (h,n) in options:continue
            rates=candidate(h,n,False)
            if rates:options[h,n]=rates
    out=[F(1)]*4
    choices={setting for i in range(4) for setting in sorted(options,key=lambda z:options[z][i])[:2]}
    for h,n in choices:
        rates=candidate(h,n,True)
        if rates:out=list(map(min,out,rates))
    return out
