"""Integer-certified Fourier cost for a rank-one phase at one exterior corner."""
from math import isqrt


PARAMETER = 8
DEN = 10**8


def _norm_upper(j):
    den = 4 * PARAMETER - j
    num = 4 * PARAMETER * DEN**2
    root = isqrt(num // den)
    return root + (root**2 * den < num)


NORMS = tuple(_norm_upper(j) for j in range(PARAMETER+1))


def extra_saving(benefit, spectrum):
    """Both inputs use mass times I**2. Return a downward-rounded saving."""
    # 1/sqrt(1-lambda/4)-1 >= lambda/8 for 0 <= lambda <= 1.
    if 8*benefit <= spectrum:
        return 0
    return max(
        (j * DEN * benefit - PARAMETER * (norm - DEN) * spectrum)
        // (PARAMETER * DEN)
        for j, norm in enumerate(NORMS)
    )
