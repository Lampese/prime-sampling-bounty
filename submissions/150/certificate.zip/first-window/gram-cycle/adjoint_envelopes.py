"""Rational odd-degree Hermite majorants for sqrt(x), in SL2 characters."""
from fractions import Fraction as F
from functools import cache
from math import cos, pi


def linear_product(a, root):
    return [-root*a[0]]+[a[i-1]-root*a[i] for i in range(1,len(a))]+[a[-1]]


def value_and_derivative(a, x):
    value = derivative = 0
    for coeff in reversed(a):
        derivative = derivative*x+value
        value = value*x+coeff
    return value, derivative


@cache
def characters(n):
    V = [[1],[-1,1]]
    for j in range(1,n):
        nxt = linear_product(V[-1],2)
        for i,v in enumerate(V[-2]):
            nxt[i] -= v
        V.append(nxt)
    return V[:n+1]


@cache
def envelope(ys):
    poly, remainder = [], [F(1)]
    for y in ys:
        x = y*y
        pv,pd = value_and_derivative(poly,x)
        rv,rd = value_and_derivative(remainder,x)
        coef = (y-pv)/rv
        slope = (1/(2*y)-pd-rd*coef)/rv
        correction = [coef*z for z in remainder]+[F(0)]
        first = linear_product(remainder,x)
        for i,v in enumerate(first):
            correction[i] += slope*v
        poly += [F(0)]*(len(correction)-len(poly))
        poly = [a+b for a,b in zip(poly,correction)]
        remainder = linear_product(first,x)
    for y in ys:
        assert value_and_derivative(poly,y*y) == (y,1/(2*y))
    basis = characters(len(poly)-1)
    a = [F(0)]*len(poly)
    for j in range(len(poly)-1,-1,-1):
        a[j] = poly[j]
        for i,v in enumerate(basis[j]):
            poly[i] -= a[j]*v
    assert all(x==0 for x in poly) and a[0]>F(4,5)
    return tuple([a[0]]+[abs(v) for v in a[1:]])


@cache
def menu(degree=7):
    out = set()
    # Node positions choose polynomial coefficients. All checks use rational nodes.
    for m in range(2,(degree+1)//2+1):
        roots = sorted(2*cos(k*pi/(2*m+1)) for k in range(1,m+1))
        for scale in (.70,.85,1,1.15,1.30):
            for shift in (-.10,0,.10,.20,.30,.40):
                ys = tuple(F(max(1,round(32*(scale*y+shift))),32) for y in roots)
                if len(set(ys))==m:
                    out.add(envelope(ys))
    return sorted(out)
