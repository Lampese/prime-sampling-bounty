"""Keep the three labels fixed across all frequencies of each completed Gram edge."""
from fractions import Fraction as F
from math import isqrt


def joint(mode,inner,s,k,span,pm,p,M,*,tails=None):
    from scale import _trials,root
    R=(span+1)//2+1
    rt=isqrt(p)+1
    widths=[c for c in _trials(R,s,rt) if R<c and 2*c<pm]
    if not widths:return F(1)
    if tails:
        fracs=tuple((a,b,float(f),f) for a,b,f in tails)
    def front(c,approx):
        num=float if approx else F
        if tails:
            return 1+sum(num(c)*(b-a)/((c-b)*(c-a))*(u if approx else f)
                          for a,b,u,f in fracs)
        return num(c)/(c-R)
    if mode=='pair':
        mu,quad2=(F(1),F(1)) if inner else (F(1,2),F(0))
    elif mode=='six':
        mu,quad2=(F(2,9),F(1,9)) if inner else (F(3,16),F(0))
    else:raise ValueError(mode)
    def cost(c,approx):
        num=float if approx else F
        sq=(lambda x:x**.5) if approx else root
        cap=num(2*c*c+1)/(3*c)
        scale=cap*cap*(1+num(2*rt)/pm)/pm
        weight=num(M)/(s*s)
        def quartic(g,b,m):
            return sq(sq(weight*(g*rt+b+m*scale)))
        adj=quartic(60,20,3)
        adjq=quartic(60,20,12) if inner else adj
        cross=quartic(170,70,16 if inner else 4)
        factor=min(2,sq(num(mu)+num(mu-quad2)*adj+num(quad2)*adjq+num(1-mu)*cross))
        return sq(front(c,approx)*(num(c)/s+rt*factor)/k)
    return min([F(1)]+[cost(c,False) for c in sorted(widths,key=lambda c:cost(c,True))[:4]])


def prime_tails(span,k,logmin,ymax,eps,bins=32):
    """logmin <= log y throughout true sampling interval, ymax >= all y."""
    if logmin<40:raise ValueError('theta bound requires log of lower sampling endpoint >= 40')
    R=(span+1)//2+1
    cuts=sorted({i*R//bins for i in range(bins+1)})
    return tuple((u,v,min(F(1),(2+(2*(R-u+1)+4*eps*ymax)/logmin)/k))
                 for u,v in zip(cuts,cuts[1:]))


def rates(mode,s,k,span,pm,p,M,degree=7):
    from paired_completion import rates as pair_rates
    old=pair_rates(mode,s,k,span,pm,p,M,degree)
    return tuple(min(old[q],joint(mode,q,s,k,span,pm,p,M)) for q in (0,1))


def reweighted_six(inner,s,k,span,pm,p,M):
    """Propagate the Cauchy change of the cubic-label-zero mass to the joint moment."""
    from scale import _trials,root
    R=(span+1)//2+1
    rt=isqrt(p)+1
    widths=[c for c in _trials(R,s,rt) if R<c and 2*c<pm]
    if not widths:return F(1)
    orig=F(1,3) if inner else F(1,2)
    menu=sorted({orig,*(F(i,96) for i in range(18,51))})
    def params(t):
        penalty=orig**2/t+(1-orig)**2/(1-t)
        q=t*t if inner else 0
        mu=(t*t if inner else t*t/2)+(1-t)**2/4
        return penalty,q,mu
    exact=[params(t) for t in menu]
    floats=[tuple(map(float,vals)) for vals in exact]
    def quantities(c,approx):
        num=float if approx else F
        sq=(lambda x:x**.5) if approx else root
        cap=num(2*c*c+1)/(3*c)
        scale=cap*cap*(1+num(2*rt)/pm)/pm
        weight=num(M)/(s*s)
        def fourth(g,b,m):return sq(sq(weight*(g*rt+b+m*scale)))
        return fourth(60,20,3),fourth(60,20,12 if inner else 3),fourth(170,70,16 if inner else 4)
    def choose(c,approx,only=None):
        num=float if approx else F
        sq=(lambda x:x**.5) if approx else root
        adj,adjq,ec=quantities(c,approx)
        opts=enumerate(floats if approx else exact)
        def rate(row):
            penalty,quad2,mu=row
            f=min(2,sq(mu+(mu-quad2)*adj+quad2*adjq+(1-mu)*ec))
            return sq(penalty*num(c)/(c-R)*(num(c)/s+rt*f)/k)
        return min((rate(row),i) for i,row in opts if only is None or i==only)
    proposed=sorted((choose(c,True),c) for c in widths)[:5]
    return min([F(1)]+[choose(c,False,j)[0] for (unused,j),c in proposed])
