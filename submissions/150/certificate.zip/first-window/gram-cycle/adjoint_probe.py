"""Compare original and local-conductor bounds on the early G3200 outer boxes."""
from fractions import Fraction as F
from pathlib import Path
import os,sys

work = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(work / name) for name in ("prime-sampling","residue-bridge/crt-fast","trace-dilate")]
if (work / "zig-cxx.cmd").exists():
    os.environ.setdefault("CXX",str(work / "zig-cxx.cmd"))
    os.environ.setdefault("ZIG_GLOBAL_CACHE_DIR",str(work / "zig-cache"))
    os.environ.setdefault("ZIG_LOCAL_CACHE_DIR",str(work / "zig-local-cache"))
from prime_sampling.rectangles import boxes as m, sieved_lift
from prime_sampling.spectrum import squarerates as sr
import crt_fibres, scale, adjoint_local

m.initialize(F(150),F(4801,32))
sieved_lift.install(m)
crt_fibres.install(corner=True,layered=True)
for u in map(F,(".335",".35",".375",".40")):
    v = u+F(1,3200)
    cl = max(m.LAM*m.Xlo(u-v),m.Xlo(2*u-1))
    eps,_,a,b,s,width,ylo,yhi = m.params(u,v)
    eps = max(eps,m.thetaerr((1-u)*m.zl+m.b(cl,"ln",False)))
    k = (m.abel.lower_count(cl,1,eps,(1-u)*m.zh,m)*ylo).__ceil__()
    span = ((1-cl)*yhi).__ceil__()+2
    M = min(sr.dirichlet_cap(a,b,width,m.pmin,m.pmax),sr.previous_cap(width,b,m.pmin),sr.square_cap(a,b,width,m.pmin,m.pmax))
    M = scale.prime_fibre(a,b,width,m.pmin,M)
    vals = [m.upint(fun(s,k,span,m.pmin,m.pmax,M,degree))
            for fun in (scale.completion,adjoint_local.completion) for degree in (2,3)]
    g,q = adjoint_local.menu_rates("six",s,k,span,m.pmin,m.pmax,M)
    only3 = adjoint_local.completion(s,k,span,m.pmin,m.pmax,M,4,True)
    up5 = adjoint_local.completion(s,k,span,m.pmin,m.pmax,M,5,True)
    g7,q7 = adjoint_local.menu_rates("six",s,k,span,m.pmin,m.pmax,M,7)
    print(u,"original quadratic/cubic and refined quadratic/cubic",*vals,
          "six exterior/interior degree 3 and 7",m.upint(g),m.upint(q),m.upint(g7),m.upint(q7),
          "expanded cubic and quintic",m.upint(only3),m.upint(up5),flush=True)
if os.name == "nt":
    import _ctypes
    _ctypes.FreeLibrary(sr._lib._handle)
