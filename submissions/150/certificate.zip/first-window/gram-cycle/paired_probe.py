"""Compare local single-character and genuinely paired completion on fixed rectangles."""
from fractions import Fraction as F
from pathlib import Path
import os,sys

work=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(work/i) for i in ('prime-sampling','residue-bridge/crt-fast','trace-dilate','gram-cycle')]
if (work/'zig-cxx.cmd').is_file():
    os.environ.setdefault('CXX',str(work/'zig-cxx.cmd'))
    os.environ.setdefault('ZIG_GLOBAL_CACHE_DIR',str(work/'zig-cache'))
    os.environ.setdefault('ZIG_LOCAL_CACHE_DIR',str(work/'zig-local-cache'))
from prime_sampling.rectangles import boxes as m,sieved_lift
from prime_sampling.spectrum import squarerates as sr
from scale import prime_fibre
from adjoint_local import menu_rates
from paired_completion import rates
import crt_fibres
from argparse import ArgumentParser
cli=ArgumentParser()
cli.add_argument('--polynomial',action='store_true')
cli.add_argument('--joint',action='store_true')
cli.add_argument('--group-polynomial',action='store_true')
cli.add_argument('--prime-front',action='store_true')
cli.add_argument('--reweight',action='store_true')
args_cli=cli.parse_args()

m.initialize(F(150),F(4801,32))
sieved_lift.install(m)
crt_fibres.install(corner=True,layered=True)
for u in map(F,('.335','.35','.36','.375','.38','.4','.45','.49')):
    v=u+F(1,3200)
    cl=max(m.LAM*m.Xlo(u-v),m.Xlo(2*u-1))
    eps,_,a,b,s,width,ylo,yhi=m.params(u,v)
    eps=max(eps,m.thetaerr((1-u)*m.zl+m.b(cl,'ln',False)))
    k=(m.abel.lower_count(cl,1,eps,(1-u)*m.zh,m)*ylo).__ceil__()
    span=((1-cl)*yhi).__ceil__()+2
    M=min(sr.dirichlet_cap(a,b,width,m.pmin,m.pmax),sr.previous_cap(width,b,m.pmin),sr.square_cap(a,b,width,m.pmin,m.pmax))
    M=prime_fibre(a,b,width,m.pmin,M)
    args=('six',s,k,span,m.pmin,m.pmax,M,7)
    old=menu_rates(*args);new=rates(*args)
    extra=[]
    if args_cli.polynomial:
        from paired_envelopes import paired_polynomial
        g=min(new[0],paired_polynomial(s,k,span,m.pmin,m.pmax,M))
        extra=[g,new[1]+2*(g-new[0])/3]
    if args_cli.joint:
        from joint_completion import joint
        extra.extend(min(new[q],joint('six',q,s,k,span,m.pmin,m.pmax,M)) for q in (0,1))
    if args_cli.group_polynomial:
        from group_envelope import external
        extra.append(external('six',s,k,span,m.pmin,m.pmax,M))
    if args_cli.prime_front:
        from joint_completion import prime_tails,joint
        zlo=(1-u)*m.zl+m.b(cl,'ln',False)
        tails=prime_tails(span,k,zlo,yhi,m.thetaerr(zlo))
        extra.extend(joint('six',q,s,k,span,m.pmin,m.pmax,M,tails=tails) for q in (0,1))
    if args_cli.reweight:
        from joint_completion import reweighted_six
        extra.extend(reweighted_six(q,s,k,span,m.pmin,m.pmax,M) for q in (0,1))
    print(u,'previous then paired',*map(m.upint,(*old,*new,*extra)),flush=True)
if os.name=='nt':
    import _ctypes
    _ctypes.FreeLibrary(sr._lib._handle)
