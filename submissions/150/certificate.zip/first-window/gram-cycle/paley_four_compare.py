"""Compare like-for-like first-window late rates before hierarchical macro accounting."""
from pathlib import Path
from fractions import Fraction
import json

work=Path(__file__).resolve().parents[1]
old={};new={}
files=sorted((work/'hyperbola-next').glob('smooth-grid-*.json'))
files+=sorted((work/'fibre-portfolio').glob('strip-*.json'))
for path in files:
    data=json.loads(path.read_text())
    if data.get('hypothetical') or data.get('grid')!=3200:continue
    if not {'left','right','rows'}<=data.keys():continue
    if Fraction(data['left'])!=150 or Fraction(data['right'])!=Fraction(4801,32):continue
    source=new if data.get('paley_four') else old
    for i,p,s in data['rows']:
        if not 95*16<=i<100*16:continue
        for mode,row in enumerate((p,s)):
            for col,v in enumerate(row):
                point=(i,mode,col)
                if point not in source or v<source[point]:source[point]=v
for j in range(95,100):
    desc=[]
    for mode in (0,1):
        gains=[(old[k]-new[k],k) for k in old.keys()&new.keys() if j*16<=k[0]<(j+1)*16 and k[1]==mode]
        pos=sorted((g,k) for g,k in gains if g>0)
        desc.append((len(pos),len(gains),pos[-1] if pos else None))
    print(j,'improved/compared and largest integer rate gain (row,spectrum,column)',*desc)
