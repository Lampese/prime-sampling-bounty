# 内部六谱的四面体四次项

固定 \(p\equiv1\bmod 6\)、本题窗内的非零原位移、全部权和标签。令 \(\rho\) 为六次本原角色，\(\eta=\rho^3\)，\(\theta=\rho^2\)。考虑四个互异物理位移，四槽（已将两个负槽的角色取逆）的六次指数为 \((1,1,1,3)\) 或 \((5,5,5,3)\) 的任一排列。这两个族和 paley-four.md 的 \((\rho',\rho',\eta\bar\rho',\eta\bar\rho')\) 族不交。

## 三根和对应的秩二层

四槽角色积为主。给原仿射和 \(S\) 补上 \(\infty\) 处的首项 1，得到 \(S_{\rm pr}=S+1\)。将二次字符所在的根 Möbius 变换至 \(\infty\)，其余三根送到 \(0,1,\lambda\)。每个线性因子的公共分母所带的角色之积平凡，余下只有单位常数和真正的对应零点。因此 \(|S_{\rm pr}|\) 是

\[
 |H(\lambda)|,\qquad H(\lambda)=\sum_x \rho(x(x-1)(x-\lambda)),
\]

或它的共轭；\(\lambda\notin\{0,1\}\)。对任一乘法字符 \(\psi\) 作 Mellin 变换。按 \(\lambda=xu\) 先求 \(\lambda\) 和，再求 \(x\) 和，得到

\[
\sum_{\lambda\ne0}\psi(\lambda)H(\lambda)
=\rho(-1)J(\psi,\rho)J(\psi\rho^2,\rho).
\]

当 \(\rho\ne1\) 时，\(J(\alpha,\rho)=G(\alpha)G(\rho)\overline{G(\alpha\rho)}/p\) 也包括 \(\alpha=1\) 和 \(\alpha\rho=1\) 的特殊点（主字符一律在零处延拓为零）。故这是 Katz 的平衡型 \((2,2)\) 超几何 Mellin 乘积，上列 \(\{1,\rho^2\}\)，下列 \(\{\rho,\rho^3\}\)。更换 Mellin 符号可交换两列或取逆，不改变下文的射影惯性。上述识别也可对每个有限扩域取范数提升的角色逐一进行，常数 Gauss 因子只给算术标量扭转；Hasse–Davenport 的两份因子符号相抵。[Katz，Exponential Sums and Differential Equations，§8.2–8.4](https://web.math.princeton.edu/~nmk/wholebookcorrms.pdf) · [Katz 对平衡超几何和及局部单值的复述，§3](https://web.math.princeton.edu/~nmk/dworkfam64.pdf)

上下列互不相交，故层几何不可约，秩二，在 \(\mathbb P^1-\{0,1,\infty\}\) 光滑、处处温和。\(0,\infty\) 的特征比均为 \(\rho^{\pm2}\)，阶三；局部特征不同，因此半单。在 \(1\) 处为伪反射，非平凡特征是两列总积之比或其逆，亦为 \(\rho^{\pm2}\)。所以三个惯性生成元的射影像都恰为三阶。此 family 的 \(H(\lambda)\) 是纯权一的秩二迹（整体正负号无关）：在 \(x\)-球面的四个奇点，Kummer 特征 \(\rho,\rho,\rho,\eta\) 均非平凡，紧支一次上同调即中延拓的一次上同调，维数二。每个点的两个 Frobenius 特征值模均为 \(\sqrt p\)。[Deligne，Weil II](https://www.numdam.org/item/PMIHES_1980__52__137_0/)

## 几何与算术射影群

温和几何基本群有三个拓扑生成元 \(x,y,z\)，各生成对应惯性且 \(xyz=1\)。故射影像由 \(X,Y\) 生成，\(X,Y,XY\) 各三阶。论证在特征零的 \(\overline{\mathbb Q}_\ell\) 系数域进行。选 \(X,Y\) 的 \(\mathrm{SL}_2\) 提升 \(A,B\) 使 \({\rm tr}A={\rm tr}B=1\)。此时 \({\rm tr}(AB)\in\{1,-1\}\)。若为 \(-1\)，二矩阵可同时上三角化：对角化 \(A={\rm diag}(\xi,\xi^{-1})\)，\(\xi+\xi^{-1}=1\)，由 \({\rm tr}B=1,\ {\rm tr}(AB)=-1=\xi^2+\xi^{-2}\) 得 \(B\) 的两个对角元分别为 \(\xi,\xi^{-1}\)，故非对角元乘积为零。这和不可约矛盾。因此 \({\rm tr}(AB)=1\)。一般地，给定三个迹即唯一确定这样的不可约矩阵对至同时共轭：前两条线性关系已确定 \(B\) 的对角，行列式确定其非零的两个非对角元的乘积，再用对角共轭调其一。[SGA 1，Exposé XIII，Corollaire 2.12](https://arxiv.org/abs/math/0206203)

标准四面体旋转群 \(A_4\subset{\rm SO}_3(\mathbb C)\cong{\rm PGL}_2(\mathbb C)\) 中，\((123),(134)\) 生成整群且其乘积三阶；它们没有共同不动线（有限上三角群在射影线上若固定一点必为循环群）。给相应二元四面体 \({\rm SL}_2\) 提升同样选择迹为1，由上面的不可约性判定，乘积迹也是1。因此上述秩二层的几何射影群恰为 \(A_4\)。此比较可取代任何解析 Schwarz 名单。

算术射影群正规化该 \(A_4\)，且此正规化子嵌入 \(\operatorname{Aut}(A_4)=S_4\)。确切地，\(A_4\) 的射影中心化子平凡：Klein 四群的三个非主对合可共轭成 \(z\mapsto-z,1/z,-1/z\)，其同时中心化子仍是 Klein 四群；三阶旋转又无不动地循环置换这三个对合。在这个注入下几何群是 \(S_4\) 中标准的 \(A_4\)。如果一次 Frobenius 在外陪集，则所有有理点的 Frobenius 都在该陪集，其阶为二或四。两个特征值模相等，射影阶二、四分别给 \(|H|^2=0,2p\)，所以相对原物理通项每个互异配置可节省至少 \(2p\)。

若 Frobenius 在内，则算术射影群等于 \(A_4\)。商 \(A_4/V_4=C_3\) 给秩一三次几何 Kummer 层，在三个奇点的每个局部指数非零，因此三个指数必须全为1或全为2。它与 \(\theta(\lambda(1-\lambda))^{\pm1}\) 仅差算术三次常数 \(\gamma\)。此处可直接用 Kummer 理论：去掉规定的三个分歧后剩下的在几何射影直线上处处未分歧，故几何平凡。取任一所需的根排列时，\(\theta(\lambda(1-\lambda))\) 等于

\[
\theta(\Delta),\qquad \Delta=\prod_{i<j}(z_i-z_j).
\]

交叉比代入恒等式，两者的比是符号乘一个立方；符号是立方。因而根排列也不会改变这个三次性状。商 Frobenius 非平凡时，原 \(A_4\) 元必为三循环，射影阶三给 \(|H|^2=p\)。原仿射的 \(|S|\le |H|+1\)；原净主通项按 \((2\sqrt p+1)^2-(p-4)\) 或其稍宽界计。故这里每个此类互异配置可节省至少 \(3p\)。

## 在短物理位移内平均三次性状

对真实概率 \(w\) 的四次独立采样，有重复的概率 \(P_0\le6\omega\)，\(\omega\ge\max w\)。用 \(M^\theta_{ab}=\sqrt{w_aw_b}\theta(a-b)\)。固定另两点 \(c,d\)，Vandermonde 的六个因素中，只有 \(a-b\) 同时含 \(a,b\)；其余因子分别乘在两个单位有界向量上。因此 \(|\mathbb E\,\theta(\Delta)|\le\|M^\theta\|_{\rm op}\)。在内陪集情形，对互异的样本按 \(1_{\gamma\theta(\Delta)^{\pm1}\ne1}=(2-2\Re(\gamma\theta(\Delta)^{\pm1}))/3\) 求和，概率至少 \((2/3)(1-P_0-\|M^\theta\|_{\rm op})\)。外陪集降价 \(2p(1-P_0)\) 更强。两种算术情形都可合计减去 \(2p(1-6\omega-\|M^\theta\|_{\rm op})_+\)。

paley-four.md 的 Toeplitz 块范数与进程完全相同。对三次角色，混合 Burgess 的退化完全和必须在每个短位移上正负重数的差为 \(0\bmod3\)。若有 \(r\) 个不同位移，每个出现两次，故原 \((2r-1)!!V^r\) 上界仍覆盖。其余退化元组至多有 \(r-1\) 个不同位置，用 \((2r)^{2r}V^{r-1}\) 补入。这对应 mixed_burgess(...,cubic=True) 的显式修正。无需对原始非零移位、素数或标签取平均。

内部角色在四个实际槽的分布相同，二次权为 \(t\)，每个三次或六次非二次角色的权为 \(d=(1-t)/4\)。两族各有四个位置给二次字符，且每次的标签正交和为3，因此扣减的角色权为 \(24td^3\)。以上概率、通项及下界均在项目原来的第四物理矩之前独立估成。--tetra-four 是独立开关，已包含旧对合时两个不交配置可分别扣减。tetrahedral_check.py 在十个 \(p\equiv1\bmod6\) 的有限域独立枚举各小样本位移的射影和，并按 \(\theta(\Delta)\) 记录输出 tetrahedral-check.txt。
