"""Direct fixed-shift completion after pairing two same-label Kummer transforms."""
from fractions import Fraction as F
from math import isqrt


def paired(s,k,span,pm,p,M):
    from scale import _trials,root
    R=(span+1)//2+1
    rt=isqrt(p)+1
    candidates=[c for c in _trials(R,s,rt) if R<c and 2*c<pm]
    if not candidates:return F(1)
    def score(c,approx):
        def number(x):return float(x) if approx else F(x)
        sqrt=(lambda x:x**.5) if approx else root
        cap=number(2*c*c+1)/(3*c)
        mult=1+number(2*rt)/pm
        v=number(M)/(s*s)
        priced=cap*cap*mult/pm
        e3=sqrt(sqrt(v*(60*rt+20+3*priced)))
        ec=sqrt(sqrt(v*(170*rt+70+4*priced)))
        # The pair and each member have the same Fourier completion phase.
        factor=min(2,sqrt((1+e3+ec)/2))
        value=number(c)/(c-R)*(number(c)/s+rt*factor)/k
        return sqrt(value)
    return min([F(1)]+[score(c,False) for c in sorted(candidates,key=lambda c:score(c,True))[:4]])


def rates(mode,s,k,span,pm,p,M,degree=7):
    from adjoint_local import completion
    two=paired(s,k,span,pm,p,M)
    old=completion(s,k,span,pm,p,M,degree,nonquadratic=True)
    q=completion(s,k,span,pm,p,M,degree)
    g=min(two,old)
    return g, ((2*g+q)/3 if mode=='six' else q)
