"""Test CRT signs, integer cube formula, and an actual same-orbit cancellation sum."""
from cmath import exp,pi
from fractions import Fraction as F
from itertools import product
from math import gcd,prod
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"operator-new"))
from carrier_cancellation import centre_count,sign_mass,reduced
from frequency_envelope import powers


for W in (3,6):
    for k in (4,6):
        gamma=[prod(F(-1,q-1) if j%q else F(1) for q in (2,3) if W%q==0) for j in range(W)]
        freq=0
        for first in product(range(W),repeat=k-1):
            j=(*first,(sum(first[:k//2])-sum(first[k//2:]))%W)
            if sum(x%3!=0 for x in j)%2:
                one=prod(gamma[x] for x in j)
                other=prod(gamma[3*x%W] for x in j)
                assert one*other<0 and abs(other)>=8*abs(one)
                freq+=abs(one)
        assert freq==sign_mass(W,k)
for H in (1,2,3):
    for k in (4,6):
        hist={}
        for q in product(range(-H,H+1),repeat=k):hist[sum(q)]=hist.get(sum(q),0)+1
        for c in range(k//2+1):assert hist[c]==centre_count(H,k,c)

p,W,m=2017,3,8
gamma=[1.,-.5,-.5]
es=[exp(2j*pi*i/p) for i in range(p)]
w=[F(W,2)*F(max(0,W*m-abs(x)),(W*m)**2) if gcd(x,W)==1 else F(0) for x in range(-W*m,W*m+1)]
hat=[sum(float(y)*es[(x*h)%p] for x,y in zip(range(-W*m,W*m+1),w)).real for h in range(p)]
inv=pow(W,-1,p)
# Sum over just one of the nested cubes, using direct signed frequency products.
H=7
X=range(-H*W,(H+1)*W)
actual=0.
for x,y,z in product(X,repeat=3):
    a=x+y-z
    if a not in X:continue
    hs=[v*inv%p for v in (x,y,z,a)]
    value=prod(hat[h] for h in hs)
    tripled=prod(hat[3*h%p] for h in hs)
    if value*tripled<0:actual+=min(abs(value),abs(tripled))
# The proven full-domain reduction must fit inside direct absolute cancellation
# on the union of all carrier boxes used to derive it.
from carrier_cancellation import reduced as reduction
upper=powers({m:F(1)},W)[2]
refined=reduction({m:F(1)},W,p,p)[2]
# At this finite p the final rational annuli also include larger cubes than H.
# Restrict resolution by setting a smaller pm while retaining the same true p.
smallp=630
sub=upper-reduction({m:F(1)},W,smallp,p)[2]
assert F(21,64)*smallp/(m*W)<H+2 and float(sub)*p**3<=2*actual+1e-6
assert refined<upper
print("CRT signs and cube counts passed; twice the direct partial span cancellation",round(2*actual,3),
      "certified on a contained box",round(float(sub)*p**3,3),"full normalized gain",float(1-refined/upper))
