# 同标签二次扭转对的直接 Gram 完成

记 $H_\rho(x)=p^{-1/2}\sum_v \rho((v-1)/(v+1))e_p(xv)$，奇点处取零。它是真实值，因取共轭后作 $v\mapsto-v$ 恢复原和，且 $H_\rho(0)=-p^{-1/2}$。取同一个标签的两个非主角色 $\alpha,\beta=\alpha\eta$，假设它们均非二次，且 $\alpha\ne\beta^{\pm1}$。pair 外部代表的阶为奇平方自由数且大于一，故 $\alpha^2\ne\eta$。six 外部用 $\alpha=\chi\theta^j$，仍为非平凡奇数阶。six 内部仅将 $\theta^j,\eta\theta^j$ 配对，$j=1,2$，且对单个二次角色 $\eta$ 用原来的单项估计。pair 内部也沿用单项。

固定每个实际素数 $p>5$、非零 $t$ 及任意原题权和标签。两个角色有相等的组内权，先对它们的方向绝对均值作 Cauchy，再用支撑于整数中心附近的完成三角 $T(b)=(1-|b-b_0|/C)_+$，$2C<p$。同一方向上的 $z_a\zeta^{jk_a}$ 与其共轭的乘积是组内共同因子。对 $d=1/a'-1/a\ne0$ 作居中线性换元，完成 Fourier 取值为 $e_p(\pm h(t/a+t/a')/2)H_\rho(\pm htd/2)$，其中符号及加上中心后所生的相位都与角色无关。因此两个角色在丢掉复相位之前合并为

\[
Z(x)=(H_\alpha(x)+H_\beta(x))/2.
\]

所需的是 $Z$ 的绝对均值。组与组之间允许分别取 Cauchy 后相加。令 $S\ge s$ 为输入素数数目，$k$ 为采样数下界，$R$ 为覆盖采样范围至中心的最大距离上界。令 $m_d$ 为非零倒数差的有序纤维重数，$\max m_d\le M,\sum m_d=S(S-1)$。固定非零伸缩只排列 $d$，故以下界与 $t$ 无关。完成三角的 Fourier 概率 $w_h=|\sum_{0\le j<C} e_p(hj)|^2/(p C)$，有 $\sum_h w_h=1,\sum w_h^2=\sigma=(2C^2+1)/(3pC)$。

## 交叉项的伸缩四次矩

设 $Y(x)=H_\alpha(x)H_\beta(x)$。由上游已经证明的射影等价分类，$(\rho,h)$ 只与自身及 $(\rho^{-1},-h)$ 等价。不同等价类的几何导出因子为独立的 $\mathrm{SL}_2$。本对中的两个角色均非二次且互非逆，所以在实际用到的族 $(\alpha,h),(\beta,h)$ 中，不同非零 $h$ 和不同角色全都落入不同射影类。这条论证特意不把 $h,-h$ 合并。它适用于六谱内部两组分别取绝对值，不能把两组的四个角色同时视为互异射影类。[上游题面第四矩来源](https://github.com/Lampese/prime-sampling-bounty/blob/63a2d41e8124320784c244336ff36ac5f2285418/PROBLEM.md) · [Fouvry–Kowalski–Michel，Proposition 3.9](https://people.math.ethz.ch/~kowalski/sums-of-products.pdf)

考察 $\prod_{i=1}^4Y(h_i x)$ 对应的八重标准表示。秩 $256$，零处温和，各因子是非平凡单幂 Jordan 块；整体零处不变量数是同一对角标准幺幂在八重张量的固定维数 $\binom84=70$。这来自偶次张量的每个不可约对称幂都各有一条幺幂固定线及一条零权线。在无穷远，每个同位的二因子 $H_\alpha(h_i\cdot)H_\beta(h_i\cdot)$ 有野相位系数 $2h_i,0,0,-2h_i$。逐组选零给 $2^4$ 个 break 零的权（温和特征不要求平凡），故总 Swan 至多 $256-16=240$。令 $e$ 为几何常值维数。剥去常值后，紧支一次上同调维数至多 240；单算零处可分离至少 $70-e$ 条权至多零的边界线。因而总和绝对值至多

\[
(240-70)\sqrt p+70+e(p+\sqrt p-2)
\le 170\sqrt p+70+e(p+2\sqrt p).
\]

若某个 $h_i$ 单现，中心元素 $-I$ 作用在它自己的因子上，故 $e=0$。若频率形成两个不同对，两个角色各自在两对出现两次，故 $e=1$。若四频相同，标准表示四次张量对每个角色各有两个不变量，故 $e=4$。未归一频率权对所有几何不变量的和不超过 $4\sigma^2$。事实上三个配对总权 $3\sigma^2$ 已覆盖两个不同对的全部可能；四同频被覆盖三次，只需再加 $\sum_{h\ne0}w_h^4\le\sigma^2$。由零频以外的四次矩和 Hölder，

\[
\left|S^{-2}\sum_d m_d\sum_{h\ne0} w_hY(htd/2)\right|
\le e_c:=\left[{M\over S^2}\{170\sqrt p+70+4(p+2\sqrt p)\sigma^2\}\right]^{1/4}.
\]

同样的真实非二次单层伴随估计给 $H_\rho^2-1$ 的误差 $e_3=[M/S^2\{60\sqrt p+20+3(p+2\sqrt p)\sigma^2\}]^{1/4}$。常数与 adjoint_local.py 一致。秩 $3^4=81$，野相位均取零给 Swan 至多 80，零处惯性维数 19，无穷至少一条完全平凡的权，故通用项 $60\sqrt p+20$；不变量配对按三条配对估，正负号射影等价由非二次假设排除。

## 最终价格

在 $h\ne0$ 上使用 $4Z^2=(H_\alpha^2-1)+(H_\beta^2-1)+2Y+2$。零频处 $Z(0)^2=1/p\le1/2$，因而常数 $1/2$ 可直接计在全部频率及倒数差总质量上。再用一次加权 Cauchy，

\[
S^{-2}\sum_d m_d\sum_h w_h |Z(htd/2)|\le f=\min\{2,\sqrt{(1+e_3+e_c)/2}\}.
\]

加回行对角 $C/S$ 后，二角色组的方向率至多

\[
\sqrt{\frac{C}{k(C-R)}\left(\frac{C}{S}+\sqrt p f\right)} .
\]

paired_completion.py 中用 $S\ge s$、上下端 $p_0,p_1$、$r=1+\lfloor\sqrt{p_1}\rfloor$，将 $(p+2\sqrt p)\sigma^2$ 换成 $((2C^2+1)/(3C))^2(1+2r/p_0)/p_0$。浮点仅提供四个整数尺度候选；各候选的外取整及开方在上游工具内按有理数核验。外部六谱三对取同界，内部六谱的最终上界为该对界的 $2/3$ 加原二次界的 $1/3$。pair 外部使用同一对界，内部保持二次界。

运行 `python -B work/gram-cycle/paired_probe.py`，首窗外接矩形同方向逐行向上取整的实价见 paired-six.txt。
