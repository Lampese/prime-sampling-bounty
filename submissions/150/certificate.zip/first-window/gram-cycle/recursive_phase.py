"""Apply exterior constant and phase savings to terminal panels of the Abel recursion."""
from argparse import ArgumentParser
from functools import cache
from pathlib import Path
import runpy
import sys

from corner_phase import extra_saving


def leaf_factory(m,banks,branches,I,J,mass,box,bounds,axis_factors,parts,two_sections=False):
    @cache
    def lower(a,b,c,d):
        if c>=d:
            return 0
        val=2*m.Xlo(a+c-1)*max(0,axis_factors(a,b)[0])*max(0,axis_factors(c,d)[0])/m.zh
        return (J*val).__floor__()

    @cache
    def price(u,v,w,z):
        nodes=[u+(v-u)*j/parts for j in range(parts+1)]
        outside=largest=0
        section={}
        for j,left in enumerate(nodes[:-1]):
            for k in range(j+1,len(nodes)):
                right=nodes[k]
                lo,hi=bounds(left,right,False)
                a=lower(left,right,w,min(z,lo))
                b=lower(left,right,max(w,hi),z)
                section[j,k]=a+b
                if k==j+1:
                    outside+=a+b
                largest=max(largest,a,b)
        if two_sections and parts>1:
            largest=max(largest,max(section[0,j]+section[j,parts] for j in range(1,parts)))
        M=mass(u,v,w,z)*J
        full=M.__ceil__()
        g,q0=box(u,v,w,z)
        result=[]
        for br in branches:
            rows,scale=banks[br]
            fees=[]
            for f,n,q in (*rows,(0,0,0)):
                mu=(I-f)*I
                mu_lo=mu-I if f or n or q else mu
                floor=max(0,mu_lo-(n+q)*I)
                spec=n*g+q*q0
                gain=floor*outside+extra_saving((mu_lo-floor)*largest,spec*full)
                slope=scale*(mu+spec)-J*I**2
                assert slope>=0
                fees.append(((slope*M-scale*gain)/(J*I**2)).__ceil__())
            result.append(min(fees))
        return tuple(result)
    return price


if __name__=='__main__':
    folder=Path(__file__).resolve().parent
    work=folder.parent
    ap=ArgumentParser(add_help=False)
    ap.add_argument('--phase-slabs',type=int,default=4)
    ap.add_argument('--two-sections',action='store_true')
    ap.add_argument('--signed-top',type=int,default=0)
    opt,rest=ap.parse_known_args()
    assert 1<=opt.phase_slabs<=16
    assert 0<=opt.signed_top<=5
    original=runpy.run_path
    canonical=(work/'hyperbola-next/rectangles.py').resolve()

    def run(path,*args,**kwargs):
        if Path(path).resolve()!=canonical:
            return original(path,*args,**kwargs)
        source=canonical.read_text(encoding='utf8')
        anchor='    def pieces(u,v,interval,parent):'
        assert source.count(anchor)==1
        source=source.replace(anchor,'    phase_leaf=leaf_factory(m,banks,branches,I,J,mass,box,bounds,axis_factors,phase_slabs,two_sections)\n\n'+anchor)
        if opt.signed_top:
            extra='''
    from sign_panel import top_factory
    signed_top=top_factory(m,banks,branches,I,J,mass,box,axis_factors,sign_depth)
    @cache
    def partial_top(u,v,w,z):
        cut=max(v,1-u-B)
        acc=[]
        if w<min(z,cut):acc.append(partial(u,v,w,min(z,cut)))
        if max(w,cut)<z:
            lo=max(w,cut)
            acc.append(price(u,v,lo,z) if v+z<=1 else signed_top(u,v,lo,z))
        return tuple(map(sum,zip(*acc))) if acc else zero
'''
            source=source.replace(anchor,extra+'\n'+anchor)
        anchor='        value=[s+boundary(u,v) for s in pieces(u,v,outer,parent)]'
        assert source.count(anchor)==1
        source=source.replace(anchor,anchor+'''
        segments=subtract(outer,parent)
        if segments:
            new=map(sum,zip(*(phase_leaf(u,v,l,r) for l,r in segments)))
            value=[min(old,s+boundary(u,v)) for old,s in zip(value,new)]
''')
        if opt.signed_top:
            mark='            value=[min(old,s+boundary(u,v)) for old,s in zip(value,new)]'
            assert source.count(mark)==1
            source=source.replace(mark,mark+'\n            signed=map(sum,zip(*(partial_top(u,v,l,r) for l,r in segments)))\n            value=list(map(min,value,signed))')
        frozen='            return pieces(u,v,bounds(u,v,False),parent)[branch]+boundary(u,v)'
        if frozen in source:
            start=source.index(anchor)
            stop=source.index('        if capture:',start)
            terminal=source[start:stop]
            source=source[:start]+'        value=list(phase_terminal(u,v,outer,parent))\n'+source[stop:]
            entry='    @cache\n    def evaluate(u,v,parent,depth):'
            assert source.count(entry)==1 and source.count(frozen)==1
            source=source.replace(entry,'    @cache\n    def phase_terminal(u,v,outer,parent):\n'+terminal
                                  +'        return tuple(value)\n\n'+entry)
            source=source.replace(frozen,'            return phase_terminal(u,v,bounds(u,v,False),parent)[branch]')
        env={'__name__':'__main__','__file__':str(canonical),'leaf_factory':leaf_factory,'phase_slabs':opt.phase_slabs,'two_sections':opt.two_sections,'sign_depth':opt.signed_top}
        exec(compile(source,str(canonical),'exec'),env)
        return env
    runpy.run_path=run
    sys.argv=['envelope_macro.py',*rest]
    run(work/'operator-new/envelope_macro.py',run_name='__main__')
