"""Enumerate the four-point involution, weighted C4, and frequency maximal inequality."""
from cmath import exp,pi
from itertools import combinations,product
from collections import Counter
from math import sqrt
from fractions import Fraction as F
from paley_four import weight


def check(p):
    for g in range(2,p):
        log={pow(g,i,p):i for i in range(p-1)}
        if len(log)==p-1:break
    roots=[exp(2j*pi*i/(p-1)) for i in range(p-1)]
    def ch(k,x):return roots[k*log[x%p]%(p-1)] if x%p else 0
    def eta(x):return (1 if log[x%p]%2==0 else -1) if x%p else 0
    points=list(range(min(p,8)))
    good=0
    for a,b in combinations(points,2):
        for c,d in combinations([v for v in points if v not in (a,b)],2):
            if eta((a-c)*(b-c)*(a-d)*(b-d))!=-1:continue
            for k in range(1,p-1):
                l=(k+(p-1)//2)%(p-1)
                if not l:continue
                v=sum(ch(k,(x-a)*(x-b))*ch(-l,(x-c)*(x-d)) for x in range(p))
                assert abs(v+1)<1e-9
                good+=1
    pts=(0,2,3,5,6)
    w={x:F(i+1,15) for i,x in enumerate(pts)}
    weighted=F(0);neg=F(0);zero=F(0)
    for a,b,c,d in product(pts,repeat=4):
        val=eta((a-c)*(a-d)*(b-c)*(b-d));mass=w[a]*w[b]*w[c]*w[d]
        weighted+=val*mass;neg+=(val<0)*mass;zero+=(val==0)*mass
    alt=sum(w[a]*w[b]*sum(w[c]*eta(a-c)*eta(b-c) for c in pts)**2 for a in pts for b in pts)
    assert weighted==alt and neg==(1-zero-weighted)/2
    return good


print('checked nonsplit projective sums and weighted Paley fourth identities',
      [(p,check(p)) for p in (11,13,17,19,31)])

for t in (F(1,3),F(2,5),F(1,2)):
    rows=[(i,t if i==3 else (1-t)/4) for i in (1,2,3,4,5)]
    result=0
    for ((a,wa),(b,wb),(c,wc),(d,wd)) in product(rows,repeat=4):
        active=(a,b,(-c)%6,(-d)%6)
        distinct=set(active)
        if len(distinct)!=2:continue
        l,r=sorted(distinct)
        if active.count(l)==2 and (l+r)%6==3:
            assert sum(active)%6==0
            result+=3*wa*wb*wc*wd
    assert result==weight('six',True,t)
print('exact six-internal tuple weights verified for three tilts')

# This checks the progressions even at nonzero residue, independently of the
# explicit large-U prime count used to obtain a useful hybrid estimate.
for p,W,N,U,denoms in ((1009,2,12,7,(5,7)),(3001,6,22,13,(7,11,13))):
    for j in range(1-W,W):
        nu=Counter((W*n+j)*pow(W*u,-1,p)%p for n in range(1,N+1) for u in denoms)
        A=len(denoms)
        collision=sum(v*v for v in nu.values())
        bound=F(1,A*N)+(1+F(2*(N+1),U))/(N*N)
        assert F(collision,(A*N)**2)<=bound
print('rational Burgess collision bound checked across 14 signed residues')
