# 在现有 Abel 递归的末面板扣除外溢通过质量

适用范围与现有 Abel 矩形递归相同。固定实际 \(p,X,t\)、模数分支、谱类别和一个允许的正上多项式 \(P\ge F\ge0\)。记 \(\mu\) 为常数系数，\(\delta\) 为所考察真实矩形 \(Q\) 上的单位双端复权频费，\(s\ge1/g_0\) 为同一分支刻度。一个末面板还需保留的目标为 \(H_Q=H\cap Q\)。此处使用 \(M_0=X/(2\log X)\) 归一，以下竖线表示归一化点数。

可由该行得到 \(0\le L\le P(a,b)\) 的逐点下界。对 pair 或 six，若整数行是 \((f,n,q)\)，单位为 \(I=10^{10}\)，则
\[
 \mu^+=(I-f)/I,\quad \mu^-=(I-f-1)/I,\quad
 L=\max(0,\mu^--(n+q)/I).
\]
这直接来自非主部分的 Fourier 系数绝对值总和至多 \((n+q)/I\)。对另加的常多项式 \(P=1\) 用确切的 \(\mu^+=\mu^-=L=1\)。谱费为 \(\delta=(n g+q q_0)/I^2\)，其中 \(g,q_0\) 是原矩形的向上取整谱率。选中不同矩形的不同多项式只发生在这些实际互不相交的末面板之间。

把横轴等分成四段 \(A_j=(l_j,r_j]\)。对于任一段与任意实际 \(X\)，真正条带均位于
\[
 \bigl(\max(l_j,1-r_j-C),1-l_j\bigr],\qquad C\ge\log_X32 .
\]
故与其补集相交的上下两块均在 \(Q\setminus H_Q\)。逐段取真实素数 θ 质量下界后相加，得到 \(e_-\le|Q\setminus H_Q|\)。再枚举四段中的任意一组相邻横段，在它们的上下两个外块中独立挑一个，其质量的最大下界为 \(m_-\)。启用 --two-sections 时，同一横轴的一个分点将其分成两组，每组均可同时取上下外块，形成两种列截面，其总质量仍是可用的 \(m_-\)。

设 \(S\subset Q\setminus H_Q\) 是实现相应下界的掩码集合。corner-phase.md 给出 \(M=1-\lambda{\bf1}_S\) 的复相位表示。正性给
\[
 \int_{Q\setminus H_Q} M P\ge L(|Q\setminus H_Q|-\lambda|S|).
\]
减掉这一项并代入对 \(\int_Q MP\) 的刻画可得
\[
 \int_{H_Q} F
 \le (\mu^++\delta)|Q|-L e_-
 -\max_{\lambda\in\{0,1/8,\ldots,1\}}
 \big\{\lambda(\mu^- -L)m_--(c_\lambda-1)\delta |Q|^+\big\}.
\]
收入与费用相减前均取指定方向的整数界。这里选出的宽外块可以穿过先前的细分片，因为逐点的 \(L\) 同时适用于整个外溢集合。

由 \(T(H_Q)=\int_{H_Q}F/g_0-|H_Q|\)，可把右端的全矩形主系数写为 \(s(\mu^++\delta)-1\ge0\)，另加 \(|Q\setminus H_Q|\)。生成器将后者保留在原来的 boundary(u,v) 上界中，其他部分替换原来的末面板全矩形费用。每个节点的各个纵向剩余段互不相交，每个已选祖先内核均已从它们扣除；原树的分裂和取小仍然有效。加入新候选前也保留原节点价格。

首窗六谱复算命令如下，程序同时逐宏写入 JSON。

    python -B work/gram-cycle/recursive_phase.py --phase-slabs 4 --angular --local-conductor --reweight --paley-four --tetra-four --mode six --bins 96 --macros 95 96 97 98 --out work/gram-cycle/phase-recursive-six.json

work/gram-cycle/corner_phase.py 给出范数的整数上整，recursive_phase.py 调用原 operator-new/envelope_macro.py。未带 --signed-top 时不加载 sign_panel.py。指定 --left L --right R 可在该实际参数窗重算所有质量和谱率。
