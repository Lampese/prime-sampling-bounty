"""Measure the normalized projective squared trace for the (1,1,1,3) sextic cover."""
from itertools import combinations,product
from fractions import Fraction as F
from math import prod
for p in (7,13,19,31,37,43,61,73,97,127):
    for b in range(2,p):
        logs={pow(b,i,p):i for i in range(p-1)}
        if len(logs)==p-1:break
    R=((1,0),(0,1),(-1,1),(-1,0),(0,-1),(1,-1))
    pool={}
    for z in combinations(range(min(p,11)),4):
        args=prod(y-x for x,y in combinations(z,2))%p
        c=logs[args]%3
        for special in range(4):
            a,b=1,0
            for x in range(p):
                if x in z:continue
                n=sum(logs[(x-v)%p]*(3 if j==special else 1) for j,v in enumerate(z))
                u,v=R[n%6]
                a+=u
                b+=v
            # Norm in Z[e^(pi*i/3)], computed only with integers.
            val=a*a+a*b+b*b
            assert val in (0,p,2*p,4*p),(p,z,special,val)
            pool.setdefault(c,set()).add(val//p)
    assert sum(values!={1} for values in pool.values())<=1,(p,pool)
    print(p,pool)

for t in (F(1,3),F(2,5),F(1,2)):
    law={i:t if i==3 else (1-t)/4 for i in range(1,6)}
    prob=0
    for a,b,c,d in product(law,repeat=4):
        signed=sorted((a,b,-c%6,-d%6))
        if signed in ([1,1,1,3],[3,5,5,5]):
            prob+=3*law[a]*law[b]*law[c]*law[d]
    assert prob==24*t*((1-t)/4)**3
print('all 625 signed assignments verified at three tilts')
