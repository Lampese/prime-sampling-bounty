# 复相位外角权

设 \(O=A\times B\) 是一个可计价素数矩形，\(H\subset O\) 是本条带实际使用的素数对，\(S=A'\times B'\subset O\setminus H\)。积分记号使用原始素数对上的正测度。取固定的实筛多项式 \(P\ge{\bf1}_{\rm pass}\ge0\)，均值为 \(\mu\)。已有全权谱价给出

\[
 \left|\int_O u(a)v(b)(P-\mu)\right|\le\delta |O|
 \quad\text{对所有}\quad |u(a)|,|v(b)|\le1 .
\]

这里双端任意复权的量词不可删去。若一个分组上界允许每个角色分别选权，给每个角色同乘下文的相位后仍属于原测试类。若要求同一组共用两端的权，同乘同一对相位仍满足此约束。

给定 \(0\le\lambda\le1\)，取 \(4\sin^2\theta=\lambda,\;0\le\theta\le\pi/6\)。把 \(A\setminus A',A'\) 上的相位依次设为 \(1,e^{2i\theta}\)，把 \(B\setminus B',B'\) 上的相位依次设为 \(e^{-i\theta},e^{i\theta}\)。三个格的乘积实部均为 \(\cos\theta\)，第四格为 \(\cos3\theta=(1-\lambda)\cos\theta\)。因此

\[
 M=1-\lambda{\bf1}_S
   =\frac{uv+\bar u\bar v}{2\cos\theta},\qquad
 \left|\int_O M(P-\mu)\right|
 \le c_\lambda\delta|O|,\quad c_\lambda=(1-\lambda/4)^{-1/2}.
\]

设外侧切出的互不相交的矩形为 \(S_i\)，下界为 \(|S_i|\ge m_i\)、\(\int_{S_i}P\ge B_i=m_i L_i\)，其中 \(0\le L_i\le\mu^-\le\mu\)。选其中一个 \(S_j\) 作相位角。因为 \(M=1\) 于 \(H\) 而 \(MP\ge0\) 于 \(O\)，

\[
 \int_H {\bf1}_{\rm pass}\le(\mu+c_\lambda\delta)|O|
 -\sum_i B_i-\lambda(\mu^-m_j-B_j).
\]

故在原有外侧扣减之上，若 \(|O|\le O^+\)，还可统一扣去

\[
 \max_{j,\,\lambda\in\{0,1/8,\ldots,1\}}
 \left\{ \lambda(\mu^-m_j-B_j)-(c_\lambda-1)\delta O^+ \right\}.
\]

整数模块 corner_phase.py 以 \(10^8\) 为分母对 \(c_\lambda\) 向上取整，以整数平方检验取整方向。以收入下取整、支出上取整结合现有共同未知质量的线性约束。micro_credit.py 对固定互不相交的原生小格集合选一个角。pass_credit.py 的可选整条宏边在递归中分别记录 \(P\) 的原扣减和「至多一个相位角」扣减，每个结点只合并相互不交的子域。结果按整条边进入路径优化。

上述论证可在任意窗重复，只需按新窗重算矩形质量和谱价。

在只允许单位双端因子的表示中，上述 \(c_\lambda\) 已是单角的最佳常数。任何一项 \(u(a)v(b)\) 的 Schur 逐项乘法是左右乘以对角收缩，故其加权绝对和至少为该掩码的 Schur 乘子范数。取范数一的实正交矩阵
\[
 A=\begin{pmatrix}x&\sqrt{1-x^2}\\\sqrt{1-x^2}&-x\end{pmatrix},\qquad x=1/\sqrt{4-\lambda}.
\]
掩码 \(\left(\begin{smallmatrix}1&1\\1&1-\lambda\end{smallmatrix}\right)\) 与 \(A\) 逐项相乘后，较大特征值为
\(\lambda x/2+\sqrt{1-(\lambda-\lambda^2/4)x^2}=(1-\lambda/4)^{-1/2}\)。
这一下界与显式相位表示一致。在 \(\lambda=1\) 时得到三格布尔掩码的已知 \(2/\sqrt3\) 常数，可对照 Levene 论文的有限 Schur 乘子分类。 [Levene, Norms of idempotent Schur multipliers](https://nyjm.albany.edu/j/2014/20-19v.pdf)

## 同一费用容许两种纵向截面

把 \(A\) 分成 \(A_+,A_-\)。任选列集合 \(E_+,E_-\)，要求 \(S=(A_+\times E_+)\cup(A_-\times E_-)\subset O\setminus H\)。记 \(m_\pm(b)=1-\lambda{\bf1}_{E_\pm}(b)\)。对 \(\lambda>0\)，置

\[
 u_\pm=e^{\pm i\theta},\qquad
 v(b)=(m_++m_-)/2+i(m_--m_+)/(2\tan\theta).
\]

于是 \(m_\pm=c_\lambda\operatorname{Re}(u_\pm v)\)。两值相等的列满足 \(|v|\le1\)，相差 \(\lambda\) 的列有
\((1-\lambda/2)^2+\lambda^2/(4\tan^2\theta)=1\)。当原谱价只承认模长严格为一的权，以同均值的随机单位相位表示每个列权，再取期望即可。零参数恢复常值。由此可同时处理两组纵向截面的所有上下外角，费用仍为 \(c_\lambda\)。

若沿用已知的正下界 \(B_i\)，取集合 \(J\) 包含所有可能与 \(S\) 相交的已扣矩形编号。由于其权至少为 \(1-\lambda\)，被扣收益至少 \(\sum_iB_i-\lambda\sum_{i\in J}B_i\)；额外收益的首项可取 \(\lambda(\mu^-m_S-\sum_{i\in J}B_i)\)。micro_credit.py 的 --mask-sets 在七个明确分点上构造真实矩形下界并检验严格区间相交。在下边缘使用 \(\max(a,1-b-B)\) 保证落在每一实际外盒中，\(\max(l,1-r-C)\) 保证离开真实域。recursive_phase.py 的 --two-sections 采用正筛多项式逐点下界 \(L=\max(0,\mu^- - (n+q)/I)\)，故异质交集的额外费用消失，可以改用 \((\mu^- -L)m_S\)。原来的每个末段边界仍照常计入。固定内核和递归中各条可选分支保留原价。
