"""Hermite majorants for |(tr U+tr V)/2| in the SL2 x SL2 character basis."""
from collections import defaultdict
from fractions import Fraction as F
from functools import cache
from math import comb


@cache
def powers(n):
    # Trace^n in irreducible SL2 characters of highest weights i.
    return tuple((n-2*j,comb(n,j)-(comb(n,j-1) if j else 0)) for j in range(n//2+1))


@cache
def moments(i,j):
    weights=[0]*(i+j+1)
    for x in range(i+1):
        for y in range(j+1):weights[x+y]+=1
    z=weights[(i+j)//2] if (i+j)%2==0 else 0
    square=[sum(weights[x]*weights[t-x] for x in range(max(0,t-i-j),min(t,i+j)+1))
            for t in range(2*(i+j)+1)]
    b=sum(v*v for v in square)
    d=(i+1)*(j+1)
    return d**4-z**4-b,b,max(3,d)


def hermite(ys):
    from adjoint_envelopes import linear_product,value_and_derivative
    poly=[];rem=[F(1)]
    for y in ys:
        x=y*y
        value,deriv=value_and_derivative(poly,x)
        den,dd=value_and_derivative(rem,x)
        a=(y-value)/den
        b=(1/(2*y)-deriv-dd*a)/den
        part=[a*z for z in rem]+[F(0)]
        first=linear_product(rem,x)
        for j,z in enumerate(first):part[j]+=b*z
        poly+=[F(0)]*(len(part)-len(poly))
        poly=[y+z for y,z in zip(poly,part)]
        rem=linear_product(first,x)
    coeff=defaultdict(F)
    for l,a in enumerate(poly):
        n=2*l
        for k in range(n+1):
            a0=a*F(comb(n,k),2**n)
            for i,ci in powers(k):
                for j,cj in powers(n-k):coeff[tuple(sorted((i,j)))]+=a0*ci*cj
    constant=coeff.pop((0,0))
    assert constant>F(1,2)
    return constant,{key:abs(v) for key,v in coeff.items() if v}


@cache
def menu():
    shapes=[tuple(F(y,16) for y in tup) for tup in
           [(x,y) for x in (5,7,9,11,13) for y in (16,20,24,28,32)]
          +[(x,y,z) for x in (5,7) for y in (15,18) for z in (25,30)]]
    return [hermite(shape) for shape in shapes]


@cache
def profiles():
    opts=menu()
    keys=sorted({key for c,row in opts for key in row})
    rows=[(c,[row.get(key,0) for key in keys]) for c,row in opts]
    return tuple(moments(*key) for key in keys),rows,[(float(c),list(map(float,row))) for c,row in rows]


def paired_polynomial(s,k,span,pm,p,M):
    from scale import _trials,root
    from math import isqrt
    R=(span+1)//2+1
    rt=isqrt(p)+1
    widths=[c for c in _trials(R,s,rt) if R<c and 2*c<pm]
    if not widths:return F(1)
    moments,exact,floating=profiles()
    weight=F(M,s*s)
    def price(c,approx):
        num=float if approx else F
        sq=(lambda x:x**.5) if approx else root
        cap=num(2*c*c+1)/(3*c)
        pair=cap*cap*(1+num(2*rt)/pm)/pm
        errors=[sq(sq(num(weight)*(g*rt+b+m*pair))) for g,b,m in moments]
        rows=floating
        if not approx:
            proposal=min(range(len(floating)),key=lambda i:floating[i][0]+sum(v*e for v,e in zip(floating[i][1],map(float,errors))))
            rows=[exact[proposal]]
        factor=min(c0+sum(v*e for v,e in zip(row,errors)) for c0,row in rows)
        return sq(num(c)/(c-R)*(num(c)/s+rt*factor)/k)
    return min([F(1)]+[price(c,False) for c in sorted(widths,key=lambda c:price(c,True))[:3]])
