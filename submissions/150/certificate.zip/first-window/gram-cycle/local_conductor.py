"""Uniform finite-window constants for the signed Fourier moment completion."""
from fractions import Fraction as F
from math import comb, factorial, isqrt, prod


def fourier_parts(mode, inside, r, pmin, pmax, sigma, head_weight=None):
    """Return (weighted generic coefficient, pairing price, pairing surcharge).

    The first entry already includes all label and character weights and a
    factor sqrt(p). For the usual Young estimate, multiply it by
    pmax*sigma*(pmax*B1/M1**2)**(r-1). The second entry is the full raw
    geometric-constant contribution, including its surcharge. To patch
    an existing centered fourth moment add only the third to its Fourier
    generic term before its minimum with the physical estimate.
    """
    if mode not in ("pair", "six") or r < 2:
        raise ValueError("expected pair or six and r at least two")
    pmin, pmax = int(pmin), int(pmax)
    sqrt_lower = isqrt(pmin)
    sqrt_upper = isqrt(pmax) + 1
    m = 1 if mode == "pair" else 3
    if mode == "pair":
        D = F(1) if inside else F(1, 2)
    else:
        D = F(2, 9) if inside else F(3, 16)
    C = 1 + F(2, 16**r) if mode == "six" and not inside else F(1)
    if head_weight is not None:
        assert mode=="six" and 0<head_weight<1
        D=head_weight**2/(1 if inside else 2)+(1-head_weight)**2/4
        C=1+2*((3*head_weight-1)/2)**(2*r)
    if mode == "pair" and inside:
        even = C
    else:
        signed = F(3, 3**(2*r)) if mode == "six" and inside else F(0)
        if inside and head_weight is not None:signed=3*head_weight**(2*r)
        even = (C + signed) / 2
    local_zero = comb(2*r, r)
    subtracted = C*local_zero + 2*even
    generic = (C*(4**r - 2) - subtracted)*sqrt_upper + subtracted
    matchings = prod(range(1, 2*r, 2))
    lead = m*(matchings if inside else factorial(r))*D**r
    all_pairs = m*matchings*((2*D if inside else D)**r)
    ordinary = lead*pmax**2*sigma**r + (all_pairs-lead)*pmax*sigma**(r-1)
    surcharge = ordinary * F(2, sqrt_lower)
    return generic, ordinary + surcharge, surcharge
