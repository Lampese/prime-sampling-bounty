"""Reprice the original mixed four-moment and preserve wheel, tilt and geometry."""
from fractions import Fraction as F
from pathlib import Path
from math import isqrt
import inspect,os,sys
from argparse import ArgumentParser

work=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(work/p) for p in ('prime-sampling','operator-new','residue-bridge/crt-fast','gram-cycle')]
if (work/'zig-cxx.cmd').is_file():
    os.environ.setdefault('CXX',str(work/'zig-cxx.cmd'))
    os.environ.setdefault('ZIG_GLOBAL_CACHE_DIR',str(work/'zig-cache'))
    os.environ.setdefault('ZIG_LOCAL_CACHE_DIR',str(work/'zig-local-cache'))
from prime_sampling.rectangles import boxes as m,sieved_lift
from prime_sampling.spectrum import squarerates as sr
import mixed,crt_fibres,paley_four

cli=ArgumentParser()
cli.add_argument('--rows',nargs='+',type=F,default=list(map(F,('.47','.475','.48','.49','.495'))))
cli.add_argument('--mode',choices=['pair','six'],default='six')
cfg=cli.parse_args()
old=mixed.price
src=inspect.getsource(old)
needle='        power=sigma*l1**2'
assert src.count(needle)==1
src=src.replace(needle,"        physical4-=4*window[0]*window[1]*paley_four.weight(mode,q,head)\n"+needle)
window=[]
env=dict(vars(mixed),paley_four=paley_four,window=window)
exec(compile(src,'<projective-split>','exec'),env)
def both(*a,**kw):
    before=old(*a,**kw)
    after=env['price'](*a,**kw)
    assert all(x>=y for x,y in zip(before,after))
    log.append((before,after,window[1],kw.get('tilt')))
    return after
def change(weights,W,phi,pm,p):
    window[:]=[pm,paley_four.good(weights,W,phi,pm,p)]
src=inspect.getsource(mixed.install)
mark='            answer=price('
assert src.count(mark)==1
src=src.replace(mark,'            change(weights,W,phi,pm,p)\n'+mark)
e=dict(vars(mixed),change=change,price=both)
exec(compile(src,'<projective-involution>','exec'),e)
m.initialize(F(150),F(4801,32));sieved_lift.install(m);crt_fibres.install(corner=True,layered=True)
m.rates=lambda *a:[F(1)]*2
e['install'](cfg.mode,m,envelope=True,wheel_search=True,conductor=True,reweight=cfg.mode=='six')
for u in cfg.rows:
    v=u+F(1,3200)
    out=[]
    for low,high in (m.inner(u,v),(max(m.LAM*m.Xlo(u-v),m.Xlo(2*u-1)),F(1))):
        if low>=high:continue
        log=[]
        m.joint(u,v,low,high)
        if not log:continue
        for q in (0,1):
            orig=min(t[0][q] for t in log)
            win=min(log,key=lambda t:t[1][q])
            out.append((m.upint(orig),m.upint(win[1][q]),round(float(win[2]),5)))
    print(u,out,flush=True)
if os.name=='nt':
    import _ctypes
    _ctypes.FreeLibrary(sr._lib._handle)
