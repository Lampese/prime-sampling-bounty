"""Independently form the constrained frequency weights by cyclic convolution."""
from cmath import exp,pi
from fractions import Fraction as F
from itertools import product
from math import gcd,prod
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"operator-new"))
from frequency_envelope import powers as pure_powers
from taper import kernel
from trap_envelope import powers


def convolve(a,b):
    p=len(a)
    return [sum(a[i]*b[(x-i)%p] for i in range(p)) for x in range(p)]


def direct(p,W,m,n,shape):
    qs = [q for q in (2,3,5,7) if W%q==0]
    phi = sum(gcd(x,W)==1 for x in range(W))
    pmin = lambda x: max(0,x)
    def tri(width, x):
        return F(pmin(W*width-abs(x)),(W*width)**2)
    def trap(x):
        return F(pmin(W*(n+m)//2-abs(x))-pmin(W*(n-m)//2-abs(x)),m*n*W*W)
    co = {m:F(1,3),n:F(2,3)} if m != n else {m:F(1)}
    if shape=="auto":
        k = kernel(m,n,F(-1,4))
        if k is None: return 0
        co = k[0]
    T = trap if shape=="trap" else lambda x: sum(v*tri(l,x) for l,v in co.items())
    w = []; em = []; en = []; mixed = []
    for i in range(p):
        x=i if i<p//2+1 else i-p
        mask=prod(2 if x%q==0 else F(q-2,q-1) for q in qs)
        w.append(F(W,phi)*T(x) if gcd(x,W)==1 else 0)
        em.append(mask*tri(m,x))
        en.append(mask*tri(n,x))
        mixed.append(mask*T(x))
    assert sum(w)==1
    es=[exp(2j*pi*i/p) for i in range(p)]
    def four(a):
        return [sum(float(v)*es[(i*h)%p] for i,v in enumerate(a)) for h in range(p)]
    aw=list(map(abs,four(w)))
    def nonneg(a):
        ft=four(a)
        assert min(v.real for v in ft)>-1e-10 and max(abs(v.imag) for v in ft)<1e-10
        return [max(0,v.real) for v in ft]
    if shape=="trap":
        a,b=nonneg(em),nonneg(en)
        assert min(x*y-z*z for x,y,z in zip(a,b,aw))>=-1e-10
        bound = powers(m,n,W)
    else:
        a=nonneg(mixed)
        assert min(x-y for x,y in zip(a,aw))>=-1e-10
        bound = pure_powers(co,W)
    conv=aw
    for r in range(2,6):
        conv=convolve(conv,aw)
        freq=sum(x*x for x in conv)
        exact=sum((x*y)**r for x,y in zip(em,en)) if shape=="trap" else sum(x**(2*r) for x in mixed)
        assert freq/p**(2*r-1)<=float(exact)+1e-13 and exact<=bound[r]
    return 1


if __name__ == "__main__":
    total=sum(direct(113,W,m,n,kind) for W,(m,n),kind in product((1,2,3,6,10),((2,4),(4,4),(2,6)),("trap","mixture","auto")) if 2*n*W<113)
    print("passed direct signed, pointwise and constrained Fourier checks on",total,"wheel/width/shape cases, orders 4 through 10")
