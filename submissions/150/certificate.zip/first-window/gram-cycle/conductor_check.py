"""Direct sums over d for balanced frequencies, including zero and coincident slots."""
from collections import Counter
from cmath import exp, pi
from math import comb, prod, sqrt
from random import Random


def check(p):
    gen = next(g for g in range(2,p) if len({pow(g,i,p) for i in range(p-1)}) == p-1)
    log = {pow(gen,i,p):i for i in range(p-1)}
    e = [exp(2j*pi*i/p) for i in range(p)]
    rng = Random(p)
    characters = [1, p-2, (p-1)//2]
    tables = {}
    for k in characters:
        f = [exp(2j*pi*((k*log[(x-1)*pow(x+1,-1,p)%p])%(p-1))/(p-1))
             if x not in (1,p-1) else 0 for x in range(p)]
        tables[k] = [sum(f[x]*e[h*x%p] for x in range(p))/sqrt(p) for h in range(p)]
        differences = [abs(abs(tables[k][h])**2-abs(tables[k][-h])**2) for h in range(1,p)]
        assert (max(differences) < 1e-8) == (2*k % (p-1) == 0)
    counts = Counter()
    for r in (2,3,4):
        for kind in ("generic", "one-zero", "two-zero", "paired", "even"):
            for _ in range(20):
                f = [rng.randrange(1,p) for i in range(2*r-1)]
                ch = [rng.choice(characters) for i in range(2*r)]
                if kind == "one-zero":
                    f[0] = 0
                if kind == "two-zero":
                    f[:2] = [0,0]
                f.append((sum(f[:r])-sum(f[r:]))%p)
                if kind == "even":
                    ch[r:] = ch[:r][::-1]
                if kind == "paired":
                    f[r:] = f[:r][::-1]
                    ch[r:] = ch[:r][::-1]
                total = abs(sum(prod(tables[k][h*d%p] for k,h in zip(ch,f)) for d in range(1,p)))
                zeros = f.count(0)
                if zeros:
                    bound = 2**(2*r-1) if zeros == 1 else 2**(2*r-2)
                else:
                    grouped = Counter(min((c,h),((-c)%(p-1),(-h)%p)) for c,h in zip(ch,f))
                    invariant = prod(0 if v%2 else comb(v,v//2)//(v//2+1) for v in grouped.values())
                    even = (sum(ch[:r])-sum(ch[r:]))%(p-1)==0
                    dim = comb(2*r,r)+2*even
                    bound = (4**r-2-dim)*sqrt(p)+dim+invariant*(p+2*sqrt(p)-3)
                assert total <= bound+1e-7, (p,r,kind,total,bound)
                counts[kind] += 1
    return counts


if __name__ == "__main__":
    total = check(101) + check(211)
    print("passed",sum(total.values()),"balanced frequency sums at p=101,211;",dict(total))
