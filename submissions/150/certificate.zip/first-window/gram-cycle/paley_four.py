"""A projective involution and an explicit hybrid Burgess bound on the displacement grid."""
from fractions import Fraction as F
from functools import cache
from math import isqrt,prod


def iroot(n,d):
    t=1 << ((n.bit_length()+d-1)//d)
    while True:
        v=((d-1)*t+n//t**(d-1))//d
        if v>=t:return t
        t=v


@cache
def mixed_burgess(N,W,pm,p,cubic=False):
    """Uniform quadratic (or cubic) short mixed sum bound, |j|<W."""
    from centered_powers import nroot_upper
    best=(1.,None)
    rt=isqrt(p)+1
    for r in (3,4,5,6):
        lead=prod(range(1,2*r,2))
        seed=iroot(p,2*r-2)
        for scale in (1,2,3,4,6,8):
            V=max(1,seed*scale)
            if V>=pm:continue
            # Nonpaired cubic exceptions have at most r-1 distinct shifts.
            extra=(2*r)**(2*r) if cubic else 0
            for power in (3,4,5,6,7,8,9,10):
                U=min(N//((1<<power)*V),(pm-1)//(W*(N+1)))
                if U<=max(2*W,2*10**6):continue
                # Dusart Th. 6.9 and log U <= .7 bit_length(U).
                A=4*U//(7*U.bit_length())
                if not A:continue
                second=1/(A*N)+(1+2*(N+1)/U)/(N*N)
                exceptions=lead*p/V**(r-1)
                if cubic:exceptions+=extra*p/V**r
                size=r*((2*r-1)*rt+exceptions)*second
                val=U*(V+1)/N+size**(1/(2*r))
                if val<best[0]:best=val,(r,lead,U,V,A)
    if best[1] is None:return F(1)
    r,lead,U,V,A=best[1]
    second=F(1,A*N)+(1+F(2*(N+1),U))/(N*N)
    extra=(2*r)**(2*r) if cubic else 0
    size=r*((2*r-1)*rt+F(lead*p,V**(r-1))+F(extra*p,V**r))*second
    edge=F(U*(V+1),N)
    return min(F(1),edge+nroot_upper(size,2*r))


@cache
def negative_four(m,W,phi,pm,p):
    """Lower probability of nonsplit, all distinct for a pure unit-wheel Fejer law."""
    N=2*m+1
    b=mixed_burgess(N,W,pm,p)
    op=min(F(1),F(1+2*N*b,m))
    # A repeated vertex in either bipartition can only give zero or positive;
    # zero products have probability <=4 sum w^2 <=4/(phi*m).
    return max(F(0),(1-op*op-F(4,phi*m))/2)


def weight(mode,inside,head=None):
    m=3 if mode=='six' else 1
    if mode=='pair':
        return F(0) if inside else F(1,8)
    if head is None:head=F(1,3) if inside else F(1,2)
    # Internally the post-conjugation menu is symmetric at all four slots;
    # each of its two unordered nonprincipal pairs has six permutations.
    if inside:return m*12*((1-head)/4)**4
    return m*(2*(head/2)**4+4*((1-head)/4)**4)


def good(weights,W,phi,pm,p):
    positive=[(m,c) for m,c in weights.items() if c]
    assert all(c>0 for m,c in positive) and sum(c for m,c in positive)==1
    separate=sum(c**4*negative_four(m,W,phi,pm,p) for m,c in positive)
    op2=0
    for m,c in positive:
        for n,t in positive:
            D=m+n+1
            h=1+2*D*mixed_burgess(D,W,pm,p)
            op2+=c*t*h*h/(m*n)
    omega=sum(c/F(m*phi) for m,c in positive)
    return max(separate,(1-op2-4*omega)/2)


@cache
def support_good(radius,W,phi,omega,pm,p):
    """A nonnegative unit-wheel law in |x| <= W*radius with mass <=omega per atom."""
    N=2*radius+1
    op=phi*omega*(1+2*N*mixed_burgess(N,W,pm,p))
    return max(F(0),(1-op*op-4*omega)/2)


def tetra_share(weights,radius,W,phi,omega,pm,p):
    """Guarantee 1-P(repeated vertex)-|E cubic(Vandermonde)|."""
    from centered_powers import nroot_upper
    if weights is None:
        N=2*radius+1
        op=phi*omega*(1+2*N*mixed_burgess(N,W,pm,p,True))
    else:
        op2=0
        for m,c in weights.items():
            for n,t in weights.items():
                if not c*t:continue
                N=m+n+1
                v=1+2*N*mixed_burgess(N,W,pm,p,True)
                op2+=c*t*v*v/(m*n)
        op=nroot_upper(op2,2)
    return max(F(0),1-6*omega-op)
