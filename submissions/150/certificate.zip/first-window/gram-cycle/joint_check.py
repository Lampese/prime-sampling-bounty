"""Direct Gram/Fourier pricing and independent invariant counting with arbitrary labels."""
from cmath import exp,pi
from collections import Counter
from fractions import Fraction as F
from itertools import combinations,product
from math import sqrt


def run(p,base):
    for gen in range(2,p):
        log={pow(gen,j,p):j for j in range(p-1)}
        if len(log)==p-1:break
    unit=[exp(2j*pi*i/p) for i in range(p)]
    chars=[exp(2j*pi*i/(p-1)) for i in range(p-1)]
    zeta=exp(2j*pi/3)
    inv2=pow(2,-1,p)
    shift=5
    A=[1,3,5,7,9]
    # Same difference can carry distinct labels. The check does not
    # require v to come from vertex labels, as the proof works edgewise.
    edges=[(shift*(pow(c,-1,p)-pow(a,-1,p))%p,(2*u*v+u+2*v)%3)
           for u,a in enumerate(A) for v,c in enumerate(A) if a!=c]
    w=[abs(sum(unit[j*h%p] for j in range(4)))**2/(p*4) for h in range(p)]
    sig=sum(v*v for v in w)
    fields=[]
    for inside in (False,True):
        grp=[]
        for j,i in product(range(3),range(2)):
            u=(base*(not inside)+i*((p-1)//2)+j*((p-1)//3))%(p-1)
            if not u:continue
            mass=((1/3 if not j else 1/6) if inside else (1/4 if not j else 1/8))
            grp.append((u,j,mass))
        H={}
        for k,j,m in grp:
            chi=[0 if v in (p-1,1) else chars[k*log[(v-1)*pow(v+1,-1,p)%p]%(p-1)]
                 for v in range(p)]
            H[k]=[sum(c*unit[v*h%p] for v,c in enumerate(chi)).real/sqrt(p) for h in range(p)]
        mu=sum(m*m for k,j,m in grp)
        sc=1/len(A)**2
        vals=[(z,abs(sum(m*zeta**(j*v)*H[k][h*d*inv2%p] for k,j,m in grp)))
              for d,v in edges for h,z in enumerate(w)]
        mean=sc*sum(z*y for z,y in vals)
        second=sc*sum(z*y*y for z,y in vals)
        assert mean**2<=second+1e-9
        maj=mu
        for k,j,m in grp:
            maj+=sc*m*m*sum(abs(sum(w[h]*(H[k][h*d*inv2%p]**2-1) for h in range(1,p))) for d,v in edges)
        for (k,j,m),(l,j1,m1) in combinations(grp,2):
            maj+=2*sc*m*m1*sum(abs(sum(w[h]*H[k][h*d*inv2%p]*H[l][h*d*inv2%p] for h in range(1,p))) for d,v in edges)
            # Projective class (k,h) modulo (k,h)~(-k,-h).
            def cls(k,h):return min((k,h),((-k)%(p-1),-h))
            for hs in product((-2,-1,1,2),repeat=4):
                counts=Counter(cls(t,h) for h in hs for t in (k,l))
                e=0 if any(v%2 for v in counts.values()) else 2**sum(v==4 for v in counts.values())
                g=Counter(abs(h) if inside else h for h in hs)
                ex=0 if 1 in g.values() else (4 if len(g)==1 else 1)
                assert max(counts.values())<=4 and e<=ex
        assert second<=maj+1e-9
        fields.append((round(mean,5),round(second,5),round(maj,5)))
    return fields


print('p, (sampled absolute mean, sampled square, edgewise expansion upper bound):')
for p,base in ((31,6),(61,12),(67,6)):
    print(p,run(p,base))
