"""A Fourier hyperplane bound for a wheel restricted difference of unequal boxes."""
from fractions import Fraction as F
from functools import cache
from math import comb


@cache
def powers(m,n,W):
    """Bound sum_x E_m(x)^r E_n(x)^r, where E is the CRT positive envelope."""
    from frequency_envelope import residue_moment
    if not 1 <= m <= n:
        raise ValueError("expected ordered positive aperture widths")
    result = {}
    for r in range(2,6):
        # Integral of T_m(x)^r T_n(x)^r on [0,m], using x=m(1-u).
        part = sum(F(comb(r,j)*(n-m)**(r-j)*m**j, r+j+1) for j in range(r+1))
        integral = part / (m**(r-1)*n**(2*r))
        coarse = F(1,(m*n)**r) + 2*integral
        result[r] = coarse*residue_moment(W,2*r)
    return result
