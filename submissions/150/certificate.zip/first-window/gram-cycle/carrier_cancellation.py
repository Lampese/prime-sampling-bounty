"""All-dilation-invariant Fourier hyperplane prices for wheel triangles."""
from fractions import Fraction as F
from functools import cache
from math import comb,prod


@cache
def centre_count(H,k,c):
    """Count sum b_i=c with k coordinates of absolute value at most H."""
    if abs(c)>k*H:return 0
    c=abs(c)
    target=k*H+c
    return sum((-1)**j*comb(k,j)*comb(target-j*(2*H+1)+k-1,k-1)
               for j in range(k+1) if target>=j*(2*H+1))


@cache
def sign_mass(W,k):
    """Weighted CRT classes whose sign changes when every frequency is tripled."""
    qs=[q for q in range(2,W+1) if W%q==0 and all(q%d for d in range(2,q))]
    assert prod(qs)==W
    if 3 not in qs:return F(0)
    def absolute(q):
        return (2**k+(q-1)*F(q-2,q-1)**k)/q
    negative=(absolute(3)-F(2,3)*F(3,2)**k)/2
    return negative*prod(absolute(q) for q in qs if q!=3)


def separate_cells(weights,W,pm,p,k,leakage,response):
    """Lower bound the constrained product of the per-coordinate common amplitudes."""
    n=max(i for i,w in weights.items() if w)
    L=int(pm//(64*W*n))
    if L%2==0:L-=1
    if L<1:return F(0)
    d=L//2
    scale=10**8
    radius=22
    # Packing a polynomial into radix 2**bits allows exact integer convolution.
    bits=(scale*(2*radius+1)).bit_length()*k+1
    mask=(1<<bits)-1
    polys=[0,0]
    for q in range(-radius,radius+1):
        z=F(n*W*(abs(q)*L+d+1),pm)
        if 3*z>1:continue
        f=max(0,sum(w*response(z*i/n) for i,w in weights.items())-leakage)
        g=max(0,sum(w*response(3*z*i/n) for i,w in weights.items())-leakage)
        for status in (0,1):
            yi=int(scale*min(f,(2**status)*g))
            polys[status]+= yi << (bits*(q+radius))
    qs=[q for q in range(2,W+1) if W%q==0 and all(q%d for d in range(2,q))]
    rest=prod((2**k+(q-1)*F(q-2,q-1)**k)/q for q in qs if q!=3)
    full=0
    for active in range(3,k+1,2):
        # For a prescribed set of active coordinates, count nonzero residues mod three.
        crt=F(comb(k,active)*(2**active-2),3*2**active)*rest
        poly=polys[0]**(k-active)*polys[1]**active
        total=0
        for t in range(-k,k+1):
            ways=centre_count(d,k,k//2-L*t)
            if ways:
                total+=ways*((poly >> (bits*(k*radius+t))) & mask)
        full+=crt*total
    return full/(p**(k-1)*scale**k)


def reduced(weights,W,pm,p):
    """One-sided power upper bounds on the grouped generic weights; pm<=p_actual<=p."""
    from frequency_envelope import powers
    upper=powers(weights,W)
    positive=[i for i,v in weights.items() if v]
    if W%3 or min(weights.values())<0:return upper
    m,n=min(positive),max(positive)
    if m < 5:return upper
    primes=[q for q in range(2,W+1) if W%q==0 and all(q%d for d in range(2,q))]
    leakage=F(2**len(primes)*prod(q-1 for q in primes),m*m)
    def response(z):
        angle=F(22,7)*z
        a2=angle*angle
        return max(0,1-a2/6+a2**2/120-a2**3/5040)**2 if z<=1 else F(0)
    # z bounds n*W*|h/p-j/W|, with the scaled frequency at most 3z.
    for r in upper:
        k=2*r
        best=0
        prev=None
        for z in (F(j,64) for j in range(1,22)):
            H=(pm*z/(W*n)).__floor__()-1
            if H<=k or k*(H+1)*W>=pm:continue
            if H==prev:continue
            amplitude=max(0,sum(v*response(z*i/n) for i,v in weights.items())-leakage)
            scale=max(0,sum(v*response(3*z*i/n) for i,v in weights.items())-leakage)
            # On a balanced mod-3 tuple an odd number of nonzero entries is at least three.
            tuples=centre_count(H,k,k//2)-(centre_count(prev,k,0) if prev is not None else 0)
            best+=F(max(0,tuples),p**(k-1))*sign_mass(W,k)*min(amplitude**k,8*scale**k)
            prev=H
        # Group h and 3h once, without a half: the former has at least three
        # nonzero mod-3 carriers and every carrier of the latter is zero mod 3.
        best=2*max(best,separate_cells(weights,W,pm,p,k,leakage,response))
        assert 0<=best<upper[r]
        upper[r]-=best
    return upper
