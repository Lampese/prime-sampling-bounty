from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
import os,sys

here=Path(__file__).resolve().parent
work=here.parent
ap=ArgumentParser()
for k,d in dict(repo='prime-sampling',selectors='operator-new',base='weighted-base',
                reflection='reflection',cap='residue-bridge/crt-fast').items():
    ap.add_argument('--'+k,type=Path,default=work/d)
ap.add_argument('--mode',choices=('pair','six'),default='six')
ap.add_argument('--j',type=int,choices=(2,3,5,7),default=2)
ap.add_argument('--triple',action='store_true')
ap.add_argument('--wheel',action='store_true')
ap.add_argument('--energy',action='store_true')
ap.add_argument('--rows',type=F,nargs='+',default=list(map(F,('.38','.39','.40','.42'))))
args=ap.parse_args()
sys.path[:0]=[str(x.resolve()) for x in (args.selectors,args.repo,args.base,args.cap,args.reflection)]
if (work/'zig-cxx.cmd').exists():
    os.environ.setdefault('CXX',str(work/'zig-cxx.cmd'))
    os.environ.setdefault('ZIG_GLOBAL_CACHE_DIR',str(work/'zig-cache'))
    os.environ.setdefault('ZIG_LOCAL_CACHE_DIR',str(work/'zig-local-cache'))
    dll=args.base.resolve()/'mixed.so'
    if dll.is_file():os.environ.setdefault('PRIME_MIXED_SELECTOR_DLL',str(dll))
from prime_sampling.rectangles import boxes as model,sieved_lift
from prime_sampling.spectrum import squarerates as sr
import mixed,weighted,reflection,crt_fibres,dilation
dilation.use_wheel=args.wheel
dilation.use_energy=args.energy

model.initialize(F(150),F(4801,32))
sieved_lift.install(model)
crt_fibres.install(corner=True,layered=True)
model.rates=lambda *x:[F(1)]*2
prices=None
cache={}
def reflected(co,a,b,v,s,h,pm,p,r,rad=None):
    cache['r1']=r
    return reflection.refine(co,a,b,v,s,h,pm,p,r,True,rad,joint=args.energy)

def getargs(mode,s,k,p,front,co,sigma,omega,l1):
    global prices
    prices=(front,co,sigma,omega,l1)
    return mixed.price(mode,s,k,p,front,co,sigma,omega,l1)

weighted.price=getargs

def trace(ignored,wi,hi,mi,ni,ti,l,h,z,rates):
    a,b,v,s,k,span=rect
    ymin,ymax=map(int,axis)
    for q in (0,1):
        best[q]=min(best[q],rates[q])
        base[q]=min(base[q],rates[q])
    W=(2,6,30)[wi]
    j=args.j
    if j>2 and W%j==0:return
    classes=2 if j==2 else j-1
    d=sr.ceildiv(span,W)+7
    m,n=(max(1,d*i//8) for i in (mi,ni))
    wt=F(ti,4)
    pm,p=model.pmin,model.pmax
    front,co1,sigma,omega,l1=prices
    r1=cache['r1']
    A,B=weighted.base(h,l,z)
    peak1=max(A,1-z)/h
    rad1=weighted.coll_radius(h,l,A,B)[1]
    md=min(sr.dirichlet_cap(a,b,v,pm,p),sr.previous_cap(v,b,pm),sr.square_cap(a,b,v,pm,p))
    if args.triple and W==2 and 5*b<pm:
        for h3 in (max(1,h//3),max(1,2*h//3)):
            h2=max(1,h//2)
            if 6*W*(h+h2+h3+4)>=pm:continue
            vals=[]
            for order,length in ((2,h2),(3,h3)):
                key=('triple',order,length,m,n,wt)
                if key not in cache:
                    f=dilation.flat_front(W,length,m,n,wt,k,span,ymin,ymax,model,order)
                    c=dilation.second_auto(a,b,v,s,pm,p,length,md,order,2)
                    cache[key]=f,c
                vals.append(cache[key])
            (f2,c2),(f3,c3)=vals
            if not f2 or not f3:continue
            c12=dilation.cross(a,b,v,s,pm,p,h,h2,r1,F(1,h2),peak1,F(1,h2),2,2,rad1)
            c13=dilation.cross(a,b,v,s,pm,p,h,h3,r1,F(1,h3),peak1,F(1,h3),3,2,rad1)
            c23=dilation.cross_two(a,b,v,s,pm,p,h2,h3,F(1,h2),F(1,h3),F(1,h2),F(1,h3),2,3,2,2)
            for i2,i3 in ((1,1),(2,2),(1,2),(2,1),(1,3)):
                l2,l3=F(i2,8),F(i3,8)
                w1=1-l2-l3
                mf=1/(w1/front+l2/f2+l3/f3)
                mc=w1*w1*co1+l2*l2*c2+l3*l3*c3+2*(w1*l2*c12+w1*l3*c13+l2*l3*c23)
                ns=mixed.price(args.mode,s,k,p,mf,mc,sigma,omega,l1)
                for q in (0,1):
                    if ns[q]<best[q]:
                        best[q]=ns[q]
                        winner[q]=('triple',round(h3/h,3),str(l2),str(l3),round(float(c23/co1),6))
    for h2 in {max(1,h*num//den) for num,den in ((1,j),(2,j),(1,1))}:
        key=(W,h2,m,n,wt)
        if key not in cache:
            fr=dilation.flat_front(W,h2,m,n,wt,k,span,ymin,ymax,model,j)
            cl=dilation.second_auto(a,b,v,s,pm,p,h2,md,j,classes)
            cache[key]=(fr,cl)
        fr,co2=cache[key]
        if fr is None or j*W*(h+h2+4)>=pm or (j+1)*b>=pm:
            continue
        cx=dilation.cross(a,b,v,s,pm,p,h,h2,r1,F(1,h2),peak1,F(1,h2),j,classes,rad1)
        for lam in map(F,('1/8','1/4','1/2')):
            mixfront=1/((1-lam)/front+lam/fr)
            mixco=(1-lam)**2*co1+lam**2*co2+2*lam*(1-lam)*cx
            if mixfront>=front and mixco>=co1:
                continue
            ans=mixed.price(args.mode,s,k,p,mixfront,mixco,sigma,omega,l1)
            for q in (0,1):
                if ans[q]<best[q]:
                    best[q]=ans[q]
                    winner[q]=(W, round(h2/h,3), str(lam),round(float(cx/co1),6),
                               round(float(fr/front),6),round(float(co2/co1),6))

weighted.install(args.mode,model,lambda:axis,args.selectors,64,
                 shape_menu=[(F(1,2),F(0)),(F(1,2),F(-1,4)),(F(2,3),F(-1,8))],
                 trace=trace,co_refiner=reflected,pass_radius=args.energy)
for u in args.rows:
    v=u+F(1,3200)
    for name,(cl,et) in zip(('inner','outer'),(model.inner(u,v),(max(model.LAM*model.Xlo(u-v),model.Xlo(2*u-1)),F(1)))):
        if cl>=et:continue
        eps,_,a,b,s,V,ylo,yhi=model.params(u,v)
        eps=max(eps,model.thetaerr((1-u)*model.zl+model.b(cl,'ln',False)))
        k=(model.abel.lower_count(cl,et,eps,(1-u)*model.zh,model)*ylo).__ceil__()
        x,y=(cl*ylo).__floor__(),(et*yhi).__ceil__()
        span=((et-cl)*yhi).__ceil__()+2
        best=[F(1)]*2;base=[F(1)]*2;winner=[None,None]
        for axis,rect in (((x,y),(a,b,V,s,k,span)),((a,b),(x,y,min(y-x,span),k,s,V))):
            cache={}
            model.rates(*rect,model.pmin,model.pmax)
        print(args.mode,str(u),name,*map(model.upint,base),'->',*map(model.upint,best),winner,flush=True)
if os.name=='nt':
    import _ctypes
    _ctypes.FreeLibrary(sr._lib._handle)
