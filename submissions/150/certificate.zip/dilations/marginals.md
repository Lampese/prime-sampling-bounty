# A Cauchy bound for two distinct sampling dilations

For an actual input set A of S primes define the unnormalized one-coordinate marginal Qⱼ(x)=Σ_{u∈A}Pr[(nⱼ+t/u)/j=x]. After dispensing with equality of labels, a cross collision of two off-diagonal samplers is determined by the collision of their first coordinates followed by at most M−1 choices for their two remaining input primes. The mixed fiber bound M depends on the relative reflection sign. In the notation of odd-prime.md,

    coᵢⱼ,± ≤ (M±−1) S⁻⁴ Σₓ Qᵢ(x) Qⱼ(±x).

Apply Cauchy to the full sum. The reflection, translations of the base, and dilation of an entire marginal are permutations of the field, so its squared norm uses the original physical base difference against t(1/u−1/c). The diagonal u=c gives S Rⱼ(0). If its complete autocorrelation Rⱼ(d) is majorized by rⱼ(1−|d|/Hⱼ)₊ on the wheel-step lattice (and 2Hⱼ<p), the project's uniform weighted_near gives

    ||Qⱼ||₂² ≤ S rⱼ (1+weighted_near(a,b,V,p₋,p₊,1,Hⱼ)).

Here the factor W multiplying each base step can be absorbed into the common nonzero field shift t/W. The flat 2h₂ base has r₂=1/(2h₂), H₂=2h₂. For the punctured odd prime base the explicit envelope (r,H) in odd-prime.md is sufficient. A two-level first base takes the certified autocorrelation radius from weighted.coll_radius; if the exact radius is absent, any distribution of support h and squared mass r₀ obeys R(d)≤2r₀(1−|d|/(2h))₊ by Cauchy. Let Eⱼ denote the upper bound on ||Qⱼ||²/S. Both relative signs satisfy

    coᵢⱼ,± ≤ (M±−1) sqrt(Eᵢ Eⱼ)/s³.

This can be combined by taking the minimum with the previous mixed-digit arbitrary-centre count before the last multiplication. The --energy implementation outward-rounds the geometric mean on a relative binary mesh. It treats each of (1,2), (1,3), (2,3) in the same way. For the within-branch reflected samplers the same argument is the existing reflection joint bound.
