# Two sampling dilations with one Fejér kernel

Fix an actual prime rectangle, any allowed nonzero shift t, and a fixed menu with its prescribed input labels. Let S and K be the actual source and target prime counts, with certified lower bounds s and k. Let W be 2, 6 or 30. In the existing mixed Fejér certificate, w is an even probability law supported on integer units modulo W, with interpolation between adjacent coarse tent values and denominator φ(W). Use this identical law in both branches. The first base is O₁+Wi with O₁ divisible by W and weights bᵢ from the original certificate. Write h₁ for its length and r₁=Σbᵢ². The second base is

    n₂=O₂+W(2i+e),       0≤i<h₂, e∈{0,1},

with i,e uniform and independent. In branch j the target sample is b=nⱼ+jz with z drawn from w. Every n₂ is odd by the choice of O₂ below. Branch 2 is not the reflection of branch 1.

## Coverage of every target prime

Let L be the actual left endpoint of the target interval and let B bound its span. Set U=2W, D=ceil(B/U)+8, s₀=floor((h₂−D)/2), and

    O₂=W/2+U(floor((L−W/2)/U)−s₀−1).

For every target prime b>W there is exactly one e for which y=(b−O₂−We)/2 is odd, because W/2 is odd. For every odd prime divisor q of W, 2y≡b mod q, so y is a unit modulo W. The other e has zero w probability. On the surviving e, b=n₂+2z is equivalent to y=Wi+z. Set x=floor(y/W), r=y mod W and let C be the coarse interval convolution of the original mixed triangular law in the flat base of length h₂. Then

    P₂(b)=[(1−r/W)C(x)+(r/W)C(x+1)]/[2h₂φ(W)].

The formula follows by summing the two linear pieces of each discrete fine triangle and by the wheel restriction. The index x equals floor((b−W/2)/U)−floor((L−W/2)/U)+s₀+1+δ where δ is 0 or −1. Consequently s₀≤x≤x+1≤h₂−1−s₀. For cuts s₀≤i≤floor((h₂−1)/2), a probability below C(i)/(2h₂φ(W)) can occur only if x<i or x+1>h₂−1−i. Each tail has physical length at most (i−s₀+4)U. The right tail starts at least at L+(h₂−6−i−s₀)U. These loosened endpoints absorb either value of δ and the floor at L. The argument follows immediately from s₀−1+(b−L)/U≤x≤s₀+2+(b−L)/U and B≤(D−8)U, with 2s₀≤h₂−D. Applying the existing two prime tail bounds with logarithmic secants and upward mesh rounding gives flat_front. Cases C(s₀)=0 are discarded. The bin thresholds approximate the layer-cake inequality for reciprocal probabilities, so rounding upwards preserves a valid upper bound even when the numerical improvement is small.

Individually certified constants Fⱼ bound Σ_b 1/Pⱼ(b) divided by K². For P=(1−λ)P₁+λP₂, the harmonic mean is concave and homogeneous because (Σ1/P(b))⁻¹=min_{Σx_b=1}ΣP(b)x_b². Therefore the mixed cost is at most F=[(1−λ)/F₁+λ/F₂]⁻¹. This applies for every collection of prime targets in the rectangle.

## The common kernel and its mass

In branch j the two arguments of the correlation kernel are (nⱼ+t/u)/j and (nⱼ+t/c)/j. Character factors of j cancel within each same-character Gram product, before taking the linear combination over the fixed menu. The old input-dependent phases and arbitrary labels therefore enter the very same kernel K_v in both branches. A source diagonal still costs 1/s and the off-diagonal mass remains at most one. After discarding unimodular phases, take the convex combination of the two nonnegative off-diagonal sampling distributions. The even law allows each to be averaged with its reflection, at the same physical cost. Denote the two reflected laws by μ₁ and μ₂ and their certified squared masses by c₁ and c₂. For the second base all 2h₂ indices have equal probability, so the original flat triangular autocorrelation applies with length 2h₂. Indeed multiplication by j in two simultaneous collisions cancels out of the within-branch identity. The old reflection theorem accepts any base origin and any nonzero t.

Each signed cross requires

    t(2/u ±1/v)=t(2/c ±1/d)  (mod p)

and a corresponding base sum/difference ±n₂−2n₁. The input prime pairs within each individual sample are distinct. For restricted true short source interval [a,b] of span V, b<p/3 and prime endpoints >3, neither mixed rational can be zero modulo p. For a common congruence class of the base difference its integer coarse index is unique, because W(2h₁+2h₂+4)<p. Its parity fixes e. Hence its mass is at most

    r₁₂=½ min(maxᵢ bᵢ,1/h₂,√(r₁/h₂)).

The supremum and the Cauchy inequality on the two shifted vectors give these three bounds. Fix u. Then a valid v must have (t/W)/v inside a translated modular interval of radius h₁+h₂+1. The uniform reflection near_plus lemma gives at most N choices, for either sign. Its proof uses Dirichlet approximation to the interval centre and divisibility by a source prime, with explicit constants. For a fixed (u,v) on a fiber of size M one must omit (c,d)=(u,v), since the first branch requires c≠u. Dropping the equality of the labels only increases this bound. Summing the S N choices and normalizing by S⁴ gives

    c₁₂ ≤ r₁₂ N (M₊+M₋−2)/(2s³).

The factor ½ here averages the two relative signs of the independent reflections. The final collision bound is (1−λ)²c₁+2λ(1−λ)c₁₂+λ²c₂. In the centered estimate the subtracted constant and total mass are shared. In the higher moment estimates the common kernel has precisely the old moments. Thus all existing mixed.price lines apply with the new F and collision bound, including the final square roots. All arithmetic in certificate evaluation is integral or rational with the existing outward roots. Floating point only selects candidate shape parameters and formats diagnostics.

## Integer fiber bounds

For σ=±1 consider the rational function f=2/u+σ/v. Its reduced fraction identifies the ordered pair of prime arguments. If u≠v its denominator is uv, and the choice of order is fixed by its numerator 2v+σu. If u=v the denominator is the single prime u. All reduced numerators and denominators are odd for u,v>3, even after the cancellation in the equal-argument case. Distinct rationals with the same mod p value differ by at least 2p/b⁴. Their range has length at most 3V/[a(a+V)]. This proves the separation bound. Before cancellation the cross-determinant is the sum of two endpoint differences times products of primes, with coefficients 2 and σ. Its absolute value is at most 3b²V. If 3b²V<2p each fiber has size at most one.

Every integer point (E,P)=(2v+σu,uv) on the given modular fiber lies in one affine lattice of covolume at least 4p. Indeed E and P each have fixed odd parity, and in the coordinate sublattice of step 2 the additional congruence E=fP has index p. The map is injective on source prime pairs by rational uniqueness. All images lie in the quadrilateral spanned by the four endpoint images, by bilinear interpolation. When σ=+ and b<2a the Jacobian σu−2v has a constant sign. When σ=− its sign is always constant. In these cases the four directed edges are line segments, and their turns consistently have the sign of the Jacobian at the four vertices, hence the quadrilateral is convex. Its area is bounded by JV², where J=2b−a in the former case and 3b in the latter. For σ=+ and b≥2a one can always bound the area of the axis-aligned bounding rectangle by 6bV². The code uses this fallback. Any triangulation of n noncollinear points yields at least n−2 nondegenerate triangles. It follows that n≤2+floor(JV²/(2p)).

For collinear points with constant E, the interval of possible P is of length at most 2bV+V² and has one class mod p. Otherwise write the line dP−gE=j with d>0 and gcd(d,g)=1. Then U=du−2g, Z=dv−σg satisfy UZ=N=dj+2σg². N=0 fixes one member and its modular fiber uniquely determines the other in each of the two branches. N≠0 gives at most 2τ(|N|) ordered pairs, because U is an injective signed divisor on this fiber. For the large-|N| alternative assign each pair to either its u or v coordinate whose affine factor has magnitude at least √|N|. In either class the assigned endpoint is distinct between pairs. For n=2k+1 distinct endpoints xᵢ write Aᵢ=dxᵢ−G, where G is 2g or σg. Set

    Q=N^{k(k+1)/2} ∏_{i<j}(xⱼ−xᵢ) / ∏ᵢ Aᵢ^k.

The determinant of columns 1,x,…,x^k,y,…,y^k, where y is the partner integral endpoint, equals ±d^{k²}Q. This follows by changing variables to A and N/A, multiplying every row by A^k and taking the Vandermonde determinant. For any odd prime dividing d all Aᵢ are units. If 2 exactly divides d the determinant bounds the denominator of Q at 2 by 2^{k²}. If 4 divides d and G=2g, each Aᵢ has 2-adic valuation exactly one; when G=±g all Aᵢ are odd. Thus 2^{nk}Q is always a nonzero integer. When the xᵢ lie in an interval of length T we get

    1≤(2T)^{nk}|N|^{−k²/2}.

For each dyadic threshold the project's old_fibre.arc(2V) combines this endpoint spacing bound in the two groups with 2τ(|N|) for small |N|. The implementation allows another harmless factor two. Taking the larger of linear and noncollinear bounds, then the smaller of that, rational separation and the number of odd endpoints proves mixed_fibre. This fiber derivation uses the same lattice and divisor-spacing approach as the reflection proof, with the extra powers of 2 above necessary for the asymmetric coefficients. A related original reference is [Cilleruelo and Garaev](https://arxiv.org/abs/1007.1526).
