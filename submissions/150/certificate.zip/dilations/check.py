"""Small exact checks of prime coverage, mixed fibers and signed collisions."""
from collections import Counter
from argparse import ArgumentParser
from fractions import Fraction as F
from math import gcd,isqrt
from pathlib import Path
import sys
work=Path(__file__).resolve().parents[1]
args=ArgumentParser()
for k,d in dict(repo='prime-sampling',selectors='operator-new',reflection='reflection').items():
    args.add_argument('--'+k,type=Path,default=work/d)
options=args.parse_args()
sys.path[:0]=[str(p.resolve()) for p in (options.repo,options.selectors,options.reflection)]
import dilation
def coverage(x,h,m):
    return F(sum(max(0,m-abs(x-i)) for i in range(h)),m*m)

def prime(n):
    return n>1 and all(n%i for i in range(2,isqrt(n)+1))

def check_coverage():
    checks=0
    for W in (2,6,30):
        phi=sum(gcd(r,W)==1 for r in range(W))
        for j in (2,3,5,7):
            if j>2 and W%j==0:continue
            es=tuple(range(2)) if j==2 else tuple(range(1,j))
            for L in range(101,143,3):
                h,m,B=13,4,4*j*W+1
                U=j*W
                D=-(-B//U)+8
                start=(h-D)//2
                offset=W//2 if j==2 else 0
                origin=offset+U*((L-offset)//U-start-1)
                for b in range(L,L+B+1):
                    if not prime(b):continue
                    mass=F()
                    for e in es:
                        for i in range(h):
                            n=origin+W*(j*i+e)
                            assert gcd(n,j)==1
                            if (b-n)%j==0:
                                z=(b-n)//j
                                if gcd(z,W)==1:
                                    mass+=F(max(0,m*W-abs(z)),len(es)*h*phi*m*m*W)
                    gs=[(b-origin-W*e)//j for e in es if (b-origin-W*e)%j==0
                        and gcd((b-origin-W*e)//j,W)==1]
                    assert len(gs)==1
                    x,r=divmod(gs[0],W)
                    predicted=((W-r)*coverage(x,h,m)+r*coverage(x+1,h,m))/(W*len(es)*h*phi)
                    assert mass==predicted and mass>0
                    assert start<=x<x+2<=h-start
                    for cut in range(start,(h-1)//2+1):
                        if mass>=coverage(cut,h,m)/(len(es)*h*phi):continue
                        assert b<=L+(cut-start+4)*U or b>=L+(h-6-cut-start)*U
                    checks+=1
    return checks


def check_fibers():
    checks=0
    for p in (127,251,509,1013,10009,100003):
        for j in (2,3,5,7):
            for a in (11,19,31,61):
                for V in (4,9,15,33):
                    b=a+V
                    if (j+1)*b>=p:continue
                    primes=[q for q in range(a,b+1) if prime(q)]
                    for sign in (-1,1):
                        counts=Counter((j*pow(u,-1,p)+sign*pow(v,-1,p))%p for u in primes for v in primes)
                        assert 0 not in counts
                        assert max(counts.values(),default=0)<=dilation.mixed_fibre(a,b,V,p,sign,j)
                        checks+=len(counts)
    return checks


def check_cross():
    checks=0
    p,W=509,2
    A=[11,13,17,19,23,29,31]
    S=len(A)
    h1,h2=4,5
    for j in (2,3,5,7):
        es=tuple(range(2)) if j==2 else tuple(range(1,j))
        second=[(W//2 if j==2 else 0)+W*(j*i+e) for i in range(h2) for e in es]
        auto=Counter((x-y)//W for x in second for y in second)
        R=F(1,len(second))
        if j>2:
            for d,v in auto.items():
                assert F(v,len(second)**2)<=R*F(h2+1,h2)*(1-F(abs(d),j*(h2+1)))
        for t in range(1,p,7):
            def law(js,bases):
                ans=Counter()
                for n in bases:
                    for u in A:
                        for c in A:
                            if u==c:continue
                            for sign in (-1,1):
                                x=sign*(n+t*pow(u,-1,p))*pow(js,-1,p)%p
                                y=sign*(n+t*pow(c,-1,p))*pow(js,-1,p)%p
                                ans[x,y]+=1
                return ans
            mu1=law(1,[W*i for i in range(h1)])
            mu2=law(j,second)
            val=F(sum(n*mu2[xy] for xy,n in mu1.items()),4*h1*len(second)*S**4)
            bound=dilation.cross(min(A),max(A),max(A)-min(A),S,p,p,h1,h2,F(1,h1),F(1,h2),F(1,h1),F(1,h2),j,len(es))
            assert val<=bound,(j,t,val,bound)
            checks+=1
            if j==3:
                doubled=[1+W*(2*i+e) for i in range(h1) for e in (0,1)]
                both=law(2,doubled)
                actual=F(sum(n*mu2[xy] for xy,n in both.items()),4*len(doubled)*len(second)*S**4)
                bound=dilation.cross_two(min(A),max(A),max(A)-min(A),S,p,p,h1,h2,
                       F(1,h1),F(1,h2),F(1,h1),F(1,h2),2,3,2,2)
                assert actual<=bound
                checks+=1
    return checks

print('exact prime coverage',check_coverage(),'modular fibers',check_fibers(),'signed collisions',check_cross())
dilation.use_wheel=True
dilation.mixed_fibre.cache_clear()
print('residue-class wheel fibers',check_fibers(),'signed collisions',check_cross())
dilation.use_energy=True
print('cross-marginal energy collisions',check_cross())
