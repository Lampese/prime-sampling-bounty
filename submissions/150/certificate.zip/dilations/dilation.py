"""Common signed Fejer kernel at two genuinely different sampling dilations."""
from fractions import Fraction as F
from functools import lru_cache
from math import isqrt

from reflection import near_plus, refine
from prime_sampling.spectrum import fullprice as sr
from prime_sampling.rectangles.old_fibre import arc

use_wheel=False
use_energy=False


def root_upper(x):
    if not x:return F(0)
    shift=max(0,(x.denominator.bit_length()-x.numerator.bit_length()+1)//2)+64
    scale=1<<shift
    return F(1+isqrt(x.numerator*scale*scale//x.denominator),scale)


@lru_cache(maxsize=1024)
def mixed_fibre(a,b,v,pm,sgn,j=2,k=1):
    # j/x+sgn*k/y with coprime coefficients 1 or prime, and j>k.
    if a<=2:return v+1
    if a<=j+k or (j+k)*b>=pm:
        return 1+v//2
    if (j+k)*v*b*b < 2*pm:
        return 1
    spread=1+(j+k)*v*b**4//(2*pm*a*(a+v))
    # The Jacobian is u*sgn-2*v (coordinate names u,v). For +, the
    # sign is constant when b<2a. For -, its magnitude is at most 3b.
    jac=(j*b-k*a if k*b<j*a else 2*(j+k)*b) if sgn==1 else (j+k)*b
    noncol=2+jac*v*v//(2*pm)
    line=max(2*arc(j*v),1+(2*b*v+v*v)//pm)
    best=min(1+v//2,spread,max(noncol,line))
    if not use_wheel:return best
    # A dense residue class is either noncollinear in a larger lattice
    # or furnishes a long segment which restricts all parallel lines.
    area=jac*v*v
    denominator=2*pm
    M=count=1
    for q in (3,5,7,11,13,17,19):
        if q>=a or q>=pm:break
        M*=q
        count*=(q-1)**2 if (j*k)%q==0 else q*(q-1)//2
        single=2+area//(denominator*M*M)
        approx=1+isqrt(area*line//(denominator*M*count))
        for t in (max(1,single),approx,approx+line//count,approx+line//(2*count)):
            bound=max(count*max(t,single),line*(1+area//(denominator*M*t)))
            best=min(best,bound)
        if 2*count>=best:break
    return best


def cross(a,b,v,s,pm,p,h1,h2,r1,r2,peak1,peak2,j=2,classes=2,rad1=None):
    return cross_two(a,b,v,s,pm,p,h1,h2,r1,r2,peak1,peak2,1,j,1,classes,rad1)


@lru_cache(maxsize=20000)
def marginal(a,b,v,pm,p,h,r,j,classes,rad=None):
    if j==1:
        if rad is None:
            if r==F(1,h):rad=h
            else:rad=2*h;r*=2
    elif classes==j:
        rad=j*h;r/=j
    else:
        rad=j*(h+1);r=F(h+1,classes*h*h)
    if 2*rad>=pm:return None
    return r*(1+sr.weighted_near(a,b,v,pm,p,1,rad))


def cross_two(a,b,v,s,pm,p,h1,h2,r1,r2,peak1,peak2,i,j,classes1,classes2,rad1=None):
    # The offset of a non-wrapping base difference fixes both CRT digits.
    mass=min(peak1,peak2,sr.root(r1*r2))/(classes1*classes2)
    near=near_plus(a,b,v,(i*j*(h1+h2+1)+1)//2,pm,p)
    # Both distributions are reflected, so +/- fibres enter equally.
    msum=sum(mixed_fibre(a,b,v,pm,sign,j,i)-1 for sign in (1,-1))
    bound=mass*near
    if use_energy:
        e1=marginal(a,b,v,pm,p,h1,r1,i,classes1,rad1)
        e2=marginal(a,b,v,pm,p,h2,r2,j,classes2)
        if e1 and e2:bound=min(bound,root_upper(e1*e2))
    return bound*F(msum,2*s**3)


def flat_front(W,h,m,n,wt,k,span,ymin,ymax,model,j,bins=48):
    from mixed import coverage
    # j=2 uses e uniform, and exactly one parity reaches each prime.
    unit=W*j
    d=sr.ceildiv(span,unit)+8
    start=(h-d)//2
    peak=(h-1)//2
    def cov(x):
        return (1-wt)*coverage(x,h,m)+wt*coverage(x,h,n)
    if cov(start)<=0:
        return
    def invlog(y):
        return 1/model.b(y,'ln',False)
    eps=model.thetaerr(model.b(ymin,'ln',False))
    def pop(y,N):
        return N*(invlog(y)+invlog(y+N))/2+2*eps*ymax*invlog(y)
    mean=1/cov(peak)
    last=1/cov(start)
    for i in range(1,bins+1):
        cut=start+(peak-start)*i//bins
        # The residue-dependent e may change the coarse index by one. This
        # conservative extra 3 cells covers either endpoint and either e.
        length=unit*(cut-start+4)
        right=max(ymin,ymin+(h-6-cut-start)*unit)
        cap=min(1,(pop(ymin,length)+pop(right,length)+2)/k)
        new=1/cov(cut)
        mean+=F(((last-new)*cap*10**17).__ceil__(),10**17)
        last=new
    phi={2:1,6:2,30:8}[W]
    classes=j if W%j==0 else j-1
    return F(classes*h*phi,k)*mean


def flat_auto(a,b,v,s,pm,p,h,md):
    r=F(1,h)
    near=sr.weighted_near(a,b,v,pm,p,1,h)
    return refine(r*(1+F(md*near,s))/s**2,a,b,v,s,h,pm,p,r,True,h if use_energy else None,joint=use_energy)


def second_auto(a,b,v,s,pm,p,h,md,j,classes):
    if j==classes:
        return flat_auto(a,b,v,s,pm,p,j*h,md)
    # A punctured progression. A difference d leaves at most classes
    # times (h-floor(|d|/j)) representations.
    return F(j*(h+1)**2,classes*h*h)*flat_auto(a,b,v,s,pm,p,j*(h+1),md)
