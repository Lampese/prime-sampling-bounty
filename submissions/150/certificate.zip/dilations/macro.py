"""Price the two-dilation form in the same macro recursion as the reflector."""
from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
import os,runpy,sys

work=Path(__file__).resolve().parents[1]
ap=ArgumentParser(add_help=False)
for k,d in dict(base='weighted-base',selectors='operator-new',repo='prime-sampling',reflection='reflection').items():
    ap.add_argument('--'+k,type=Path,default=work/d)
ap.add_argument('--tuned',action='store_true')
ap.add_argument('--triple',action='store_true')
ap.add_argument('--wheel',action='store_true')
ap.add_argument('--energy',action='store_true')
args,rest=ap.parse_known_args()
sys.path[:0]=[str(x.resolve()) for x in (args.selectors,args.base,args.repo,args.reflection)]
if (work/'zig-cxx.cmd').exists():
    os.environ.setdefault('CXX',str(work/'zig-cxx.cmd'))
    os.environ.setdefault('ZIG_GLOBAL_CACHE_DIR',str(work/'zig-cache'))
    os.environ.setdefault('ZIG_LOCAL_CACHE_DIR',str(work/'zig-local-cache'))
    dll=args.base.resolve()/'mixed.so'
    if dll.is_file():os.environ.setdefault('PRIME_MIXED_SELECTOR_DLL',str(dll))
import dilation,mixed,weighted,reflection
dilation.use_wheel=args.wheel
dilation.use_energy=args.energy
from prime_sampling.spectrum import squarerates as sr
from tuned import selector

previous=weighted.install
def install(mode,model,opposite,selectors,bins,**kwargs):
    cache={}
    costs={}
    def price(mode,s,k,p,front,co,sigma,omega,l1):
        costs['args']=front,co,sigma,omega,l1
        return mixed.price(mode,s,k,p,front,co,sigma,omega,l1)
    def reflected(co,a,b,v,s,h,pm,p,r,rad=None):
        costs['r']=r
        costs['rad']=rad
        return reflection.refine(co,a,b,v,s,h,pm,p,r,True,rad,joint=args.energy)
    def trace(_,wi,hi,mi,ni,ti,l,h,z,ans):
        a,b,v,s,k,span,pm,p=costs['rect']
        W=(2,6,30)[wi]
        d=sr.ceildiv(span,W)+7
        m,n=(max(1,d*i//8) for i in (mi,ni))
        wt=F(ti,4)
        front,co1,sigma,omega,l1=costs['args']
        r1=costs['r']
        A,B=weighted.base(h,l,z)
        peak1=max(A,1-z)/h
        md=min(sr.dirichlet_cap(a,b,v,pm,p),sr.previous_cap(v,b,pm),sr.square_cap(a,b,v,pm,p))
        for h2 in (max(1,h//2),):
            key=W,h2,m,n,wt
            if key not in cache:
                ymin,ymax=opposite()
                fr=dilation.flat_front(W,h2,m,n,wt,k,span,ymin.__floor__(),ymax.__ceil__(),model,2,bins=48)
                cl=dilation.flat_auto(a,b,v,s,pm,p,2*h2,md)
                cache[key]=fr,cl
            fr,co2=cache[key]
            if fr is None or 2*W*(h+h2+4)>=pm:continue
            cx=dilation.cross(a,b,v,s,pm,p,h,h2,r1,F(1,h2),peak1,F(1,h2),rad1=costs.get('rad'))
            if args.triple and W==2 and 5*b<pm:
                for h3 in (max(1,h//3),max(1,2*h//3)):
                    if 6*W*(h+h2+h3+4)>=pm:continue
                    key=('third',h3,m,n,wt)
                    if key not in cache:
                        ymin,ymax=opposite()
                        f3=dilation.flat_front(W,h3,m,n,wt,k,span,ymin.__floor__(),ymax.__ceil__(),model,3,bins=48)
                        c3=dilation.second_auto(a,b,v,s,pm,p,h3,md,3,2)
                        cache[key]=f3,c3
                    f3,c3=cache[key]
                    if not f3:continue
                    c13=dilation.cross(a,b,v,s,pm,p,h,h3,r1,F(1,h3),peak1,F(1,h3),3,2,costs.get('rad'))
                    c23=dilation.cross_two(a,b,v,s,pm,p,h2,h3,F(1,h2),F(1,h3),F(1,h2),F(1,h3),2,3,2,2)
                    for i2,i3 in ((1,1),(2,2),(1,2),(2,1),(1,3)):
                        w2,w3=F(i2,8),F(i3,8)
                        w1=1-w2-w3
                        mf=1/(w1/front+w2/fr+w3/f3)
                        mc=w1*w1*co1+w2*w2*co2+w3*w3*c3+2*(w1*w2*cx+w1*w3*c13+w2*w3*c23)
                        if mf>=front and mc>=co1:continue
                        ans[:]=map(min,ans,mixed.price(mode,s,k,p,mf,mc,sigma,omega,l1))
            for lam in (F(1,8),F(1,4)):
                mixfront=1/((1-lam)/front+lam/fr)
                mixco=(1-lam)**2*co1+lam**2*co2+2*lam*(1-lam)*cx
                if mixfront>=front and mixco>=co1:continue
                rates=mixed.price(mode,s,k,p,mixfront,mixco,sigma,omega,l1)
                ans[:]=map(min,ans,rates)
    weighted.price=price
    if args.tuned:
        kwargs['extra_choices']=selector(selectors,mode,True)
    previous(mode,model,opposite,selectors,bins,trace=trace,co_refiner=reflected,pass_radius=True,**kwargs)
    saved=model.rates
    def rates(*rect):
        cache.clear()
        costs['rect']=rect
        return saved(*rect)
    model.rates=rates
weighted.install=install
sys.argv=['hyperbola.py','--repo',str(args.repo),'--selectors',str(args.selectors),*rest]
runpy.run_path(str((args.base/'hyperbola.py').resolve()),run_name='__main__')
