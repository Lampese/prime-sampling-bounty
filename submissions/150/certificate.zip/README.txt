Run from this directory with Python 3.10 or later: python -B verify_all.py --require-bounty
The checker runs the first-window proof replay, separate rational per-cell ledgers, and the unmodified upstream grade for [152,651/4].
It prints the exact union and exits with code 2 if there is a gap. Stored estimates have proof sources and may be regenerated separately.
Each hash in analytic-coverage/selected-inputs and spectrum-inputs identifies the exact input used.
