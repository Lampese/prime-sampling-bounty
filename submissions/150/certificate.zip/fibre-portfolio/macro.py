"""Reprice Abel macro bands with the angular fibre, actual endpoint measure, and weighted bases."""
from pathlib import Path
from argparse import ArgumentParser
import runpy,sys

here=Path(__file__).resolve().parent
work=here.parent
cli=ArgumentParser(add_help=False)
cli.add_argument('--repo',type=Path,default=work/'prime-sampling')
opt,_=cli.parse_known_args()
sys.path[:0]=[str(work/'fibre-lines'),str(opt.repo.resolve()),str(work/'weighted-base')]
import fast_fibre
if '--directional' in sys.argv:
    sys.argv.remove('--directional')
    import directional as fast_fibre
if '--both-axes' in sys.argv:
    sys.argv.remove('--both-axes')
    sys.path.insert(0,str(work/'operator-new'))
    from functools import lru_cache
    from prime_sampling.rectangles import sieved_lift
    from prime_sampling.spectrum import squarerates as sr
    import weighted
    fast_fibre.calculate=lru_cache(maxsize=65536)(fast_fibre.calculate)
    old_install=sieved_lift.install
    def patch_fibre(model):
        old_install(model)
        previous=sr.square_cap
        @lru_cache(maxsize=65536)
        def patched(a,b,v,p0,p1):
            val=previous(a,b,v,p0,p1)
            if 194<a<b<p0<=p1<2*p0 and 0<v<=b and p0<=10**6*b*b and b*b<=2*p1:
                val=min(val,fast_fibre.calculate(a,b,v,p0,p1))
            return val
        sr.square_cap=patched
    sieved_lift.install=patch_fibre
    old_weighted=weighted.install
    def broaden(*args,**kw):
        previous=kw.get('include')
        kw['include']=lambda a,b,v,s,k,span,ys:previous(a,b,v,s,k,span,ys) or (a<=ys[1] and ys[0]<=b)
        return old_weighted(*args,**kw)
    weighted.install=broaden
sys.modules['smooth_wide']=fast_fibre
if '--joint-reflection' in sys.argv:
    sys.argv.remove('--joint-reflection')
    sys.argv+=['--wide','--sharp','--profile','--tuned','--joint','--crt','--family',
               '--near-shape',str(work/'near-lines')]
    sys.path.insert(0,str(work/'reflection'))
    runpy.run_path(str(work/'reflection'/'macro.py'),run_name='__main__')
    sys.exit()
sys.argv+=['--wide','--shape-bound']
runpy.run_path(str(work/'weighted-base'/'hyperbola.py'),run_name='__main__')
