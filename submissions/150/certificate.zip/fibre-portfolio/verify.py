"""Validate certified geometry, reprice the independent strip ledger, and optionally regenerate spectra."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
from tempfile import TemporaryDirectory
import json,os,shutil,subprocess,sys

HERE=Path(__file__).resolve().parent
WORK=HERE.parent


def records(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def canonical_hash(value):
    return sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode('ascii')).hexdigest()


def compile_shape(cxx,dest):
    source=WORK/'fibre-lines'/'main_shape.cpp'
    subprocess.run([cxx,'-O3','-std=c++17',str(source),'-o',str(dest)],check=True)
    if not dest.is_file():raise RuntimeError('C++17 lattice verifier did not compile')


def main():
    cli=ArgumentParser(description=__doc__)
    cli.add_argument('--repo',required=True,type=Path)
    cli.add_argument('--cxx',help='a C++17 compiler or compiler wrapper; default is CXX or a compiler on PATH')
    cli.add_argument('--rebuild',action='store_true',help='regenerate every strip spectrum and direct macro')
    cli.add_argument('--only',nargs='+',help='regenerate just the named spectrum or direct macro JSON files')
    cli.add_argument('--macro',type=int,help='restrict --only to a particular macro within each source')
    cli.add_argument('--out',type=Path,help='write the certified macro upper costs for the portfolio alone')
    args=cli.parse_args()
    if not __debug__:raise RuntimeError('Run the verifier without -O')
    repo=args.repo.resolve()
    if not (repo/'prime_sampling'/'accounting'/'ledger.py').is_file():raise ValueError('Invalid upstream checkout')
    cxx=args.cxx or os.environ.get('CXX') or shutil.which('c++') or shutil.which('g++') or shutil.which('clang++')
    if not cxx:raise RuntimeError('Provide the C++17 compiler using --cxx or CXX')
    if Path(cxx).is_file():cxx=str(Path(cxx).resolve())
    spec=records(HERE/'recipes.json')
    snapshots={x['file']:records(HERE/x['file']) for x in spec}
    expected_all=records(HERE/'standalone-macros.json')
    improved=records(HERE/'improved-macros.json')
    if args.only and any(name not in {x['file'] for x in spec} for name in args.only):raise ValueError('Unknown --only file')
    if args.macro is not None and not args.only:raise ValueError('--macro requires --only')
    with TemporaryDirectory() as folder:
        tmp=Path(folder)
        exe=tmp/('main_shape.exe' if os.name=='nt' else 'main_shape')
        compile_shape(cxx,exe)
        env=dict(os.environ,CXX=cxx,PRIME_SHAPE_EXE=str(exe),PYTHONOPTIMIZE='',PYTHONPATH=str(repo))
        env.pop('PYTHONOPTIMIZE',None)
        def run(cmd,*params,quiet=False):
            subprocess.run([sys.executable,'-B',str(cmd),*map(str,params)],check=True,env=env,
                           stdout=subprocess.DEVNULL if quiet else None)
        # Schedules are disjunctions independent of the rectangle, verified by returning zero for every shape.
        for row in records(WORK/'fibre-lines'/'shape-schedules.json'):
            ticks=row['ticks']
            if len(ticks)!=24 or any(type(v)!=int or not 0<=v<=40 for v in ticks):raise ValueError('Invalid schedule')
            mask=' '.join(str(int(k>v)) for v in ticks for k in range(41))
            if int(subprocess.check_output([str(exe),'--price'],input=mask,text=True))!=0:
                raise ValueError('The schedule fails to cover every normalized lattice')
        print('All angular schedules cover the determinant-one shape space.',flush=True)
        run(HERE/'check_directional.py','--repo',repo)
        for item in spec:
            snapshot=snapshots[item['file']]
            if canonical_hash(snapshot)!=item['sha256_json']:raise ValueError('Saved JSON differs: '+item['file'])
            if not args.rebuild and item['file'] not in (args.only or []):continue
            limits=item['macros'] if args.macro is None else [args.macro]
            if any(m not in item['macros'] for m in limits):raise ValueError('Macro outside saved source')
            temp=tmp/item['file']
            strips=item['program']=='rows.py'
            run(HERE/item['program'],'--repo',repo,*item['options'],'--macro' if strips else '--macros',*limits,'--out',temp)
            got=records(temp)
            if strips:
                grid=snapshot['grid']
                reference=[r for r in snapshot['rows'] if 200*r[0]//grid in limits]
                envelopes=[r for r in snapshot['envelopes'] if 200*r[0]//grid in limits]
                if sorted(got['rows'])!=sorted(reference) or sorted(got['envelopes'])!=sorted(envelopes):
                    raise ValueError('Reconstructed strip differs: '+item['file'])
            else:
                if got!={str(m):snapshot[str(m)] for m in limits}:raise ValueError('Reconstructed macro differs: '+item['file'])
            print('Regenerated',item['file'],flush=True)
        strips=[HERE/x['file'] for x in spec if x['program']=='rows.py']
        native_grids=set()
        for path in strips:
            data=records(path);grid=data['grid']
            if grid not in (1600,2400,3200,4800) and grid not in native_grids:
                run(WORK/'wide-coverage'/'native.py',path,tmp/f'native-{grid}','--repo',repo,quiet=True)
                print('Rebuilt original nine-column geometry at grid',grid,flush=True)
                native_grids.add(grid)
        combined=tmp/'strips.json'
        run(HERE/'strip_costs.py','--repo',repo,'--native-dir',tmp,'--inputs',*strips,'--out',combined)
        prices=records(combined)
        for item in spec:
            if item['program']=='rows.py':continue
            for macro,branches in snapshots[item['file']].items():
                for branch,value in branches.items():
                    row=prices.setdefault(macro,{})
                    row[branch]=min(row.get(branch,value),value)
        if prices!=expected_all:raise ValueError('Independent macro ledger differs')
        if any(prices[m][b]!=n for m,row in improved.items() for b,n in row.items()):raise ValueError('Published macro cost differs')
        if args.out:args.out.write_text(json.dumps(improved,indent=2)+'\n',encoding='ascii')
        print('Exact standalone macro costs reproduced.',flush=True)


if __name__=='__main__':main()
