"""Snapshot completed, strictly improving direct runs and reproducible strip inputs."""
from copy import deepcopy
from pathlib import Path
import json
from verify import canonical_hash

here=Path(__file__).resolve().parent
def read(p):return json.loads((here/p).read_text())
def write(p,data):(here/p).write_text(json.dumps(data,indent=2)+'\n',encoding='ascii')
audit=read('all-micros-audit.json')
prices=read('strip-macros.json')
grids=[1600,2400,3200,4800]
if (here/'strip-macros-five.json').exists():
    extra=read('strip-macros-five.json')
    if any(v<prices[m][b] for m,row in extra.items() for b,v in row.items()):
        prices=extra;grids.append(6400)
spec=[]
for grid in grids:
    file=f'strip-{grid}.json';r=read(file)
    directional=grid not in (2400,3200)
    r['fibre_model']='directional-schedule' if directional else 'angular-schedule'
    (here/file).write_text(json.dumps(r),encoding='ascii')
    options=['--grid',str(grid),'--groups',str(8 if grid>=4800 else 4)]
    if directional:options+=['--directional']
    spec.append(dict(file=file,program='rows.py',options=options,macros=sorted({200*x[0]//grid for x in r['rows']},reverse=True),
                     sha256_json=canonical_hash(r)))
origins={}
old=audit['incumbents']
samples=[('macro-six.json','weighted-angular.json',[]),
         ('directional-six.json','weighted-directional.json',['--directional']),
         ('joint-six.json','reflection-directional.json',['--directional','--joint-reflection'])]
own=deepcopy(prices)
for source,_,_ in samples:
    if not (here/source).is_file():continue
    for m,row in read(source).items():
        for b,n in row.items():
            current=own.setdefault(m,{}).get(b,old[m][b])
            if n<min(old[m][b],current):
                own[m][b]=n
                origins[m,b]=source
for src,name,opts in samples:
    selected={m:{b:own[m][b]} for (m,b),v in origins.items() if v==src}
    if not selected:continue
    write(name,selected)
    spec.append(dict(file=name,program='macro.py',options=['--mode','six',*opts],
                     macros=sorted(map(int,selected),reverse=True),sha256_json=canonical_hash(selected)))
write('recipes.json',spec)
own={m:r for m,r in own.items() if r}
write('standalone-macros.json',own)
improved={m:{b:n for b,n in row.items() if n<old[m][b]} for m,row in own.items()}
improved={m:r for m,r in improved.items() if r}
write('improved-macros.json',improved)
summary={}
for b in ('with3','without3'):
    total0=sum(r[b] for r in old.values())
    gain=sum(old[m][b]-r[b] for m,r in improved.items() if b in r)
    summary[b]=dict(previous=total0,new=total0-gain,saved=gain)
write('summary.json',summary)
manifest=['fibre-portfolio/'+x for x in ['verify.py','rows.py','macro.py','directional.py','strip_costs.py','check_directional.py',
                                         'recipes.json','standalone-macros.json','improved-macros.json','summary.json','directional-proof.md']]
manifest.extend('fibre-portfolio/'+x['file'] for x in spec)
manifest.extend('fibre-lines/'+x for x in ['fast_fibre.py','angular_fibre.py','shaped_fibre.py','smooth_cascade.py',
                                            'smooth_split.py','smooth_tail.py','smooth_wide.py','local_divisors.py',
                                            'main_shape.cpp','shape-schedules.json','main-shape-proof.md','angular-proof.md','proof.md','smooth-proof.md'])
(here/'manifest.txt').write_text('\n'.join(manifest)+'\n',encoding='ascii')
print(json.dumps(summary))
