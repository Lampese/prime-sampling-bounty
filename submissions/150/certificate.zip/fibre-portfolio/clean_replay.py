"""Check the portable overlay in an independent temp copy of the preceding first-window package."""
from argparse import ArgumentParser
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile
import os,shutil,subprocess,sys

here=Path(__file__).resolve().parent
work=here.parent
cli=ArgumentParser()
cli.add_argument('--repo',type=Path,required=True)
cli.add_argument('--cxx',required=True)
cli.add_argument('--out',type=Path,required=True)
args=cli.parse_args()
with TemporaryDirectory() as dirname:
    root=Path(dirname)
    with ZipFile(work.parent/'outputs'/'prime-sampling-first-window.zip') as z:z.extractall(root)
    for name in (here/'manifest.txt').read_text().splitlines():
        source=work/name;dest=root/name
        dest.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(source,dest)
    env=dict(os.environ,PYTHONIOENCODING='utf-8')
    if Path(args.cxx).resolve()==(work/'zig-cxx.cmd').resolve():
        env.setdefault('ZIG_GLOBAL_CACHE_DIR',str(work/'zig-cache'))
        env.setdefault('ZIG_LOCAL_CACHE_DIR',str(work/'zig-local-cache'))
    output=subprocess.check_output([sys.executable,'-B',str(root/'fibre-portfolio'/'verify.py'),
                                   '--repo',str(args.repo.resolve()),'--cxx',str(Path(args.cxx).resolve())],cwd=root,
                                  encoding='utf8',env=env)
    if 'Exact standalone macro costs reproduced.' not in output:raise RuntimeError('Missing replay result')
    args.out.write_text(output,encoding='utf8')
