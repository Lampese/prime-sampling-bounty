"""Select genuine per-macro improvements over the recorded merged micros and whole incumbent."""
from argparse import ArgumentParser
from pathlib import Path
import json

here=Path(__file__).resolve().parent
cli=ArgumentParser()
cli.add_argument('--micro',type=Path,default=here/'all-micros-audit.json')
cli.add_argument('--direct',nargs='*',type=Path,default=[])
cli.add_argument('--out',type=Path,required=True)
cli.add_argument('--detail',type=Path,required=True)
args=cli.parse_args()
ref=json.loads(args.micro.read_text())
sources={p.name:json.loads(p.read_text()) for p in args.direct}
details={};costs={};total={}
for branch in ('with3','without3'):
    before=after=0
    for m,old in ref['incumbents'].items():
        options=[(old[branch],ref['incumbent_sources'][m][branch])]
        if branch in ref['costs'].get(m,{}):options.append((ref['costs'][m][branch],'merged new micros'))
        options.extend((rec[m][branch],name) for name,rec in sources.items() if branch in rec.get(m,{}))
        value,which=min(options)
        before+=old[branch];after+=value
        if value<old[branch]:
            costs.setdefault(m,{})[branch]=value
            details.setdefault(m,{})[branch]=dict(before=old[branch],after=value,saved=old[branch]-value,
                    previous=ref['incumbent_sources'][m][branch],source=which)
    total[branch]=dict(before=before,after=after,saved=before-after)
args.out.write_text(json.dumps(costs,indent=2)+'\n',encoding='ascii')
args.detail.write_text(json.dumps(dict(improvements=details,total=total,incumbent_archive=ref['archive_sha256']),indent=2)+'\n',encoding='ascii')
print(json.dumps(total))
