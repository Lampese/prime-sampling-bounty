"""Partition a strip's true mass separately from the rectangle used for its Fourier bound."""
from functools import lru_cache
from fractions import Fraction as F
from prime_sampling.rectangles import boxes
from prime_sampling.accounting import ledger


def initialize(low,high):
    boxes.initialize(low,high)
    boxes.rates=lambda *unused:(F(1),F(1))


@lru_cache(maxsize=None)
def geometry(grid,idx,steps):
    J=ledger.J
    u=F(idx,grid);v=F(idx+1,grid)
    restricted=sum(boxes.mass(u+(v-u)*j/steps,u+(v-u)*(j+1)/steps) for j in range(steps))
    inside=boxes.inner(u,v)
    uncovered=boxes.collar(u,v,*inside,steps=steps)
    extra=boxes.outer(u,v,steps=steps)[2]
    return [(x*J).__ceil__() for x in (restricted,uncovered,extra)]


def tighten(row,grid,steps):
    m,h,e=map(min,zip(row[5:8],geometry(grid,row[0],steps)))
    if row[8]>m:raise ValueError('The original inner lower mass exceeds the new strip mass')
    return row[:5]+[m,min(h,m),e,row[8]]
