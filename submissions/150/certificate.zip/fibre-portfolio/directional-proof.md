# Endpoint-aware divisor bound for the reciprocal-difference fibre

Use the hypotheses, signed-line determinant, and 24 angle and residue choices of fibre-lines/main-shape-proof.md and fibre-lines/angular-proof.md. This note sharpens the real-variable factors when the actual small-side endpoints both belong to one interval of width \(V\), contained in \([A,B]\). It applies for every admissible prime and every nonzero shift.

Put \(x=Bd,\ y=|u|,\ G=\max(x,y),\ q=\min(x,y)/G,\ \alpha=A/B,\ v=V/B\). Let \(N=(dt+y)(ds-y)\), where \(t,s\) are the two prime endpoints. If \(x\ge y\), then \(dt+y\ge(\alpha+q)G\). If \(x\le y\), then \(dt+y\ge(1+\alpha q)G\ge(\alpha+q)G\). This gives a common minimum denominator even when \(\alpha\) is small in a broad two-dimensional macro rectangle.

The independent endpoint bound is \(|N|/G^2\le(1+q)(1-\alpha q)\). The common short interval also gives
\[
 N=d^2st-y^2+dy(s-t),\qquad |s-t|\le V .
\]
When \(x\ge y\), its positive and negative parts are bounded, after scaling by \(G^2\), by \(1-q^2+vq\) and \(q^2-\alpha^2+vq\). When \(x\le y\), the corresponding bounds are \(q^2-1+vq\) and \(1-\alpha^2q^2+vq\). Thus for all \(q\ge\tau\) in one of the certified angular sectors we may use
\[
 U\ \ge\ \min\left\{\max_{\tau\le q\le1}(1+q)(1-\alpha q),\
 \max\left(1-\alpha^2+v,\ \max_{\tau\le q\le1}(1-\alpha^2q^2+vq)\right)\right\}.
\]
Both maxima of concave quadratics have rational vertices. Clamp each vertex to its interval, evaluate exactly, and round the resulting rational upward in the fixed menu in directional.py.

For \(n=2k+1\ge7,\ T=k(k+1)/2,\ M=kn\), the changing term of the ordinary determinant bound gets a factor at most \(U^{T/M}\alpha/(\alpha+\tau)\) compared with the previous unrestricted estimate. The original estimate also remains valid. In the smooth-part cascade use the same true \(U\) in the test \(|N|/m\le U G^2/z^s\), the good-line factor \((U/z^s)^{T/M}\), and the bad-line integer threshold \(\lfloor\log_2\lfloor U g^2/z^s\rfloor\rfloor\) for \(G\ge g\). After the good-line factor, its remaining geometric reduction is \(\alpha/(\alpha+\tau)\). Since \(T/M\le 2/7\), one common upper coefficient for both applications is
\[
 \min\!\left(1,\ \frac{\alpha}{\alpha+\tau}\max(1,U^{2/7})\right).
\]
The rational upper seventh root is certified by integer multiplication. This factor changes only the width-dependent term. The fixed number of points per occupied line is priced in full. The same proof covers every previously counted bad subset. The four schedules are verified geometrically at runtime by fast_fibre.schedules().

## Rectangle and ledger replay

Run rows.py to produce a strip JSON with the original nine-column accounting. It invokes the certified smooth_rows construction with shared mixed-trapezoid selections, the established hexagonal shape neighbour bound, and a fresh grouped uniform fibre bound. For ordinary angular pricing it selects fast_fibre.calculate; --directional selects directional.calculate. No imported fibre prices or hypothetical tables are accepted. Regenerate the enclosed strip-2400.json and strip-3200.json with --grid 2400 or 3200, --groups 4 --macro 99 98 97 96 95 94 --out FILE. The strip-1600.json table also selects --directional.

For two-dimensional direct macro costs, macro.py retains the weighted-base construction with 96 frequency bins, both actual sampled endpoints, nonnegative Abel bounds, a depth-four dyadic recursion, and the established near-neighbour shape coverage. Only the reciprocal-difference cap on the smaller input axis is replaced. Both the old and new caps are uniform for every allowed choice of endpoint primes. Use --mode six --macros followed by the listed integer macro indices and --out FILE; add --directional for the new two-factor estimate.

The comparison in audit.py extracts the actual packaged first-window certificate and adds the two registered dilation energy macro tables. The prior and new runs use the same upstream checkout and the original integer ledger. Fine-grid proposals merge rates by frequency column, retain the prior mass columns, then close the six-character rates using the pair bounds. At grid 2400 it also merges all prior native tables at that grid. Independent two-dimensional macro bounds compete only after the original within-macro shortest path. Each reported saving subtracts from the actual previous macro minimum, including weighted, dilation, reflection, and native alternatives. No isolated-row estimate is substituted for the first-window verification.

## Portable replay

From a directory containing the research bundle, run

    python -B fibre-portfolio/verify.py --repo /path/to/prime-sampling

The verifier accepts --cxx /path/to/compiler or a CXX environment value and otherwise looks for a C++17 compiler on PATH. It compiles fibre-lines/main_shape.cpp in a temporary directory, independently rechecks the lattice schedules and the interval bounds, emits the unregistered grid-6400 geometry with the original checkout, and computes standalone macro prices solely from the frozen inputs. Its --out option writes the registered improvements in ordinary macro-JSON format. The --rebuild switch also regenerates all spectrum and direct-macro source data. For a single source use --only strip-4800.json --macro 99 or a direct-macro file and a macro that its recipe lists.

The exact programs, options, indices, and canonical SHA-256 are recorded in recipes.json. Canonical JSON here uses sorted keys, ASCII output, and comma and colon separators without spaces. The extra grids 4800 and 6400 focus on macro 99, whose contracted product region changes quickly. Both use --groups 8 and the improved two-factor estimate. Each new fine-strip bound is verified against its own actual primes and its unchanged original mass columns. strip_costs.py computes a shortest path using only certified new strips; it returns the winning endpoint costs without needing the earlier archive. Its table matches the combined live ledger on all of the improving small-strip entries. The optional direct two-dimensional prices may be smaller on other macros.
