"""Sharper simultaneous factor size and minimum-denominator bounds in angular sectors."""
from fractions import Fraction as F
from functools import cache
from math import isqrt
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'fibre-lines'))
from fast_fibre import schedules,price_mode
from shaped_fibre import MODES
from smooth_wide import policies


@cache
def weight_bound(n,d):
    # Upper rational seventh root of (n/d)^2 for n/d >= 1.
    if n<=d:return F(1)
    scale=10**6
    target=n*n*scale**7
    lo=scale;hi=2*lo
    while hi**7*d*d<target:hi*=2
    while hi-lo>1:
        mid=(hi+lo)//2
        if mid**7*d*d<target:lo=mid
        else:hi=mid
    return F(hi,scale)


@cache
def factors(A,B,V,tier):
    a=F(A,B);t=F(tier,4);v=F(V,B)
    # Endpoints arbitrary in [A,B] and sharing a subinterval of width V.
    q=min(F(1),max(t,(1-a)/(2*a)))
    upper=(1+q)*(1-a*q)
    # The larger of the two absolute signed-product bounds when u>=Bd or u<=Bd.
    c=min(F(1),max(t,v/(2*a*a)))
    upper=min(upper,max(1-a*a*c*c+v*c,1-a*a+v))
    ceilings=(F(1,4),F(3,8),F(1,2),F(5,8),F(3,4),F(7,8),F(1),
              F(65,64),F(17,16),F(9,8),F(5,4),F(3,2),F(2),F(4))
    U=next(q for q in ceilings if q>=upper)
    discount=min(F(1),a*weight_bound(U.numerator,U.denominator)/(a+t))
    return (discount.numerator,discount.denominator),(U.numerator,U.denominator)


def calculate(A,B,V,p0,p1,detail=False):
    norm=isqrt(p1*B)+1
    if 5*norm>=2*p0:return (V+1,None) if detail else V+1
    start=max(B,min(A*A,-(-p0//(B+V))))
    ratio=max(1,V//isqrt(norm))
    row=min(schedules(),key=lambda r:F(max(r['ratio'],ratio),min(r['ratio'],ratio)))
    cluster=policies(ratio)
    worst=0
    for j,tick in enumerate(row['ticks']):
        if tick==0:continue
        tier,index=divmod(j,6)
        arch,residual=factors(A,B,V,tier)
        hi=-(-norm*tick//16)
        result=price_mode(A,B,V,p0,start,hi,MODES[index]+(True,31),cluster,arch,residual,worst)
        worst=max(worst,result)
    cap=min(worst,V+1)
    return (cap,row['strip']) if detail else cap
