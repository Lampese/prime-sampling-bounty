"""Price each covered macro from the supplied new strips and official mass columns alone."""
from argparse import ArgumentParser
from fractions import Fraction as F
from math import lcm
from pathlib import Path
from tempfile import TemporaryDirectory
import json,sys

HERE=Path(__file__).resolve().parent
WORK=HERE.parent
cli=ArgumentParser()
cli.add_argument('--repo',type=Path,default=WORK/'prime-sampling')
cli.add_argument('--inputs',nargs='+',required=True,type=Path)
cli.add_argument('--out',type=Path,required=True)
cli.add_argument('--native-dir',type=Path,default=HERE)
cli.add_argument('--mass-steps',type=int)
args=cli.parse_args()
sys.path[:0]=[str(args.repo.resolve()),str(WORK/'spectral-coupling'),str(WORK/'harmonic-research'/'predecessor')]
from prime_sampling.accounting import ledger
from tree_sieve_trial import new_bank
from coset_split import close_six
ledger.bank=new_bank
geom=WORK/'harmonic-research'/'target'
indexed={(kind,grid):geom/path for kind,grid,path in json.loads((geom/'tables.json').read_text())}
indexed.update({(kind,2400):WORK/'native-first'/'2400'/(kind+'.dat') for kind in ('six','pair')})
for source in args.native_dir.glob('native-*/cell.json'):
    for item in json.loads(source.read_text())['tables']:
        indexed[item['kind'],item['grid']]=source.parent/item['file']
low,high=F(150),F(4801,32)
if args.mass_steps:
    if not 1<=args.mass_steps<=128:raise ValueError('Unsupported geometric partition')
    import micro_mass
    micro_mass.initialize(low,high)
inputs=[json.loads(p.read_text()) for p in args.inputs]
grids=[data['grid'] for data in inputs];assert len(set(grids))==len(grids)
unit=lcm(*grids);result={}
with TemporaryDirectory() as tmp:
    valid={}
    for obj in inputs:
        grid=obj['grid'];rows={i:(pair,six) for i,pair,six in obj['rows']}
        assert F(obj['left'])==low and F(obj['right'])==high and not obj.get('hypothetical')
        inputs2={}
        for kind,position in [('pair',0),('six',1)]:
            base=[list(map(int,s.split())) for s in indexed[kind,grid].read_text().splitlines()]
            for pos,row in enumerate(base):
                i=row[0]
                row[1:5]=rows[i][position] if i in rows else [10**10]*4
                if i in rows and args.mass_steps:base[pos]=micro_mass.tighten(row,grid,args.mass_steps)
            inputs2[kind]=base
        inputs2['six']=[close_six(p,s) for p,s in zip(inputs2['pair'],inputs2['six'],strict=True)]
        for kind,base in inputs2.items():
            path=Path(tmp)/f'{kind}-{grid}.dat'
            path.write_text(''.join(' '.join(map(str,row))+'\n' for row in base),encoding='ascii')
            for branch in ('with3','without3'):
                if branch=='without3' and kind=='six':continue
                fees=ledger.strip_costs(path,grid,kind,ledger.rank(high,branch))
                valid[kind,grid,branch]={i:fees[i-67*grid//200] for i in rows}
    for j in range(67,100):
        start,end=j*unit//200,(j+1)*unit//200
        for branch in ('with3','without3'):
            graph={end:0}
            for a in range(end-1,start-1,-1):
                values=[]
                for (_,g,b),fees in valid.items():
                    step=unit//g
                    if b==branch and a%step==0 and a+step in graph and a//step in fees:
                        values.append(fees[a//step]+graph[a+step])
                if values:graph[a]=min(values)
            if start in graph:result.setdefault(str(j),{})[branch]=graph[start]
args.out.write_text(json.dumps(result,indent=2)+'\n',encoding='ascii')
print(json.dumps(result))
if args.mass_steps:
    import os
    if os.name=='nt':
        import _ctypes
        from prime_sampling.spectrum import squarerates as sr
        _ctypes.FreeLibrary(sr._lib._handle)
