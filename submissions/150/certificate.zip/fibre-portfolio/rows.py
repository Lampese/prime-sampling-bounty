"""Generate strip tables with the verified angular schedules and mixed trapezoidal kernels."""
from pathlib import Path
from argparse import ArgumentParser
import json,runpy,sys

here=Path(__file__).resolve().parent
work=here.parent
cli=ArgumentParser(add_help=False)
cli.add_argument('--repo',type=Path,default=work/'prime-sampling')
cli.add_argument('--out',type=Path,required=True)
cli.add_argument('--directional',action='store_true')
opt,_=cli.parse_known_args()
sys.path[:0]=[str(work/'fibre-lines'),str(opt.repo.resolve())]
import fast_fibre
if opt.directional:
    sys.argv.remove('--directional')
    import directional as fast_fibre
if '--hypothetical' in sys.argv or '--caps' in sys.argv:raise ValueError('Rebuild the uniform caps from the lattice schedules')
sys.modules['shaped_fibre']=fast_fibre
sys.argv+=['--shape-fibre','--near-shape','--shared-shapes','--trapezoid']
runpy.run_path(str(work/'hyperbola-next'/'smooth_rows.py'),run_name='__main__')
data=json.loads(opt.out.read_text())
data['fibre_model']='directional-schedule' if opt.directional else 'angular-schedule'
opt.out.write_text(json.dumps(data),encoding='ascii')
