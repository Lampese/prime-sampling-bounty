"""Price certified new micros and direct macros against the actual merged first-window incumbent."""
from argparse import ArgumentParser
from hashlib import sha256
from io import BytesIO
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile
import json,os,subprocess,sys

HERE=Path(__file__).resolve().parent
WORK=HERE.parent
REPO=WORK/'prime-sampling'
ARCHIVE=WORK.parent/'outputs'/'prime-sampling-first-window.zip'
sys.path[:0]=[str(REPO),str(WORK/'spectral-coupling')]
from coset_split import close_six


def write_native(root,data):
    grid=data['grid']
    native=root/'native-first'
    # Same exact nine-column geometry, componentwise minimum of new and archived rates.
    sources=[p.parent for p in native.glob('*/cell.json')
             if int(json.loads(p.read_text())['tables'][0]['grid'])==grid]
    assert sources,grid
    output=native/f'portfolio-{grid}'
    output.mkdir()
    merged={}
    for kind in ('pair','six'):
        for folder in sources:
            rows=[list(map(int,s.split())) for s in (folder/f'{kind}.dat').read_text().splitlines()]
            if kind not in merged:merged[kind]=rows;continue
            for cur,other in zip(merged[kind],rows,strict=True):
                assert cur[:1]+cur[5:]==other[:1]+other[5:]
                cur[1:5]=map(min,zip(cur[1:5],other[1:5]))
    for idx,pair,six in data['rows']:
        for mode,columns in [('pair',pair),('six',six)]:
            cur=merged[mode][idx-67*grid//200]
            assert cur[0]==idx
            cur[1:5]=map(min,zip(cur[1:5],columns))
    merged['six']=[close_six(p,s) for p,s in zip(merged['pair'],merged['six'],strict=True)]
    for kind,data in merged.items():
        (output/f'{kind}.dat').write_text(''.join(' '.join(map(str,row))+'\n' for row in data),encoding='ascii')
    (output/'cell.json').write_bytes((sources[0]/'cell.json').read_bytes())


def load_table(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def main():
    cli=ArgumentParser()
    cli.add_argument('--sources',type=Path,nargs='*',default=[])
    cli.add_argument('--macros',type=Path,nargs='*',default=[])
    cli.add_argument('--out',type=Path,required=True)
    args=cli.parse_args()
    payload=ARCHIVE.read_bytes()
    with TemporaryDirectory(dir=HERE) as tmp:
        root=Path(tmp)
        with ZipFile(BytesIO(payload)) as z:z.extractall(root)
        geo=root/'hyperbola-next'
        records={x['file']:load_table(geo/x['file']) for x in load_table(geo/'recipes.json')}
        for mode in ('six','pair'):
            src=WORK/'dilations'/f'macro-{mode}-energy.json'
            records['dilations/'+src.name]=load_table(src)
        def price(micro):
            out=root/(micro+'.json')
            result=subprocess.check_output([sys.executable,'-B',str(geo/'compare.py'),'--repo',str(REPO),
                                            '--combined','--out',str(out)],encoding='utf8')
            return load_table(out)
        initial=price('former')
        previous={};winners={}
        def best(raw,j,b,more):
            opts=[(raw[j][b],'merged micros')]+[(r[j][b],name) for name,r in more.items() if b in r.get(j,{})]
            return min(opts)
        for j,row in initial.items():
            previous[j]={};winners[j]={}
            for b in row:previous[j][b],winners[j][b]=best(initial,j,b,records)
        for s,data in enumerate(map(load_table,args.sources)):
            assert not data.get('hypothetical') and data['left']=='150' and data['right']=='4801/32'
            grid=data['grid']
            if grid in (1600,3200,4800):
                (geo/f'smooth-grid-new-portfolio-{s}.json').write_text(json.dumps(data),encoding='ascii')
            else:write_native(root,data)
        updated=price('updated') if args.sources else initial
        for path in args.macros:records['portfolio/'+path.name]=load_table(path)
        fees={};savings={}
        for j,row in initial.items():
            for b in row:
                val,winner=best(updated,j,b,records)
                if val<previous[j][b]:
                    fees.setdefault(j,{})[b]=val
                    savings.setdefault(j,{})[b]=dict(before=previous[j][b],after=val,saving=previous[j][b]-val,
                                                       predecessor=winners[j][b],winner=winner)
        report={'archive_sha256':sha256(payload).hexdigest(),
                'source_files':[p.name for p in args.sources],'macro_files':[p.name for p in args.macros],
                'incumbents':previous,'incumbent_sources':winners,'improvements':savings,'costs':fees,'total':{}}
        for b in ('with3','without3'):
            before=sum(row[b] for row in previous.values())
            saved=sum(row.get(b,{}).get('saving',0) for row in savings.values())
            report['total'][b]=dict(before=before,after=before-saved,saving=saved)
            print(b,report['total'][b])
        args.out.write_text(json.dumps(report,indent=2)+'\n',encoding='ascii')
        print(json.dumps(savings,indent=1))


if __name__=='__main__':main()
