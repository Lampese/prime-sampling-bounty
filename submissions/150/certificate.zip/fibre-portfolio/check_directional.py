from fractions import Fraction as F
from pathlib import Path
from argparse import ArgumentParser
import sys
cli=ArgumentParser()
cli.add_argument('--repo',type=Path,default=Path(__file__).resolve().parents[1]/'prime-sampling')
args=cli.parse_args()
sys.path.insert(0,str(args.repo.resolve()))
from directional import factors


if __name__=='__main__':
    checks=0
    checked=set()
    for B in (7,13,23):
        for A in range(1,B):
            for V in sorted(set((1,max(1,(B-A)//2),B-A))):
                for d in range(1,4):
                    for u in range(1,4*B+1):
                        G=max(B*d,u)
                        sector=min(3,4*min(B*d,u)//G)
                        k=F(sector,4);alpha=F(A,B)
                        arch,residual=factors(A,B,V,sector);U=F(*residual)
                        q=F(min(B*d,u),G)
                        key=(A,B,V,sector)
                        if key not in checked:
                            for n in (7,13,25,49,97):
                                size=n//2;num=size+1;den=2*n
                                direct=F(arch[0],arch[1])**den
                                assert direct>=1 or direct>=(alpha/(alpha+k))**den*U**num
                            checked.add(key)
                        # Bilinear extrema occur at the endpoints of each horizontal slice.
                        for t in range(A,B+1):
                            for s in (max(A,t-V),min(B,t+V)):
                                N=(d*t+u)*(d*s-u)
                                assert abs(N)<=U*G**2 and d*t+u>=(alpha+q)*G
                                checks+=1
    print('Certified endpoint and coefficient comparisons',checks)
