"""Small exact checks of disjoint ownership, bin multiplicities and the clipped last prime."""
from argparse import ArgumentParser
from collections import Counter
from fractions import Fraction as F
from itertools import combinations
from math import factorial,isqrt,prod
from pathlib import Path
import sys

ap=ArgumentParser()
ap.add_argument('--repo',type=Path,default=Path(__file__).resolve().parents[1]/'prime-sampling')
args=ap.parse_args()
sys.path.insert(0,str(args.repo.resolve()))
from prime_sampling.budget import menu,tight

def factors(n):
    ans=[];p=2
    while p*p<=n:
        while n%p==0:
            ans.append(p)
            n//=p
        p+=1
    if n>1:ans.append(n)
    return ans

def prime(n):
    return n>=2 and all(n%j for j in range(2,isqrt(n)+1))

def main():
    count=groups=0
    for r in (37,38):
        if str(r) not in tight.patterns:
            tight.patterns[str(r)]=[(h,n,t) for h in range(min(r,16)+1) for n in range(h,r+1)
                                    for t in (0,2,4) if t<=n-h]
        assert min(row[0] for row in menu.group(r)[1])>=0
    for Y,A in ((2400,5),(9000,7),(35000,11)):
        assert A**5>Y
        bins=7;lam=F(1,10);step=5
        caps=Counter();repeated=0
        for n in range(int(lam*Y)+1,Y+1):
            fs=factors(n)
            if not fs or fs[0]<A:continue
            if len(set(fs))<len(fs):
                assert any(n%(p*p)==0 for p in fs)
                repeated+=1;continue
            assert 1<=len(fs)<=4
            for i in range(bins):
                c=lam+(1-lam)*i/bins;d=lam+(1-lam)*(i+1)/bins
                if c*Y<n<=d*Y:break
            else:raise AssertionError('missing physical bin')
            cells=tuple(A+((p-A)//step)*step for p in fs[:-1])
            prefix=prod(fs[:-1])
            lower=prod(cells)
            if cells:
                assert fs[-1]>cells[-1]
                clipped=max(c,F(lower*cells[-1],Y))
                assert clipped<d and clipped*Y/prefix<fs[-1]<=d*Y/prefix
            prodlow=1
            for j,t in enumerate(cells):
                assert prodlow*t**(len(fs)-j)<=d*Y
                prodlow*=t
            caps[i,cells]=True
            count+=1
        assert repeated<=F(Y,A-1)
        for _,cells in caps:
            for t,k in Counter(cells).items():
                pp=[p for p in range(t,t+step) if prime(p)]
                h=sum((F(1,p) for p in pp),F())
                exact=sum((1/F(prod(tup)) for tup in combinations(pp,k)),F())
                assert exact<=h**k/factorial(k)
                groups+=1
    print('accepted squarefree products',count,'same-cell elementary sums',groups)

if __name__=='__main__':main()
