"""Count squarefree rough cofactors by ordered prime factors; rebuild both scalar rows."""
from argparse import ArgumentParser
from fractions import Fraction as F
from functools import cache
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
LO,HI=F(150),F(4801,32)
STOCK={38:(580959555,611360782,644124025,680021775),
       37:(562910278,592849024,625137178,660381327)}
PRIOR37=(556871065,586809811,619097965,654342113)
SIZE,FINE=F(1,80),F(1,1800)


def setup(repo):
    sys.path.insert(0,str(repo.resolve()))
    global band,menu,s,zl,zh
    from prime_sampling.budget import band,menu,widerough as s
    zl=s.dn(LO-s.lu(LO+1));zh=s.up(HI-s.ld(HI-F('1.1')))


@cache
def eupper(x):return s.up(s.eu(x))


@cache
def elower(x):return s.dn(s.trans(x,'exp',False))


@cache
def ldown(x):return s.dn(s.ld(x))


@cache
def lup(x):return s.up(s.lu(x))


@cache
def theta(t):
    assert t>=20
    return s.eta_for(t,F(1))


@cache
def harmonic(t,step):
    eta=theta(t)
    return s.up((1+eta)*lup(1+step/t)+2*eta/t+eupper(-t))


def density_core(a,L,H,step,bins,bottom=None):
    bottom=s.LAM if bottom is None else bottom
    assert 26<=a and L<=H and H<5*a and 0<bottom<1 and L+ldown(bottom)>0
    # Number of integers divisible by any primelike square >=e^(2a), per Y.
    first=elower(a).__ceil__()
    assert first>2
    result=F(1,first-1)
    allcounts=[F(0)]*4
    for bin_id in range(bins):
        c=bottom+(1-bottom)*bin_id/bins
        d=bottom+(1-bottom)*(bin_id+1)/bins
        ld=ldown(d)
        hu=H+lup(d)
        for length in range(1,5):
            if length*a>hu:break
            def descend(rem,last,slo,shi,weight,run):
                # slo and shi enclose log of the selected prefix product.
                if rem==1:
                    left=max(c,elower(slo+last-H)) if length>1 else c
                    if left>=d:return F(0)
                    lo=L+ldown(left)-shi
                    hi=L+ld-shi
                    eta=theta(lo)
                    # Restricting to strictly increasing tuples also gives log prime>=last.
                    envelope=((d-left)+(d+left)*eta)/max(last,lo)
                    # Applying partial summation to the encompassing interval is independent
                    # of that ordering. A secant bounds the convex integrand 1/log(t).
                    integral=(d-left)*(1/lo+1/hi)/2+2*eta*d/lo
                    return s.up(weight*min(envelope,integral))
                total=F(0)
                t=last
                while rem*t+slo<=hu:
                    count=run+1 if run and t==last else 1
                    mass=weight*harmonic(t,step)/count
                    total+=descend(rem-1,t,slo+t,shi+t+step,s.up(mass),count)
                    t+=step
                return total
            allcounts[length-1]+=descend(length,a,F(0),F(0),F(1),0)
    result+=sum(allcounts)
    return s.up(result),tuple(map(s.up,allcounts))


@cache
def density(a,b,step,bins):
    return density_core(a,zl-b,zh-a,step,bins)


def options(rank):
    from prime_sampling.budget import tight
    if str(rank) not in tight.patterns:
        tight.patterns[str(rank)]=[(h,n,t) for h in range(min(rank,16)+1) for n in range(h,rank+1)
                                  for t in (0,2,4) if t<=n-h]
    opts=[row[:3] for row in menu.group(rank)[1]]
    assert all(gap>=0 for gap,_,_ in opts)
    return opts,[tuple(map(float,row)) for row in opts]


def rebuild(ranks,step,bins,coarse):
    choices={r:options(r) for r in ranks}
    total={r:F(0) for r in ranks};bycut={r:[] for r in ranks}
    prior_saving=F(0);prior=[]
    u=F(26)
    for cut in (67,68,69,70):
        target=zh*cut/200
        while u<target:
            v=min(target,u+SIZE);n=max(1,((v-u)/FINE).__ceil__())
            a=(u/coarse).__floor__()*coarse;b=a+coarse+SIZE
            assert a<=u<v<=b
            Wdens,_=density(a,b,step,bins)
            w=(v-u)/n
            eps=s.eta_for(u,F('.01')/u**2)
            U=s.eu(w)
            harm=min(s.up((U-1+(U+1)*eps)/u),s.up((1+eps)*s.lu(1+w/u)+2*eps/u))
            W=s.up(2*zh*harm*Wdens)
            rows=band.params(LO,HI,u,v,n)
            changed=[(min(w0,W+e),e,di,off) for w0,e,di,off in rows]
            if changed!=rows:
                for r in ranks:
                    saving=n*max(F(0),band.price(rows,choices[r])-band.price(changed,choices[r]))
                    total[r]+=saving
                    if r==37 and u>=F(211,8):prior_saving+=saving
            u=v
        for r in ranks:
            bycut[r].append(STOCK[r][len(bycut[r])]-(total[r]*10**9).__floor__())
            print('stock-based cut',cut,'rank',r,'saved',(total[r]*10**9).__floor__(),
                  'budget',bycut[r][-1],flush=True)
        if 37 in ranks:
            prior.append(PRIOR37[len(prior)]-(prior_saving*10**9).__floor__())
            print('rank 37 with earlier disjoint proof',cut,prior[-1],flush=True)
    return bycut,prior


if __name__=='__main__':
    ap=ArgumentParser()
    ap.add_argument('--repo',type=Path,default=HERE.parent/'prime-sampling')
    ap.add_argument('--ranks',type=int,choices=(37,38),nargs='+',default=[38,37])
    ap.add_argument('--step',type=F,default=F(1,2))
    ap.add_argument('--bins',type=int,default=12)
    ap.add_argument('--coarse',type=F,default=F(1,4))
    ap.add_argument('--out',type=Path)
    ap.add_argument('--combined',type=Path)
    args=ap.parse_args()
    setup(args.repo)
    assert args.step>0 and args.bins>0 and args.coarse>0
    rows,prior=rebuild(args.ranks,args.step,args.bins,args.coarse)
    def fmt(r,vals):return ' '.join(map(str,(LO,HI,r,*vals)))+'\n'
    stock=''.join(fmt(r,rows[r]) for r in args.ranks)
    print(stock,end='')
    if args.out:args.out.write_text(stock,encoding='ascii')
    if args.combined:
        combined=''.join(fmt(r,[min(a,b) for a,b in zip(rows[r],prior)] if r==37 else rows[r])
                         for r in args.ranks)
        args.combined.write_text(combined,encoding='ascii')
