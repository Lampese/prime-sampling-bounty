"""Conditional diagnostic for extracting the outer cofactor population from stock moment terms."""
from argparse import ArgumentParser
from fractions import Fraction as F
from functools import cache
from pathlib import Path
import reprice as r

ap=ArgumentParser()
ap.add_argument('--repo',type=Path,default=r.HERE.parent/'prime-sampling')
args=ap.parse_args()
r.setup(args.repo)
s,band=r.s,r.band
choices={rank:r.options(rank) for rank in (38,37)}
acc={rank:[F(0),F(0),F(0)] for rank in choices}

@cache
def union(a,b):
    # Every admissible w is at most fine. Use this one outward union for all of them.
    bottom=s.LAM*r.elower(-r.FINE)
    return r.density_core(a,r.zl-b,r.zh-a,F(1,2),12,bottom)[0]

u=F(26)
for cut in (67,68,69,70):
    endpoint=r.zh*cut/200
    while u<endpoint:
        v=min(endpoint,u+r.SIZE);n=max(1,((v-u)/r.FINE).__ceil__())
        a=(u*4).__floor__()/F(4);b=a+F(1,4)+r.SIZE
        cnew=union(a,b)
        w=(v-u)/n;U=s.eu(w);T=v-w
        eps=s.eta_for(u,F('.01')/u**2)
        c=s.up((U-1+(U+1)*eps)/u)
        har=min(c,s.up((1+eps)*s.lu(1+w/u)+2*eps/u))
        W=s.up(2*r.zh*har*r.density(a,b,F(1,2),12)[0])
        rows=band.params(r.LO,r.HI,u,v,n)
        ref=[(min(w0,W+e),e,di,off) for w0,e,di,off in rows]
        sharp=F('.6')/u
        if 2*T>r.zl-v:
            sharp=max(sharp,1/(r.zl-v-F('1.1'))+s.eu(v)*(r.LO+1)*s.eu(-r.LO))
        rs=min(1,cnew/sharp)
        sharp_only=[(z,e,di*rs,off*rs) if i<len(ref)-5 else (z,e,di,off)
                    for i,(z,e,di,off) in enumerate(ref)]
        soft_only=list(ref)
        bottom=s.LAM*s.trans(-w,'exp',False)
        for i,rad in enumerate((F(1,8),F(1,2),F(2),F(12),F(80)),len(ref)-5):
            z,e,di,off=ref[i];length=1-bottom+rad+F('1e-8');af=s.root(length/rad)+F('1e-6')
            newdi=4*r.zh**2*cnew*c*s.eu(-u)*length
            newoff=4*r.zh**2*cnew*c*c*s.eu(T)*3*af*(r.LO+1)*s.eu(-r.LO/2)
            soft_only[i]=z,e,min(di,newdi),min(off,newoff)
        full=sharp_only[:-5]+soft_only[-5:]
        for rank,opt in choices.items():
            orig=band.price(rows,opt);cur=min(orig,band.price(ref,opt))
            for k,variant in enumerate((sharp_only,soft_only,full)):
                acc[rank][k]+=n*(orig-min(cur,band.price(variant,opt)))
        u=v
    for rank,x in acc.items():
        print('conditional',cut,rank,'(sharp, smooth, both)',
              *[r.STOCK[rank][cut-67]-(v*10**9).__floor__() for v in x],flush=True)
