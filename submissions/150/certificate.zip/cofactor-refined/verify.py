"""Reconstruct the two pairs of recorded scalar rows in any working directory."""
from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
import subprocess,sys
import reprice

here=Path(__file__).resolve().parent
ap=ArgumentParser()
ap.add_argument('--repo',type=Path,default=here.parent/'prime-sampling')
args=ap.parse_args()
repo=args.repo.resolve()
subprocess.run([sys.executable,'-B',str(here/'check.py'),'--repo',str(repo)],check=True)
reprice.setup(repo)
rows,prior=reprice.rebuild([38,37],F(1,2),12,F(1,4))
for fname,combined in (('stock-150.dat',False),('150.dat',True)):
    got={}
    for line in (here/fname).read_text().splitlines():
        lo,hi,rank,*vals=line.split()
        assert (F(lo),F(hi))==(reprice.LO,reprice.HI)
        assert int(rank) not in got
        got[int(rank)]=list(map(int,vals))
    expected={r:([min(x,y) for x,y in zip(rows[r],prior)] if r==37 and combined else rows[r])
              for r in (38,37)}
    assert got==expected
    print(fname,'both ranks and all four cutoffs agree')
