"""Supported §4 alternate estimates, retaining the proven raw monomial coefficients."""
from argparse import ArgumentParser
from fractions import Fraction as F
from functools import cache
from pathlib import Path
import sys
import reprice as r

ap=ArgumentParser()
ap.add_argument('--repo',type=Path,default=r.HERE.parent/'prime-sampling')
ap.add_argument('--tail',type=Path,default=r.HERE.parent/'scalar-tail')
args=ap.parse_args()
repo=args.repo.resolve()
r.setup(repo)
sys.path.insert(0,str(args.tail.resolve()))
# The previous proof's shared setup parses the cutoff and original repo.
sys.argv=['raw_support.py','--repo',str(repo),'--rank','38']
import smooth,multilevel

old_rough=smooth.rough
@cache
def refined(a,lo,hi,c,d):
    old=old_rough(a,lo,hi,c,d)
    bot=c/d
    if not 0<bot<1:return old
    bound,_=r.density_core(a,lo+r.ldown(d),hi+r.lup(d),F(1,2),12,bot)
    return min(old,d*bound)


for a,bits in ((F(26),26),(F(40),15),(F(45),12),(F(48),10)):
    b=a+F(1,8)
    smooth.rough=old_rough
    old=multilevel.charge(a,b,bits)[0]
    union_bottom=smooth.s.LAM*smooth.s.trans(a-b,'exp',False)
    def outer_only(t,lo,hi,c,d):
        return (refined if c==union_bottom and d==1 else old_rough)(t,lo,hi,c,d)
    smooth.rough=outer_only
    outer=multilevel.charge(a,b,bits)[0]
    smooth.rough=refined
    new=multilevel.charge(a,b,bits)[0]
    print('complete interval',a,b,'degree price bits',bits,'raw old',float(old),
          'outer only',float(outer),'outer plus physical mean and collars',float(new),
          'stock',float(smooth.stock(a,b)),flush=True)
