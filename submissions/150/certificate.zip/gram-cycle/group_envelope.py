"""External spectral group's joint quadratic majorants for the modulus."""
from collections import Counter,defaultdict
from fractions import Fraction as F
from functools import cache
from itertools import combinations,product
from math import isqrt,prod

from paired_envelopes import powers


@cache
def moment(ns):
    weights=[1]
    for n in ns:
        weights=[sum(weights[max(0,i-n):min(len(weights),i+1)]) for i in range(len(weights)+n)]
    t=sum(ns)
    z=weights[t//2] if not t%2 else 0
    square=[sum(weights[x]*weights[i-x] for x in range(max(0,i-t),min(t,i)+1)) for i in range(2*t+1)]
    b=sum(v*v for v in square)
    d=prod(n+1 for n in ns)
    return d**4-z**4-b,b,max(3,d)


def tensor(*ns):
    for term in product(*(powers(n) for n in ns)):
        yield tuple(i for i,c in term),prod(c for i,c in term)


@cache
def square_tables(mode):
    weights=(F(1,4),F(1,4),F(1,8),F(1,8),F(1,8),F(1,8)) if mode=='six' else (F(1,2),F(1,2))
    marks=(0,0,1,1,2,2) if mode=='six' else (0,0)
    ni=len(weights);zero=(0,)*ni
    tables=[]
    for tag in (0,1):
        poly=defaultdict(F)
        for i,j in product(range(ni),repeat=2):
            ns=[0]*ni;ns[i]+=1;ns[j]+=1
            poly[tuple(ns)]+=weights[i]*weights[j]*(F(-1,2) if tag*(marks[i]-marks[j])%3 else 1)
        order=[{zero:F(1)}]
        for deg in (1,2):
            nxt=defaultdict(F)
            for l,c in order[-1].items():
                for r,d in poly.items():nxt[tuple(x+y for x,y in zip(l,r))]+=c*d
            order.append(nxt)
        reps=[]
        for row in order:
            out=defaultdict(F)
            for ns,c in row.items():
                for term,a in tensor(*ns):out[term]+=c*a
            reps.append(out)
        tables.append(reps)
    return zero,tables


@cache
def proposals(mode):
    zero,tabs=square_tables(mode)
    keys=set(tabs[0][2])
    out=[]
    for v in range(8,39):
        y=F(v,32)
        b=1/(2*y*(2+y)**2)
        coeff=(y/2-b*y**4,1/(2*y)+2*b*y*y,-b)
        def val(t,k):return sum(c*row.get(k,0) for c,row in zip(coeff,t))
        c0=max(val(tab,zero) for tab in tabs)
        row=defaultdict(F)
        for k in keys-{zero}:
            row[moment(tuple(sorted(n for n in k if n)))]+=max(abs(val(t,k)) for t in tabs)
        out.append((c0,dict(row)))
    moments=sorted({m for c0,row in out for m in row})
    rows=[(c0,[row.get(m,0) for m in moments]) for c0,row in out]
    return moments,rows,[(float(c0),list(map(float,row))) for c0,row in rows]


def external(mode,s,k,span,pm,p,M):
    from scale import _trials,root
    R=(span+1)//2+1;rt=isqrt(p)+1
    widths=[c for c in _trials(R,s,rt) if R<c and 2*c<pm]
    if not widths:return F(1)
    moments,exact,floating=proposals(mode)
    def price(c,approx):
        num=float if approx else F
        sq=(lambda x:x**.5) if approx else root
        cap=num(2*c*c+1)/(3*c)
        pair=cap*cap*(1+num(2*rt)/pm)/pm
        errors=[sq(sq(num(M)/(s*s)*(g*rt+b+m*pair))) for g,b,m in moments]
        rows=floating
        if not approx:
            ef=list(map(float,errors));best=min(range(len(rows)),key=lambda i:rows[i][0]+sum(v*e for v,e in zip(rows[i][1],ef)))
            rows=[exact[best]]
        factor=min(c0+sum(v*e for v,e in zip(row,errors)) for c0,row in rows)
        return sq(num(c)/(c-R)*(num(c)/s+rt*factor)/k)
    return min([F(1)]+[price(c,False) for c in sorted(widths,key=lambda c:price(c,True))[:4]])
