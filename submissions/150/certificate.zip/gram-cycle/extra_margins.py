"""Measure new direct macro edges against each frozen input cell at its own cutoff."""
from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
import json,sys


if __name__=='__main__':
    work=Path(__file__).resolve().parents[1];here=work/'analytic-coverage'
    cli=ArgumentParser();cli.add_argument('--repo',type=Path,default=work/'prime-sampling');cli.add_argument('--ledger',type=Path,default=here/'release-current'/'ledger.json')
    cli.add_argument('--range',nargs=2,type=F,required=True);cli.add_argument('--extra',nargs='+',type=Path,required=True)
    cli.add_argument('--out',type=Path,required=True);a=cli.parse_args();sys.path.insert(0,str(here));from score import score
    low,high=a.range;results=[]
    for cell in json.loads(a.ledger.read_bytes()):
        l,h=F(cell['left']),F(cell['right'])
        if not low<=l<h<=high:continue
        args=[[work/p for p in cell[k]] for k in ('reports','native','budgets')];row={'left':str(l),'right':str(h)}
        for label,extra in [('before',[]),('after',a.extra)]:
            r=score(a.repo,l,h,args[0]+extra,*args[1:],cell.get('tree',True),cell.get('rectangle_mass',False))
            row[label]={br:max(rr['cutoffs'],key=lambda q:q['margin'] if q['margin'] is not None else -10**14) for br,rr in r.items()}
            if label=='after':row['winning_extra']={br:{k:v for k,v in rr['macros'].items() if v[1] in [p.name for p in a.extra]} for br,rr in r.items()}
        results.append(row)
        a.out.write_text(json.dumps(results,indent=2)+'\n',encoding='ascii')
        print(l,h,row['before']['with3']['margin'],row['after']['with3']['margin'],flush=True)
