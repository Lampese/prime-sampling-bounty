"""Produce top-exterior rectangle evidence and price it with complete integer arithmetic."""
from argparse import ArgumentParser
from fractions import Fraction as F
from functools import cache
from math import isqrt
from pathlib import Path
import json,os,sys
from corner_phase import extra_saving

HERE=Path(__file__).resolve().parent
WORK=HERE.parent


def price(I,J,scale,bank,fi,outer_rates,geom,limits,rects,complex_mask=False):
    """Return an integer T fee for the full strip using all fixed outer polynomials."""
    cap,collar,excess,inner_min=geom
    inner,outer=limits
    W=min(cap,inner+collar,outer)
    U=J*I**2
    si=scale*(I-fi)*I-U
    beta=scale*I**2-U
    def ceil(a,b):return -(-a//b)
    outside=rects.get('outside',[]) if isinstance(rects,dict) else rects
    inside=rects.get('inside',[]) if isinstance(rects,dict) else []
    bank=(*bank,(0,0,0))
    inner_credit=scale*sum(m*max(0,max(f*I-n*g-q*k for f,n,q in bank)) for m,g,k in inside)
    best=ceil(si*inner+beta*collar-inner_credit,U)
    for f,n,q in bank:
        spec=n*outer_rates[0]+q*outer_rates[1]
        D=scale*((I-f)*I+spec)
        mu_lo=(I-f-1)*I
        gains=[(m,max(0,mu_lo-n*g-q*k)) for m,g,k in outside]
        exterior=sum(m*lower for m,lower in gains)
        if complex_mask and gains:
            benefit=max(m*(mu_lo-lower) for m,lower in gains)
            if isinstance(rects,dict):
                for mass0,hits in rects.get('two_sections',[]):
                    benefit=max(benefit,mass0*mu_lo-sum(gains[i][0]*gains[i][1] for i in hits))
            exterior+=extra_saving(benefit,spec*outer)
        P=scale*exterior
        d=D*outer-P
        so=D-U
        assert min(si,so,beta)>=0
        for slope,intercept in ((beta,-(beta-si)*inner_min-inner_credit),
                                (si,(beta-si)*collar-inner_credit),(so,D*excess-P)):
            value=min(ceil(slope*W+intercept,U),ceil(slope*d+U*intercept,U*(U+slope)))
            if best is None or value<best:best=value
    return best


def build(grid,indices,mode,repo,deep,stock=False,low=F(150),high=F(4801,32),mask_sets=False):
    sys.path[:0]=[str(repo.resolve()),str(WORK/'trace-dilate')]
    from prime_sampling.outward import b,elo,eup,nthroot,upint
    if stock:
        if (WORK/'zig-cxx.cmd').is_file():
            os.environ.setdefault('CXX',str(WORK/'zig-cxx.cmd'))
            os.environ.setdefault('ZIG_GLOBAL_CACHE_DIR',str(WORK/'zig-cache'))
            os.environ.setdefault('ZIG_LOCAL_CACHE_DIR',str(WORK/'zig-local-cache'))
        from prime_sampling.spectrum import squarerates as sr
    assert F(150)<=low<high<=F(152)
    zl=b(F((elo(low)/(low-1)).__floor__()),'ln',False)
    zh=high-b(high-F('1.1'),'ln',False)
    pm,p=elo(low).__floor__(),eup(high).__ceil__()
    rt=isqrt(p)+1
    ep=F(2149,10**11)
    @cache
    def xl(x):return elo(x*(zl if x>=0 else zh))
    @cache
    def xu(x):return eup(x*(zh if x>=0 else zl))
    @cache
    def axis(a,b):
        assert 40 <= a*zl and 0<a<b
        norm=max(F(0),((1-ep)*xl(b-a)-(1+ep))/b)
        count=(norm*xl(a)/zh).__ceil__()
        width=(xu(b)*(1-xl(a-b))).__ceil__()+1
        return norm,count,width
    def rate(s,k,span):
        # Target odd primes b=1+2j. The character gains a scalar which
        # cancels in its Gram product; the source shifts stay distinct.
        R=(span+3)//4+1
        c=max(2*R,isqrt(2*rt*R*s))
        if 2*c>=pm or c<=R:return F(1)
        return min(F(1),nthroot(F(c,(c-R)*k)*(F(c,s)+2*rt)))
    B=b(F(32),'ln',False)/zh
    C=b(F(32),'ln',True)/zl
    records={}
    for i in indices:
        a,b=F(i,grid),F(i+1,grid)
        # At every tree node keep the rectangle covered by the right half.
        # Children only inspect the two remaining, disjoint triangles.
        row={'inside':[],'outside':[]}
        out_bounds=[]
        def add(side,l,r,bot,top):
            if l>=r or bot>=top:return
            m1,s,w1=axis(l,r)
            m2,k,w2=axis(bot,top)
            if min(s,k)<2:return
            ml=(10**12*2*xl(l+bot-1)*m1*m2/zh).__floor__()
            g=q=min(rate(s,k,w2),rate(k,s,w1))
            if stock and g>F(1,3000):
                a0,b0=xl(l).__floor__(),xu(r).__ceil__()
                y0,z0=xl(bot).__floor__(),xu(top).__ceil__()
                g1,q1=sr.rates(a0,b0,w1,s,k,w2,pm,p)
                g2,q2=sr.rates(y0,z0,w2,k,s,w1,pm,p)
                g=min(g,g1,g2)
                q=min(q,q1,q2)
            row[side].append((ml,upint(g),upint(q)))
            if side=='outside':out_bounds.append((l,r,bot,top))
        def walk(a,b,r):
            if not r:return
            c=(a+b)/2
            add('outside',c,b,1-c,1-a)
            add('inside',a,c,1-b,1-c)
            walk(a,c,r-1)
            walk(c,b,r-1)
        walk(a,b,deep)
        # The second boundary is either b>=a or ab>lambda X. Use its
        # known slope on each fine slab; the guard bands B,C enclose log_X(32).
        for j in range(2**deep):
            l=a+(b-a)*j/2**deep
            r=l+(b-a)/2**deep
            add('inside',l,r,max(r,1-l-B),max(b,1-a-C))
            add('outside',l,r,max(a,1-b-B),max(l,1-r-C))
        if mask_sets:
            w,z=max(a,1-b-B),1-a
            masks=[]
            def common(l,r):
                lo,hi=max(l,1-r-C),1-l
                return [(l,r,s,t) for s,t in ((w,min(z,lo)),(max(w,hi),z)) if s<t]
            for j in range(1,8):
                split=a+(b-a)*j/8
                parts=common(a,split)+common(split,b)
                mm=sum((10**12*2*xl(l+s-1)*axis(l,r)[0]*axis(s,t)[0]/zh).__floor__()
                       for l,r,s,t in parts)
                hits=[i for i,(L,R,S,T) in enumerate(out_bounds)
                      if any(max(l,L)<min(r,R) and max(s,S)<min(t,T) for l,r,s,t in parts)]
                masks.append((mm,hits))
            row['two_sections']=masks
        records[i]=row
    return {'left':str(low),'right':str(high),'grid':grid,'depth':deep,'mode':mode,'stock':stock,'rows':records}


if __name__=='__main__':
    args=ArgumentParser()
    args.add_argument('--repo',type=Path,default=WORK/'prime-sampling')
    args.add_argument('--left',type=F,default=F(150))
    args.add_argument('--right',type=F,default=F(4801,32))
    args.add_argument('--grid',type=int,default=3200)
    args.add_argument('--macros',nargs='+',type=int,default=list(range(67,100)))
    args.add_argument('--depth',type=int,default=2)
    args.add_argument('--stock',action='store_true')
    args.add_argument('--mask-sets',action='store_true')
    args.add_argument('--out',type=Path,required=True)
    opt=args.parse_args()
    assert opt.grid%200==0 and 1<=opt.depth<=8
    rows=[i for j in opt.macros for i in range(j*opt.grid//200,(j+1)*opt.grid//200)]
    d=build(opt.grid,rows,'single',opt.repo,opt.depth,opt.stock,opt.left,opt.right,opt.mask_sets)
    opt.out.write_text(json.dumps(d,separators=(',',':'))+'\n',encoding='ascii')
    print('completed',len(rows),'strips,',
          {k:sum(len(r[k]) for r in d['rows'].values()) for k in ('inside','outside')})
    if opt.stock and os.name=='nt':
        import _ctypes
        from prime_sampling.spectrum import squarerates as sr
        _ctypes.FreeLibrary(sr._lib._handle)
