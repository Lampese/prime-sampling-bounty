"""Check the exact staircase memberships and the joint integer mass calculation."""
from fractions import Fraction as F
from random import Random
from micro_credit import price


def geometry(u,v,B,C,L):
    order=[]
    def add(name,l,r,c,d):
        if l<r and c<d:order.append((name,l,r,c,d))
    def walk(a,b,d):
        if not d:return
        c=(a+b)/2
        add('i',a,c,1-b,1-c)
        add('o',c,b,1-c,1-a)
        walk(a,c,d-1);walk(c,b,d-1)
    walk(u,v,3)
    for j in range(8):
        a,b=u+(v-u)*j/8,u+(v-u)*(j+1)/8
        add('i',a,b,max(b,1-a-B),max(v,1-u-C))
        add('o',a,b,max(u,1-v-B),max(a,1-b-C))
    X=sorted({u,v,*[t for _,a,b,_,_ in order for t in (a,b)]})
    Y=sorted({max(v,1-u-L),max(u,1-v-L),1-u,1-v,*[t for _,_,_,a,b in order for t in (a,b)]})
    n=0
    for a in sorted(set(X)|{(l+r)/2 for l,r in zip(X,X[1:])}):
        if not u<a<=v:continue
        for b in sorted(set(Y)|{(l+r)/2 for l,r in zip(Y,Y[1:])}):
            names=[name for name,l,r,c,d in order if l<a<=r and c<b<=d]
            assert len(names)<=1
            if not names:continue
            H=a<=b and 1-L<a+b<=1
            inside=max(v,1-u-L)<b<=1-v
            outside=max(u,1-v-L)<b<=1-u
            assert outside and not inside
            assert H==(names[0]=='i')
            n+=1
    return n


total=0
for left in (F(67,200),F(45,100),F(488,1000),F(49,100),F(499,1000)):
    for grid in (1600,3200,6400):
        B,C=F(21,1000),F(23,1000)
        for L in (B,(B+C)/2,C):
            total+=geometry(left,left+F(1,grid),B,C,L)
print(total,'exact cell and boundary memberships checked')

rng=Random(105)
unit=100
J=1000
scale=3000
rows=((50,100,0),(25,50,0))
for _ in range(10000):
    # Seven disjoint populations: inner core, two certified inside cells,
    # remaining inside, two certified exterior cells, remaining exterior.
    masses=[rng.randrange(1,100) for j in range(7)]
    pops=[rng.randrange(m+1) for m in masses]
    x,y=sum(masses[:4]),sum(pops[:4])
    outer=sum(masses)
    def g(m,y):return (unit*abs(F(y,m)-F(1,2))).__ceil__()
    gi=g(masses[0],pops[0]);go=g(outer,sum(pops))
    fi=max(0,max(f-(n*gi+unit-1)//unit for f,n,q in rows))
    rects={side:[(masses[j],g(masses[j],pops[j]),g(masses[j],pops[j])) for j in ids]
           for side,ids in (('inside',(1,2)),('outside',(4,5)))}
    vals=price(unit,J,scale,rows,fi,(go,go),
               (x+rng.randrange(15),x-masses[0]+rng.randrange(12),outer-x+rng.randrange(9),
                max(0,masses[0]-rng.randrange(8))),
               (masses[0]+rng.randrange(10),outer+rng.randrange(12)),rects)
    assert vals>=3*y-x
print('10000 finite pass populations and two positive majorants passed exact pricing')
