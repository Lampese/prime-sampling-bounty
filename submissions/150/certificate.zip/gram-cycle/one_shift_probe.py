"""Reprice old and new physical remainders on the identical existing kernel candidates."""
from fractions import Fraction as F
from pathlib import Path
from math import isqrt
import inspect,os,sys
from argparse import ArgumentParser

here=Path(__file__).resolve().parent
work=here.parent
sys.path[:0]=[str(work/p) for p in ('prime-sampling','operator-new','residue-bridge/crt-fast','gram-cycle')]
if (work/'zig-cxx.cmd').is_file():
    os.environ.setdefault('CXX',str(work/'zig-cxx.cmd'))
    os.environ.setdefault('ZIG_GLOBAL_CACHE_DIR',str(work/'zig-cache'))
    os.environ.setdefault('ZIG_LOCAL_CACHE_DIR',str(work/'zig-local-cache'))
from prime_sampling.rectangles import boxes as m,sieved_lift
from prime_sampling.spectrum import squarerates as sr
import mixed,crt_fibres,one_shift

cli=ArgumentParser()
cli.add_argument('--rows',nargs='+',type=F,default=list(map(F,('.38','.4','.45','.47','.48','.49','.495'))))
cli.add_argument('--mode',choices=['pair','six'],default='six')
cli.add_argument('--detail',action='store_true')
cfg=cli.parse_args()
old=mixed.price
src=inspect.getsource(old)
marker='    for q in (0,1):'
code="""    def generic_bound(mode,q,r,p,rt,c,parity,signed=None):
        return one_shift.price(oldgeneric,mode,q,r,p,rt,c,parity,signed,sigma,l1)
"""
assert src.count(marker)==1
def remember(q,r,value,physical,spectral):
    diagnostics.setdefault(q,[]).append((value,r,float(physical/spectral)))
if cfg.detail:
    mark="        off=root(mass*sigma+root(co*variance))"
    src=src.replace(mark,mark+"\n        remember(q,2,off,physical4,spectral4)")
    mark="            off=min(off,pair10.nroot(co*raw,2*r))"
    src=src.replace(mark,mark+"\n            remember(q,r,pair10.nroot(co*raw,2*r),physical,spectral)")
env=dict(vars(mixed),oldgeneric=mixed.generic_bound,one_shift=one_shift,remember=remember)
exec(compile(src.replace(marker,code+marker),'<one-shift>','exec'),env)
def both(*a,**kwargs):
    before=old(*a,**kwargs)
    diagnostics.clear()
    after=env['price'](*a,**kwargs)
    assert all(x>=y for x,y in zip(before,after))
    log.append((before,after,float(a[8]*(isqrt(a[3])+1)),[min(rows)[1:] for q,rows in diagnostics.items()]))
    return after
diagnostics={}
mixed.price=both
m.initialize(F(150),F(4801,32));sieved_lift.install(m);crt_fibres.install(corner=True,layered=True)
m.rates=lambda *a:[F(1)]*2
mixed.install(cfg.mode,m,envelope=True,wheel_search=True,conductor=True,reweight=cfg.mode=='six')
for u in cfg.rows:
    v=u+F(1,3200)
    out=[]
    for low,high in (m.inner(u,v),(max(m.LAM*m.Xlo(u-v),m.Xlo(2*u-1)),F(1))):
        if low>=high:continue
        log=[]
        joint=m.joint(u,v,low,high)
        if not log:continue
        for q in (0,1):
            orig=min(t[0][q] for t in log)
            win=min(log,key=lambda t:t[1][q])
            aux=([win[3][q][0],round(win[3][q][1],4)] if cfg.detail else [])
            out.append((m.upint(orig),m.upint(win[1][q]),round(win[2],5),*aux))
    print(u,out,flush=True)
if os.name=='nt':
    import _ctypes
    _ctypes.FreeLibrary(sr._lib._handle)
