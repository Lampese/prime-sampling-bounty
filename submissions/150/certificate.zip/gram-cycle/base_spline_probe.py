"""Use the mixed selector's wheel and base length. Compare two Gram kernels."""
from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
import inspect, os, sys

work=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(work/p) for p in ('prime-sampling','operator-new','residue-bridge/crt-fast','gram-cycle')]
if (work/'zig-cxx.cmd').is_file():
    os.environ.setdefault('CXX',str(work/'zig-cxx.cmd'))
    os.environ.setdefault('ZIG_GLOBAL_CACHE_DIR',str(work/'zig-cache'))
    os.environ.setdefault('ZIG_LOCAL_CACHE_DIR',str(work/'zig-local-cache'))
from prime_sampling.rectangles import boxes as model,sieved_lift
from prime_sampling.spectrum import squarerates as sr
from frequency_envelope import residue_moment
from base_spline import count,masses
import mixed,crt_fibres

ap=ArgumentParser()
ap.add_argument('--mode',choices=('six','pair'),default='six')
ap.add_argument('--rows',nargs='+',type=F,default=list(map(F,('.38','.40','.45','.49'))))
ap.add_argument('--shapes',nargs='+',default=['4:1','3:2','1:1'])
ap.add_argument('--old',action='store_true')
cfg=ap.parse_args()
shapes=[tuple(map(int,z.split(':'))) for z in cfg.shapes]
model.initialize(F(150),F(4801,32))
sieved_lift.install(model)
crt_fibres.install(corner=True,layered=True)
model.rates=lambda *a:[F(1)]*2
src=inspect.getsource(mixed.install)
start=src.index('            last=prob(start)')
end=src.index('        return best',start)
orig=src[start:end]
head="""            for u,v in shapes:
                scale=(m*(4-ti)+n*ti)//4
                sm=max(1,scale*u//max(u,v))
                sn=max(1,scale*v//max(u,v))
                if 2*W*(h+2*(sm+sn)+d)>=pm: continue
                den=(sm*sn)**2
                def prob(x):return F(count(x,sm,sn,True)-count(x-h,sm,sn,True),den)
                vals=masses(sm,sn)
                tau=F(count(0,sm,sn),den)
                omega,sigma,l1=tau/phi,vals[2]/phi,tau*divisors/W
"""
tail=orig[:orig.index('            if envelope:')]+"""            kwargs['spectral_weights']={r:vals[2*r]*residue_moment(W,2*r) for r in (2,3,4,5)}
"""+orig[orig.index('            answer=price'):]
src=src[:start]+head+''.join('    '+line for line in tail.splitlines(True))+src[end:]
env=dict(vars(mixed),shapes=shapes,count=count,masses=masses,residue_moment=residue_moment)
exec(compile(src,'<spline-price>','exec'),env)
install=mixed.install if cfg.old else env['install']
install(cfg.mode,model,envelope=True,wheel_search=True,conductor=True)
for u in cfg.rows:
    v=u+F(1,3200)
    vals=(*model.joint(u,v,*model.inner(u,v))[:2],*model.outer(u,v)[:2])
    print(u,*map(model.upint,vals),flush=True)
if os.name=='nt':
    import _ctypes
    _ctypes.FreeLibrary(sr._lib._handle)
