"""Apply exterior credit to the same merged rows and dynamic program as the first-window replay."""
from argparse import ArgumentParser
from pathlib import Path
from tempfile import TemporaryDirectory
import json,re,sys
from micro_credit import price

here=Path(__file__).resolve().parent
work=here.parent
cli=ArgumentParser()
cli.add_argument('--repo',type=Path,default=work/'prime-sampling')
cli.add_argument('--credits',nargs='+',required=True,type=Path)
cli.add_argument('--prior-log',type=Path,default=work.parent/'outputs/prime-sampling-first-window-verification.txt')
cli.add_argument('--diagnostic-perfect',action='store_true',help='replace only collar rectangle rates by zero, for sensitivity')
cli.add_argument('--complex-mask',action='store_true')
cli.add_argument('--records-out',type=Path)
args=cli.parse_args()
prior={}
for line in args.prior_log.read_text(encoding='utf8').splitlines():
    m=re.match(r'^(\d+) (with3|without3) old (\d+) trial (\d+) saving (\d+)$',line)
    if m:
        j,b,old,trial,_=m.groups()
        last=prior.setdefault(j,{}).get(b,10**20)
        prior[j][b]=min(last,int(old),int(trial))
credits={}
for path in args.credits:
    d=json.loads(path.read_text())
    assert (d['left'],d['right'],d['mode'])==('150','4801/32','single')
    shared=credits.setdefault(d['grid'],{})
    for k,vals in d['rows'].items():
        i=int(k)
        if i not in shared:shared[i]=vals;continue
        for side in ('inside','outside'):
            merged=[]
            for (m,g,q),(other,G,Q) in zip(shared[i][side],vals[side],strict=True):
                assert m==other
                merged.append((m,min(g,G),min(q,Q)))
            shared[i][side]=merged
        if 'two_sections' in vals:
            assert shared[i].get('two_sections',vals['two_sections'])==vals['two_sections']
            shared[i]['two_sections']=vals['two_sections']
if args.diagnostic_perfect:
    print('HYPOTHETICAL. Perfect collar rectangle rates with the same covered masses.',flush=True)
    for rows in credits.values():
        for row in rows.values():
            for side in ('inside','outside'):
                row[side]=[(m,0,0) for m,_,_ in row[side]]
program=work/'hyperbola-next/compare.py'
source=program.read_text(encoding='utf8')
# The development directory additionally contains loose 150gNNNN-geometry.dat
# scratch files. The packaged replay has only its numbered subdirectories.
source=source.replace("            grid=int(directory.name.removeprefix('150g'))",
                      "            if not directory.is_dir():continue\n            grid=int(directory.name.removeprefix('150g'))")
marker='                        candidate.append(min(old,fee))'
assert source.count(marker)==1
add='''
                        if k in ('pair','six') and i in credit_rows.get(grid,{}):
                            new_fee=credit_price(ledger.I,ledger.J,scale,bank,f,row[2:4],row[4:],
                                                 rectangle_bounds[grid][i],credit_rows[grid][i],phase_enabled)
                            stage=min(old,fee)
                            if new_fee<stage:
                                meter=counts.setdefault((branch,k,grid),[0,0])
                                meter[0]+=1;meter[1]+=stage-new_fee
                            fee=min(fee,new_fee)
'''
source=source.replace(marker,add+marker)
counts={}
with TemporaryDirectory() as scratch:
    report=Path(scratch)/'prior.json'
    report.write_text(json.dumps(prior),encoding='ascii')
    sys.argv=['compare.py','--repo',str(args.repo),'--combined',str(report)]
    sys.path.insert(0,str(program.parent))
    env={'__name__':'__main__','__file__':str(program),'credit_rows':credits,
         'credit_price':price,'counts':counts,'phase_enabled':args.complex_mask}
    if args.records_out:
        marker='                baseline.setdefault(str(macro),{})[branch]=fee'
        assert source.count(marker)==1
        source=source.replace(marker,marker+'\n                exported.setdefault(str(macro),{})[branch]=fee')
        env['exported']={}
    exec(compile(source,str(program),'exec'),env)
    if args.records_out:
        args.records_out.write_text(json.dumps(env['exported'],indent=2)+'\n',encoding='ascii')
print('improved rows and aggregate pre-shortest-path reductions',counts)
