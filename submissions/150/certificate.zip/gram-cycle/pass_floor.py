"""Price genuine lower Bonferroni polynomials on experimental strip spectra."""
from fractions import Fraction as F
from functools import cache
from itertools import combinations
from math import comb,prod
from pathlib import Path
import json
import sys

WORK=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(WORK/'prime-sampling'))
from prime_sampling.accounting import ledger


@cache
def lowerbank(seq,mode):
    split=3 if mode=='six' else 1
    rows=[]
    for h in range(2 if mode=='six' else 1,13):
        head=prod(1-F(1,q) for q in seq[:h])
        tail=seq[h:]
        for k in (1,3):
            # Coefficient at a given nonempty support U is
            # (-1)^|U| / prod(q for q in U) times the truncated pass polynomial
            # on its complement. For odd k its residual mean is nonnegative
            # when sum_{tail}1/q <=1. The same sign then holds at all supports.
            if sum(F(1,q) for q in tail)>1:continue
            E=[F(1)]+[F(0)]*k
            C=E.copy()
            for q in tail:
                for j in range(k,0,-1):
                    E[j]+=E[j-1]/q
                    C[j]+=(1-F(2,q))*C[j-1]
            mu=head*sum((-1)**i*x for i,x in enumerate(E))
            norm=head*2**h*sum(C)
            ext=norm-(split+1)*mu
            rows.append((mu,ext,split*mu,h,k))
    return rows


def lower(g,q,seq,mode):
    return max((mu-eg*g-eq*q,h,k) for mu,eg,eq,h,k in lowerbank(seq,mode))


if __name__=='__main__':
    seq=ledger.rank(F(4801,32),'with3')
    files=list((WORK/'hyperbola-next').glob('smooth-grid-*.json'))
    caches={}
    for path in files:
        d=json.loads(path.read_text())
        if d.get('hypothetical') or d.get('grid')!=3200 or F(d.get('left',0))!=150:continue
        for i,_,s in d['rows']:
            if i not in caches:caches[i]=s.copy()
            else:caches[i]=list(map(min,caches[i],s))
    for m in (67,68,69,70,72,74,76,80,84,90,94):
        values=[]
        for j in range(2):
            if 16*m not in caches:break
            s=caches[16*m]
            g,q=[F(s[2*j+i],ledger.I) for i in range(2)]
            x,h,k=lower(g,q,seq,'six')
            values.append((float(g),float(q),float(x),h,k))
        print(m,values)
    cut=max((mu/(eg+eq),h,k) for mu,eg,eq,h,k in lowerbank(seq,'six'))
    print('equal-rate positivity threshold',float(cut[0]),cut[1:])
