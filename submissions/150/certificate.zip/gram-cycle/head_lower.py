"""Rational minorants for the first few pass coordinates, priced with single-character rates."""
from fractions import Fraction as F
from functools import cache
from math import prod
from pathlib import Path
import os,sys

WORK=Path(__file__).resolve().parents[1]


@cache
def patterns(primes):
    n=1<<len(primes)
    basis=[]
    for fails in range(n):
        v=[F(1)]
        for i,p in enumerate(primes):
            x=1 if fails>>i&1 else F(-1,p-1)
            v.extend([s*x for s in v])
        basis.append(tuple(v))
    return tuple(basis)


def optimize(primes, rate, quadratic):
    for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS'):os.environ.setdefault(key,'1')
    sys.path.insert(0,str(WORK/'math-libs'))
    import numpy as np
    from scipy.optimize import linprog
    from scipy.sparse import eye,hstack,vstack,csr_matrix
    states=patterns(primes)
    n=len(states)
    mat=csr_matrix(np.array(states,dtype=float))
    unit=eye(n-1,format='csr')
    plan=[(0,None)]*(n-1)
    costs=[-1.]+[float(quadratic if i==1 else rate) for i in range(1,n)]
    # Directly split nonconstant real Walsh coefficients into positive and negative.
    obj=np.array(costs+costs[1:])
    A=hstack([mat,-mat[:,1:]],format='csr')
    target=np.zeros(n);target[0]=1.
    result=linprog(obj,A_ub=A,b_ub=target,bounds=[(None,None),*plan,*plan],method='highs')
    assert result.success
    scale=10**8
    coeff=[F(round(scale*result.x[0]),scale)]+[
        F(round(scale*(result.x[i]-result.x[n+i-1])),scale) for i in range(1,n)]
    active=[(i,c) for i,c in enumerate(coeff) if c]
    correction=max(F(0),max(sum(c*v[i] for i,c in active)-int(j==0) for j,v in enumerate(states)))
    coeff[0]-=correction
    a=coeff[0]; b=sum(abs(x) for x in coeff[2:]); q=abs(coeff[1])
    return a,b,q,[(i,c) for i,c in enumerate(coeff) if c]


if __name__=='__main__':
    from argparse import ArgumentParser
    import json
    cli=ArgumentParser()
    cli.add_argument('--heads',type=int,nargs='+',default=[4,5,6])
    cli.add_argument('--rates',type=F,nargs='+',default=list(map(F,('.002','.025','.06','.08','.1','.24'))))
    cli.add_argument('--out',type=Path,required=True)
    args=cli.parse_args()
    allpr=(2,3,5,7,11,13,17,19,23)
    saved={}
    for h in args.heads:
        seq=allpr[:h]
        for rate in args.rates:
            a,b,q,cs=optimize(seq,rate,rate)
            lower=a-rate*(b+q)
            print(h,rate,'certified lower',round(float(lower),8),'upper direct loss ratio',flush=True)
            saved.setdefault(str(h),[]).append({'coeff':[[i,str(c)] for i,c in cs],
                                                'mean':str(a),'nonquadratic':str(b),'quadratic':str(q)})
    args.out.write_text(json.dumps(saved,indent=2)+'\n',encoding='ascii')
