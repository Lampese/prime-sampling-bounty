"""Reprice the actual reflection selectors with the local Fourier conductor."""
from fractions import Fraction as F
from math import isqrt
from pathlib import Path
import os
import runpy
import sys

from local_conductor import fourier_parts

work = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(work / name) for name in ("operator-new", "weighted-base", "reflection", "prime-sampling")]
if (work / "zig-cxx.cmd").is_file():
    os.environ.setdefault("CXX", str(work / "zig-cxx.cmd"))
    os.environ.setdefault("ZIG_GLOBAL_CACHE_DIR", str(work / "zig-cache"))
    os.environ.setdefault("ZIG_LOCAL_CACHE_DIR", str(work / "zig-local-cache"))
import mixed
from prime_sampling.rectangles import boxes
from prime_sampling.spectrum import pair10, squarerates as sr


def price(mode, s, count, p, front, co, sigma, omega, l1):
    root = sr.root
    sq = isqrt(p) + 1
    answer = []
    for q in (0, 1):
        m = 3 if mode == "six" else 1
        c = F(129, 128) if mode == "six" and not q else F(1)
        d = (F(2, 9) if q else F(3, 16)) if mode == "six" else (F(1) if q else F(1, 2))
        low = (12 if mode == "six" else (2 if q else 8))*p*sigma*(1+2*sigma)
        physical = mixed.generic_bound(mode, q, 2, p, sq, c, True) + c*p*p*sigma*omega**2
        coeff, _, extra = fourier_parts(mode, q, 2, boxes.pmin, p, sigma)
        spectral = coeff*p*p*sigma*l1**2 + extra
        variance = min(physical, spectral) + m*(2 if q else 1)*(p*sigma*d)**2 + low
        off = root(d*sigma + root(co*variance))
        for r, mult, fac in ((3, 15, 6), (4, 105, 24), (5, 945, 120)):
            coeff, pairing, _ = fourier_parts(mode, q, r, boxes.pmin, p, sigma)
            spectral = coeff*p*sigma*(p*l1*l1)**(r-1) + pairing
            lead = m*(mult if q else fac)*d**r
            physical = mixed.generic_bound(mode, q, r, p, sq, c, True)
            physical += c*p*p*sum(mixed.partitions(2*r,j)*sigma**j*omega**(2*r-2*j) for j in range(1, r)) + lead*p*p*sigma**r
            off = min(off, pair10.nroot(co*min(spectral, physical), 2*r))
        answer.append(root(front*(F(1,s) + off)))
    return answer


if __name__ == "__main__":
    if "--original" in sys.argv:
        sys.argv.remove("--original")
    else:
        mixed.price = price
    runpy.run_path(str(work / "reflection" / "probe.py"), run_name="__main__")
