"""Small-field sanity checks for the Gram and closed-cycle identities."""
from cmath import exp,pi
from itertools import product
from math import sqrt


def character(p,order):
    root=next(g for g in range(2,p) if len({pow(g,j,p) for j in range(p-1)})==p-1)
    chi={pow(root,j,p):exp(2j*pi*j/order) for j in range(p-1)}
    return lambda x:chi.get(x%p,0)


def gram(rows):
    return [[sum(x*y.conjugate() for x,y in zip(left,right)) for right in rows] for left in rows]


def run(p,order):
    C=character(p,order);A=(2,3,5);B=(3,5,7)
    if 35>=p:return
    totals=[0.,0.]
    for t in range(1,p):
        rows=[[C(t+a*b) for b in B] for a in A]
        G=gram(rows)
        for i in range(len(A)):G[i][i]=0
        H2=[[sum(G[i][j]*G[j][k] for j in range(len(A))) for k in range(len(A))] for i in range(len(A))]
        norm2=sum(abs(x)**2 for row in G for x in row)
        norm4=sum(abs(x)**2 for row in H2 for x in row)
        cycle=sum(G[i][j]*G[j][k]*G[k][l]*G[l][i] for i,j,k,l in product(range(len(A)),repeat=4))
        assert abs(norm4-cycle)<1e-8
        totals[0]+=norm2/(len(A)*len(B))**2
        totals[1]+=norm4/(len(A)*len(B))**4
    assert totals[0]/(p-1)<=1/len(B)+2*sqrt(p)/(p-1)
    assert totals[1]/(p-1)<=3/len(B)**2+112/len(B)**3+256/len(B)**4+6*sqrt(p)/(p-1)
    axis=range(1,p);t=3
    actual=[[C(t+a*b) for b in axis] for a in axis]
    fourier=[[exp(2j*pi*(a*b%p)/p) for b in axis] for a in axis]
    dual=[sum(C(c).conjugate()*fourier[c-1][b-1] for c in axis)/(p-1) for b in axis]
    modified=[[fourier[a-1][b-1]-(1-1/sqrt(p))*C(a)*dual[b-1] for b in axis] for a in axis]
    first=gram(actual);second=gram(modified)
    for a,c in product(axis,repeat=2):
        exact=p*(a==c)-1-C(a)*C(c).conjugate()
        assert abs(first[a-1][c-1]-exact)<1e-8 and abs(second[a-1][c-1]-exact)<1e-8
    return p-1


n=sum(run(p,r) for p,r in ((41,2),(41,5),(61,3),(61,5),(73,2)))
print('centred 4- and 8-cycle checks',n,'shifts, 5 complete Jacobi Gram comparator checks')
