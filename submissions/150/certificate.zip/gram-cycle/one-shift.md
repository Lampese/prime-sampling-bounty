# 将一个局部位移先作 Fourier 完成

考虑物理 \(2r\) 次矩，固定前 \(d=2r-1\) 个互异位移，写 \(F(x)=\prod_{i=1}^{d}\rho_i(x+z_i)\)，包含所需的共轭。所有角色都非主。令 \(S(u)=\sum_x F(x)\rho(x+u)\)，最后一个 \(u\) 按原概率 \(w\) 采样。对 \(u\) 的零频，非主角色的完整二点相关给

\[
p^{-1}\sum_u |S(u)|^2=\sum_x|F(x)|^2-p^{-1}|\sum_x F(x)|^2\le p-d.
\]

真实非对角扣减至少为 \(p-d-1\)，所以这一部分剩余至多 1。对非零 \(h\)，将两份 \(S\) 在 \(u\) 方向展开 Fourier，除去统一高斯常数后得到

\[
\left|\sum_u |S(u)|^2e_p(hu)\right|
=p\left|\sum_{\xi\ne0,-h}K(\xi)\overline{K(\xi+h)}\right|,
\qquad K(\xi)=\bar\rho(\pm\xi)\widehat F(\pm\xi)/\sqrt p .
\]

符号依 Fourier convention 一致取用。Laumon 的局部 Fourier 变换给 \(\widehat F\) 作为几何不可约中延拓，在 \(\mathbf G_m\) 光滑，秩为 \(d\)。直接在 Fourier 积分的 \(d\) 个互异温和有限奇点上用 GOS 亦得此秩。零处 Fourier 纤维的一次紧支上同调维数为 \(d-1\)，因 \(F\) 非主且在 \(\infty\) 温和；因此此处的惯性有余维一的固定空间，是非标量伪反射。Kummer 秩一扭转不会消去这处射影分歧，所以不同加性平移不可能射影同构。无穷远野相位分别来自原来 \(d\) 个互异的有限根。平移后两层相乘，\(d\) 个同根相位相消，Swan 至多 \(d^2-d\)。在除去 \(0,-h,\infty\) 的曲线上用 GOS、几何非同构及权界，总和至多 \((2d^2-d)\sqrt p\)。[Katz 关于朴素 Fourier 变换的不可约性、纯性及温和伪反射](https://web.math.princeton.edu/~nmk/ftsum13.pdf) · [Laumon 局部 Fourier 变换](https://www.numdam.org/item/SB_1987-1988__30__105_0.pdf)

故物理通项可用 \(1+(2d^2-d)p\sqrt p\,\|\widehat w\|_1/p\)。前 \(d\) 个实际位移有相等者的概率不超过 \(\binom d2\sigma\)，在这部分继续用原非例外点界，已由原配对项收取的例外元组也仍由原式估价。

one-shift-orders.txt 是首窗 G3200 原选择器逐列重算。在 .47 处胜出外盒的 \(x=\sqrt p\,\|\widehat w\|_1/p\) 为 0.1854 与 0.20858，原全 Fourier 通项更便宜；.48 的相同参数为 9.22369 与 6.91776，原逐点物理通项更便宜。中间到 .475 才发生方向跨换，单槽开销尚高于两个已存端点。这个方法不写入最终账本。实际通过原费率的后段改进在 paley-four.md。
