"""Average one uncompleted physical slot before taking a Weil bound."""
from fractions import Fraction as F
from math import comb


def price(old,mode,q,r,p,rt,weight,parity,signed,sigma,l1):
    generic=old(mode,q,r,p,rt,weight,parity,signed)
    d=2*r-1
    separated=weight*(1+(2*d*d-d)*p*rt*l1)
    repeated=weight*comb(d,2)*sigma*((d*d-1)*p+2*r)
    return min(generic,separated+repeated)
