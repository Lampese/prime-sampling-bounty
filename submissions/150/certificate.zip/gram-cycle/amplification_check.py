"""Finite-field checks of the shifted-Kummer and Kloosterman changes of kernel."""
from cmath import exp, pi
from math import exp as real_exp, sqrt


def small_check(p, order):
    generator = next(g for g in range(2, p) if len({pow(g, i, p) for i in range(p - 1)}) == p - 1)
    char = [0j] * p
    for i in range(p - 1):
        char[pow(generator, i, p)] = exp(2j * pi * (i % order) / order)
    additive = [exp(2j * pi * x / p) for x in range(p)]
    e = lambda x: additive[x % p]
    chi = lambda x: char[x % p]
    inv = lambda x: pow(x, -1, p)
    gauss = sum(chi(a) * e(a) for a in range(1, p))
    kl = [sum(e(a + x * inv(a)) for a in range(1, p)) / sqrt(p) for x in range(p)]
    omega = gauss * chi(-1).conjugate() / sqrt(p)
    for t in [1, p // 3, p - 1]:
        z = [omega / p * sum(chi(v) * e(t * inv(v) - u * v) for v in range(1, p)) for u in range(p)]
        residual = [chi(x + t) - sum(z[u] * kl[u*x % p] for u in range(1, p)) for x in range(p)]
        assert max(abs(a - residual[1]) for a in residual[1:]) < 1e-8
        assert abs(sum(abs(x)**2 for x in z[1:]) - (p - 2)/p) < 1e-9
        for k in [1, 2, p - 1]:
            col = [sum(chi(a) * e(h*a - k*t*inv(a)) for a in range(1, p)) for h in range(p)]
            assert abs(sum(abs(x)**2 for x in col) - p*(p - 1)) < 1e-7
            assert sum(abs(x) > 1e-8 for x in col) >= (p - 1) / 4
            for h in [0, 1, 3, p - 1]:
                direct = sum(chi(t + a*b) * e(h*a + k*b) for a in range(p) for b in range(p)) / p
                assert abs(direct - gauss * chi(k).conjugate() * col[h] / p) < 1e-8
        shifts = (1, 2, 3, 8)
        prod = lambda a,b,c,d: a*b*c.conjugate()*d.conjugate()
        L = [prod(*(chi(x + b) for b in shifts)) for x in range(p)]
        total = sum(L)
        square = sum(abs(x)**2 for x in L)
        double = triple = 0j
        for r in range(p):
            row = [prod(*(chi(t + s*(r + b)) for b in shifts)) for s in range(1, p)]
            double += sum(row)
            triple += abs(sum(row))**2 - sum(abs(x)**2 for x in row)
        assert abs(double - (p - 1)*total) < 1e-7
        assert abs(triple - (p - 2)*(abs(total)**2 - square)) < 1e-7


def exact_example(p):
    char = [-1] * p
    char[0] = 0
    for i in range(1, p):
        char[i*i % p] = 1
    shifts = (p//3, p//3 + 1, p//3 + 2, p//3 + 7)
    c = sum(char[(x+shifts[0]) % p] * char[(x+shifts[1]) % p]
            * char[(x+shifts[2]) % p] * char[(x+shifts[3]) % p] for x in range(p))
    double = (p - 1)*c
    triple = (p - 2)*(c*c - p + 4)
    m = (p + 1)//2
    lower = (p*(1 - 1/m)**4 - 3*p*p/m**2 - 54*p/m)/(3*sqrt(p))
    print('quadratic exact',p,'shift tuple',shifts,'C',c,'double',double,'triple',triple,
          'average abs(double)/p lower bound',format((p - 1)*lower/p, '.6f'))


for modulus, order in [(29, 2), (31, 3), (41, 5)]:
    small_check(modulus, order)
print('passed Fourier, synthesis, and KMS moment identities for 3 primes and 3 shifts each')
for modulus in [1009, 10007, 65537]:
    exact_example(modulus)
S, K = 4676718056126077789138941421, 1665714892280533460708089339028
print('log p = 150 with certified lower S,K at u=.49, normalized sqrt(p/SK) =',
      format(real_exp(75)/sqrt(S*K), '.8f'))
print('same price times putative p^(-1/64) =', format(real_exp(75-150/64)/sqrt(S*K), '.8f'))
print('in-principle lower bound even counting every integer in sampled box =',
      format(real_exp(-150/64)*sqrt(148/(real_exp(150/3200) - 1)), '.8f'))
