"""Exact normalization and exhaustive finite-population test of the exterior phase."""
from itertools import product
from math import isqrt
from corner_phase import DEN, NORMS, PARAMETER, extra_saving


def upper_root(n):
    r=isqrt(n)
    return r+(r*r<n)


for j,c in enumerate(NORMS):
    lhs=4*PARAMETER*DEN**2
    den=4*PARAMETER-j
    assert (c-1)**2*den < lhs <= c**2*den
    # cos(3 theta)/cos(theta)=4 cos(theta)^2-3.
    assert 4*den-3*(4*PARAMETER)==4*(PARAMETER-j)

checks=0
for masses in product((2,4,6),repeat=4):
    for pops in product(*(range(m+1) for m in masses)):
        errors=[2*f-m for m,f in zip(masses,pops)]
        # Universal bound on sum_{ab} u_a v_b E_ab. Cauchy in the two
        # rows followed by |Re(v0*v1bar)|<=1 gives this integer ceiling.
        a,b,c,d=errors
        risk=upper_root(2*(a*a+b*b+c*c+d*d+2*abs(a*b+c*d)))
        for j in range(4):
            # Mass coordinates use units of twice the counting measure.
            # P is the Boolean pass, with constant mu=1/2.
            mass=masses[j]
            lower=max(0,mass-abs(errors[j]))
            bound=sum(masses)+risk-lower-extra_saving(mass-lower,risk)
            assert 2*(sum(pops)-pops[j])<=bound
            checks+=1
print(len(NORMS),'upper norm constants and',checks,'labeled corner prices verified')
