"""Price a shared rectangle and disjoint residual panels across adjacent macro boundaries."""
from argparse import ArgumentParser
from pathlib import Path
import runpy
import sys

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
cli = ArgumentParser(add_help=False)
cli.add_argument('--width', type=int, default=2)
cli.add_argument('--edge-depth', type=int, default=3)
cli.add_argument('--credit-only', action='store_true')
cli.add_argument('--complex-mask', action='store_true')
spec, remainder = cli.parse_known_args()
assert 1 <= spec.width <= 4 and 0 <= spec.edge_depth <= 6
original = runpy.run_path
canonical = (WORK / 'hyperbola-next' / 'rectangles.py').resolve()


def run(path, *args, **kwargs):
    if Path(path).resolve() != canonical:
        return original(path, *args, **kwargs)
    full = canonical.read_text(encoding='utf8')
    start = full.index('    records={}\n    for j in args.macros:')
    stop = full.index("    if os.name=='nt':", start)
    driver = '''
    report={'left':str(args.left),'right':str(args.right),'mode':args.mode,
            'width':edge_width,'depth':edge_depth,'credit_only':credit_only,'complex_mask':complex_mask,'edges':[]}
    for j in args.macros:
        assert 67<=j<j+edge_width<=100
        u,v=F(j,200),F(j+edge_width,200)
        if credit_only:
            from pass_credit import evaluate as credit_price
            def mass_lower(a,b,c,d):
                return 2*m.Xlo(a+c-1)*max(0,axis_factors(a,b)[0])*max(0,axis_factors(c,d)[0])/m.zh
            values=credit_price(u,v,*bounds(u,v,False),box,mass,mass_lower,boundary,C,banks,I,J,edge_depth,complex_mask)
            edge={'start':j,'end':j+edge_width,'cost':{br:r[0] for br,r in values.items()},'details':values}
        else:
            core=bounds(u,v,True)
            if core[0]>=core[1]:raise ValueError("requested root has empty common core")
            root=price(u,v,*core)
            residuals=[evaluate(F(i,200),F(i+1,200),core,edge_depth)
                       for i in range(j,j+edge_width)]
            fees=tuple(map(sum,zip(root,*residuals)))
            edge={'start':j,'end':j+edge_width,'root':dict(zip(branches,root)),
                  'residuals':[dict(zip(branches,row)) for row in residuals],
                  'cost':dict(zip(branches,fees))}
        report['edges'].append(edge)
        print('joined',j,j+edge_width,edge['cost'],'rectangles',box.cache_info().currsize,flush=True)
        if args.out:args.out.write_text(json.dumps(report,indent=2)+'\\n',encoding='ascii')
'''
    source = full[:start] + driver + full[stop:]
    env = {'__name__':'__main__','__file__':str(canonical),'edge_width':spec.width,
           'edge_depth':spec.edge_depth,'credit_only':spec.credit_only,'complex_mask':spec.complex_mask}
    exec(compile(source,str(canonical),'exec'),env)
    return env


runpy.run_path = run
sys.argv = ['envelope_macro.py', *remainder]
run(WORK / 'operator-new' / 'envelope_macro.py', run_name='__main__')
