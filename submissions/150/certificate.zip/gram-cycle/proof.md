# 保留公共输入相位的 Gram 矩阵

固定 $p,X$、真实素数矩形 $U\times V$，记 $S=|U|,K=|V|$。令 $M_\chi(t)_{ab}=\chi(t+ab)$，把角色在零延拓成零。原矩阵各行多一个单位因子 $\bar\chi(a)$。写 $D_\chi$ 为把这个因子和同一标签的 $\zeta^{j_\chi k_a}$ 乘上的对角酉矩阵（根据选用列向量的共轭 convention 也可整体取共轭）。在采样侧逐列取绝对值、以 Cauchy 去掉绝对值以后，公共输入相位仍然是同一个 $z$。对六谱权再用一次 Jensen，可对任意这样的 $z$ 以

$$D_{\cal C}^2\ \le\ (S^2K)^{-1} z^*\mathcal G z,\qquad
\mathcal G=\sum_\chi w_\chi D_\chi^* M_\chi M_\chi^*D_\chi$$

控制所选方向；严格地说，上式左端先取指定权与标签的方向量，对右端同步取上确界。$\mathcal G$ 为半正定，且对角元至多 $K$。令 $\mathcal H$ 为把 $\mathcal G$ 的对角置零所得 Hermitian 矩阵。于是

$$D_{\cal C}^2\le \frac1S+\frac{\|\mathcal H\|_{\rm op}}{SK}
\le \frac1S+\frac{\operatorname{tr}(\mathcal H^{2r})^{1/(2r)}}{SK}
\quad (r=1,2).$$

该式不把不同边上的输入相位分别取模。若分角色计算 $H_\chi=M_\chi M_\chi^*-\operatorname{diag}(M_\chi M_\chi^*)$，Schatten 范数的三角不等式和 Jensen 给 $\|\mathcal H\|_{2r}^{2r}\le\sum_\chi w_\chi\operatorname{tr}(H_\chi^{2r})$。它仍允许标签随 $t$ 任意选取，代价是丢掉了不同角色之间可能出现的抵消。

## 对位移平均并剔除行对角

对 $t\in\mathbb F_p^\times$ 取均匀平均。$\operatorname{tr}(H_\chi^2)$ 的项带有 $a\ne c$。当两列 $b=d$ 时按 $1$ 计，归一贡献至多 $1/K$。否则乘积为

$$\chi\bigg(\frac{(t+ab)(t+cd)}{(t+ad)(t+cb)}\bigg).$$

分子分母没有共同根。若两侧都出现重根，必须有 $a=-c,b=-d$；本题两侧的正整数均小于 $p/2$。所以至少有一个简单根，对任意非主角色的阶均非幂。对分母用阶数减一的指数替换，写成同一个多项式。选一个不可消去的简单根 $\alpha$ 作 $t=\alpha+1/y$，总次数是角色阶的倍数，故非零 $y$ 处公共分母不贡献相位。变换后至多有三个不同有限根，且仍非幂，Weil 界为 $2\sqrt p$。$y=0$ 与代表 $t=0$ 的另一点处角色值均恰为 $1$；这是因为分子分母的首项和常数项分别相同。两项在迹所需实部上都应扣二，因此使用 $2\sqrt p$ 作上界已有余量。这给出

$$\mathbb E_t\frac{\|\mathcal H\|_2^2}{S^2K^2}
\le \frac1K+\frac{2\sqrt p}{p-1}.$$

这里下标 $2$ 是 Frobenius 范数。在稳定的几何和谱权条件下，归一方向上界的确定部分是 $S^{-1/2}$，余项的 $L^4(t)$ 范数不超过右端的四次方根。该结论也可先做逐角色算子范数，再对固定权取平均。后者适于放大至覆盖不同 $X$ 的共同矩形，因为压缩后的算子范数单调。

作为四次中心化 Gram 迹的对照，$H_\chi^4$ 的循环包含四个行顶点 $a_i$ 和四个列顶点 $b_i$，且 $a_i\ne a_{i+1}$。有单现的 $b_i$ 且该素数不在四个 $a_i$ 中时，正的边标签 $a_i b_i$ 给一个不可抵消的简单根。所有乘积小于 $p$，所以整数素数乘积唯一分解可直接用于模 $p$ 比较。固定行顶点以后，从其外选出的列顶点若占据四个位置且都不单现，有至多 $3K^2$ 种；若只占三个或两个位置，有至多 $16K$ 或 $96K$ 种；若均在行顶点中，有至多 $256$ 种。只有一个外部位置必有单现。其余非幂项至多有八个不同根，利用其简单根作同样变换，$t=0,\infty$ 的相位仍为一。因此

$$\mathbb E_t\frac{\operatorname{tr}(\mathcal H^4)}{S^4K^4}
\le\frac3{K^2}+\frac{112}{K^3}+\frac{256}{K^4}+\frac{6\sqrt p}{p-1}.$$

在本题窗口，两种平均均有平方根量级的通用余项，中心化两次 Gram 迹在 Markov 步骤的阈值只取平方，给出更好的例外比例。measure.py 沿用 shift-next 的外接几何、标量预算和头七位系数；对每个真实 $p$、在选择 $t,X$ 之前固定的各微带谱权族，得到全部允许 $X$ 同时的例外比例。此处同时性使用按容许 $X$ 放大的共同素数集合，而非把不同 $X$ 的中心化矩阵直接作主子阵比较。既有方案对未中心化六阶迹的相同比例是 $2.626\cdot10^{-14}$ 与 $1.821\cdot10^{-15}$。中心化后的有理数结果在 measure.txt；它没有剔除最后一个例外 $t$ 的保证。

## 固定 $t$ 的投影约束

在全体非零行列上，真 Jacobi 矩阵满足

$$M_\chi M_\chi^*=pI-\mathbf1\mathbf1^*-v_\chi v_\chi^*,\quad v_\chi(a)=\chi(a).$$

不同 $a,c$ 时，将 $b\mapsto(t+ab)/(t+cb)$ 看作射影直线上的分式线性双射，去除 $b=0,\infty$ 即得 $-1-\chi(a/c)$。等行时值为 $p-2$。因此整矩阵绝大多数奇异值均为 $\sqrt p$，两个异常奇异值等于 $1$。因任意子矩阵的算子范数不超过 $\sqrt p$，只得 $\sqrt{p/(SK)}$。本题矩形素数对数不超过 $2X^{1+1/3200}<0.0142p$，该价甚至大于 $8$。

同一完整 Gram 不能控制本题的压缩。令 $F_{ab}=e_p(ab)$，行列均取非零元，则 $FF^*=pI-\mathbf1\mathbf1^*$。令 $P_\chi=v_\chi v_\chi^*/(p-1)$，

$$\widetilde F=\big(I-(1-p^{-1/2})P_\chi\big)F.$$

于是 $\widetilde F\widetilde F^*=M_\chi M_\chi^*$ 精确成立。因 $\sum_c\bar\chi(c)e_p(cb)=\chi(b)\sum_c\bar\chi(c)e_p(c)$，修正项本身是 $\chi(ab)$ 的常数倍，故 $\widetilde F$ 同样只依赖乘积。Gauss 和的绝对值给 $|\widetilde F_{ab}-F_{ab}|\le1/(\sqrt p+1)$。在所有本题 G3200 外盒上，$0<ab\le X^{1+1/3200}<0.0071p$。将相位弧移至实轴中点，单用全一的秩一权，压缩的 $F$ 即给 $\ge\cos(0.0071\pi)>0.99975$ 的归一相关。$\widetilde F$ 的值至多损失 $1/(\sqrt p+1)$。若还要求每个条目模至多一，可除以 $1+1/(\sqrt p+1)$，相应全局半正定上界仍然成立。该对照不是实际特征矩阵，表明完整 Jacobi 谱、素数乘积的唯一性以及输入相位的秩一性不能单独推出小的固定 $t$ 界。

另一直接模型为 $G_\rho=(1-\rho)I+\rho zz^*$，$|z_a|=1$，$0\le\rho\le1$。它满足所有主块半正定、单位对角，还精确饱和按模相加的秩一 Rayleigh 上界。中心化后的四次迹为 $\rho^4((S-1)^4+(S-1))$。在真正的矩阵上，能超越这些统一约束的对象是受限闭路中四个交叉边的有符号乘积。

## 文献边界

按乘法角色基变换，上述乘法型 Hankel 矩阵的系数是 Jacobi 和。整矩阵的 Gauss–Jacobi 恒等式决定谱的模长，但压缩取决于其相位。Jacobi sums 的二参数矩阵自身的对角化结果也不能替代对指定素数行列的压缩估计。[Sam Vandervelde, Jacobi Sum Matrices](https://myslu.stlawu.edu/~svanderv/JacobiSumMatrices.pdf)

Fouvry、Kowalski、Michel、Sawin 的双线性定理 1.1 和 1.3 要求几何连通部分为单群或有限拟单群，定理 1.6 的额外类需要四维正交单值群。当前 $x\mapsto\chi(t+x)$ 是秩一 Kummer 层，几何群有限循环。Ping Xi 的任意支撑定理对 bountiful 层要求秩至少二。把核作 Fourier 变换后转用高秩层也会改变几何支撑，不能把原素数盒原封不动代入这些定理。[FKMS, Theorems 1.1, 1.3, 1.6](https://arxiv.org/html/2511.09459v1) · [Xi, Definition 2.3 and Theorem 1.1](https://arxiv.org/pdf/2211.14702)

Paley 限制等距性的条件性定理涉及二次剩余行选取和特定 Fourier 列；其随机性条件及矩阵支撑均不能由当前窗口的素数区间替换。[Bandeira、Mixon、Moreira](https://arxiv.org/abs/1410.6457)
