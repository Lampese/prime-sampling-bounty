"""Uniform upper mass for arbitrary logarithmic prime rectangles using just the two endpoint scales."""
from fractions import Fraction as F
from functools import cache


def factory(m,eps,parts=2):
    L,H=m.zl,m.zh;loss=((H-L)/L)**2/8
    assert 0<=loss<1 and 1<=parts<=16
    factor=1/(1-loss)
    @cache
    def axis(a,b,Z):
        step=(b-a)/parts
        growth=m.eup(step*Z)-1
        simple=growth/Z
        moment=(growth-step*Z)/Z**2
        assert moment>=0
        integral=0
        for j in range(parts):
            left=a+j*step;right=left+step
            integral+=m.eup(j*step*Z)*(simple/right+moment/(left*right))
        return (1+eps)*integral+2*eps/(a*Z)
    @cache
    def upper(u,v,w,z):
        if u>=v or w>=z:return F(0)
        assert min(u,w)*L>=40
        return factor*max(2*Z*m.eup((u+w-1)*Z)*axis(u,v,Z)*axis(w,z,Z) for Z in (L,H))
    return upper
