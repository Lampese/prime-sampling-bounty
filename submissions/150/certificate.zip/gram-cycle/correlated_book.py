"""Reprice an existing recursive rectangle bank with a shared-scale endpoint mass proof."""
from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
from tempfile import TemporaryDirectory
import json,runpy,sys


def generate(repo,bases,parts=2):
    here=Path(__file__).resolve().parent;work=here.parent;analytic=work/'analytic-coverage'
    records=[json.loads(p.read_bytes()) for p in bases];first=records[0]
    assert all(d['family']=='rectangle-book' and all(d[k]==first[k] for k in ('left','right','tree','phase_parts','mode')) for d in records)
    files={k for d in records for k in d['inputs']};macros=sorted({j for d in records for j in d['macros']})
    for d in records:
        for f,h in d['inputs'].items():assert sha256((work/f).read_bytes()).hexdigest()==h
    canonical=(work/'hyperbola-next'/'rectangles.py').resolve();original=Path.read_text
    marker='    @cache\n    def box(u,v,w,z):'
    addition="""    from exp_rectangle import factory as correlated_mass_factory
    raw_mass=mass
    mass_bound=correlated_mass_factory(m,eps,PARTS)
    @cache
    def mass(u,v,w,z):return min(raw_mass(u,v,w,z),mass_bound(u,v,w,z))

""".replace('PARTS',str(parts))
    def patched(path,*a,**kw):
        text=original(path,*a,**kw)
        if path.resolve()!=canonical:return text
        assert text.count(marker)==1
        return text.replace(marker,addition+marker)
    with TemporaryDirectory() as td:
        tmp=Path(td)/'book.json';args=[str(analytic/'book_macro.py'),'--repo',str(repo),'--window',first['left'],first['right'],
                                        '--macros',*map(str,macros),'--mode',first['mode'],'--phase-parts',str(first['phase_parts']),
                                        '--files',*map(str,(work/f for f in sorted(files))),'--out',str(tmp)]
        if first['tree']:
            tree=analytic/'150-near'/first['tree'];assert tree.is_file()
            args+=['--tree',str(tree)]
        try:
            Path.read_text=patched;sys.argv=args;runpy.run_path(args[0],run_name='__main__')
        finally:Path.read_text=original
        result=json.loads(tmp.read_bytes())
    result['family']='rectangle-book-convex';result['mass_parts']=parts
    result['source_books']={p.resolve().relative_to(work).as_posix():sha256(p.read_bytes()).hexdigest() for p in bases}
    assert all(result['fees'][j][br]<=x for d in records for j,fees in d['fees'].items() for br,x in fees.items())
    return result


if __name__=='__main__':
    here=Path(__file__).resolve().parent;work=here.parent
    cli=ArgumentParser();cli.add_argument('--repo',type=Path,default=work/'prime-sampling');cli.add_argument('--books',type=Path,nargs='+')
    cli.add_argument('--parts',type=int,default=2);cli.add_argument('--out',type=Path);cli.add_argument('--check',type=Path)
    a=cli.parse_args()
    if a.check:
        d=json.loads(a.check.read_bytes());result=generate(a.repo,[work/p for p in d['source_books']],d['mass_parts'])
        assert result==d;print('Rebuilt endpoint-correlated rectangular fees.',flush=True)
    else:
        assert a.books and a.out
        r=generate(a.repo,a.books,a.parts);a.out.write_text(json.dumps(r,indent=2)+'\n',encoding='ascii')
        print('Repriced',r['left'],r['right'],r['fees'],flush=True)
