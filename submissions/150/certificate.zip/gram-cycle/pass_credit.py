"""Credit the same nonnegative upper sieve polynomial on certified exterior rectangles."""
from fractions import Fraction as F
from functools import cache
from corner_phase import extra_saving


def evaluate(u,v,w,z,box,mass,mass_lower,boundary,C,banks,I,J,depth,complex_mask=False):
    m=mass(u,v,w,z)
    E=boundary(u,v)
    branches=list(banks)
    out={}

    @cache
    def rectangle(a,b,c,d):
        if c>=d:return None
        g,q=box(a,b,c,d)
        return (mass_lower(a,b,c,d)*J).__floor__(),g,q

    # Precompute each shared geometry independent of its polynomial.
    @cache
    def options(a,b,outer,high,lev):
        edge=max(w,min(z,1-a if high else max(a,1-b-C)))
        x,y=(edge,outer) if high else (outer,edge)
        R=rectangle(a,b,x,y)
        if not lev:return R,None,None
        mid=(a+b)/2
        skip=(options(a,mid,outer,high,lev-1),options(mid,b,outer,high,lev-1))
        take=(options(a,mid,edge,high,lev-1),options(mid,b,edge,high,lev-1)) if R else skip
        return R,skip,take

    @cache
    def saving(node,f,n,q,risk):
        rec,skip,take=node
        direct=bonus=0
        if rec:
            mass0,g0,q0=rec
            direct=mass0*max(0,(I-f-1)*I-(n*g0+q*q0))
            if complex_mask:
                bonus=extra_saving(mass0*(I-f-1)*I-direct,risk)
        if skip is None:return direct,direct+bonus
        def children(nodes):
            (a,b),(c,d)=(saving(k,f,n,q,risk) for k in nodes)
            return a+c,max(a+d,b+c)
        a,b=children(skip)
        c,d=children(take)
        return max(a,direct+c),max(b,direct+d,direct+bonus+c)

    high=options(u,v,z,True,depth)
    low=options(u,v,w,False,depth)
    g0,q0=box(u,v,w,z)
    for br in branches:
        rows,scale=banks[br]
        candidates=[]
        for f,n,q in rows:
            # The mean upper is (I-f)/I, coefficient bounds are n/I,q/I.
            # The polynomial can exceed one, so no truncation at one here.
            c=F((I-f)*I+n*g0+q*q0,I**2)
            main=((F(scale,J)*c-1)*J*m).__ceil__()+E
            risk=(n*g0+q*q0)*(J*m).__ceil__()
            a,b=saving(high,f,n,q,risk)
            c0,d=saving(low,f,n,q,risk)
            payoff=max(b+c0,a+d)
            credit=(F(scale*payoff,J*I**2)).__floor__()
            candidates.append((main-credit,main,credit,(f,n,q)))
        out[br]=min(candidates)
    return out
