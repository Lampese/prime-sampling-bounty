"""Keep a Fejer-distributed part of the base translations inside the Gram entry."""
from fractions import Fraction as F
from functools import cache
from math import comb


@cache
def knots(m,n):
    shifts={}
    for i in range(3):
        for j in range(3):
            x=i*m+j*n-m-n+2
            shifts[x]=shifts.get(x,0)+(-1)**(i+j)*comb(2,i)*comb(2,j)
    return sorted((x,c) for x,c in shifts.items() if c)


def count(x,m,n,cumulative=False):
    if x < 2-m-n:return 0
    den=(m*n)**2
    if x>m+n-2:return den if cumulative else 0
    k=4 if cumulative else 3
    return sum(c*comb(x-q+k,k) for q,c in knots(m,n) if q<=x)


@cache
def masses(m,n):
    powers=(2,4,6,8,10)
    A=(m*n)**2
    totals={k:0 for k in powers}
    first=2-m-n
    last=m+n-1
    cuts=sorted({first,last,*(q for q,c in knots(m,n) if first<q<last)})
    for a,b in zip(cuts,cuts[1:]):
        length=b-a
        vals=[count(a+j,m,n) for j in range(min(length,31))]
        for k in powers:
            diffs=[v**k for v in vals[:3*k+1]]
            for j in range(len(diffs)):
                totals[k]+=comb(length,j+1)*diffs[0]
                diffs=[y-x for x,y in zip(diffs,diffs[1:])]
    return {k:F(val,A**k) for k,val in totals.items()}


def test():
    for m in range(1,8):
        for n in range(1,8):
            a=(m*n)**2
            u={x:sum(max(0,m-abs(j))*max(0,n-abs(x-j))
                     for j in range(1-m,m)) for x in range(-m-n,m+n+1)}
            assert sum(u.values())==a and all(count(x,m,n)==v for x,v in u.items())
            assert all(count(x,m,n,True)==sum(z for j,z in u.items() if j<=x) for x in u)
            assert masses(m,n)=={k:sum(F(z,a)**k for z in u.values()) for k in (2,4,6,8,10)}
    print('49 exact brute-force convolution, coverage and power checks passed')


if __name__=='__main__':test()
