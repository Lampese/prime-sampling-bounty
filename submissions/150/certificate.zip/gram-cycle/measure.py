"""Centred Gram fourth-moment bounds and fixed-shift thresholds on real boxes."""
from argparse import ArgumentParser
from fractions import Fraction as F
from math import isqrt,prod
from pathlib import Path
import sys

work=Path(__file__).resolve().parents[1]
ap=ArgumentParser()
ap.add_argument('--repo',type=Path,default=work/'prime-sampling')
ap.add_argument('--geometry',type=Path,default=work/'character-next')
ap.add_argument('--rows',type=Path,default=work/'research-bilinear/m3200-six.dat')
args=ap.parse_args()
sys.path[:0]=[str(args.repo.resolve()),str(args.geometry.resolve())]
from prime_sampling.outward import b,elo,eup
from prime_sampling.accounting import ledger
from prime_sampling.accounting.catalog import BUDGETS
from characters import ceil_scaled,root_upper,decimal_up


def evaluate(high,whole):
    lo=F(150);step=F(1,3200);lam=F(1,32);eps=F(2149,10**11);dx=F(68,100000)
    zl=b(F((elo(lo)/(lo-1)).__floor__()),'ln',False)
    zh=high-b(high-F('1.1'),'ln',False)
    pm=elo(lo).__floor__();span=eup(step*zh)
    assert span/(lo-F('1.1'))<F(71,10000)
    # All cross ratios at t=0 and infinity equal one, giving a real-part
    # subtraction after a simple root has been moved to infinity.
    weil=F(2*(isqrt(pm)+1),pm-1)
    factor=step*span+eps*(span+1)/zl
    xa=eup(dx);xb=elo(-dx);a=b(32,'ln',True)
    base=excess_total=det=stoch=F(0)
    table={int(z[0]):z for l in args.rows.read_text().splitlines() if (z:=l.split())}
    for i in range(1072,1600):
        u=F(i,3200);v=u+step
        lower=max(lam*elo(-step*zh),elo((2*u-1)*zh))
        upper=max(lam,eup((2*u-1)*zl))
        den=u*(1-u-step-a/zl)
        out=ceil_scaled(2*factor*(1-lower+2*eps)/den)
        excess=ceil_scaled(2*factor*(max(lam*(1-elo(-step*zh)),eup((2*u-1)*zl)*(span-1))+4*eps)/den)
        s=(elo(u*zl)*((1-eps)*elo(step*zl)-(1+eps))/(v*zh)).__ceil__()
        k=(elo((1-u)*zl)*((1-eps)-(1+eps)*upper)/((1-u)*zh)).__ceil__()
        assert min(s,k)>=2
        uedges=1-elo(-u*dx)+span*(eup(v*dx)-1)+4*eps*span*xa
        sr=1+(v/u)*zl/(zl-dx)*uedges/((1-eps)*elo(step*zl)-(1+eps))
        vedges=xa-1+upper*(1-xb)+4*eps*xa
        kr=1+((1-u)/(1-u-step-(a+dx)/zl))*vedges/((1-eps)-(1+eps)*upper)
        inflation=root_upper(sr*kr,2)
        norm=F(1,k)+weil
        det+=ceil_scaled(out*inflation*root_upper(F(1,s),2))
        stoch+=ceil_scaled(out*inflation*root_upper(norm,4))
        base+=out;excess_total+=min(out,excess)
        if not whole and i in (1072,1280,1440,1568):
            row=table[i];rate=F(int(row[3]),10**10)
            gap=rate**2-F(1,s)
            assert gap>0
            # For a fixed pair of true sets and a shift-independent character menu.
            t4=norm/gap**2
            cent8=F(3,k**2)+F(112,k**3)+F(256,k**4)+F(6*(isqrt(pm)+1),pm-1)
            t8=cent8/gap**4
            print(float(u),'S>=',s,'K>=',k,'reference',float(rate),
                  'closed 4/8 caps',format(float(gap**2),'.5e'),format(float(gap**4),'.5e'),
                  'bad t fractions',format(float(t4),'.5e'),format(float(t8),'.5e'))
    if whole:
        A=F(ledger.allowance(high),ledger.J)
        for branch in ('with3','without3'):
            seq=ledger.rank(high,branch);g=prod(1-F(1,q) for q in seq)
            mu=prod(1-F(1,q) for q in seq[:7]);coef=(2**7-1)*mu/g
            rs=[]
            for l in range(150,161):
                h=min(high,F(l+1));rank=len(ledger.rank(h,branch))
                rs.append(min(row[0] for group,low,hi,cap,row in BUDGETS if group=='extension' and low<=l<h<=hi and cap>=rank and row[0] is not None))
            R=F(max(rs),10**9);room=A-R-(mu/g-1)*base-excess_total-coef*det
            assert room>0
            print(branch,'centred deterministic weighted part',decimal_up(det,21),'stochastic L4',decimal_up(stoch,21),
                  'bad t <=',decimal_up((coef*stoch/room)**4,33))


evaluate(F(4801,32),False)
evaluate(F(641,4),True)
