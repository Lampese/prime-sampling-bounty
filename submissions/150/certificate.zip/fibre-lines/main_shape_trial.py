from fractions import Fraction as F
from math import isqrt
from probe import boxes,sieved_lift
from smooth_cascade import segment
from smooth_wide import policies
from time import perf_counter


if __name__=='__main__':
    boxes.initialize(F(150),F(4801,32));sieved_lift.install(boxes)
    for u in map(F,('.45','.47','.49')):
        _,_,A,B,_,V,_,_=boxes.params(u,u+F(1,3200));p0,p1=boxes.pmin,boxes.pmax
        G=isqrt(p1*B)+1;cluster=policies(V//isqrt(G))
        st=perf_counter()
        for odd in (False,True):
            for state in ('d','u','free'):
                row=[]
                for f in map(F,('.75','1','1.25','1.5','2')):
                    hi=(G*f).__ceil__();lo=hi//4
                    row.append(segment(A,B,V,p0,lo,hi,(odd,state),cluster))
                print(u,odd,state,*row,flush=True)
        print('seconds',round(perf_counter()-st,2),flush=True)
