"""Test the compiled lattice cover on exact finite-field lattices and the 2-adic lemma on hyperbolas."""
from itertools import combinations
from math import gcd,isqrt
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'prime-sampling'))
from local_divisors import balanced,distributed,multiplier,two_adic_weight,reduced_two_exponent,conditional_two
from shaped_fibre import menu
from angular_fibre import EXE,EXE5,residual_ratio
from subprocess import check_output


def val2(z):
    return (abs(z)&-abs(z)).bit_length()-1


def exact_radii(beta,p,B,oriented=False,five=False):
    den=B*p
    found=[[99]*6 for _ in range(4)]
    if five:found=[[[99]*6 for _ in range(4)] for _ in range(2)]
    # Include all lifts whose normalized max norm is at most 5/2.
    top=isqrt(25*den//4)
    for d in range(1,top//B+1):
        res=d*beta%p
        first=res-((top+res)//p)*p
        for u in range(first,top+1,p):
            if abs(u)>top or gcd(d,u)!=1:continue
            rg=max(B*d,abs(u))
            lower=isqrt((16*rg)**2//den)
            tick=lower+(lower*lower*den<(16*rg)**2)
            idx=3*(d%2==u%2)+(0 if d%3==0 else 1 if u%3==0 else 2)
            tier=min(3,4*min(B*d,abs(u))//rg)
            target=found[int(u%5==0)] if five else found
            for l in range(tier+1):target[l][idx]=min(target[l][idx],tick)
    if five:return found
    return tuple(tuple(r) for r in found) if oriented else tuple(found[0])


def lattice_test():
    rows=menu()
    seen=set()
    for p,B in [(101,3),(257,7),(1009,17),(2003,31)]:
        for beta in range(1,p):
            row=exact_radii(beta,p,B)
            if row not in seen:
                assert any(all(a<=b for a,b in zip(row,limit)) for limit in rows),(p,B,beta,row)
                seen.add(row)
    return len(seen)


def determinant_test():
    tests=0
    for d,u in [(1,2),(2,1),(1,1),(3,5)]:
        for v2 in range(10):
            N=2**v2*3**4*5**3*7**2*11*13
            divisors=[2**h*3**a*5**b*7**c*11**e*13**f for h in range(v2+1)
                      for a in range(5) for b in range(4) for c in range(3)
                      for e in range(2) for f in range(2)]
            xs=sorted(x for x in divisors if (x-u)%d==0 and (N//x+u)%d==0
                      and ((x-u)//d)%2 and ((N//x+u)//d)%2)
            for n in [7,13,25]:
                odd=(d%2 and u%2)
                k=n//2
                if odd:
                    bound=k*(k+1)
                    f=2
                    while f<n:
                        bound+=min([balanced(n,f)]+[(s-k)*(s-k-1)//2+balanced(n-s,f-1) for s in range(n+1)])
                        f*=2
                else:bound=distributed(n,2,1)
                assert two_adic_weight(n,odd)==multiplier(n,2,bound)
                if len(xs)<n:continue
                for offset in {0,(len(xs)-n)//2,len(xs)-n}:
                    selected=xs[offset:offset+n]
                    ts=[(x-u)//d for x in selected]
                    actual=v2*k*(k+1)//2+sum(val2(y-x) for x,y in combinations(ts,2))-k*sum(map(val2,selected))
                    assert actual>=bound,(d,u,N,n,actual,bound)
                    if odd and v2<=5:
                        assert v2>=2 and actual>=reduced_two_exponent(n,v2-2),(d,u,N,n,actual,v2)
                    tests+=1
    for n in (7,13,25):
        weight=two_adic_weight(n,True)
        mean,err,largest=conditional_two(n)
        samples=[min(weight,multiplier(n,2,reduced_two_exponent(n,val2(i)))) if i%16 else weight for i in range(16)]
        assert sum(samples)/16==mean and max(samples)==largest and largest<=err
    return tests


def angular_test():
    # The shape checker sees unrelated monotone toy tariffs on each mode.
    prices=[];maxima=[]
    for seed in (2,5,13):
        grid=[[[((19*seed+3*i)%47+9)*(3*t+1)*(14-l) for t in range(41)]
                for i in range(6)] for l in range(4)]
        ranks=' '.join(str(v) for group in grid for mode in group for v in mode)
        maxima.append(int(check_output([str(EXE),'--price'],input=ranks,text=True)))
        prices.append(grid)
    count=0
    for p,B in [(101,3),(257,7),(1009,17),(2003,31)]:
        for beta in range(1,p):
            actual=exact_radii(beta,p,B,True)
            for grid,worst in zip(prices,maxima):
                best=min(grid[l][i][t] for l,m in enumerate(actual) for i,t in enumerate(m) if t<99)
                assert best<=worst,(p,B,beta,best,worst)
            count+=1
    products=0
    for B in (9,17,31):
        for A in range(1,B):
            for d in range(1,5):
                for u in range(1,5*B):
                    G=max(B*d,u);tier=min(3,4*min(B*d,u)//G)
                    n,b=residual_ratio(A,B,tier)
                    largest=max(abs((d*t+u)*(d*s-u)) for t in (A,B) for s in (A,B))
                    assert b*largest<=n*G**2,(A,B,d,u,n,b,largest)
                    products+=1
    return count*len(prices),products


def five_test():
    prices=[[[[((19+3*i)%17+7-2*f)*(3*t+1)*(14-l) for t in range(41)]
              for i in range(6)] for l in range(4)] for f in range(2)]
    ranks=' '.join(str(v) for sub in prices for group in sub for mode in group for v in mode)
    maximum=int(check_output([str(EXE5),'--price5'],input=ranks,text=True))
    count=0
    for p,B in [(257,7),(1009,17)]:
        for beta in range(1,p):
            actual=exact_radii(beta,p,B,True,True)
            best=min(prices[f][l][i][t] for f,sub in enumerate(actual) for l,grp in enumerate(sub)
                     for i,t in enumerate(grp) if t<99)
            assert best<=maximum,(p,B,beta,best,maximum)
            count+=1
    return count


if __name__=='__main__':
    print('small lattices',100+256+1008+2002,'distinct radii',lattice_test(),flush=True)
    print('determinant valuations',determinant_test(),flush=True)
    print('angular lattices and product ranges',*angular_test(),flush=True)
    if EXE5.exists():print('additional five-mode angular lattices',five_test(),flush=True)
