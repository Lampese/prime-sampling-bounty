#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <numeric>
#include <set>
#include <string>
#include <vector>

using I=std::int64_t;
using Row=std::array<int,6>;
constexpr I K=64, unit=K*K, tick=16; // upper radius unit = 1/16
constexpr int none=99;
struct Vector {int direction2,direction3,direction5,norm,tier;};

I minimum_abs(I lo,I hi) {return lo<=0 && 0<=hi?0:std::min(std::abs(lo),std::abs(hi));}

int direction(int i,int j,int p) {
    if(j%p==0)return p;
    for(int s=0;s<p;++s)if((i+s*j)%p==0)return s;
    std::abort();
}
int main(int argc,char **argv) {
    bool five=argc==2 && std::string(argv[1])=="--price5";
    bool price=five || (argc==2 && std::string(argv[1])=="--price");
    int ranks[2][4][6][41]={},worst=0;
    if(price){
        for(int f=0;f<=(int)five;++f){
            for(auto &group:ranks[f])for(auto &mode:group)for(auto &r:mode)if(!(std::cin>>r))return 2;
            for(int mode=0;mode<6;++mode)worst=std::max(worst,ranks[f][0][mode][8]);
        }
    }
    std::set<Row,std::greater<Row>> unique;
    for(int c=0;c<6;++c){Row r;r.fill(none);r[c]=8;unique.insert(r);}
    constexpr I step=2;
    for(I tl=K/2;tl<K;tl+=step)for(I rl=0;rl<=tl+step && rl<K;rl+=step)
    for(I zl=-K/2;zl<K/2;zl+=step) {
        const I th=tl+step,rh=rl+step,zh=zl+step;
        std::vector<Vector> vec;
        for(int j=0;j<=4;++j)for(int i=-6;i<=6;++i) {
            if(std::gcd(std::abs(i),j)!=1)continue;
            I h0=i*K+j*zl,h1=i*K+j*zh;
            I X=th*std::max(std::abs(h0),std::abs(h1));
            I Y0=std::min({rl*h0,rl*h1,rh*h0,rh*h1})+j*K*unit/th;
            I Y1=std::max({rl*h0,rl*h1,rh*h0,rh*h1})+(j*K*unit+tl-1)/tl;
            I top=std::max({X,std::abs(Y0),std::abs(Y1)});
            // v is known to have norm exactly t even if rl+step>th.
            if(j==0)top=th*K;
            int n=static_cast<int>((top*tick+unit-1)/unit);
            I mx=tl*minimum_abs(h0,h1),my=minimum_abs(Y0,Y1);
            int tier=static_cast<int>(std::min<I>(3,4*std::min(mx,my)/top));
            if(n<=40)vec.push_back({direction(i,j,2),direction(i,j,3),direction(i,j,5),n,tier});
        }
        for(int both=0;both<3;++both)for(int d=0;d<4;++d)for(int u=0;u<4;++u) {
            if(d==u)continue;
            Row r;r.fill(none);
            int value[6]={2000000000,2000000000,2000000000,2000000000,2000000000,2000000000};
            for(auto v:vec) {
                int mode=(v.direction2==both?3:0)+(v.direction3==d?0:v.direction3==u?1:2);
                r[mode]=std::min(r[mode],v.norm);
                if(five)for(int line=0;line<6;++line)
                    value[line]=std::min(value[line],ranks[line==v.direction5][v.tier][mode][v.norm]);
                else if(price)value[0]=std::min(value[0],ranks[0][v.tier][mode][v.norm]);
            }
            if(price){for(int f=0;f<(five?6:1);++f)worst=std::max(worst,value[f]);continue;}
            unique.insert(r);
        }
    }
    if(price){std::cout<<worst<<"\n";return 0;}
    std::vector<Row> maximal;
    for(auto r:unique) {
        bool covered=false;
        for(auto m:maximal) {
            bool dominates=true;
            for(int j=0;j<6;++j)if(m[j]<r[j]){dominates=false;break;}
            if(dominates){covered=true;break;}
        }
        if(!covered)maximal.push_back(r);
    }
    for(auto r:maximal){for(auto x:r)std::cout<<x<<" ";std::cout<<"\n";}
    std::cerr<<"distinct "<<unique.size()<<" maximal "<<maximal.size()<<"\n";
}
