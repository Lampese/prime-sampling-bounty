"""Price all norm and angle alternatives on the exact finite shape cover."""
from functools import lru_cache
from math import isqrt
from pathlib import Path
from subprocess import check_output
import os
from shaped_fibre import MODES
from smooth_wide import policies
from smooth_cascade import segment

EXE=Path(os.environ['PRIME_SHAPE_EXE']) if 'PRIME_SHAPE_EXE' in os.environ else Path(__file__).with_name('angular_main_shape'+('.exe' if os.name=='nt' else ''))
EXE5=EXE.with_name('angular_five_shape'+EXE.suffix)


def residual_ratio(A,B,tier):
    if tier and A*(4+tier)>=4*B:return (1,1)
    for n,d in ((65,64),(17,16),(9,8),(3,2),(2,1)):
        if (A+B)**2*d<=4*A*B*n:return (n,d)
    return (4,1)


def calculate(A,B,V,p0,p1,detail=False,tight=True,sieve=False,five=False,schedule=False):
    start=max(B,min(A*A,-(-p0//(B+V))))
    norm=isqrt(p1*B)+1
    if 5*norm>=2*p0:return (V+1,None) if detail else V+1
    cluster=policies(V//max(1,isqrt(norm)))
    grid=[]
    for f,tier in ((f,t) for f in (('unit-u','u') if five else (None,)) for t in range(4)):
        for basic in MODES:
            angle=(4,4+tier) if tier and A*(4+tier)>=4*B else (1,1)
            residual=residual_ratio(A,B,tier) if tight else (4,1)
            mode=basic+((True,31) if sieve else (True,))
            if five:mode=basic+(True,31,f)
            current=0
            upper=0
            scores=[0]*41
            for tick in range(8,41):
                endpoint=-(-norm*tick//16)
                hi=endpoint
                if hi<start:continue
                lo=max(start,upper)
                parts=[]
                while hi//16>lo:
                    parts.append((hi//16,hi));hi//=16
                parts.append((lo,hi))
                for l,h in reversed(parts):
                    direct=segment(A,B,V,p0,l,h,mode,(),arch=angle,residual=residual)
                    if direct>current:direct=segment(A,B,V,p0,l,h,mode,cluster,arch=angle,residual=residual)
                    current=max(current,direct)
                upper=endpoint
                scores[tick]=current
            scores[:8]=[scores[8]]*8
            grid.extend(scores)
    unique=sorted(set(grid))
    inverse={cost:i for i,cost in enumerate(unique)}
    rankdata=' '.join(str(inverse[cost]) for cost in grid)
    winning=int(check_output([str(EXE5 if five else EXE),'--price5' if five else '--price'],input=rankdata,text=True))
    result=min(V+1,unique[winning])
    if schedule:
        limits=[max((t for t in range(8,41) if grid[j+t]<=unique[winning]),default=0)
                for j in range(0,len(grid),41)]
        return result,limits
    return (result,(winning,len(unique))) if detail else result


def install(sieve=False):
    from prime_sampling.spectrum import squarerates as sr
    old=sr.square_cap
    @lru_cache(maxsize=65536)
    def joined(A,B,V,p0,p1):
        prev=old(A,B,V,p0,p1)
        if not (194<A<B<p0 and 0<V<=B and p0<=p1<2*p0):return prev
        return min(prev,calculate(A,B,V,p0,p1,sieve=sieve))
    sr.square_cap=joined
