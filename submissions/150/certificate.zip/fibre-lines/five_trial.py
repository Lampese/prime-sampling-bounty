from fractions import Fraction as F
from math import isqrt
import os
from probe import boxes,sieved_lift
from smooth_cascade import segment
from smooth_wide import policies
from angular_fibre import residual_ratio

if __name__=='__main__':
    boxes.initialize(F(150),F(4801,32));sieved_lift.install(boxes)
    for strip in (F('.47'),F('.49')):
        _,_,A,B,_,V,_,_=boxes.params(strip,strip+F(1,3200));p0,p1=boxes.pmin,boxes.pmax
        H=isqrt(p1*B)+1;L=H*15//16;cluster=policies(V//isqrt(H))
        for odd in (False,True):
            for state in ('d','u','free'):
                vals=[]
                for five in (None,'d','u','free'):
                    mode=(odd,state,True,31,five)
                    vals.append(segment(A,B,V,p0,L,H,mode,cluster,residual=residual_ratio(A,B,0)))
                print(strip,odd,state,*vals,flush=True)
    if os.name=='nt':
        import _ctypes
        from prime_sampling.spectrum import squarerates as sr
        _ctypes.FreeLibrary(sr._lib._handle)
