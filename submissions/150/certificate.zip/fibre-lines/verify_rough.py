from collections import Counter
from fractions import Fraction as F
from itertools import product
from math import prod,isqrt
from random import Random
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'prime-sampling'))
from rough_select import omega_bounds
from smooth_split import primes


def check():
    rng=Random(20261125);checked=0
    ps=primes(1200)
    for _ in range(700):
        factors=sorted(rng.choices(ps,k=rng.randrange(2,10)),reverse=True)
        Y=rng.choice((10000,400000,10**6,10**8,10**11))
        Z=rng.choice((107,251,503,997))
        b=0;t=1
        while t<Y:t*=Z;b+=1
        selected=[];m=1
        for q in factors:
            if q<=101:break
            m*=q;selected.append(q)
            if m>=Y:break
        tau=prod(e+1 for e in Counter(selected).values())
        avail=Counter(q for q in factors if 101<q<=Z)
        es=[]
        for exps in product(*(range(h+1) for h in avail.values())):
            pp=[q for (q,h),i in zip(avail.items(),exps) for _ in range(i)]
            if pp:es.append((prod(pp),min(pp)))
        bound=0
        for h in range(b):
            if h and max(factors)>Y//Z**(h-1):continue
            coeff=2 if h==0 else 2**h
            bound+=coeff*(1+sum(e*e*Z**h<Y*small for e,small in es))
        assert tau<=bound,(factors,Y,Z,tau,bound)
        checked+=1
    for a,b,P,Z in ((100,1000,101,457),(9000,18000,107,313),(100000,150000,113,1103)):
        H,C=omega_bounds(a,b,P,Z)
        allowed=set(primes(Z))-set(primes(P))
        vals=[1]
        for p in sorted(allowed):
            fresh=[]
            for d in vals:
                dp=d*p
                while dp<=b:fresh.append(dp);dp*=p
            vals+=fresh
        true=[d for d in vals if a<d<=b]
        assert len(true)<=C and sum(F(1,d) for d in true)<=H
    return checked


if __name__=='__main__':
    print('directed prime-factor assignments and smoothed allocation upper envelopes:',check())
