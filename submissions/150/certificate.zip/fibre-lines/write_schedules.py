from fractions import Fraction as F
from pathlib import Path
from math import isqrt
from time import perf_counter
from subprocess import check_output
import json
import os
from probe import boxes,sieved_lift
from angular_fibre import calculate,EXE

if __name__=='__main__':
    boxes.initialize(F(150),F(4801,32));sieved_lift.install(boxes)
    rows=[]
    for strip in map(F,('.40','.45','.47','.49')):
        _,_,A,B,_,V,_,_=boxes.params(strip,strip+F(1,3200));p0,p1=boxes.pmin,boxes.pmax
        start=perf_counter()
        value,limits=calculate(A,B,V,p0,p1,sieve=True,schedule=True)
        mask=' '.join(str(int(k>t)) for t in limits for k in range(41))
        assert int(check_output([str(EXE),'--price'],input=mask,text=True))==0
        rows.append({'strip':str(strip),'ratio':V//isqrt(isqrt(B*p1)+1),'ticks':limits})
        print(strip,value,limits,'seconds',round(perf_counter()-start,2),flush=True)
    Path(__file__).with_name('shape-schedules.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='ascii')
    if os.name=='nt':
        import _ctypes
        from prime_sampling.spectrum import squarerates as sr
        _ctypes.FreeLibrary(sr._lib._handle)
