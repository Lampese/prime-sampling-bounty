"""Both endpoints of the divisor pairing restrict the factor-base interval."""
from functools import cache
from math import comb,isqrt
from bisect import bisect_right
from fractions import Fraction as F
import rough_factor as rf
from smooth_split import ceilrat,primes,SCALE
from smooth_tail import count as analytic_count

original=rf.rough_blocks


@cache
def prime_elements(lo,hi):
    if hi<=lo:return F(0),0
    bases=primes(200000)
    count=0;recip=0
    if lo<200000:
        p0=bisect_right(bases,lo);p1=bisect_right(bases,min(hi,200000))
        table=prime_prefix()
        count+=p1-p0;recip+=table[p1]-table[p0];lo=200000
    while lo<hi:
        end=min(hi,lo+lo//4)
        c=analytic_count(lo,end);count+=c;recip+=ceilrat(c*SCALE,lo+1)
        lo=end
    return F(recip,SCALE),count


@cache
def prime_prefix():
    out=[0]
    for q in primes(200000):out.append(out[-1]+ceilrat(SCALE,q))
    return out


@cache
def omega_bounds(a,b,P,Z):
    P=max(P,101);Z=min(b,Z)
    if P>=Z:return F(0),0
    # Only k in this range can be the full number of prime factors.
    klo=1;mult=Z
    while mult<=a:klo+=1;mult*=Z
    khi=0;mult=1
    while mult*(P+1)<=b:khi+=1;mult*=P+1
    if khi<klo:return F(0),0
    prime_sum,qcount=prime_elements(P,Z)
    hs=prime_sum;H=F(0);C=0
    for k in range(1,khi+1):
        if k>=klo:
            each=comb(qcount+k-1,k)
            H+=min(hs,F(each,a+1))
            C+=min(each,(b*hs).__floor__())
        hs=hs*(prime_sum+F(k,P+1))/(k+1)
    return H,C


@cache
def selected(Y,Z,tag=False):
    if Z==0:
        old=original(Y,Z)
        return [(*row,0) for row in old] if tag else old
    hmax=0;prod=1
    while prod<Y:hmax+=1;prod*=Z
    blocks=[] if tag else [(1,1,F(2**hmax),2**hmax)]
    for h in range(hmax):
        coef=2 if h==0 else 2**h
        qmax=Y//Z**(h-1) if h else 0
        if tag:blocks.append((1,1,F(coef),coef,qmax))
        E=isqrt(Y*Z//Z**h)
        a=1
        while a<E:
            b=min(E,max(101,a*8))
            P=max(101,a*a*Z**h//Y)
            base_h,base_count=rf.interval(a,b)
            hr,c=omega_bounds(a,b,P,Z)
            hr=min(hr,base_h);c=min(c,base_count)
            if hr and c:
                row=(a+1,b,coef*hr,coef*c)
                blocks.append((*row,qmax) if tag else row)
            a=b
    # Preserve the sharper of the two positive bounds per dyadic width
    # by using this as an additional price, independently from the old edge.
    return blocks


def install():
    rf.rough_blocks=selected


def install_tagged():
    rf.rough_blocks=lambda y,z:selected(y,z,True)
