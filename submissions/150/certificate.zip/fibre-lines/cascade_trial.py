from fractions import Fraction as F
from math import isqrt
from time import perf_counter
import sys
from probe import boxes,sieved_lift
from smooth_cascade import calculate,segment

if __name__=='__main__':
    boxes.initialize(F(150),F(4801,32))
    sieved_lift.install(boxes)
    if '--mixed' in sys.argv:
        from mixed_events import install_coefficients
        install_coefficients()
    for u in map(F,('.40','.45','.47','.49')):
        _,_,a,b,_,v,_,_=boxes.params(u,u+F(1,3200))
        p0,p1=boxes.pmin,boxes.pmax
        D=isqrt(p1//b);G=max(b*D,-(-p1//D))
        start=perf_counter()
        if '--search' in sys.argv or '--tail-search' in sys.argv:
            candidates=tuple((z,s) for z in (1000,3000,10000,30000,100000,300000) for s in (2,3,4,5,6))
            if '--tail-search' in sys.argv:
                candidates+=tuple((10**i,s) for i in range(6,12) for s in (1,2,3,4,5))
            scores=[segment(a,b,v,p0,G//16,G,g3,candidates,True) for g3 in (False,True)]
            val=max(x[0] for x in scores)
            print(u,'top segment',val,scores,'per envelope',float(F(val*p0,v*G+p0)),'sec',round(perf_counter()-start,2),flush=True)
        else:
            if '--wide' in sys.argv:
                from smooth_wide import calculate
            if '--extreme' in sys.argv:
                val,rows=calculate(a,b,v,p0,p1,True,extreme=True)
            else:
                val,rows=calculate(a,b,v,p0,p1,True)
            worst=max(rows,key=lambda r:max(r[2][0],r[3][0]))
            print(u,'all directions',val,worst[2:],'per envelope',float(F(val*p0,v*G+p0)),'sec',round(perf_counter()-start,2),flush=True)
