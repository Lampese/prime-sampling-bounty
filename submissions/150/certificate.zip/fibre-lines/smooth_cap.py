"""Uniform two-endpoint fibre envelope by removing large prime factors."""
from functools import lru_cache
from fractions import Fraction as F
from math import isqrt
from smooth_split import split_at


def calculate(A,B,V,p0,p1,detail=False):
    D=isqrt(p1//B)
    gmin=max(B,min(A*A,-(-p0//(B+V))))
    gmax=max(B*D,-(-p1//D))
    if gmin>gmax:return (0,[]) if detail else 0
    # This is just a portfolio of rigorous parameters. No prime factorization
    # or observed prime p in the window is used to make a validity decision.
    ratio=V//max(1,isqrt(gmax))
    if ratio<500:
        portfolio=((1000,3),(3000,4))
    elif ratio<18000:
        portfolio=((30000,4),(10000,4))
    elif ratio<200000:
        portfolio=((10000,4),(10000,5))
    else:
        portfolio=((30000,5),(10000,5))
    rows=[]
    hi=gmax
    while True:
        lo=max(gmin,hi//16)
        cases=[]
        for g3 in (False,True):
            prices=[]
            for z,s in portfolio:
                trial=split_at(A,B,V,p0,hi,lo,False,g3,z,s)
                if trial is not None:
                    (x,*_),(y,*_)=trial
                    prices.append(((x+y).__ceil__(),z,s))
            # For fixed a there is at most one choice of c.
            cases.append(min(prices,default=(V+1,0,0)))
        rows.append((lo,hi,*cases))
        if lo==gmin:break
        hi=lo
    cap=min(V+1,max(max(x[2][0],x[3][0]) for x in rows))
    return (cap,rows) if detail else cap


def install():
    from prime_sampling.spectrum import squarerates as sr
    old=sr.square_cap
    @lru_cache(maxsize=65536)
    def joined(A,B,V,p0,p1):
        prev=old(A,B,V,p0,p1)
        if not (194<A<B<p0 and 0<V<=B and p0<=p1<2*p0):return prev
        D=isqrt(p1//B)
        if not 0<D<p0:return prev
        return min(prev,calculate(A,B,V,p0,p1))
    sr.square_cap=joined
