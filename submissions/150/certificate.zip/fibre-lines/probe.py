"""Audit elementary line conditions and direct divisor thresholds on four real strips."""
from fractions import Fraction as F
from math import gcd,isqrt
from pathlib import Path
import json
import os
import sys

here=Path(__file__).resolve().parent
work=here.parent
sys.path[:0]=[str(work/'prime-sampling'),str(work/'residue-bridge'/'crt-fast')]
if (work/'zig-cxx.cmd').is_file():
    os.environ.setdefault('CXX',str(work/'zig-cxx.cmd'))
    os.environ.setdefault('ZIG_GLOBAL_CACHE_DIR',str(work/'zig-cache'))
    os.environ.setdefault('ZIG_LOCAL_CACHE_DIR',str(work/'zig-local-cache'))
from prime_sampling.rectangles import boxes,sieved_lift
from prime_sampling.spectrum import squarerates as sr
import crt_fibres,line_cap


def main():
    boxes.initialize(F(150),F(4801,32))
    sieved_lift.install(boxes)
    actual=json.loads((work/'energy-next'/'local-witness.json').read_text())['p']
    for u in map(F,('.40','.45','.47','.49')):
        _,_,a,b,_,v,_,_=boxes.params(u,u+F(1,3200))
        p0,p1=boxes.pmin,boxes.pmax
        D=isqrt(p1//b);U=(p1+D-1)//D
        assert (D*b*b+U*v)//p0<a
        d=6*(D//6)
        # A genuine denominator/numerator pair on the prime in the existing
        # Lucas certificate. This example does not assert that its fibre is nonempty.
        beta=pow(d,-1,actual)
        assert d*beta%actual==1 and d>0 and gcd(d,actual)==1
        nmin=(d*a-1)*(d*a+1)
        # If both signed factors came from actual endpoints, their absolute
        # product would exceed d^4 and the interval d*v would exceed N^(1/4).
        nmax=(d*b+1)**2
        assert d**4<nmin and (d*v)**4>nmax
        md0=min(sr.dirichlet_cap(a,b,v,p0,p1),sr.square_cap(a,b,v,p0,p1),sr.previous_cap(v,b,p0))
        old=min(md0,crt_fibres.partition(a,b,v,p0,p1,corner=True,layered=True))
        cap,det,rows=line_cap.calculate(a,b,v,p0,p1,True)
        worst=max(rows,key=lambda r:r[2])
        from math import log
        print(u,'a,b-width',a,v,'old',old,'new',min(old,cap),'two-basis',cap,'line-only',det,flush=True)
        print('  bottleneck G/start,end values',worst[0],worst[1],worst[4],flush=True)
        print('  actual p; 6|d,u=1 rexponent',log(d)/log(nmin),'arc exponent',log(d*v)/log(nmax),flush=True)
    if os.name=='nt':
        import _ctypes
        _ctypes.FreeLibrary(sr._lib._handle)


if __name__=='__main__':main()
