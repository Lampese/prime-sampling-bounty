from fractions import Fraction as F
from math import isqrt
from time import perf_counter
from probe import boxes,sieved_lift
from smooth_cap import calculate

if __name__=='__main__':
    boxes.initialize(F(150),F(4801,32))
    sieved_lift.install(boxes)
    for u in map(F,('.40','.45','.47','.49')):
        _,_,a,b,_,v,_,_=boxes.params(u,u+F(1,3200))
        start=perf_counter()
        cap,rows=calculate(a,b,v,boxes.pmin,boxes.pmax,True)
        worst=max(rows,key=lambda r:max(r[2][0],r[3][0]))
        G=rows[0][1];p0=boxes.pmin
        print(u,'all-directions cap',cap,'segments',len(rows),'bottleneck',rows.index(worst),
              'modes',worst[2:],'per envelope',float(F(cap*p0,v*G+p0)),
              'seconds',round(perf_counter()-start,2),flush=True)
