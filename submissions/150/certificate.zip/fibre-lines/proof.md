# A two-endpoint divisor determinant on the lifted reciprocal-difference lines

Let \(p_0\le p\le p_1<2p_0\) be prime, \(194<A<B<p_0\), and \(0<V\le B\). For each \(p\) separately let the prime endpoints \(a,c\) lie in one interval \([L,H]\subset[A,B]\) of width at most \(V\). Fix any nonzero \(\beta\bmod p\) and count all ordered pairs satisfying \(ac\equiv \beta(c-a)\bmod p\). All bounds below are uniform in \(\beta,p,L,H\). The grading hook uses only the one-dimensional method described here. Both orientations of the endpoint pair are accounted for by the ordered count.

## The lift and the second direction

Set \(D=\lfloor\sqrt{p_1/B}\rfloor,\ G_0=\max(B,\min(A^2,\lceil p_0/(B+V)\rceil)),\ G_1=\max(BD,\lceil p_1/D\rceil)\), with \(1\le D<p_0,\ G_1<Bp_0/4\). Dirichlet approximation and cancellation give a primitive pair \(1\le d\le D,\ u\equiv d\beta\bmod p,\ 0<|u|\le\lceil p_1/D\rceil\). Set \(G=\max(Bd,|u|)\). If the fibre is nonempty then \(G_0\le G\le G_1\). Indeed \(G<A^2,\ G(B+V)<p\) gives \(dac=u(c-a)\). Since \(a\ne c\) are primes, \((ac,c-a)=1\) so \(ac\mid u\), a contradiction.

Write \(dac-u(c-a)=jp\). On \([L,H]^2\) this bilinear expression obtains its extrema at corners. Adjacent corner differences are at most \(V(dB+|u|)\), and the two diagonal differences are \(d(H^2-L^2)\) and \(2u(H-L)\) up to sign. Thus the possible \(j\) lie in a real interval of width \(Y=2VG/p_0\). A single residue class modulo \(m\) has counting discrepancy at most 1 relative to the actual interval length divided by \(m\).

We always have \(j\equiv d\bmod2\). If \(d,u\) are odd, the factorization \((da-u)(dc+u)=djp-u^2\) restricts \(j\) to one residue modulo 4. If \(3\nmid d\), the allowed classes modulo 3 number at most two, as established below. Hence one gets a direct bound \(1+Y/m\) or \(2+2Y/(3m)\), where \(m=4\) or 2 respectively according to the common oddness of \(d,u\).

There is a useful choice of direction in the remaining case \(3\mid d\) and \(d,u\) have opposite parity. Take a Bézout complement \((d',u')\) with \(du'-ud'=p\). It also satisfies \(u'\equiv\beta d'\bmod p\) and \(3\nmid d'\). Modulo 2 its coordinate opposite an even component of \((d,u)\) is odd. Adding a multiple of \((d,u)\) can make the other coordinate odd as well. Among the shifts of this prescribed parity choose the one that makes \(|d'|\le d\) if \(Bd\ge|u|\), and \(|u'|\le|u|\) otherwise. This follows by rounding along a progression of step \(2d\) or \(2|u|\). The determinant then gives
\[
  pB/(2G)\le G'=\max(B|d'|,|u'|)\le pB/G+G .
\]
The lower bound follows from \(p\le 2GG'/B\). For the upper bound solve for the other component in the determinant. We may flip both signs to take \(d'>0\). Since \(G\ge B,\ B>194,\ G\le G_1<Bp_0/4,\ p_1<2p_0\), we have \(d'<p\) and \((d',u')\mid p\) implies that the complement is primitive. Also \(u'\ne0\). Consequently we can independently bound this exceptional direction by a direction with both coordinates odd and \(3\nmid d'\), keeping the smaller of its two bounds.

## Determinant on a single integer line

Choose \(n=2k+1\) with \(2n<A\), and \(M=n(n-1)/2=kn\). Fix \(j\), and put \(N=djp-u^2\ne0\), since \(p\nmid u\). Let \(x=dt+|u|\), taking \(t=c\) for \(u>0\) or \(t=a\) for \(u<0\). The other factor \(y=ds-|u|\) equals \(N/x\). Distinct solutions have distinct \(t\), and \(t,s\) are prime endpoints. For any \(n\) distinct solutions set
\[
 Z=N^{k(k+1)/2}\prod_{i<j}(t_j-t_i)\big/\prod_i x_i^k .
\]
Up to sign, this equals the integer determinant with columns \(1,t,\ldots,t^k,s,\ldots,s^k\), divided by \(d^{k^2}\). To check this, translate and scale the powers of \(t,s\) to those of \(x,y\), substitute \(y=N/x\), clear \(x_i^k\) in every row and use Vandermonde in \(x\). Thus \(Z\) is integral at primes not dividing \(d\). At primes dividing \(d\), the displayed formula is integral because every \(x_i\) is a unit. In particular \(Z\) is a nonzero integer.

With \(R=dB+|u|\), \(r_0=dA+|u|\), one has \(|N|\le R^2,\ R/r_0\le B/A,\ r_0\ge(A/B)G\). Thus \(|Z|\le (B/A)^M G^{-k^2}|\operatorname{Vand}(t)|\). For points of span \(T\), evaluating the monic rescaled Chebyshev polynomials of degrees \(0,\ldots,n-1\) and applying Hadamard gives
\[
 |\operatorname{Vand}(t)|\le n^{n/2} 2^{n-1}(T/4)^M .
\]
If \(K\mid Z\) for every such choice, then \(T\ge C_n(K)(A/B)G^{k/n}\), where \(C_n(K)=4[K/(n^{n/2}2^{n-1})]^{1/M}\). Sort all solutions by \(t\). Disjoint consecutive stretches of \(n-1\) gaps each have this minimal span, so their number in width \(V\) gives the line bound \(n+(n-1)VB/[A\,C_n(K)G^{k/n}]\).

## Prime factors of the determinant from both endpoints

Define \(b(h,f)\) as the minimum number of pairs in equal classes when \(h\) points are distributed into \(f\) classes. It is attained by class sizes differing by at most one. For \(f=0\), only \(h=0\) is possible. Write \(H_r(h,f)=\sum_{\ell\ge0} b(h,fr^\ell)\) for \(f>0\). If at most \(f\) classes modulo a prime \(r\) are allowed, the \(r\)-adic valuation of the Vandermonde is at least \(H_r(h,f)\), by counting coincident pairs at each prime power.

For clarity the baseline \(K_0\) already present for \(n\le97\) has \(v_r(K_0)=E_0\). For each \(h\ge1\) put \(f=(r-1)r^{h-1}\), and sum
\[
 \min\left(b(n,f),\ \min_{0\le s\le n}
       \left[\tfrac12(s-k)(s-k-1)+b(n-s,f-1)\right]\right).
\]
Terms vanish for \(f\ge n\). If \(r\mid d\) this follows from \(v_r Z=v_r\operatorname{Vand}(t)\). Otherwise the congruence \(x=0\bmod r^h\) corresponds to one \(t\) class. If that class is possible and \(h\le v_rN\), take \(s=\#\{i:r^h\mid x_i\}\); its pair contribution together with the powers of \(N,x_i\) is \((s-k)(s-k-1)/2\). The remaining points occupy at most \(f-1\) classes. If that class is impossible use \(b(n,f)\). For \(h>v_rN\) all \(x_i\) avoid zero modulo \(r^h\). The argument applies to \(r<A\), guaranteed for each prime with a nonzero summand. It applies without change to \(n=193,385\).

For an odd prime \(r<\min(A,p)\), fixed \(j\bmod r\) gives this sharper table whenever \(N\not\equiv0\bmod r\). It gives the number \(f\) of possible residues of \(t\). In each realizable case \(v_r Z=v_r\operatorname{Vand}(t)\ge H_r(n,f)\).

| Parameters modulo \(r\) | \(j=0\) | Other \(j\) with \(N\ne0\bmod r\) |
|---|---:|---:|
| \(d=0\) | \(r-1\) | \(r-2\) |
| \(u=0\) | impossible | \(r-1\) |
| \(du\ne0\) | \(r-2\) | \(r-3\) |

For the last row solve \(c=(jp-ua)/(da-u)\). In the generic case one must omit the three distinct residues \(0,u/d,jp/u\). For \(j=0\) two of them coincide. Interchanging the coordinate counted yields the same cardinalities. For \(d=0\) use \(u(a-c)=jp\), and for \(u=0\) use \(dac=jp\). In particular an odd prime \(r\ge5\) with \(r\nmid du\) omits no \(j\) class altogether. Solutions in any permitted class lift to all powers whenever one partial derivative is a unit. In the singular residue choose one factor zero and its partner nonzero; with \(r\ge5\) there are suitable units. If \(d\equiv0\bmod6,\ u=1\), all even \(j\) occur locally at every prime power. This assertion concerns local obstructions, irrespective of the box.

If \(r\nmid du\) and \(l=v_r N\ge1\), partition by \(i=v_rx\in[0,l]\). Let the sizes be \(s_i\), with \(S_h=\sum_{i\ge h}s_i\). Then
\[
 v_rZ\ \ge\ \sum_{h=1}^l (S_h-k)(S_h-k-1)/2+
       \sum_{i=0}^l H_r(s_i,f_i),\qquad
       f_0=f_l=r-2,\quad f_i=r-1\ (0<i<l).
\]
Indeed unequal valuations contribute their common minimum to every difference. The same minimum contributes for equal valuations, and one must add the Vandermonde of \(x/r^i\) within each group. The base contributions at level \(h\) are \(\binom{S_h}2+k(k+1)/2-kS_h\). In the first group \(x=dt+|u|\) omits \(|u|\bmod r\) because \(t\) is a unit. In the last group \(y=ds-|u|\) omits \(-|u|\bmod r\), excluding one residue of \(x/r^l\) using its inverse times \(N/r^l\). This proves the claimed counts and the elementary dynamic-programming minimization implemented in local_divisors.py. The implementation may conservatively revert to \(E_0\) for \(l\ge4\), and for \(n>97,l\ge2\).

## Accumulating one prime power at a time

For each \(r\) use an upper rational weight \(W_r(j)\ge r^{-\max(E(j)-E_0,0)/M}\) on allowed \(j\), with \(W_r=0\) in excluded classes. The second term of the line bound can be multiplied by \(\prod_r W_r\); its first term \(n\) can be multiplied by the indicator of allowed classes. The two terms use their respective weights independently.

For \(r\nmid du\) the weight is a constant plus a multiple of \(1_{r\mid j}\) and up to four multiples of \(1_{r^h\mid djp-u^2}\) for \(1\le h\le4\). All these conditions are single classes, including each higher singular class. In the cases \(r\mid d\) or \(r\mid u\) only one exceptional residue is needed. Write \(\mu_r\) for the mean over a full period and \(L_r\) for the sum of the absolute values of all coefficients, including the constant. Multiplication across primes and CRT give
\[
 \sum_{j\equiv j_0\bmod m,\ j\text{ in the interval}} \prod_r W_r(j)
 \le (Y/m)\prod_r\mu_r+\prod_r L_r .
\]
Each monomial in the expansion represents a single residue modulo a product of coprime prime powers together with \(m\); its actual count differs by at most one from its length divided by that modulus. Positivity of the total mean permits replacing actual length by the upper bound \(Y\). The same proof applies to the indicator for the \(n\) term. Taking the maximum of either parameter over the possibilities \(r\mid d,r\mid u,r\nmid du\) gives a valid bound without knowing the direction. For some primes it can be cheaper to use the same upper weight on all classes in the \(r\mid u\) case. A second implementation counts every residue in complete combined periods with one remainder charged as a full additional period.

On a segment \(G\in[g,h]\), for each fixed choice of weights and \(n\) the upper bound is a sum of nonnegative multiples of \(1,G,G^{-k/n},G^{1-k/n}\). It is convex in \(\log G\) and hence bounded by the larger of its two endpoint values. Only after taking this maximum may we minimize over choices. For the exceptional direction the complementary interval is enclosed by \(\max(B,\lfloor p_0B/(2h)\rfloor)\) and \(\lceil\max_{G=g,h}(p_1B/G+G)\rceil\). The final cap takes the maximum across direction cases and all segments, then the minimum with \(V+1\), a consequence of uniqueness of \(c\) for fixed \(a,\beta\).

Computations of the baseline determinant \(C_n\) and negative powers in the local weights are outward rounded. For large \(n\), Python Decimal's correctly rounded ln and exp at 48 decimal digits are each surrounded by adjacent decimal numbers, and resulting endpoints are converted to exact fractions. The interpolation lower bound for \(G^{k/n}\) uses secants of a concave function as in the repository's lattice.py. All coefficient groups finally round upwards to multiples of \(10^{-14}\). The optional two-dimensional striped diagnostic in calculate is excluded by the lines_only=True hook.

## Literature and first-window scale

Cilleruelo and Garaev's modular hyperbola theorem gives a subpower bound for arbitrary translated boxes of side below \(p^{1/4}\), with an asymptotic factor. Cilleruelo and Jiménez-Urroz's Theorem 4 averages over products of points in a box. Here products on a chosen direction form the thin progression \(djp-u^2\). Lenstra's constant bound for all divisors in a reduced residue class starts at modulus larger than \(N^{1/4+\epsilon}\). Nair and Tenenbaum's short sum theorem estimates multiplicative functions at polynomial values and has implicit constants and size conditions. None of these statements as cited supplies the constant 500 in the four boxes. [Cilleruelo–Garaev](https://arxiv.org/abs/1007.1526) · [Cilleruelo–Jiménez-Urroz](https://www.numdam.org/article/JTNB_2000__12_1_87_0.pdf) · [Lenstra](https://pub.math.leidenuniv.nl/~lenstrahw/PUBLICATIONS/1984b/art.pdf) · [Nair–Tenenbaum](https://tenenb.perso.math.cnrs.fr/PPP/ShortSums.pdf)

The four actual short sides at grid 3200 in the window \([150,4801/32]\) have the following integer cap comparison. The old cap includes the strengthened two-layer CRT estimate; the entry in the last column is the independent one-dimensional bound prior to taking minima with other estimates. For the concrete valid direction \(d=6\lfloor D/6\rfloor,u=1\) and the prime from local-witness.json, all four parameter sets obey \(d^4<(dA-1)(dA+1)\) and \((dV)^4>(dB+1)^2\). For example at \(u_{\rm strip}=0.45\) we have \(d<N^{0.19683}\) and \(dV>N^{0.48552}\) whenever populated. These direction examples test known thresholds and make no claim about population.

For divisors in a short interval at \(X=N^\theta\), Letendre's Proposition 1 covers widths below \(N^{\theta^2-\epsilon}\). The general Theorem 1 keeps a power of \(\tau(N)\) in the wider range. For \(\theta\) near \(1/2\) in the example above, the unscaled interval width is near \(N^{0.486}\). The arithmetic progressions and the average over \(j\) in smooth-proof.md use additional information. [P. Letendre, Divisors of an Integer in a Short Interval](https://arxiv.org/html/2503.12146v1)

| Strip | Existing reference cap in probe.py | New single-line sum cap |
|---|---:|---:|
| 0.40 | 3,247,347 | 504,829 |
| 0.45 | 3,994,350,324,114 | 1,535,538,918,614 |
| 0.47 | 768,069,163,756,137 | 1,005,797,870,281,171 |
| 0.49 | 238,623,171,274,124,076 | 685,876,475,526,462,517 |

At \(0.49\) a separate, previously computed adaptive two-dimensional cap is \(234424689954005304\). The one-dimensional result improves the first two rows. These are total-fibre upper bounds. They do not establish a uniform mean of 500 over populated lines for the difficult strips. For a possible elementary filter, \(jp\equiv-u(c-a)\bmod d\) implies \((j,d)=(c-a,d)\). If \(0<|j|<A\) then \((j,u)=1\) because a common prime would divide \(ac\). In the four concrete boxes the direct integer bound \((DB^2+\lceil p_1/D\rceil V)/p_0<A\) verifies the size hypothesis.

From the workspace root, run python -B work/fibre-lines/probe.py, followed by python -B work/fibre-lines/verify_local.py. Files large-degree.txt and verification.txt store the four interval results and the finite independent checks. Run python -B work/operator-new/probe.py --mode six --grid 3200 --method mixture --line-cap for the rectangle pricing, replacing six with pair for its other branch. These commands rely on the unchanged prime-sampling checkout in work/prime-sampling, the CRT extension in work/residue-bridge/crt-fast, and the bundled compiler configuration used by that checkout.
