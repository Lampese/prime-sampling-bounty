"""Average single-line Vandermonde divisibility using the prime endpoint in both coordinates."""
from fractions import Fraction as F
from functools import cache
from math import exp, log,isqrt
from decimal import Decimal,Context
from prime_sampling.rectangles.sieved_det import balanced


PRIMES=(3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71,73,79,83,89,97,101)
ctx=Context(prec=48)


@cache
def ln_bounds(n):
    x=ctx.ln(Decimal(n))
    return F(ctx.next_minus(x)),F(ctx.next_plus(x))


def exp_lower(x):
    t=ctx.divide(Decimal(x.numerator),Decimal(x.denominator))
    return F(ctx.next_minus(ctx.exp(ctx.next_minus(t))))


@cache
def det_factor(n):
    from prime_sampling.rectangles import allsquarecap as av
    if n<=97:return av.det_factor(n)
    power=n*(n-1)//2
    pset=[r for r in range(2,n+2) if all(r%d for d in range(2,isqrt(r)+1))]
    lg=sum(old_exponent(n,r)*ln_bounds(r)[0] for r in pset)
    z=ln_bounds(4)[0]+(lg-(n-1)*ln_bounds(2)[1]-n*ln_bounds(n)[1]/2)/power
    return (100*exp_lower(z)).__floor__()


@cache
def old_exponent(n,r):
    k=(n-1)//2
    f=r-1;e=0
    while f<n:
        e+=min([balanced(n,f)]+[(s-k)*(s-k-1)//2+balanced(n-s,f-1) for s in range(n+1)])
        f*=r
    return e


@cache
def distributed(n,r,f):
    e=0
    while f<n:
        e+=balanced(n,f)
        f*=r
    return e


@cache
def multiplier(n,r,e):
    e=max(0,e-old_exponent(n,r))
    if not e:return F(1)
    power=n*(n-1)//2
    scale=10**8
    if n>97:
        return F(scale,(scale*exp_lower(e*ln_bounds(r)[0]/power)).__floor__())
    est=int(exp(e*log(r)/power)*scale)
    rhs=r**e*scale**power
    while est**power>rhs:est-=1
    while (est+1)**power<=rhs:est+=1
    return F(scale,est)

@cache
def reciprocal_gain(n,r,f):
    if f<=0:return F(0)
    return multiplier(n,r,distributed(n,r,f))


@cache
def two_adic_weight(n,odd):
    if not odd:return multiplier(n,2,distributed(n,2,1))
    k=n//2
    e=k*(k+1)
    f=2
    while f<n:
        e+=min([balanced(n,f)]+[(s-k)*(s-k-1)//2+balanced(n-s,f-1) for s in range(n+1)])
        f*=2
    return multiplier(n,2,e)


@cache
def reduced_two_exponent(n,h):
    """Valuation of Z/4^T at fixed h=v2(N/4), with all reduced units odd."""
    k=n//2
    exact=[distributed(s,2,1) for s in range(n+1)]
    costs=exact
    for _ in range(h):
        costs=[min(costs[N-s]+(N-s-k)*(N-s-k-1)//2+exact[s]
                   for s in range(N+1)) for N in range(n+1)]
    return k*(k+1)+costs[n]


@cache
def conditional_two(n):
    """Conditional means and coefficient masses on the single allowed class mod 4."""
    base=two_adic_weight(n,True)
    ws=[min(base,multiplier(n,2,reduced_two_exponent(n,h))) for h in range(4)]+[base]
    mean=ws[0];err=ws[0]
    for h,(x,y) in enumerate(zip(ws,ws[1:]),1):
        mean+=(y-x)/2**h
        err+=abs(y-x)
    return mean,err,max(ws)


@cache
def singular_exponent(n,r,valuation):
    k=(n-1)//2
    # After the nonunit residue is factored off, the first and the last
    # valuation groups still omit one unit class due to a prime endpoint.
    costs=[distributed(m,r,r-2) for m in range(n+1)]
    if valuation==1:
        return min(costs[s]+costs[n-s]+(s-k)*(s-k-1)//2 for s in range(n+1))
    middle=[distributed(m,r,r-1) for m in range(n+1)]
    for level in range(valuation):
        tail=costs if level==0 else partial
        next_cost=costs if level==valuation-1 else middle
        partial=[min(tail[N-s]+(N-s-k)*(N-s-k-1)//2+next_cost[s]
                     for s in range(N+1)) for N in range(n+1)]
    return partial[n]


@cache
def singular_gain(n,r,valuation):
    if n>97 and valuation>1:return F(1)
    return multiplier(n,r,singular_exponent(n,r,valuation))


@cache
def sparse_local(n,r,state):
    # The density and total absolute coefficient mass of the sparse congruence expansion.
    if state=='d':
        common=reciprocal_gain(n,r,r-2);zero=reciprocal_gain(n,r,r-1)
        return F(1),F(1),common+(zero-common)/r,common+abs(zero-common)
    if state=='u':
        common=reciprocal_gain(n,r,r-1)
        return F(r-1,r),F(2),common*F(r-1,r),2*common
    common=reciprocal_gain(n,r,r-3);zero=reciprocal_gain(n,r,r-2)
    density=common+(zero-common)/r
    norm=common+abs(zero-common)
    last=common
    for valuation,updated in [(h,singular_gain(n,r,h)) for h in (1,2,3)]+[(4,F(1))]:
        density+=(updated-last)/r**valuation
        norm+=abs(updated-last)
        last=updated
    allowed=F(2,3) if r==3 else F(1)
    return allowed,(F(2) if r==3 else F(1)),density,norm


@cache
def sparse_menus(n,both_odd,three_good,relax=10**6):
    m=4 if both_odd else 2
    mass=F(1,m);err=F(1);gain=F(1,m);gainerr=F(1)
    result=[]
    for r in PRIMES:
        if r>n+3:break
        if r==3:states=('free','u') if three_good else ('d',)
        else:states=('d','u','free')
        vals=[sparse_local(n,r,state) if state!='u' or r<=relax else
              (F(1),F(1),reciprocal_gain(n,r,r-1),reciprocal_gain(n,r,r-1)) for state in states]
        mass*=max(v[0] for v in vals);err*=max(v[1] for v in vals)
        gain*=max(v[2] for v in vals);gainerr*=max(v[3] for v in vals)
        result.append((mass,err,gain,gainerr))
    return tuple(result)

@cache
def local(n,r,state):
    # state d, u or free specifies which, if either, vanishes modulo r.
    if state=='d':
        count=r
        value=reciprocal_gain(n,r,r-1)+(r-1)*reciprocal_gain(n,r,r-2)
    elif state=='u':
        count=r-1
        value=(r-1)*reciprocal_gain(n,r,r-1)
    else:
        # The singular j class receives the old, fully uniform prime gain.
        count=2+(r-2 if r>3 else 0)
        value=1+reciprocal_gain(n,r,r-2)+(r-2)*reciprocal_gain(n,r,r-3)
    return F(count,r),value/r


@cache
def menus(n,both_odd,three_good):
    # Every row is a bound over all j compatible with its prime residues.
    m=4 if both_odd else 2
    count=F(1,m);weight=F(1,m)
    choices=[(m,count,weight)]
    for r in PRIMES:
        if r>n+3:break
        if r==3:
            states=('free','u') if three_good else ('d',)
        else:
            states=('d','u','free')
        localrows=[local(n,r,state) for state in states]
        count*=max(x for x,y in localrows)
        weight*=max(y for x,y in localrows)
        m*=r
        choices.append((m,count,weight))
        if m>10**22:break
    return tuple(choices)
