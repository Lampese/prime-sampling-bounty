from fractions import Fraction as F
from pathlib import Path
from math import isqrt
import sys

here=Path(__file__).resolve().parent
sys.path.insert(0,str(here.parent/'prime-sampling'))
from probe import boxes,sieved_lift
from smooth_split import split_at


if __name__=='__main__':
    boxes.initialize(F(150),F(4801,32))
    sieved_lift.install(boxes)
    for u in map(F,sys.argv[1:] or ('.45','.47','.49')):
        _,_,a,b,_,v,_,_=boxes.params(u,u+F(1,3200))
        p0,p1=boxes.pmin,boxes.pmax
        D=isqrt(p1//b)
        hi=max(b*D,-(-p1//D));lo=hi//2
        for odd,good in ((False,True),(False,False)):
            ans=[]
            for z in (1000,3000,10000,30000,100000,300000):
                for s in (3,4,5,6,7):
                    trial=split_at(a,b,v,p0,hi,lo,odd,good,z,s)
                    if trial is None:continue
                    best_good,best_bad=trial
                    total=best_good[0]+best_bad[0]
                    ans.append((total,z,s,best_good,best_bad))
            t,z,s,g,h=min(ans)
            lines=1+v*hi//p0
            print(u,'opposite parity good3',good,'top dyadic segment bound',t.__ceil__(),
                  'bound / parity envelope',float(t/lines),'z,s',z,s,
                  'good',g[0].__ceil__(),g[1:],'bad',h[0].__ceil__(),h[1:],flush=True)
