from fractions import Fraction as F
from time import perf_counter
from argparse import ArgumentParser
import os
from probe import boxes,sieved_lift
from shaped_fibre import calculate,MODES


if __name__=='__main__':
    cmd=ArgumentParser()
    cmd.add_argument('--conditional',action='store_true')
    cmd.add_argument('--angle',action='store_true')
    cmd.add_argument('--loose-product',action='store_true')
    cmd.add_argument('--sieve',action='store_true')
    cmd.add_argument('--five',action='store_true')
    opts=cmd.parse_args()
    boxes.initialize(F(150),F(4801,32));sieved_lift.install(boxes)
    for u in map(F,('.40','.45','.47','.49')):
        _,_,A,B,_,V,_,_=boxes.params(u,u+F(1,3200));p0,p1=boxes.pmin,boxes.pmax
        start=perf_counter()
        if opts.angle:
            from angular_fibre import calculate as angular
            ans,worst=angular(A,B,V,p0,p1,True,not opts.loose_product,opts.sieve,opts.five)
            print(u,'cap',ans,'rank',worst,'seconds',round(perf_counter()-start,2),flush=True)
            continue
        ans,(worst,prices)=calculate(A,B,V,p0,p1,True,opts.conditional)
        print(u,'cap',ans,'worst menu',worst,'per-mode',
              [prices[i][r] if r!=99 else None for i,r in enumerate(worst)],
              'seconds',round(perf_counter()-start,2),flush=True)
    if os.name=='nt':
        import _ctypes
        from prime_sampling.spectrum import squarerates as sr
        _ctypes.FreeLibrary(sr._lib._handle)
