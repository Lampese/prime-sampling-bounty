"""Independent finite checks of the removed-factor and CRT moment lemmas."""
from fractions import Fraction as F
from itertools import product,combinations
from math import gcd,prod
from random import Random
from verify_local import determinant,valuation,allowed_and_weight
from smooth_split import markov,menu


def factor_witnesses():
    rng=Random(88122);total=0
    powers=((2,4),(3,3),(5,2),(7,2),(103,2),(107,1),(109,1))
    factors=[prod(r**i for (r,_),i in zip(powers,exps))
             for exps in product(*(range(h+1) for _,h in powers))]
    for sign,d,u,m in product((-1,1),(1,17,19),(1,2,7),(103,103*107,103**2*109)):
        N=sign*max(factors)
        if (N+u*u)%d:continue
        kept={}
        for x in factors:
            y=N//x
            if (x-u)%d or (y+u)%d:continue
            e=gcd(x,m)
            assert x%e==0 and y%(m//e)==0
            kept.setdefault(e,[]).append(((x-u)//d,(y+u)//d,x,y))
        for e,pts in kept.items():
            n=7;k=n//2;T=k*(k+1)//2
            if len(pts)<n:continue
            sample=sorted(rng.sample(pts,n))
            vals=[]
            for div in (1,e):
                t0,s0,_,_=sample[0]
                # This loop also handles e=1: identify transform by order.
                md=m if vals else 1
                mult=md//div
                tv=[(t-t0)//div for t,s,x,y in sample]
                sv=[(s-s0)//mult for t,s,x,y in sample]
                assert all((t-t0)%div==0 and (s-s0)%mult==0 for t,s,x,y in sample)
                V=prod(b-a for a,b in combinations(tv,2))
                z=F((N//md)**T*V,prod((x//div)**k for t,s,x,y in sample))
                assert z.denominator==1 and z
                mat=[[1]+[t**j for j in range(1,k+1)]+[s**j for j in range(1,k+1)] for t,s in zip(tv,sv)]
                assert abs(determinant(mat))==d**(k*k)*abs(z)
                vals.append(z)
            assert vals[0]==vals[1]*m**T
            total+=1
    assert total>=50
    return total


def weighted_moments():
    checks=0
    for d,u in ((1,1),(2,1),(3,1),(1,3),(5,-3)):
        n=13;p=101;z=7;H=16
        mean,error,corr=menu(n,False,d%3!=0,3)[1]
        levels=markov(z,H,corr)
        for start in (-401,1,606):
            end=start+1931
            sums=[F(0)]*4
            parity=d%2
            for j in range(start,end+1):
                if j%2!=parity:continue
                N=d*j*p-u*u
                assert N
                w=allowed_and_weight(n,3,d,u,p,j)[1]
                L=0;exceptional=0
                for r in (2,3,5,7):
                    v=valuation(N,r)
                    h=1
                    while r**(h+1)<=z*z:h+=1
                    L+=(r-1).bit_length()*min(v,h)
                    exceptional+=int(v>h)
                for i in range(4):
                    sums[i]+=w*(F(L,H)**(i+1)+exceptional)
            for actual,(a,e) in zip(sums,levels):
                assert actual<=mean*(end-start)*a+error*e
                checks+=1
    return checks


def analytic_prime_tail():
    from smooth_split import primes,population,SCALE,moments
    z=530003
    table,omitted,atoms,np,rows=population(z)
    exact_primes=primes(z)
    from smooth_tail import count
    from bisect import bisect_right
    lo=131072
    while lo<z:
        hi=min(z,lo+lo//8)
        assert bisect_right(exact_primes,hi)-bisect_right(exact_primes,lo)<=count(lo,hi)
        lo=hi
    total=[0]*5;tail=actual_atoms=0
    for r in exact_primes:
        w=(r-1).bit_length();power=r;h=1
        while power*r<=z*z:power*=r;h+=1
        actual_atoms+=h*w
        tail+=SCALE//(power*r)
        for i,b in enumerate(moments(r),1):
            total[i]+=SCALE*w**i*b//((r-1)**i)
    # A floor loses less than one fixed-point unit for every prime.
    assert all(total[i]+len(exact_primes)<=table[i] for i in range(1,5))
    assert actual_atoms<=atoms and len(exact_primes)<=np
    # On this test a per-prime unit loss could dominate the tiny tail, so
    # use the direct rational universal inequality from the proof.
    assert F(len(exact_primes),z*z)<=F(omitted,SCALE)
    return len(exact_primes)


if __name__=='__main__':
    print('allocated factor, signed product and normalized determinant witnesses:',factor_witnesses(),flush=True)
    print('weighted truncated smooth-part moments on finite intervals:',weighted_moments(),flush=True)
    print('enumerated prime verification of grouped analytic tail:',analytic_prime_tail(),flush=True)
