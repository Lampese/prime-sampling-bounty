"""Finite audits of the local line restrictions, singular determinant and CRT discrepancy."""
from fractions import Fraction as F
from itertools import combinations, product
from math import gcd, prod
from pathlib import Path
from random import Random
import sys

here=Path(__file__).resolve().parent
sys.path.insert(0,str(here.parent/'prime-sampling'))
import local_divisors as local


def oracle_modular_images():
    images=lifts=0
    for r in (3,5,7,11):
        p=13
        for d,u in product(range(r),repeat=2):
            if d==u==0:continue
            for j in range(r):
                pairs=[(a,c) for a,c in product(range(1,r),repeat=2)
                       if (d*a*c-u*(c-a)-j*p)%r==0]
                projected={a for a,c in pairs}
                if d==0:expected=r-1 if j==0 else r-2
                elif u==0:expected=0 if j==0 else r-1
                elif (d*j*p-u*u)%r==0:expected=r-1
                else:expected=r-2 if j==0 else r-3
                assert len(projected)==expected,(r,d,u,j,projected,expected)
                assert len({c for a,c in pairs})==expected
                if pairs:
                    assert any((d*a-u)%r or (d*c+u)%r for a,c in pairs)
                    lifts+=1
                images+=1
    for q in (4,8,16,32,9,27,25,49,11,13):
        d,u,p=6,1,17
        units=[a for a in range(q) if gcd(a,q)==1]
        seen={(d*a*c-u*(c-a))*pow(p,-1,q)%q for a,c in product(units,repeat=2)}
        assert seen==set(range(0,q,2 if q%2==0 else 1))
    return images,lifts


def valuation(value,r):
    assert value
    v=0
    while value%r==0:
        value//=r
        v+=1
    return v


def determinant(matrix):
    # Bareiss, independent of the Vandermonde factorization.
    a=[row[:] for row in matrix]
    previous=sign=1
    for i in range(len(a)-1):
        pivot=next(j for j in range(i,len(a)) if a[j][i])
        if i!=pivot:
            a[i],a[pivot]=a[pivot],a[i]
            sign=-sign
        for j in range(i+1,len(a)):
            for l in range(i+1,len(a)):
                num=a[i][i]*a[j][l]-a[j][i]*a[i][l]
                assert num%previous==0
                a[j][l]=num//previous
        previous=a[i][i]
    return sign*a[-1][-1]


def divisor_determinants():
    rng=Random(312403)
    count=0
    cases=set()
    for r in (3,5,7,11):
        other=[(q,2) for q in (2,3,5,7,11,13) if q!=r]
        for power in (0,1,2,3):
            pp=other+[(r,power)]
            factors=sorted(prod(q**e for (q,_),e in zip(pp,exps))
                           for exps in product(*(range(a+1) for _,a in pp)))
            for sign,d,u in product((-1,1),(1,17),(1,2,5)):
                if gcd(d,u)>1 or u%r==0:continue
                N=sign*factors[-1]
                if (N+u*u)%d:continue
                pts=[]
                for x in factors:
                    y=N//x
                    if (x-u)%d or (y+u)%d:continue
                    t,s=(x-u)//d,(y+u)//d
                    if t%r and s%r:pts.append((t,s,x))
                for n in (7,13):
                    if len(pts)<n:continue
                    k=n//2
                    for _ in range(2):
                        sample=sorted(rng.sample(pts,n))
                        V=prod(b[0]-a[0] for a,b in combinations(sample,2))
                        Z=F(N**(k*(k+1)//2)*V,prod(x**k for _,_,x in sample))
                        assert Z.denominator==1 and Z
                        base=determinant([[1]+[t**j for j in range(1,k+1)]+
                                         [s**j for j in range(1,k+1)] for t,s,_ in sample])
                        assert abs(base)==d**(k*k)*abs(Z)
                        if power:
                            bound=local.singular_exponent(n,r,power)
                        else:
                            # x cannot be u, and N/x cannot be -u.
                            f=r-2 if (N+u*u)%r==0 else r-3
                            bound=local.distributed(n,r,f)
                        assert valuation(Z.numerator,r)>=max(local.old_exponent(n,r),bound)
                        count+=1
                        cases.add((r,power))
    assert {(r,l) for r in (3,5,7,11) for l in (1,2,3)}<=cases
    return count,len(cases)


def allowed_and_weight(n,r,d,u,p,j):
    if d%r==0:
        return 1,local.reciprocal_gain(n,r,r-1 if j%r==0 else r-2)
    if u%r==0:
        return (1,local.reciprocal_gain(n,r,r-1)) if j%r else (0,F(0))
    if j%r==0:return 1,local.reciprocal_gain(n,r,r-2)
    N=d*j*p-u*u
    if N%r:
        return int(r>3),local.reciprocal_gain(n,r,r-3)
    if N%r**4==0:return 1,F(1)
    return 1,local.singular_gain(n,r,valuation(N,r))


def discrepancy():
    rng=Random(733201)
    checks=0
    for _ in range(80):
        n=rng.choice((7,13,25));pset=(3,5,7)
        d,u,p=rng.randrange(1,120),rng.randrange(-100,100),127
        if gcd(d,u)!=1:continue
        m=4 if d%2 and u%2 else 2
        residue=pow(d*p,-1,4)*u*u%4 if m==4 else d%2
        row=[local.sparse_local(n,r,'d' if d%r==0 else 'u' if u%r==0 else 'free') for r in pset]
        means=[prod(x[i] for x in row) for i in range(4)]
        left=F(rng.randrange(-20000,20000),7)
        right=left+F(rng.randrange(10,3000),11)
        weighted=F(0);occupied=0
        for j in range(left.__ceil__(),right.__floor__()+1):
            if j%m!=residue:continue
            vals=[allowed_and_weight(n,r,d,u,p,j) for r in pset]
            occupied+=prod(x for x,y in vals)
            weighted+=prod(y for x,y in vals)
        length=right-left
        assert occupied<=length*means[0]/m+means[1]
        assert weighted<=length*means[2]/m+means[3]
        checks+=1
    assert checks>40
    return checks


def complementary_directions():
    tested=0
    for p,B,d,u in product((101,103,107),(3,7,11),range(3,25,3),range(-28,29)):
        if gcd(d,u)!=1 or (d-u)%2==0:continue
        G=max(B*d,abs(u))
        ds=(-p*pow(u,-1,d))%d
        us=(p+u*ds)//d
        vals=[]
        for t in range(-200,201):
            e,f=ds+t*d,us+t*u
            if e%2 and f%2:
                vals.append((max(abs(e)*B,abs(f)),e,f))
        norm,e,f=min(vals)
        assert e%3 and d*f-u*e==p and 2*norm*G>=p*B
        assert norm<=F(p*B,G)+G
        tested+=1
    return tested


if __name__=='__main__':
    print('modular images and nonsingular lifts:',*oracle_modular_images(),flush=True)
    print('exact divisor determinants and prime/valuation states:',*divisor_determinants(),flush=True)
    print('rational multi-prime interval-discrepancy checks:',discrepancy(),flush=True)
    print('complement direction checks:',complementary_directions(),flush=True)
