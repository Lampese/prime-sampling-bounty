"""Prime endpoint restrictions on lifted hyperbola lines."""
from fractions import Fraction as F
from functools import cache,lru_cache
from math import isqrt

from prime_sampling.rectangles import allsquarecap as av
from local_divisors import menus,sparse_menus,det_factor


def ceil(value):
    return -(-value.numerator//value.denominator)


@cache
def classes(n):
    from math import gcd
    q=2*n
    units=[i for i in range(q) if gcd(i,q)==1]
    return len({((a-c)%q,a*c%q) for a in units for c in units})


SCALE=10**14


@cache
def fast_coefficients(n,odd,g3):
    rows=set()
    for relax in (3,11,31,10**6):rows.update(sparse_menus(n,odd,g3,relax))
    for mod,count,weight in menus(n,odd,g3):
        rows.add((count,mod*count,weight,mod*weight))
    return tuple(tuple(ceil(x*SCALE) for x in row) for row in rows)


def calculate(a,b,v,p0,p1,detail=False,average=True,lines_only=False):
    D=isqrt(p1//b)
    start=max(b,min(a*a,av.ceildiv(p0,b+v)))
    end=max(D*b,av.ceildiv(p1,D))
    if end<start:return (0,0,[]) if detail else 0
    slope=F(v,p0)
    degrees=tuple(k for k in (3,6,12,24,48,96,192) if 2*(2*k+1)<a)
    @cache
    def determinant_at(g,offset,factor):
        out=[]
        for k in degrees:
            n=2*k+1
            per=n+F(2*k*v*b*(100<<16),det_factor(n)*a*av.pow_lower(g,k))
            out.append(ceil((offset+factor*slope*g)*per))
        return tuple(out)
    def determinant(lo,hi,offset,factor):
        return min(max(x,y) for x,y in zip(determinant_at(lo,offset,factor),determinant_at(hi,offset,factor)))
    @cache
    def averaged(g,odd,good3):
        opts=[]
        for k in degrees:
            n=2*k+1
            num=2*k*v*b*(100<<16);den=det_factor(n)*a*av.pow_lower(g,k)
            level=2*v*g
            for count,err,weight,werr in fast_coefficients(n,odd,good3):
                opts.append(av.ceildiv(n*den*(level*count+p0*err)+num*(level*weight+p0*werr),den*p0*SCALE))
        return tuple(opts)
    @cache
    def sieved(lo,hi,js,ks,parity,striped):
        U=slope*hi/js
        K=F(v*b,lo*ks)+U/2
        A=slope*v*b/(ks*js)+U**2/2
        prices=[]
        for n in ((1,2,4,8) if striped else (1,2,3,6,18)):
            count=(classes(2*n)//2 if parity else classes(n))*(2 if striped else 1)
            bill=av.bill(ceil(U/n+3),ceil(K/n+3),ceil(A/n**2+3*(U+K)/n+9),b,p0)
            if bill is not None:prices.append(count*bill)
        return min(prices) if prices else v+1
    @cache
    def oriented(lo,hi,odd,good3):
        js,ks=(2,1) if odd else (1,2)
        if good3:
            off,f=2,F(1,3) if odd else F(2,3)
        else:
            off,f=1,F(1,2) if odd else F(1)
        line=determinant(lo,hi,off,f)
        if average:
            line=min(line,min(max(x,y) for x,y in zip(averaged(lo,odd,good3),averaged(hi,odd,good3))))
        if lines_only:return line,line
        square=min(sieved(lo,hi,1,1,False,False),sieved(lo,hi,js,ks,True,False))
        if good3:
            square=min(square,sieved(lo,hi,3*js,ks,True,True))
        return min(line,square),line
    rows=[]
    hi=end
    while hi>=start:
        lo=max(start,hi//2)
        # The complementary vector with both coordinates odd and 3 not dividing
        # its denominator is only required in the opposite-parity, 3|d case.
        l2=max(b,(p0*b)//(2*hi))
        h2=max(ceil(F(p1*b,g)+g) for g in (lo,hi))
        good=[oriented(lo,hi,odd,res) for odd,res in ((True,True),(False,True),(True,False))]
        bad=oriented(lo,hi,False,False)
        alt=oriented(l2,h2,True,True)
        combined=min(bad[0],alt[0])
        per=min(bad[1],alt[1])
        rows.append((lo,hi,max(combined,*[r[0] for r in good]),
                     max(per,*[r[1] for r in good]),[r[0] for r in good]+[bad[0],alt[0]]))
        if lo==start:break
        hi=lo
    cap=min(v+1,max(r[2] for r in rows))
    return (cap,max(r[3] for r in rows),rows) if detail else cap


def install():
    from prime_sampling.spectrum import squarerates as sr
    original=sr.square_cap
    @lru_cache(maxsize=32768)
    def joined(a,b,v,p0,p1):
        old=original(a,b,v,p0,p1)
        if not (194<a<b<p0 and 0<v<=b and p0<=p1<2*p0):return old
        D=isqrt(p1//b)
        if not D or max(b*D,av.ceildiv(p1,D))>=b*p0//4:return old
        return min(old,calculate(a,b,v,p0,p1,lines_only=True))
    sr.square_cap=joined
