# Angular and higher-power refinements to the six-mode lattice cover

This extends main-shape-proof.md for the same endpoints and shifts. The scalar radius and the angle type below are simultaneous guarantees on a single primitive lattice direction.

## The prime 2 on the occupied line class

For opposite parities of \(d,u\), the local weights from main-shape-proof.md are uniform on the allowed parity. Since \(N\) is always odd on an occupied line, every moment atom \(1_{2^i\mid N}\) vanishes there. Removing the local moment and large-power-tail terms for 2 is exact. The code conservatively keeps 2 in the crude bound on the total coefficient mass.

For both coefficients odd, \(N=djp-u^2\) is divisible by 4 on a single residue class of \(j\). Parameterize that class by \(j=j_0+4q\). Then \(N/4\) is an affine function of \(q\) with odd slope \(dp\). For \(h=v_2(N/4)\in\{0,1,2,3\}\), partition the indices by \(i=v_2(x'_i)\in[0,h]\), using the reduced variables from main-shape-proof.md. Write \(s_i\) for the group sizes and \(S_r=\sum_{i\ge r}s_i\). Dividing out the common powers of 2 from each \(x'_i\) group leaves odd units, which occupy one class modulo 2. The pair counts by each common level and the numerator and denominator powers therefore give
\[
 v_2 Z\ge 2T+\sum_{r=1}^h (S_r-k)(S_r-k-1)/2
                 +\sum_{i=0}^h H_2(s_i,1).
\]
The determinant differences may be computed in \(x'_i\) since their slope in \(t'_i\) is odd. Minimize this expression over all compositions of \(n\), including empty groups. The dynamic program reduced_two_exponent adds the first group and recursively accumulates the tail terms with the original fixed \(k\). Combine the resulting gain with the uniform common-odd gain by taking the smaller upper weight. Denote the four weights by \(w_0,\ldots,w_3\) and use the uniform gain \(w_4\) for \(v_2(N/4)\ge4\).

The weight on the allowed class is \(w_0+\sum_{h=1}^4(w_h-w_{h-1})1_{2^h\mid N/4}\). Its mean relative to that class is \(w=w_0+\sum(w_h-w_{h-1})/2^h\) and its absolute coefficient norm is \(L=w_0+\sum|w_h-w_{h-1}|\). In the smooth-part bad-line estimates, the absolute full-period mean with a prescribed \(2^i\mid N\) is at most \((\max_j w_j)/2^i\), since \(dp\) is odd. Relative to the full mean \(w/4\), use correction \(4\max_j(w_j)/w\) with the original moment upper bounds. The unrestricted profile remains independently available in the pricing. Smooth-split factors greater than 101 are coprime to these valuations.

## Geometry of the two endpoint factors

Put \(x=Bd,\ y=|u|,\ \alpha=A/B,\ G=\max(x,y),\ q=\min(x,y)/G\). For either endpoint ordering,
\[
 0<dt+|u|\le(1+q)G,\quad dt+|u|\ge\alpha(1+q)G,\quad
 |ds-|u||\le(1-\alpha q)G.
\]
For \(y\ge x\) the last assertion follows from \(ds\ge\alpha x\) and \(ds\le y\). For \(x\ge y\) it follows from \(\max(|\alpha-q|,1-q)\le1-\alpha q\). Hence
\[
 |N|\le (1+q)(1-\alpha q)G^2
       \le \frac{(1+\alpha)^2}{4\alpha}G^2 .
\]
If the lattice cover certifies \(q\ge\tau\) and \(\alpha(1+\tau)\ge1\), the stronger bound \(|N|\le G^2\) holds because \((1+q)(1-\alpha q)\le1\). Choose \(U=1\) in this case. Otherwise use the smaller of 4 and an outward rational rounding of \((1+\alpha)^2/(4\alpha)\). The unconditional \(4G^2\) bound remains valid. The implemented rounding menu uses \(65/64,17/16,9/8,3/2,2,4\).

In the small-smooth-part argument define a good line by \(|N|/m\le U G^2/z^s\), where \(m\) contains the \(s\) largest factors exceeding 101, counting multiplicity, or all if fewer. On a bad line some remaining factor above \(z\) would imply \(m>z^s\), contradicting \(|N|\le U G^2\). Hence \(P_z(N)>U G^2/z^s\) and one must now use \(H=\lfloor\log_2\lfloor U g^2/z^s\rfloor\rfloor\) in each segment \(G\in[g,h]\). The good-line factor changes to \((U/z^s)^{T/M}\). Both changes are applied together. The rational root bounding and all final pricing round outward; command-line verification samples in check_main_shape.py use integer comparisons throughout.

For the angular sector with threshold \(\tau\) and \(\alpha(1+\tau)\ge1\), the direct determinant satisfies
\[
 |Z|\le \frac{G^{2T}}{(\alpha(1+\tau)G)^M}|\operatorname{Vand}(t)|.
\]
Here \(2T-M=-k^2\). After taking the \(M\)-th root and comparing with the earlier direct bound, every varying term of the line price can be multiplied by \(1/(1+\tau)\). On good lines replace \(N\) by \(N/m\le U G^2/z^s\), with exactly the same denominator, so the same angular factor applies there. It also applies on an arbitrary previously charged bad set by positivity. The additive \(n\) contribution on each occupied line stays as before.

## Joint price on normalized norm and angle

On each normalized shape box from main-shape-proof.md the C++ verifier bounds the absolute coordinates of each primitive alternative from below as well as above. If an interval for a coordinate crosses zero its lower absolute value is zero. A lower bound on the minimum of the two absolute coordinates divided by the upper bound on the norm gives a lower bound on \(q\). Round it down to \(\tau\in\{0,1/4,1/2,3/4\}\). This is invariant under sign changes and interchanging the coordinates in the lattice normalization. For \(t\le1/2\) use just its single vector at radius \(1/2\) with \(\tau=0\).

angular_fibre.calculate computes integer upper prices for the rectangle for each of the four angle tiers, each of six residue modes, and all upper radius ticks through \(40/16\). These prices cover every nonempty admissible \(G\) below that tick by exhaustive consecutive intervals. For smaller ticks the value at \(8/16\) is also a valid upper bound. Send the ranks of the integer prices to the C++ verifier, which takes the minimum across simultaneous alternatives in each shape cell and residue assignment and the maximum over the entire cover. Sorting costs and using ranks only in the geometry checker avoids any fixed-width conversion of the true integer prices. All 36 projective assignments, the short-vector boundary case, and all closed normalized shape cells are evaluated. This gives an all-prime, all-shift bound.

Compile main_shape.cpp with C++17 optimization into angular_main_shape.exe on Windows or angular_main_shape on other platforms. It retains the earlier mode to regenerate the six-column radius menu; the new mode --price accepts the \(4\cdot6\cdot41\) increasing-order ranks on standard input. Run python -B work/fibre-lines/main_shape_full.py --angle for the four real short sides. For the angular method with the earlier product bound \(U=4\), add --loose-product. Run python -B work/fibre-lines/check_main_shape.py for independent finite-field, determinant-valuation, and product checks. The first-window rectangle entry point is python -B work/operator-new/probe.py --grid 3200 --mode six --method mixture --angular-fibre --shape-near. Replace six with pair and the grid by 1600 or 4800 for the other tables.

The --sieve option on main_shape_full.py and --precise-sieve on the rectangle probe retain the single excluded residue \(j=0\bmod r\) when \(r\mid u,\ r\ge5\), up to selectable cutoffs \(7,13,31\), instead of using the same pointwise upper weight on all residues at every such prime. All the coefficient means and discrepancy norms come from the existing sparse local row proved in proof.md. Each of the previously valid cutoffs, including the complete relaxation, is independently available. The moment computation includes the exact removal of the 2-adic moment in the opposite-parity case. When the very-large-\(z\) tail uses an aggregate upper count of primes times \(1/z^2\), subtract the unrounded \(1/z^2\) for the absent prime.

| Short-side strip | Six modes | Angular and exact 2-adic class | Angular and refined smooth threshold | Additional exact small-prime masks |
|---:|---:|---:|---:|---:|
| 0.40 | 356966 | 290539 | 290539 | 259870 |
| 0.45 | 29781830757 | 28486663998 | 26732518505 | 26107192035 |
| 0.47 | 2311771618464 | 2151307246504 | 2083185464298 | 2072629233836 |
| 0.49 | 228065515857138 | 213040058067579 | 204299351450591 | 197300411715515 |

Independent checks in main-shape-check.txt cover 3,366 actual field lattices, all 90 tested determinant collections, 10,098 finite-field angular price comparisons, and 25,264 integer endpoint product checks.

## Reusing the lattice alternatives at new geometry

For an attained full angular cap, retain, for each of the 24 combinations of angle tier and residue mode, the largest norm tick whose price does not exceed that cap. This gives a finite disjunction independent of \(A,B,V,p\). Its exact geometric coverage is verified again by feeding a binary rank table into the C++ shape verifier: use zero for ticks meeting each of the 24 limits and one for every other tick. A returned maximum of zero certifies that every normalized lattice has at least one of the specified directions. The JSON schedules generated by write_schedules.py are checked in this way every time fast_fibre.py initializes. No trust in their generating prices is needed.

To price any new rectangle, choose any of the four fully validated schedules. The implementation uses the closest origin ratio \(V/\sqrt{S}\) on a multiplicative scale as a deterministic convenience. Evaluate the 24 or fewer eligible directions at their permitted upper norm ticks, covering every integer \(G\) from its nonempty-fibre minimum to each upper radius. The fast method starts with segments at \(1,15/16,3/4,1/2,1/4\) times the upper radius, and successively divides the last endpoint by 16 down to \(G_0\). The worst of the certified mode bounds is a valid cap because at least one mode is available on every lattice. The subdivisions differ from the full rank-table calculation, so its cap may change slightly in either direction.

From the workspace root, run python -B work/fibre-lines/write_schedules.py to reproduce shape-schedules.json, or use the shipped JSON with its per-session geometric verification. Run python -B work/fibre-lines/fast_trial.py for rates and timings. To install the rectangle hook call fast_fibre.install(), after importing the repository's spectrum and any earlier cap. It requires the same angular_main_shape executable and Python dependencies as the full method. On the four original short sides the fast caps were 259899, 26114562127, 2073177489238, 197298391674339.

On the four changed strips at all three grids, with the original predecessor ledger, the complete --precise-sieve version gave \(T=1.707584673629\) with 3 and \(T=1.426940891360\) without 3. Their respective margins are \(-0.339048515114\) and \(-0.040355455845\). To reproduce, use the six files named MODE-sieved-GRID.txt with python -B work/operator-new/point_ledger.py --line-data work/fibre-lines --line-pattern '{mode}-sieved-{grid}.txt'.

The optional --five run adds one projective point modulo 5: the condition \(5\mid u\) pulls back to one of the six points of \(\mathbb P^1(\mathbb F_5)\) in any basis. Include all six choices along with the 36 earlier assignments. For \(5\nmid u\), take the larger of the local profiles for \(5\mid d\) and \(5\nmid du\). For \(5\mid u\) use its precise local profile. The resulting four caps are 259415, 25990981596, 2064084226220, 197030520111646. This extra finite-field classification costs more and is excluded from the above fast or full three-grid rates. Compile the same main_shape.cpp to angular_five_shape for this test, adding the .exe suffix on Windows, and run python -B work/fibre-lines/main_shape_full.py --angle --five. The checker additionally covers 1,264 finite-field examples of these 12 residue modes when that executable is present.
