from fractions import Fraction as F
from math import isqrt
from probe import boxes,sieved_lift
from rough_factor import good_rows, multiplicity

if __name__=='__main__':
    boxes.initialize(F(150),F(4801,32))
    sieved_lift.install(boxes)
    for u in map(F,('.45','.47','.49')):
        _,_,a,b,_,v,_,_=boxes.params(u,u+F(1,3200))
        p,p1=boxes.pmin,boxes.pmax
        D=isqrt(p1//b);G=max(b*D,-(-p1//D));lo=G//16
        J=F(v*G+p,p)
        for g3 in (False,True):
            ans=[]
            for scale in range(7,33):
                Y=10**scale
                for Z in (0,127,1000,10000,100000,10**6,10**8,10**10,10**12):
                    if Z>=Y:continue
                    (c,n)=good_rows(a,b,v,p,lo,G,g3,Y,Z)
                    ans.append((c,n,Y,Z))
            for name,opts in [('one',[v for v in ans if not v[3]]),('two',[v for v in ans if v[3]])]:
                c,n,Y,Z=min(opts)
                mu,err=multiplicity(Y,Z)
                ideal=good_rows(a,b,v,p,lo,G,g3,Y,Z,True)
                print(u,g3,name,'good cost',c,'per envelope',float(c/J),'Y,Z',Y,Z,'n',n,
                      'mean tau upper',float(mu),'discrepancy /J',float(err/J),
                      'ideal unit-multiplicity good per line',float(ideal[0]/J),flush=True)
