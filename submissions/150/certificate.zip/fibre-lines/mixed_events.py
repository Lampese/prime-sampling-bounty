"""Two smooth-prime ranges in one positive indicator polynomial."""
from fractions import Fraction as F
from functools import cache
from smooth_split import SCALE,ceilrat,menu,moment_model,population,primes
import smooth_cascade as sc


@cache
def block_atoms(y,z):
    total=0
    for p in primes(y):
        power=p;h=1
        while power*p<=z*z:power*=p;h+=1
        total+=(p-1).bit_length()*h
    return total


@cache
def extras(n,g3,z,idx):
    if z<10000:return ()
    full,_,all_atoms,np,_=population(z)
    candidates=[]
    for y in (1000,10000,100000):
        if y>=z:continue
        small=population(y)[0]
        large_moment=F(full[1]-small[1],SCALE)
        assert large_moment>=0
        small_atoms=block_atoms(y,z)
        # The total upper bound on the atomic sum is valid after subtracting
        # the exact part at primes <=y.
        large_atoms=all_atoms-small_atoms
        for cut in sc.CUTS:
            mu,E,corr=menu(n,False,g3,cut)[idx]
            bs=(F(1),)+moment_model(y,corr)[0]
            eps=moment_model(z,corr)[1]
            for level in (2,3,4):
                terms=[(mu*eps,E*np)]
                for j in range(1,level+1):
                    mean=large_moment*bs[j-1]
                    err=large_atoms*small_atoms**(j-1)
                    if j==level:
                        mean+=bs[j];err+=small_atoms**level
                    terms.append((mu*mean,E*err))
                candidates.append(tuple(((SCALE*a).__ceil__(),(SCALE*b).__ceil__()) for a,b in terms))
    return tuple(candidates)


original=sc.coefficients


@cache
def combined(n,g3,z,H,idx):
    rows=list(original(n,g3,z,H,idx))
    for terms in extras(n,g3,z,idx):
        t=len(terms)-1
        ac=bc=0
        for a,b in terms:
            ac=ac*H+a;bc=bc*H+b
        rows.append((ceilrat(ac,H**t),ceilrat(bc,H**t)))
    return sc.envelope(rows)


def install_coefficients():
    sc.coefficients=combined
