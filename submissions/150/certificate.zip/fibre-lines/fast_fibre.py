"""Reprice a pre-certified selection of lattice directions at a new geometry."""
from fractions import Fraction as F
from functools import cache,lru_cache
from math import isqrt
from pathlib import Path
from subprocess import check_output
import json
from angular_fibre import EXE,residual_ratio
from shaped_fibre import MODES
from smooth_cascade import segment
from smooth_wide import policies


@cache
def schedules():
    rows=json.loads(Path(__file__).with_name('shape-schedules.json').read_text(encoding='ascii'))
    if not rows:raise ValueError('Empty schedule list')
    for row in rows:
        limits=row['ticks']
        if len(limits)!=24 or not all(isinstance(v,int) and 0<=v<=40 for v in limits):
            raise ValueError('Invalid norm limits')
        mask=' '.join(str(int(k>v)) for v in limits for k in range(41))
        if int(check_output([str(EXE),'--price'],input=mask,text=True))!=0:
            raise ValueError('The listed directions do not cover the whole shape space')
    return rows


def price_mode(A,B,V,p0,start,hi,mode,cluster,arch,residual,skip):
    if hi<start:return 0
    worst=0
    cuts=[hi,hi*15//16,hi*3//4,hi//2,hi//4]
    while cuts[-1]>start:
        cuts.append(cuts[-1]//16)
    for top,bottom in zip(cuts,cuts[1:]):
        if top<start:break
        bottom=max(start,bottom)
        val=segment(A,B,V,p0,bottom,top,mode,(),arch=arch,residual=residual)
        if val>max(skip,worst):
            val=segment(A,B,V,p0,bottom,top,mode,cluster,arch=arch,residual=residual)
        worst=max(worst,val)
    return worst


def calculate(A,B,V,p0,p1,detail=False):
    norm=isqrt(p1*B)+1
    if 5*norm>=2*p0:return (V+1,None) if detail else V+1
    start=max(B,min(A*A,-(-p0//(B+V))))
    ratio=max(1,V//isqrt(norm))
    row=min(schedules(),key=lambda r:F(max(r['ratio'],ratio),min(r['ratio'],ratio)))
    cluster=policies(ratio)
    worst=0
    for j,tick in enumerate(row['ticks']):
        if tick==0:continue
        tier,index=divmod(j,6)
        arch=(4,4+tier) if tier and A*(4+tier)>=4*B else (1,1)
        residual=residual_ratio(A,B,tier)
        hi=-(-norm*tick//16)
        result=price_mode(A,B,V,p0,start,hi,MODES[index]+(True,31),cluster,arch,residual,worst)
        worst=max(worst,result)
    best=min(worst,V+1)
    return (best,row['strip']) if detail else best


def install():
    from prime_sampling.spectrum import squarerates as sr
    old=sr.square_cap
    @lru_cache(maxsize=65536)
    def joined(A,B,V,p0,p1):
        prev=old(A,B,V,p0,p1)
        if not (194<A<B<p0 and 0<V<=B and p0<=p1<2*p0):return prev
        return min(prev,calculate(A,B,V,p0,p1))
    sr.square_cap=joined
