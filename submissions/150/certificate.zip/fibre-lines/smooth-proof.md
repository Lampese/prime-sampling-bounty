# Explicit averaging of divisors in the two simultaneous progressions

This strengthens the preceding proof.md. All its hypotheses, including that both endpoints \(a,c\) are primes in one interval of width \(V\), remain in force. The new cap uses the original positive Dirichlet denominator in all cases, so it needs no complementary-direction argument. It bounds the entire fibre for every \(\beta,p\) and in particular for all shifts in the rectangle estimate.

## Removing the largest prime factors

Fix a line \(j\), the corresponding nonzero \(N=djp-u^2\), and the notation \(x=dt+|u|,\ y=ds-|u|,\ xy=N\) of proof.md. Let \(z\ge101,\ s\ge1\) be integers. Remove the \(s\) largest prime factors of \(|N|\) that exceed 101, counting multiplicity, or all such factors if there are fewer. Denote their product by \(m\). Thus \(\tau(m)\le 2^s\). The line estimate uses \(n\in\{7,13,25,49,97\}\) and the determinant factors from primes \(r\le101\).

Set \(R=dB+|u|\). Call the line good for \((z,s)\) if \(|N|/m\le 4G^2/z^s\). On a good line distribute the solutions into at most \(\tau(m)\) classes as follows. For each \(q^h\Vert m\), prescribe \(b_q=\min(v_q(x),h)\) and fix \(e=\prod q^{b_q}\). Then \(e\mid x,\ (m/e)\mid y\). Since \((d,N)=1\), the reduced factors \(x'=x/e,\ y'=y/(m/e)\) are in fixed residue classes modulo \(d\) and have product \(N/m\). Within one class write \(t'=(t-t_0)/e\), where \(t_0\) is the \(t\)-coordinate of any one of its points. This is an integer because \(e\mid x-x_0=d(t-t_0)\). Define the integer \(s'\) analogously using \(m/e\). Then \(x'\) and \(y'\) are affine polynomials in \(t',s'\) with common positive leading coefficient \(d\) and constants coprime to \(d\).

The determinant lemma of proof.md applied to these two affine progressions gives a nonzero integer
\[
 Z'=(N/m)^{T}\operatorname{Vand}(t')/\prod_i(x_i/e)^k
   =Z/m^{T},\qquad T=k(k+1)/2.
\]
Here \(\operatorname{Vand}(t')=\operatorname{Vand}(t)/e^M\) and \(nk=M\) exactly. The integrality proof allows any two constants coprime to \(d\), and either sign for \(y'\). Hence \(m^T\mid Z\). Its prime divisors all exceed 101, so it multiplies the original baseline and both-endpoint CRT gains without any overlap.

One can use the small size of the remaining factor at the same time. The original archimedean upper bound on \(|Z|\) has a factor \((|N|/R^2)^T\) that was bounded by 1 in proof.md. Thus dividing by \(m^T\) replaces this by \((|N|/(mR^2))^T\le(4/z^s)^T\). The \(V\)-dependent term of the line bound gains a factor \(\lambda=(4/z^s)^{T/M}\), where \(T/M=(k+1)/(2n)\). This describes a single use of \(m^T\). The good-line cap for the full line is
\[
 2^s[n\,1_{\rm allowed}(j)+\lambda\,C(G)\,W(j)],
 \quad C(G)=\frac{(n-1)VB}{A C_n(K_0) G^{k/n}},
\]
using the arithmetic weights of proof.md. We may sum this cost over every line, including bad ones, to avoid needing a lower count for the good set.

## Bad lines contain a large smooth divisor

If \(|N|/m>4G^2/z^s\) then all prime factors left after removing \(m\) are at most \(z\). Otherwise the \(s\) factors removed each exceed \(z\), giving \(m>z^s\), whereas \(|N|\le R^2\le4G^2\). Fix a segment \(g\le G\le h\). Writing \(P_z(N)=\prod_{r\le z} r^{v_r(N)}\), for primes \(r\), every bad line satisfies \(P_z(N)>4g^2/z^s\). Take
\[
 H=\left\lfloor\log_2\left\lfloor4g^2/z^s\right\rfloor\right\rfloor>0,
 \qquad w_r=\lceil\log_2 r\rceil,\quad a_r=\lfloor\log_r z^2\rfloor .
\]
Either some \(r^{a_r+1}\mid N\), or \(L(j)=\sum_{r\le z}w_r\sum_{i=1}^{a_r}1_{r^i\mid N}\ge H\). Consequently the bad indicator is at most
\[
  (L/H)^t+\sum_{r\le z}1_{r^{a_r+1}\mid N}
\]
for any positive integer \(t\). We use \(t=1,2,3,4\). Because \((d,N)=1,\ p\nmid N\), each condition \(r^i\mid N\) is one class modulo \(r^i\), or is empty.

## Explicit weighted moments and endpoint errors

The two nonnegative weights required by the fallback row bound are \(U(j)=1_{\rm allowed}(j)\) and \(U(j)=W(j)\). Include parity as one residue modulo \(m_0=2\), with an optional stronger version for common oddness. Let \(\mu\) be the upper full-period density of the whole weight including parity, and \(E\) its upper expansion coefficient norm as in proof.md. For an odd prime in the finite CRT weight let \(\bar\mu_r\) be the largest possible local mean across the states under consideration. For a prime absent from that weight use \(\bar\mu_r=1\). For \(r=2\) set \(\bar\mu_2=1/m_0\).

For every prime \(r\), a condition \(r^i\mid N\) together with its local weight has density at most \(1/r^i\), since all local weights are \(\le1\). Relative to the factor \(\bar\mu_r\) in the upper unconditioned product, the upper bound is \(1/(\bar\mu_r r^i)\). This remains true when the prime divides \(d\) or \(p\) because the condition is then empty. The bounds multiply over distinct primes by CRT. For a single prime write
\[
 b_{r,j} = \frac{w_r^j}{\bar\mu_r}
        \sum_{i\ge1}\frac{i^j-(i-1)^j}{r^i},\qquad b_j=\sum_{r\le z}b_{r,j}.
\]
The four rational sums before multiplying by \(w_r^j/\bar\mu_r\) are \(1/(r-1)\), \((r+1)/(r-1)^2\), \((r^2+4r+1)/(r-1)^3\), and \((r^3+11r^2+11r+1)/(r-1)^4\). Truncation of the actual exponent variable only decreases these positive quantities. On expanding \(L^t\), group the \(t\) labeled factors by equal prime. For each set partition the product over blocks of \(b_{|B|}\) dominates the contribution of assignments of distinct primes to the blocks. Therefore the uniform full-period weighted mean of \(L^t\) is at most \(\mu B_t\), where
\[
 B_0=1,\qquad B_t=\sum_{i=1}^t {t-1\choose i-1}b_i B_{t-i}.
\]
The exceptional prime-power union has full-period weighted mean at most \(\mu\,\epsilon\), \(\epsilon=\sum_{r\le z}1/(\bar\mu_r r^{a_r+1})\).

For an actual real \(j\) interval of width at most \(Y\), each monomial in the CRT expansion differs from its mean times the actual width by at most one per unit of coefficient norm. Multiplying a CRT atom by more divisibility conditions produces one class or the empty set, even when the same prime occurs more than once. Hence the discrepancy norm increases by at most \((\sum_r w_r a_r)^t\) for \(L^t\) and by at most \(\pi(z)\) for the exceptional union, relative to \(E\). Positivity of the actual full-period mean allows replacing the width by \(Y\). The final fallback sum for \(U\) on bad lines is bounded by
\[
  \mu Y \left(\frac{B_t}{H^t}+\epsilon\right)
 + E\left[\left(\frac{\sum_r w_r a_r}{H}\right)^t+\pi(z)\right].
\]
We may also bound it by the unscreened \(\mu Y+E\). The choices of \(t\) and of pricing parameters for allowed counts and for reciprocal gain may be optimized independently. The fallback determinant exponents and CRT parameters may differ from the good-line choices. These operations sum upper bounds on nonnegative contributions.

For a segment, coefficients of \(Y\) are charged at \(h\), since \(Y\propto G\) and \(YC(G)\propto G^{1-k/n}\) increase. Discrepancy coefficients multiplying \(C(G)\) are charged at \(g\), since \(C(G)\) decreases. The integer \(H\) is computed at \(g\). Thus the entire closed segment is bounded. We cover \([G_0,G_1]\) by successive overlapping segments and take their maximum. Each top-level direction either satisfies \(3\mid d\) or \(3\nmid d\); the mod-2 pricing remains valid in either parity configuration. No primality heuristic or asymptotic \(O\)-constant enters this bound.

All command inputs use exact integer and rational arithmetic. In population, each single-prime arithmetic expectation is rounded upwards to \(10^{-12}\) before summing. Multiplying these upper values by \(1/\bar\mu_r\ge1\) preserves direction. The inverse attenuation is evaluated by integer-power bisection with a downward-rounded denominator. The function smooth_cap.calculate(A,B,V,p0,p1) returns an integer uniform in the entire parameter interval. The hook smooth_cap.install() combines it with the existing rectangle cap after sieved_lift.install(boxes). Run python -B work/fibre-lines/full_smooth.py from the workspace root for the four representative full-window fibre bounds.

## Repeated fallback

For each finite policy \(b=(z_b,s_b)\), write \(F_b\) for its bad event and \(U_b(j)\) for the good-line cap in the first section. Write \(U_0(j)\) for the ordinary unconditional determinant. For any ordered list \(b_1,\ldots,b_k\), each line count \(K(j)\) satisfies
\[
 K(j)\le U_{b_1}(j)+
    \sum_{i=2}^k 1_{F_{b_{i-1}}}(j)\, U_{b_i}(j)
    +1_{F_{b_k}}(j)\,U_0(j).
\]
If the first good policy is \(b_i\), its term occurs on the right; if every policy fails then the last term occurs. This argument works for arbitrary bad sets. For the empty list use \(K(j)\le U_0(j)\).

Apply the proved weighted Markov bound for \(F_a\) to both the allowed and varying terms of \(U_b\). It bounds every directed edge \(a\to b\) as a sum over all \(j\). The initial edge is unconditional, and the terminal edge omits splitting. Every path's sum is an upper bound, so the shortest path in this finite graph is again an upper bound. The allowed-count and varying terms can use different valid congruence weights because each has its own uniform bound. All coefficients in smooth_cascade.py are rounded upwards; in particular the preliminary high-precision products are rounded upwards separately before further division by \(H^t\).

Use python -B work/fibre-lines/cascade_trial.py to reconstruct the complete four-strip comparison. The least favorable of all segments and directions gives the following bounds. The last column divides the certified cap by \(1+VG_1/p_0\), the full-parameter geometric upper envelope for the number of parity-compatible integer lines. It describes the scale of the result and does not count populated lines.

| First-window grid-3200 strip | Full cap using repeated fallback | Cap / geometric envelope |
|---|---:|---:|
| .40 | 675,977 | 84.79 |
| .45 | 82,207,745,541 | 194.76 |
| .47 | 8,684,987,840,909 | 265.34 |
| .49 | 1,224,903,612,274,193 | 482.60 |

The displayed integers include the faster, conservative upward pre-rounding of coefficients, as recorded in cascade-prices.txt. The interface is smooth_cascade.calculate(A,B,V,p0,p1), or smooth_cascade.install() to strengthen the current square_cap hook. Every segment is covered, including those where the ordinary determinant already beats the upper bound achieved by preceding segments. No shortest-path step changes the arithmetic content of the preceding lemmas.

## Large prime cutoffs

The same proof permits sums over \(r\le z\) for much larger \(z\) without listing those primes. The file smooth_tail.py splits at \(y=131072\). It computes the contributions from primes through \(y\) as before. For each integer interval \((a,b]\) above \(y\) with \(b\le 9a/8\), it uses
\[
 \pi(b)-\pi(a)\le\left\lfloor b/(\log b-1.1)-a/(\log a-1)\right\rfloor .
\]
These are exactly the two explicit prime-count bounds used in the project's PROBLEM.md above 60184. The logarithms are enclosed as described in proof.md. Bound the weights \(w_r\) by \(\lceil\log_2 b\rceil\), and each geometric moment \(\sum_{i\ge1}(i^j-(i-1)^j)/r^i\) by its value at \(r=a+1\); every term is positive and decreasing in \(r\). For all primes combined, the exceptional density without local corrections is at most \(\pi(z)/z^2\). Also \(a_r w_r\le2\log_2 z\,(\log_2r+1)/\log_2 r\le4\log_2 z\), so the total atomic mass is at most \(4\lceil\log_2(z+1)\rceil\pi(z)\). Corrections for the finite small-prime CRT density can still be computed one prime at a time with the same upward rounding. [P. Dusart, Estimates of Some Functions Over Primes without R.H.](https://arxiv.org/abs/1002.0442)

With these bounds the extra parameter sets in smooth_wide.py give the following further unconditional fibre caps. Run python -B work/fibre-lines/cascade_trial.py --wide to reconstruct wide-certified.txt. The old and large-cutoff hooks can each strengthen an initial CRT estimate independently.

| Strip | Cap | Cap / geometric envelope |
|---|---:|---:|
| .40 | 675,977 | 84.79 |
| .45 | 49,302,038,557 | 116.80 |
| .47 | 4,005,788,330,277 | 122.39 |
| .49 | 409,216,938,637,449 | 161.23 |

An optional refinement takes a fixed \(\sigma\in\{8,32\}\) and \(\theta=V/(2B\sigma)\). If \(|N|<\theta G^2\), then \(dB>G/2\), since otherwise the two factors have magnitudes at least \(G/2\) and \(G\). The short range of \(N=djp-u^2\) therefore leaves a \(j\)-interval of width at most \(2\theta G^2/(dp)\le Y/\sigma\). On its complement a good line has \(m\ge \theta z^s/4\). If this last bound exceeds 1 then the two allocation groups \(e=1,m\) are distinct. In the first group the \(s\)-coordinates of the prime endpoints are all in one class modulo \(m\); in the second group this holds for the \(t\)-coordinates. Each group thus has at most \(1+\lfloor V/m\rfloor\le1+\lfloor 8B\sigma/z^s\rfloor\) points. Bound at most \(2^s-2\) general groups on the full interval, two extreme groups by this simple spacing bound there, and two general groups on the small-\(|N|\) interval. Every previous-event moment bound applies on either interval with the identical coefficient error. The cheaper of this and the earlier full price remains valid. Run python -B work/fibre-lines/cascade_trial.py --wide --extreme. On the .49 strip the all-direction cap becomes 381,978,239,653,585. This optional billing is disabled by default.
