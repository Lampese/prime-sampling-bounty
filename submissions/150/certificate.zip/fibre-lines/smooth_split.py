"""A finite smooth-part moment majorant for divisors in a fixed reduced class."""
from fractions import Fraction as F
from functools import cache
from math import comb,isqrt
from local_divisors import sparse_local,PRIMES

SCALE=10**12


def ceilrat(a,b):
    return -(-a//b)


@cache
def primes(z):
    flags=bytearray(b'\1')*(z+1)
    flags[:2]=b'\0\0'
    for r in range(2,isqrt(z)+1):
        if flags[r]:flags[r*r::r]=bytes((z-r*r)//r+1)
    return [r for r in range(2,z+1) if flags[r]]


def moments(r):
    return (1,r+1,r*r+4*r+1,r**3+11*r*r+11*r+1)


@cache
def population(z):
    if z>300000:
        from smooth_tail import population as large
        return large(z)
    qlist=primes(z)
    total=[0]*5
    tail=atoms=0
    rows={}
    for r in qlist:
        w=(r-1).bit_length()
        h=1;power=r
        while power*r<=z*z:
            h+=1;power*=r
        atoms+=w*h
        row=[ceilrat(b*w**i*SCALE,(r-1)**i) for i,b in enumerate(moments(r),1)]
        epsilon=ceilrat(SCALE,power*r)
        tail+=epsilon
        for i,value in enumerate(row,1):total[i]+=value
        if r<=max(PRIMES):rows[r]=(row,epsilon)
    return tuple(total),tail,atoms,len(qlist),rows


@cache
def menu(n,odd,good3,cut,keep=3,five=None):
    m=4 if odd else 2
    means=[F(1,m),F(1,m)]
    errors=[F(1),F(1)]
    # Divide out the upper mean of a local factor if its root is prescribed.
    correction=[[ (2,F(m)) ],[(2,F(m))]]
    for r in PRIMES:
        if r>min(cut,n+3):break
        if r==3:
            states=(good3,) if isinstance(good3,str) else (('free','u') if good3 else ('d',))
        elif r==5 and five:
            states=('d','u') if five=='axis' else ('d','free') if five=='unit-u' else (five,)
        else:states=('free','d','u')
        values=[]
        for state in states:
            a,b,c,d=sparse_local(n,r,state)
            if state=='u' and r>keep:
                c=c*r/(r-1);a=b=1;d=c
            values.append((a,b,c,d))
        for i in range(2):
            mu=max(x[i*2] for x in values)
            means[i]*=mu;errors[i]*=max(x[i*2+1] for x in values)
            correction[i].append((r,1/mu))
    return tuple((mu,e,tuple(corr)) for mu,e,corr in zip(means,errors,correction))


@cache
def moment_model(z,corr):
    total,tail,atoms,np,rows=population(z)
    tot=list(map(lambda x:F(x,SCALE),total))
    eps=F(tail,SCALE)
    for r,scale in corr:
        if r>z:continue
        moment,epsilon=rows[r]
        for i,value in enumerate(moment,1):tot[i]+=(scale-1)*F(value,SCALE)
        # For very large z the tail averages an upper prime count with
        # unrounded per-prime bound 1/z². Subtract only that amount when
        # excluding a prime from the aggregate outward bound.
        local_tail=F(1,z*z) if scale<1 and z>300000 else F(epsilon,SCALE)
        eps+=(scale-1)*local_tail
    # Bell polynomial bound for independent nonnegative summands.
    bell=[F(1)]
    for level in range(1,5):
        bell.append(sum(comb(level-1,j-1)*tot[j]*bell[level-j] for j in range(1,level+1)))
    return tuple(bell[1:]),eps,atoms,np


@cache
def markov(z,H,corr):
    bell,eps,atoms,np=moment_model(z,corr)
    return tuple((b/H**level+eps,F(atoms,H)**level+np) for level,b in enumerate(bell,1))


def split_at(A,B,V,p0,g,lo,odd,g3,z,s):
    """Bound the whole segment [lo,g], using monotonicity of G^(1-k/n)."""
    from local_divisors import det_factor
    from prime_sampling.rectangles.allsquarecap import pow_lower
    Y=F(2*V*g,p0)
    # If the product of the s largest prime factors of N above 101 is
    # inadequate, all remaining factors <=z and their product exceeds 4G²/z^s.
    H=((4*lo*lo)//z**s).bit_length()-1
    if H<=0:return None
    nvals=(7,13,25,49,97)
    cuts=(0,3,7,13,31)
    good=[];bad=[]
    for n in nvals:
        k=n//2
        term=F(2*k*V*B*(100<<16),det_factor(n)*A*pow_lower(g,k))
        outer=F(2*k*V*B*(100<<16),det_factor(n)*A*pow_lower(lo,k))
        # Downward-approximate (z^s/4)^((k+1)/(2n)) by integer bisection.
        root=scaled_root(z**s,k+1,2*n)
        for cut in cuts:
            data=menu(n,odd,g3,cut)
            (mu0,e0,_),(mu1,e1,_)=data
            good.append((2**s*(n*(mu0*Y+e0)+(term*mu1*Y+outer*e1)/root),n,cut))
            options=[]
            for (inner,edge),(mu,e,corr) in zip(((n,n),(term,outer)),data):
                values=[(inner*mu*Y+edge*e,0)]
                for level,(avg,err) in enumerate(markov(z,H,corr),1):
                    values.append((inner*mu*Y*avg+edge*e*err,level))
                options.append(min(values))
            bad.append((sum(x[0] for x in options),n,cut,tuple(x[1] for x in options)))
    return min(good),min(bad)


@cache
def scaled_root(t,num,den):
    scale=10**9
    hi=scale;rhs=t**num*scale**den;coef=4**num
    while coef*hi**den<=rhs:hi*=2
    lo=hi//2
    while hi-lo>1:
        mid=(lo+hi)//2
        if coef*mid**den<=rhs:lo=mid
        else:hi=mid
    return F(lo,scale)
