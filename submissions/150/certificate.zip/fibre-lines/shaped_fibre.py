"""Uniform prime reciprocal-difference cap from a finite family of lattice directions."""
from fractions import Fraction as F
from functools import cache,lru_cache
from hashlib import sha256
from math import isqrt
from pathlib import Path
from smooth_cascade import segment
from smooth_wide import policies

MODES=tuple((odd,s) for odd in (False,True) for s in ('d','u','free'))
TABLE=Path(__file__).with_name('main-shape-menu.dat')


@cache
def menu():
    rows=tuple(tuple(map(int,line.split())) for line in TABLE.read_text(encoding='ascii').splitlines())
    canonical=''.join(' '.join(map(str,row))+'\n' for row in rows).encode('ascii')
    if sha256(canonical).hexdigest()!='0d6ada455b5ecd87444ac0d65a5f602f31ccd6e205c3455bc7a8d1dc47503ed7':
        raise ValueError('Lattice direction coverage table differs from the certified table')
    if len(rows)!=8815 or any(len(row)!=6 or any(r!=99 and not 1<=r<=40 for r in row) for row in rows):
        raise ValueError('Invalid direction coverage row')
    return rows


def calculate(A,B,V,p0,p1,detail=False,conditional=False):
    start=max(B,min(A*A,-(-p0//(B+V))))
    norm=isqrt(p1*B)+1
    if 5*norm>=2*p0:return (V+1,[]) if detail else V+1
    cluster=policies(V//max(1,isqrt(norm)))
    rows=menu()
    prices=[]
    for idx,mode in enumerate(MODES):
        if conditional:mode=mode+(True,)
        ticks=sorted({r[idx] for r in rows if r[idx]!=99})
        # An encompassing interval or collection of adjacent intervals in G
        # is repriced for this residue class alone.
        current=0;upper=0;values={}
        for tick in ticks:
            hi=-(-norm*tick//16)
            if hi<start:values[tick]=0;continue
            lo=max(start,upper)
            parts=[]
            while hi//16>lo:
                parts.append((hi//16,hi));hi=hi//16
            parts.append((lo,hi))
            for l,h in reversed(parts):
                direct=segment(A,B,V,p0,l,h,mode,())
                if direct>current:
                    direct=segment(A,B,V,p0,l,h,mode,cluster)
                current=max(current,direct)
            upper=-(-norm*tick//16)
            values[tick]=current
        prices.append(values)
    best=0;worst=None
    for row in rows:
        val=min(prices[i][r] for i,r in enumerate(row) if r!=99)
        if val>best:best=val;worst=row
    best=min(best,V+1)
    return (best,(worst,prices)) if detail else best


def install(conditional=False):
    from prime_sampling.spectrum import squarerates as sr
    old=sr.square_cap
    @lru_cache(maxsize=65536)
    def joined(A,B,V,p0,p1):
        prev=old(A,B,V,p0,p1)
        if not (194<A<B<p0 and 0<V<=B and p0<=p1<2*p0):return prev
        return min(prev,calculate(A,B,V,p0,p1,conditional=conditional))
    sr.square_cap=joined
