# Choosing the reciprocal-difference direction jointly at 2 and 3

This bound applies uniformly in every nonzero shift and every prime in the parameter window. The interval hypotheses and the one-direction determinant are in proof.md. Its smooth-part estimates and the costs along the finite fallback paths are in smooth-proof.md.

## A covering of determinant-one lattices

For a fixed prime \(p>3\), a shift \(\beta\ne0\bmod p\), and the endpoint upper bound \(B\), let \(S=\sqrt{Bp}\). Send the lattice of \((d,u)\in\mathbb Z^2\) with \(u\equiv d\beta\bmod p\) to \((Bd/S,u/S)\). Its determinant is one and its maximum norm equals \(G/S\). Minkowski's theorem applied to the centered square, first enlarged by a positive amount and then taking a limit, produces a primitive lattice vector of maximum norm at most one. Signs and a coordinate interchange allow the vector to be written \(v=(t,r)\), \(0<t\le1,\ 0\le r\le t\). These operations only change the coordinates used for norm calculations. All residue tests refer to the original basis.

Complete \(v\) to a lattice basis \((v,w)\) of determinant one, using the chosen orientation. Adding an integral multiple of \(v\) gives
\[
 w=(tz,\ 1/t+rz),\qquad -1/2\le z\le1/2 .
\]
If \(t\le1/2\), that single vector suffices and its residue mode is arbitrary. If \(t\ge1/2\), the procedure in main_shape.cpp covers \(t,r,z\) by closed intervals whose endpoints are multiples of \(1/32\). Cells intersecting \(0\le r\le t\) are all included. In each cell it considers primitive combinations \(iv+jw\), with \(0\le j\le4\) and \(-6\le i\le6\). Only members of this finite family are needed for the upper bound. The two coordinates are \(t(i+jz)\) and \(j/t+r(i+jz)\). Bound the product term by all four corners, separately bound \(j/t\) using the endpoints of \(t\), combine, and take absolute values. All arithmetic rounds outward on a grid of denominator \(64^2\). For \(j=0\), \(\|v\|_\infty=t\) by construction. Store the upper norm as a multiple of \(1/16\), omitting norms exceeding \(5/2\).

Any lattice-basis matrix in the original integer coordinates has determinant \(\pm p\). Its images modulo 2 and modulo 3 are bases. The residue condition that \(d,u\) are both odd corresponds to one of the three points of \(\mathbb P^1(\mathbb F_2)\) in basis coordinates. The two conditions \(3\mid d,3\mid u\) correspond to an ordered pair of different points of \(\mathbb P^1(\mathbb F_3)\). The remaining two points give \(3\nmid du\). Exhausting all \(3\cdot4\cdot3=36\) assignments covers every basis. For each of six resulting modes record the smallest certified radius among its available combinations. An absent mode receives the sentinel 99. Every recorded vector is primitive in the lattice because \((i,j)=1\). If \(5\lceil\sqrt{Bp_1}\rceil/2<p_0\), its nonzero integer coordinates have absolute values less than \(p\), and neither coordinate can vanish by the lattice congruence. An integer common divisor prime to \(p\) could be cancelled in the congruence, contradicting lattice primitivity. Thus the original coordinates are coprime. Flip both signs to obtain \(d>0\).

The output rows bound radii from above. If one row exceeds another componentwise it covers the latter for every nondecreasing cost. Sorting in decreasing lexicographic order and dropping rows already covered leaves 8,815 rows from 134,232 distinct initial rows. In particular every lattice has one certified output row for which a direction exists in each finite slot with \(G\le(\mathrm{tick}/16)S\). This is an intersection of available alternatives for a single lattice. Costs can be minimized among the directions of the row before maximizing across the cover.

## Determinant weights at the prime 2

Use \(n=2k+1,\ M=kn,\ T=k(k+1)/2\), \(x_i=dt_i+|u|,\ y_i=ds_i-|u|\), and \(N=x_i y_i\). All \(t_i,s_i\) are odd primes. For opposite parities of \(d,u\), both factors and \(N\) are odd. Therefore the valuation of \(Z=N^T\operatorname{Vand}(t_i)/\prod x_i^k\) equals that of the Vandermonde, which is at least \(H_2(n,1)=\sum_{h\ge0}b(n,2^h)\), since there is only one allowed residue modulo 2.

For common oddness, write \(x'_i=x_i/2,\ y'_i=y_i/2,\ N'=N/4\), \(t'_i=(t_i-t_1)/2\), and similarly \(s'_i\). The reduced two progressions have common odd slope \(d\) and integral offsets. Since \(M=kn\),
\[
 Z'= (N')^T \operatorname{Vand}(t'_i)/\prod(x'_i)^k=Z/4^T .
\]
For \(h\ge1\) with \(h\le v_2(N')\), let \(s\) be the number of \(x'_i\) divisible by \(2^h\). Their equal-class pairs, the denominator, and the \(N'\)-factor contribute \(\binom{s}{2}-ks+T=(s-k)(s-k-1)/2\). The other points occupy at most \(2^h-1\) classes, since \(d\) is odd. For \(h>v_2(N')\), the numerator and denominator powers do not contribute and the equal-class pairs give at least \(b(n,2^h)\). Consequently
\[
 v_2Z\ge 2T+\sum_{h\ge1}\min\!\left\{b(n,2^h),\
    \min_{0\le s\le n}\left((s-k)(s-k-1)/2+b(n-s,2^h-1)\right)\right\}.
\]
For example, at \(n=13\) these two refinements yield 134 and 54 respectively against the unconditional valuation 33. Each determinant's baseline factor is already in the archived proof. Only the excess over its baseline is inserted as a multiplicative weight. The gain is constant over every permitted line for a fixed mode. Both the old weighted main term and its absolute discrepancy can therefore be multiplied by that constant, including after the smooth-part moment bound. Large-prime splitting uses only primes exceeding 101, coprime to 2. At 3 the selected mode fixes exactly one existing local profile from proof.md and smooth-proof.md.

## Exact pricing and reproduction

For a number \(q\) of radius ticks, let \(P_m(q)\) be an upper price for all directions of mode \(m\) with \(G_0\le G\le \lceil q(\lfloor\sqrt{Bp_1}\rfloor+1)/16\rceil\). Here \(G_0\) is the nonempty-fibre lower bound of proof.md. An interval below \(G_0\) certifies an empty fibre. The integer intervals between consecutive available ticks, with extra subdivisions in factors of 16 for long intervals, cover every admissible integer \(G\). Applying the fixed-mode determinant and smooth bound on each, then keeping the running maximum, ensures \(P_m(q)\) is nondecreasing. The cap returned by shaped_fibre.calculate is the minimum of \(V+1\) and
\[
 \max_{\text{rows}}\ \min_{m\ \text{present}} P_m(q_m).
\]
For the guard failure the routine uses \(V+1\). The hook takes the minimum of this new bound and all bounds installed previously. It requires the original repository and the local modules smooth_cascade.py, smooth_wide.py, smooth_split.py, smooth_tail.py, and local_divisors.py, plus the certified main-shape-menu.dat.

From the workspace root compile main_shape.cpp with a C++17 compiler, run the executable, and redirect standard output to work/fibre-lines/main-shape-menu.dat as ASCII. The canonical SHA-256 of the 8,815 six-integer rows in original order, with one ASCII space between integers and one LF per row, is 0d6ada455b5ecd87444ac0d65a5f602f31ccd6e205c3455bc7a8d1dc47503ed7. The loader verifies this automatically. Run python -B work/fibre-lines/check_main_shape.py for direct integer-lattice and valuation cross-checks. Run python -B work/fibre-lines/main_shape_full.py to reproduce the four short-side caps in main-shape-certified.txt. To reproduce the genuine rectangle rates run python -B work/operator-new/probe.py --grid 3200 --mode six --method mixture --shaped-fibre --shape-near, replacing six with pair for the other branch.

| Strip left endpoint | Previous smooth cap | Lattice modes and strengthened 2-adic determinant |
|---:|---:|---:|
| 0.40 | 675977 | 356966 |
| 0.45 | 49302038557 | 29781830757 |
| 0.47 | 4005788330277 | 2311771618464 |
| 0.49 | 409216938637449 | 228065515857138 |
