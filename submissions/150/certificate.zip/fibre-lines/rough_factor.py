"""Adaptive coarse-factor cutoffs with a mean divisor multiplicity."""
from bisect import bisect_right
from fractions import Fraction as F
from functools import cache
from math import isqrt
from local_divisors import ln_bounds,det_factor
from smooth_split import ceilrat,primes,scaled_root
from smooth_cascade import DEGREES,coefficients,monotone_min,SCALE
from prime_sampling.rectangles.allsquarecap import pow_lower


SMALL=65536


@cache
def local_sieve():
    allowed=bytearray(b'\1')*(SMALL+1);allowed[0]=0
    local=primes(101)
    for r in local:allowed[r::r]=bytes(SMALL//r)
    vals=[i for i,t in enumerate(allowed) if t]
    pref=[0]
    for v in vals:pref.append(pref[-1]+ceilrat(SCALE,v))
    rho=F(1);dens=[]
    for i,r in enumerate(local,1):
        rho*=F(r-1,r);dens.append((rho,2**i))
    return vals,pref,dens


@cache
def interval(a,b):
    if a>=b:return F(0),0
    vals,pref,dens=local_sieve()
    count=0;harm=F(0)
    if a<SMALL:
        lo=bisect_right(vals,a);hi=bisect_right(vals,min(b,SMALL))
        count=hi-lo;harm=F(pref[hi]-pref[lo],SCALE);a=SMALL
    while a<b:
        stop=min(8*a,b)
        log=ln_bounds(stop)[1]-ln_bounds(a)[0]
        count+=min((r*(stop-a)+e).__floor__() for r,e in dens)
        harm+=min(r*log+F(e,a) for r,e in dens)
        a=stop
    return harm,count


@cache
def multiplicity(Y,Z):
    if Z==0:
        h,num=interval(1,Y)
        return 2+2*h,2+2*num
    b=0;prod=1
    while prod<Y:prod*=Z;b+=1
    mu=err=2**b
    lower=1
    for j in reversed(range(b)):
        E=isqrt(Y*Z//Z**j)
        h,num=interval(lower,E)
        mu+=2**(j+1)*h;err+=2**(j+1)*num
        lower=max(lower,E)
    return mu,err


@cache
def rough_blocks(Y,Z):
    if not Z:
        buckets=[(1,Y,2)];base=2
    else:
        b=0;prod=1
        while prod<Y:prod*=Z;b+=1
        base=2**b;lower=1;buckets=[]
        for j in reversed(range(b)):
            E=isqrt(Y*Z//Z**j)
            if E>lower:buckets.append((lower,E,2**(j+1)));lower=E
    out=[(1,1,F(base),base)]
    for l,r,coeff in buckets:
        # Subdivide to retain the effect of log e in the conditional moment.
        while l<r:
            stop=min(r,max(101,l*1024))
            h,num=interval(l,stop)
            if num:out.append((l+1,stop,coeff*h,coeff*num))
            l=stop
    return out


def restricted(A,B,V,p,lo,hi,g3,Y,Z,zprev,Hprev):
    raw_y=2*V*hi
    rows=[]
    for n in DEGREES:
        k=n//2;dh=pow_lower(hi,k);dl=pow_lower(lo,k)
        root=scaled_root(Y,k+1,2*n)
        bill=0
        for entry in rough_blocks(Y,Z):
            _,emax,harm,cnt=entry[:4]
            H=Hprev-(emax-1).bit_length()
            z=zprev if H>0 else 0
            xy=(raw_y*harm).__ceil__();dis=p*cnt
            count=monotone_min(coefficients(n,g3,z,max(0,H),0),xy,dis)
            wt=monotone_min(coefficients(n,g3,z,max(0,H),1),xy*dl,dis*dh)
            if len(entry)>4 and 101<entry[4]<=10**12:
                Hnew=(V*lo*lo//(16*B*emax)).bit_length()-1
                if Hnew>0:
                    # For small |N| the possible j occupy 1/8 of the
                    # original width, or there are no such solutions.
                    ns=coefficients(n,g3,z,max(0,H),0);ws=coefficients(n,g3,z,max(0,H),1)
                    small0=ceilrat(monotone_min(ns,xy,8*dis),8)
                    small1=ceilrat(monotone_min(ws,xy*dl,8*dis*dh),8)
                    main0=monotone_min(coefficients(n,g3,entry[4],Hnew,0),xy,dis)
                    main1=monotone_min(coefficients(n,g3,entry[4],Hnew,1),xy*dl,dis*dh)
                    count=min(count,small0+main0)
                    wt=min(wt,small1+main1)
            # Here count and wt include the block's own multiplicity already.
            bill+=n*ceilrat(count,SCALE*p)
            bill+=ceilrat(wt*2*k*V*B*(100<<16)*root.denominator,
                          SCALE*p*dl*dh*det_factor(n)*A*root.numerator)
        rows.append((bill,n))
    return min(rows)


def good_rows(A,B,V,p,lo,hi,g3,Y,Z,oracle=False):
    mut,et=(F(1),F(0)) if oracle else multiplicity(Y,Z)
    y=2*V*hi
    vals=[]
    for n in DEGREES:
        k=n//2
        opts=coefficients(n,g3,0,0,0)
        mass=n*min((mu*y*mut+e*p*et)/(SCALE*p) for mu,e in opts)
        dh=pow_lower(hi,k);dl=pow_lower(lo,k)
        opts=coefficients(n,g3,0,0,1)
        weight=min((mu*y*dl*mut+e*p*dh*et)/(SCALE*p*dl*dh) for mu,e in opts)
        term=F(2*k*V*B*(100<<16),det_factor(n)*A)
        root=scaled_root(Y,k+1,2*n)
        vals.append(((mass+term*weight/root).__ceil__(),n))
    return min(vals)
