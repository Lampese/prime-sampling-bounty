from fractions import Fraction as F
from heapq import heappop,heappush
from math import isqrt
import sys
from probe import boxes,sieved_lift
from smooth_cascade import profile,goodprice,policies_for,DEGREES
from rough_factor import restricted


def shortest(scores,labels):
    end=len(labels);dist={0:0};back={};queue=[(0,0)]
    while queue:
        cost,i=heappop(queue)
        if i==end:break
        if cost!=dist[i]:continue
        for j,edge in enumerate(scores[i],1):
            if i==j:continue
            val=cost+edge
            if val<dist.get(j,val+1):
                dist[j]=val;back[j]=i;heappush(queue,(val,j))
    path=[];k=back[end]
    while k:path.append(labels[k]);k=back[k]
    return dist[end],list(reversed(path))


def compare(u,A,B,V,p,G,g3):
    lo=G//16;ratio=V//isqrt(G)
    pbase=policies_for(ratio)
    extra=((10**9,3),(10**8,3)) if u==F('.47') else ((10**11,3),(10**10,3),(10**6,5))
    ordinary=[('p',z,s) for z,s in pbase+extra]
    # Include direct single thresholds and two-stage cutoffs around the
    # observed change between constant term, attenuation and CRT discrepancy.
    rough=[('r',10**j,0) for j in (7,9,11,13)]
    rough.extend(('r',10**j,10**k) for j in (11,14,16,18,20,22,24) for k in (3,5,6,8,10))
    if '--narrow' in sys.argv:
        rough=[('r',10**j,10**k) for j in (14,16,18,20) for k in (3,5,6)]
    nodes=[('p',0,0)]+ordinary+rough
    rows=[];exitnode=[]
    for k,a,b in nodes:
        z,H=(a,(4*lo*lo//(a**b)).bit_length()-1) if k=='p' and a else (0,0)
        if k=='r':z,H=101,(4*lo*lo//a).bit_length()-1
        prof=[profile(n,g3,z,H,A,B,V,p,lo,G) for n in DEGREES]
        row=[goodprice(prof,(c,d)) for _,c,d in ordinary]
        for _,c,d in rough:row.append(restricted(A,B,V,p,lo,G,g3,c,d,z,H)[0])
        termination=goodprice(prof,None)
        rows.append(row+[termination]);exitnode.append(termination)
    before=[r[:len(ordinary)]+[end] for r,end in zip(rows[:1+len(ordinary)],exitnode)]
    return shortest(before,nodes[:1+len(ordinary)]),shortest(rows,nodes)


if __name__=='__main__':
    if '--selected' in sys.argv:
        from rough_select import install
        install()
    if '--tagged' in sys.argv:
        from rough_select import install_tagged
        install_tagged()
    boxes.initialize(F(150),F(4801,32));sieved_lift.install(boxes)
    for u in map(F,('.47','.49')):
        _,_,a,b,_,v,_,_=boxes.params(u,u+F(1,3200))
        p,p1=boxes.pmin,boxes.pmax
        d=isqrt(p1//b);g=max(b*d,-(-p1//d))
        for mod in (False,True):
            old,new=compare(u,a,b,v,p,g,mod)
            print(u,mod,'old',old[0],'new',new[0],'saving',old[0]-new[0],
                  'chosen',new[1],flush=True)
