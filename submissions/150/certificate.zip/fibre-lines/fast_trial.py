from fractions import Fraction as F
from time import perf_counter
import os
from probe import boxes,sieved_lift
from fast_fibre import calculate

if __name__=='__main__':
    boxes.initialize(F(150),F(4801,32));sieved_lift.install(boxes)
    for strip in map(F,('.40','.43','.45','.46','.47','.48','.49')):
        _,_,A,B,_,V,_,_=boxes.params(strip,strip+F(1,3200));p0,p1=boxes.pmin,boxes.pmax
        start=perf_counter()
        bound,choice=calculate(A,B,V,p0,p1,True)
        print(strip,'used',choice,'cap',bound,'seconds',round(perf_counter()-start,3),flush=True)
    if os.name=='nt':
        import _ctypes
        from prime_sampling.spectrum import squarerates as sr
        _ctypes.FreeLibrary(sr._lib._handle)
