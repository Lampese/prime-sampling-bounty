"""Short-sum cap using rigorously grouped prime cutoffs above 300000."""
from functools import lru_cache
from math import isqrt
from smooth_cascade import calculate as cascade,policies_for


def policies(ratio):
    cluster=policies_for(ratio)
    if ratio<500:more=()
    elif ratio<18000:more=((10**8,3),(10**7,3),(100000,4),(10000,5),(10000,4))
    elif ratio<200000:more=((10**9,3),(10**8,3))
    else:more=((10**11,3),(10**10,3),(10**6,5))
    return cluster+more


def calculate(A,B,V,p0,p1,detail=False,extreme=False):
    D=isqrt(p1//B)
    G=max(B*D,-(-p1//D))
    ratio=V//max(1,isqrt(G))
    return cascade(A,B,V,p0,p1,detail,policies=policies(ratio),extreme=extreme)


def install():
    from prime_sampling.spectrum import squarerates as sr
    old=sr.square_cap
    @lru_cache(maxsize=65536)
    def joined(A,B,V,p0,p1):
        prev=old(A,B,V,p0,p1)
        if not (194<A<B<p0 and 0<V<=B and p0<=p1<2*p0):return prev
        D=isqrt(p1//B)
        if not 0<D<p0:return prev
        return min(prev,calculate(A,B,V,p0,p1))
    sr.square_cap=joined
