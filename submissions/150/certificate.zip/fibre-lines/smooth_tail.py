"""Dusart interval upper counts for very large trial cutoffs in the smooth-part bound."""
from fractions import Fraction as F
from functools import cache
from local_divisors import ln_bounds,PRIMES


@cache
def count(lo,hi):
    assert 60184<=lo<hi
    # Both inequalities are in Dusart's 2010 theorem on pi(x).
    upper=F(hi)/(ln_bounds(hi)[0]-F(11,10))
    lower=F(lo)/(ln_bounds(lo)[1]-1)
    return (upper-lower).__floor__()


@cache
def population(z):
    from smooth_split import population as base,SCALE,ceilrat,moments
    small=131072
    raw,_,_,_,local=base(small)
    total=list(raw)
    lo=small
    np=(F(z)/(ln_bounds(z)[0]-F(11,10))).__floor__()
    while lo<z:
        hi=min(z,lo+lo//8)
        n=count(lo,hi);w=(hi-1).bit_length();r=lo+1
        for i,b in enumerate(moments(r),1):
            total[i]+=ceilrat(SCALE*n*w**i*b,(r-1)**i)
        lo=hi
    # For r<=z, r^(a_r+1)>z², and a_r*ceil(log2 r)<=4log2 z.
    tail=ceilrat(SCALE*np,z*z)
    atoms=4*z.bit_length()*np
    rows={r:(vals,ceilrat(SCALE,z*z)) for r,(vals,_) in local.items()}
    return tuple(total),tail,atoms,np,rows
