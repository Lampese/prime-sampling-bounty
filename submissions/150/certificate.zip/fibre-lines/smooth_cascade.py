"""Exact portfolio pricing of nested fallbacks for smooth-part line bounds."""
from functools import cache,lru_cache
from fractions import Fraction as F
from heapq import heappop,heappush
from math import isqrt
from smooth_split import menu,moment_model,scaled_root,SCALE,ceilrat
from local_divisors import det_factor
from prime_sampling.rectangles.allsquarecap import pow_lower

DEGREES=(7,13,25,49,97)
CUTS=(0,3,7,13,31)


def envelope(rows):
    # Remove simultaneous dominations of a main-term and a discrepancy term.
    out=[];smallest=None
    for c,e in sorted(set(rows)):
        if smallest is None or e<smallest:
            out.append((c,e));smallest=e
    return tuple(out)


@cache
def preliminary(n,g3,z,idx):
    plain=[];screened=[]
    from local_divisors import two_adic_weight,conditional_two
    odd,state=g3[:2] if isinstance(g3,tuple) else (False,g3)
    dynamic=isinstance(g3,tuple) and len(g3)>2 and g3[2]
    keep=g3[3] if isinstance(g3,tuple) and len(g3)>3 else 3
    five=g3[4] if isinstance(g3,tuple) and len(g3)>4 else None
    extra=two_adic_weight(n,odd) if isinstance(g3,tuple) and idx else F(1)
    for cut in CUTS:
        mu,E,correction=menu(n,odd,state,cut,keep,five)[idx]
        if dynamic and not odd:
            correction=((2,F(0)),)+correction[1:]
        if dynamic and odd and idx:
            mean,norm,maximum=conditional_two(n)
            mu*=mean;E*=norm
            correction=((2,4*maximum/mean),)+correction[1:]
        else:
            mu*=extra;E*=extra
        plain.append(((SCALE*mu).__ceil__(),(SCALE*E).__ceil__()))
        if z:
            bell,eps,atoms,npr=moment_model(z,correction)
            ac=(SCALE*mu*eps).__ceil__()
            bc=(SCALE*E*npr).__ceil__()
            for level,b in enumerate(bell,1):
                screened.append((level,ac,(SCALE*mu*b).__ceil__(),bc,(SCALE*E*atoms**level).__ceil__()))
    if keep>3:
        lesser=13 if keep>13 else 7 if keep>7 else 3
        old_plain,old_screened=preliminary(n,(odd,state,dynamic,lesser,five),z,idx)
        plain.extend(old_plain);screened.extend(old_screened)
    elif dynamic:
        old_plain,old_screened=preliminary(n,(odd,state),z,idx)
        plain.extend(old_plain);screened.extend(old_screened)
    return plain,screened


@cache
def coefficients(n,g3,z,H,idx):
    plain,screened=preliminary(n,g3,z,idx)
    rows=list(plain)
    powers=(1,H,H*H,H**3,H**4)
    for level,a,x,b,y in screened:
        den=powers[level]
        rows.append((a+ceilrat(x,den),b+ceilrat(y,den)))
    return envelope(rows)


def monotone_min(rows,x,y):
    return min(c*x+e*y for c,e in rows)


@lru_cache(maxsize=40000)
def profile(n,g3,z,H,A,B,V,p,lo,hi,shrink=1):
    """Return contributions to the constant and varying terms on this bad set."""
    k=n//2
    Y=2*V*hi
    ns=coefficients(n,g3,z,H,0)
    mass=n*ceilrat(monotone_min(ns,Y,p*shrink),SCALE*p*shrink)
    weight=coefficients(n,g3,z,H,1)
    dh=pow_lower(hi,k);dl=pow_lower(lo,k)
    bill=monotone_min(weight,Y*dl,p*dh*shrink)
    w=ceilrat(bill*2*k*V*B*(100<<16),SCALE*p*shrink*dh*dl*det_factor(n)*A)
    return mass,w


@cache
def residual_root(t,n,residual):
    num=n//2+1;den=2*n
    if residual==(4,1):return scaled_root(t,num,den)
    ratio_top,ratio_bottom=residual
    scale=10**9
    rhs=(t*ratio_bottom)**num*scale**den
    coef=ratio_top**num
    lo=0;hi=scale
    while coef*hi**den<=rhs:lo=hi;hi*=2
    while hi-lo>1:
        mid=(lo+hi)//2
        if coef*mid**den<=rhs:lo=mid
        else:hi=mid
    return F(lo,scale)


def goodprice(profiles,next_policy,residual=(4,1)):
    if next_policy is None:return min(a+b for a,b in profiles)
    z,s=next_policy
    return 2**s*min(a+ceilrat(b*root.denominator,root.numerator)
                     for n,(a,b) in zip(DEGREES,profiles)
                     for root in [residual_root(z**s,n,residual)])


def segment(A,B,V,p,lo,hi,g3,policies,detail=False,extreme=False,arch=(1,1),residual=(4,1)):
    # A path A->B pays B's good cap on the entire bad-A set. A path ending
    # at the terminal pays the full fallback there. No nesting is assumed.
    valid=[]
    for z,s in policies:
        H=(residual[0]*lo*lo//(residual[1]*z**s)).bit_length()-1
        if H>0:valid.append(((z,s),H))
    nodes=[(None,0)]+valid
    profs=[];small=[]
    for par,H in nodes:
        z=par[0] if par else 0
        row=[profile(n,g3,z,H,A,B,V,p,lo,hi) for n in DEGREES]
        if arch!=(1,1):
            row=[(a,ceilrat(b*arch[0],arch[1])) for a,b in row]
        profs.append(row)
        if extreme:
            small.append({sh:[profile(n,g3,z,H,A,B,V,p,lo,hi,sh) for n in DEGREES]
                          for sh in (8,32)})
    terminal=len(nodes)
    distances={0:0};parent={}
    queue=[(0,0)]
    while queue:
        cost,i=heappop(queue)
        if i==terminal:break
        if cost!=distances[i]:continue
        for dest in range(1,terminal+1):
            if dest==i:continue
            policy=nodes[dest][0] if dest!=terminal else None
            edge=goodprice(profs[i],policy,residual)
            if extreme and policy is not None:
                z,s=policy;power=z**s
                for sh,sub in small[i].items():
                    if power*V<=8*B*sh:continue
                    per=1+8*B*sh//power
                    for n,(a,b),(sa,sb) in zip(DEGREES,profs[i],sub):
                        root=scaled_root(power,n//2+1,2*n)
                        base=a+ceilrat(b*root.denominator,root.numerator)
                        residual=sa+ceilrat(sb*root.denominator,root.numerator)
                        edge=min(edge,(2**s-2)*base+2*per*(a//n)+2*residual)
            bill=cost+edge
            if bill<distances.get(dest,bill+1):
                distances[dest]=bill;parent[dest]=i
                heappush(queue,(bill,dest))
    if not detail:return distances[terminal]
    path=[];cursor=parent[terminal]
    while cursor:
        path.append(nodes[cursor][0]);cursor=parent[cursor]
    return distances[terminal],list(reversed(path))


def policies_for(ratio):
    if ratio<500:return ((1000,3),(3000,4))
    if ratio<18000:return ((300000,3),(30000,4),(3000,4),(1000,5),(1000,3))
    if ratio<200000:return ((300000,4),(30000,5),(10000,5),(3000,5),(3000,6),(1000,6),(1000,3))
    return ((300000,5),(100000,5),(30000,6),(10000,6),(3000,6),(1000,6),(1000,3))


def calculate(A,B,V,p0,p1,detail=False,policies=None,extreme=False):
    D=isqrt(p1//B)
    start=max(B,min(A*A,-(-p0//(B+V))))
    top=max(B*D,-(-p1//D))
    if start>top:return (0,[]) if detail else 0
    if policies is None:policies=policies_for(V//max(1,isqrt(top)))
    rows=[];cap=0;hi=top
    while True:
        lo=max(start,hi//16)
        scores=[]
        for g3 in (False,True):
            value=segment(A,B,V,p0,lo,hi,g3,(),detail)
            if (value[0] if detail else value)>cap:
                value=segment(A,B,V,p0,lo,hi,g3,policies,detail,extreme)
            scores.append(value)
        cap=max(cap,*(v[0] if detail else v for v in scores))
        if detail:rows.append((lo,hi,*scores))
        if lo==start:break
        hi=lo
    answer=min(cap,V+1)
    return (answer,rows) if detail else answer


def install():
    from prime_sampling.spectrum import squarerates as sr
    old=sr.square_cap
    @lru_cache(maxsize=65536)
    def joined(A,B,V,p0,p1):
        prev=old(A,B,V,p0,p1)
        if not (194<A<B<p0 and 0<V<=B and p0<=p1<2*p0):return prev
        D=isqrt(p1//B)
        if not 0<D<p0:return prev
        return min(prev,calculate(A,B,V,p0,p1))
    sr.square_cap=joined
