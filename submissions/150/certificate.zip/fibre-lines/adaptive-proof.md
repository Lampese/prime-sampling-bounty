# Adaptive divisor cutoffs in the lifted progression

Use the notation in smooth-proof.md. Fix \(Y>Z>101\). Select prime factors of \(|N|\) in decreasing order with multiplicity. First take the factors above \(Z\), stopping as soon as their product \(m_1\) reaches \(Y\). If it does not, take factors from \((101,Z]\) until \(m_1m_2\) first reaches \(Y\), or until these factors run out. Set \(m=m_1m_2\). The last factor can overshoot the cutoff. If \(m<Y\) then \(|N|/m=P_{101}(N)\). If \(m\ge Y\) then \(|N|/m\le4G^2/Y\). Consequently the same good-line bound applies with attenuation \((4/Y)^{(k+1)/(2n)}\) and front multiplier \(\tau(m)\); the new fallback event is \(P_{101}(N)>4g^2/Y\).

Write \(b=\lceil\log_Z Y\rceil\). If \(m_1\) reaches \(Y\), then \(\tau(m)\le2^b\). Otherwise \(m_1\) has \(h\le b-1\) prime factors, so \(m_1\ge Z^h\) and \(\tau(m_1)\le2^h\). Pair the divisors of \(m_2\) with their complements to give
\[
 \tau(m)\le 2^{h+1}\!\!\!\sum_{\substack{e\mid N,\ e\le E_h\\
                         P^-(e)>101,\ P^+(e)\le Z}}\!1,\qquad
 E_h=\lfloor\sqrt{YZ/Z^h}\rfloor .
\]
The sum includes 1. If the second stage reaches its threshold, its last factor \(q_*\) gives \(m_2<Yq_*/m_1\); if it does not, \(m_2<Y/m_1\). In particular for \(e>1\) in the paired small-divisor set one can also impose \(e^2<Y P^-(e)/Z^h\). This uses the decreasing order of the selected factors and \(q_*\le P^-(e)\).

Let \(A_h\) be these necessary conditions on \(e>1\), using either the base version \(e\le E_h,\ P^-(e)>101\) or the strengthened version just proved. They decrease with \(h\). With \(c_0=2\) and \(c_h=2^h\) for \(h\ge1\), a uniform pointwise upper envelope is
\[
 \tau(m)\le 2^b+\sum_{h=0}^{b-1}c_h\sum_{e\in A_h,\ e\mid N}1,
\]
because \(\sum_{i=0}^h c_i=2^{h+1}\). For the single-stage version, if there is a prime \(q>Y\) use \(m=q\). If there is none, the first crossing among primes above 101 gives \(m<Y^2\). The corresponding envelope is \(2+2\sum_{e\mid N,\ 1<e\le Y,\ P^-(e)>101}1\).

Every \(e\) in these nonconstant sums is coprime to 101 and all smaller primes. Its divisibility condition is empty if \((e,dp)>1\), and otherwise is one class modulo \(e\). Thus for any existing CRT weight of mean bound \(\mu\) and discrepancy bound \(E\), the cost of an \(e\)-bucket is \(\mu L\sum_e 1/e + E\,\#\{e\}\), where \(L\) is the \(j\)-interval width bound. This applies separately to the constant and varying terms of the determinant estimate.

The reciprocal and ordinary counts in rough_factor.py use a finite sieve exactly below 65,536. Above that threshold, for the first \(k\) primes through 101 with coprime density \(\rho\), inclusion-exclusion gives at most \(\rho(t-a)+2^k\) admissible integers in \((a,t]\). Partial summation gives at most \(\rho\log(b/a)+2^k/a\) for the sum of reciprocals in \((a,b]\). Taking the minimum over \(k\) in each of the two bounds is valid.

The stronger version uses intervals \(a<e\le b\) and primes \(P<q\le\min(b,Z)\), with \(P=\max(101,\lfloor a^2 Z^h/Y\rfloor)\). The number \(j=\Omega(e)\) is confined by \((P+1)^j\le b,\ Z^j>a\). If \(S\ge\sum_q1/q\), the total reciprocal mass of all such \(j\)-prime products, with repeated factors allowed and ordering disregarded, is at most
\[
 h_j\le\frac1{j!}\prod_{i=0}^{j-1}(S+i/(P+1)).
\]
Indeed the log of its ordinary generating function is \(\sum_{t\ge1}\sum_q q^{-t}X^t/t\), coefficientwise bounded by the log of \((1-X/(P+1))^{-S(P+1)}\). For each \(j\), the count is bounded by \(\min\{\binom{\pi_*+j-1}j,bh_j\}\), where \(\pi_*\) bounds the number of eligible primes. The reciprocal sum is bounded by \(\min\{h_j,\binom{\pi_*+j-1}j/(a+1)\}\). Small primes use exact finite sieving; grouped large primes use the same explicit Dusart inequalities as smooth_tail.py.

## Conditioning on an earlier bad event

Let an earlier graph node have event \(P_z(N)>4g^2/z^s\), with integer logarithm threshold \(H\). Condition on \(e\mid N\) in an \(e\)-bucket up to \(B_e\). Write \(j=j_e+e j'\). Then \(N'=N/e\) has integral slope \(dp\) in \(j'\), and the new geometric interval has width at most \(L/e\). Since \(P_z(N)=P_z(e)P_z(N')\) and \(P_z(e)\le e\),
\[
 \log_2 P_z(N')>H-\lceil\log_2 B_e\rceil .
\]
Every fixed CRT weight involves only primes \(\le101\), and \(e\) is coprime to all of them. Passing from \(j\) to \(j'\) preserves its mean and expansion-norm bounds. The weighted Markov lemma only uses the upper weight 1 for local interactions with roots of the linear form and its invertible slope at primes dividing \(N'\), so its proof applies to this progression. For a nonpositive reduced threshold use the unconditional bound. After summing over an \(e\)-bucket, its harmonic mass multiplies the main term and its ordinary count multiplies the discrepancy. This produces certified directed prices both to and from the new fallback node without assuming event independence.

Run python -B work/fibre-lines/rough_trial.py for unconditional good-line costs; python -B work/fibre-lines/rough_graph.py for the combined graph; and python -B work/fibre-lines/rough_graph.py --selected for the stronger factor restrictions. These are research comparisons on the dominant first-window segment at \(u=0.47,0.49\). The project-facing smooth_wide hook remains unchanged.

For the optional tagged refinement, the constant \(2^b\) can itself be written \(2+\sum_{i=1}^{b-1}2^i\). To need its \(i\)-th increment, or the corresponding nonconstant small-divisor increment, the first \(i\) selected factors above \(Z\) must have product \(<Y\). Thus the largest prime factor of \(N\) is at most \(Q_i=\lfloor Y/Z^{i-1}\rfloor\). On any such line \(N'=N/e\) is \(Q_i\)-smooth. If \(|N|<VG^2/(16B)\), then necessarily \(dB>G/2\); otherwise both factors have magnitude at least \(G/2\) and the larger at least \(G\). Since \(N=djp-u^2\), the interval with this small \(|N|\) has width at most \(VG^2/(8Bdp)\le VG/(4p)\), one eighth of the original geometric width bound. On all remaining lines, \(P_{Q_i}(N')=|N'|\ge Vg^2/(16B B_e)\), which can be priced by the same explicit moments. The tagged refinement takes the smaller of the previous bound and these two upper estimates added together.
