"""Substitute a proved absolute prefix into a positive additive budget path."""
from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path

def main():
    p=ArgumentParser(description=__doc__);p.add_argument('--original',type=Path,required=True)
    p.add_argument('--improved',type=Path,required=True);p.add_argument('--budget',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True);p.add_argument('--check',action='store_true');a=p.parse_args()
    old,new=(t.read_text().split() for t in (a.original,a.improved))
    assert old[2]==new[2] and F(old[0])<=F(new[0])<F(new[1])<=F(old[1])
    assert F(old[-1])==F(new[-1])==26
    # Both directed absolute seed paths end at u=26 and include their reserve.
    saving=(int(old[3])-int(new[3]))//1000
    assert saving>=0
    lines=[]
    for line in a.budget.read_text().splitlines():
        l,h,r,*v=line.split()
        assert F(old[0])<=F(l)<F(h)<=F(old[1]) and r==old[2] and len(v)==4
        l,h=max(F(l),F(new[0])),min(F(h),F(new[1]))
        if l<h:lines.append(' '.join([str(l),str(h),r,*(str(int(t)-saving) for t in v)]))
    answer='\n'.join(lines)+'\n'
    if a.check:assert answer==a.out.read_text()
    else:a.out.write_text(answer,encoding='ascii')
    print('absolute prefix reduction',int(old[3])-int(new[3]),'directed budget improvement',saving,'child rows',len(lines),flush=True)

if __name__=='__main__':main()
