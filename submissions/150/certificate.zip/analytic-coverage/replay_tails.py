"""Regenerate the logarithmic convolution suffixes actually selected in a release."""
from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
from tempfile import TemporaryDirectory
import json,subprocess,sys
HERE=Path(__file__).resolve().parent
W=HERE.parent
def main():
    p=ArgumentParser(description=__doc__);p.add_argument('--release',type=Path,default=HERE/'release')
    p.add_argument('--repo',type=Path,default=W/'prime-sampling');p.add_argument('--match',default='')
    a=p.parse_args();release=a.release.resolve()
    original=json.loads((release/'input-paths.json').read_text())
    cells=[c for x in json.loads((release/'runs.json').read_text()) for c in json.loads((release/x['manifest']).read_text())['cells']]
    suffixes={}
    portfolio=W/'portable-fit'
    entries={k:(F(l),F(h),int(r)) for k,l,h,r in [line.split() for line in (portfolio/'cases.dat').read_text().splitlines()]}
    def add(table,origin,prefix=None):
        if not origin.name.startswith('log-budgets-'):return
        assert '-pooled-' not in origin.name
        first,last=[table.read_text().splitlines()[i].split() for i in (0,-1)]
        lo,hi,r=F(first[0]),F(last[1]),int(first[2])
        key=next(k for k,(l,h,rank) in entries.items() if l<=lo<hi<=h and rank==r)
        if prefix is None:
            n=origin.stem.removeprefix('log-budgets-')
            if n.startswith('local-'):
                row=next(v.split() for v in (HERE/'terminal-cases.dat').read_text().splitlines() if v.split()[0]==n.removeprefix('local-'))
                prefix=W/row[4]
            elif n.startswith('narrow-'):
                n=n.removeprefix('narrow-')
                prefix={'early':W/'narrow-prefix/left150/partial-prefix.dat','eighth2':W/'prefix-cap-audit/a-wide.dat',
                        'q2':W/'prefix-cap-audit/a-wide.dat','q3':portfolio/'aw150b.dat','q4':portfolio/'aw150b.dat',
                        'q6':portfolio/'aw151a.dat'}[n]
            else:
                assert n==key
                prefix=next(p for p in (portfolio/f'aw-strong{key}.dat',portfolio/f'aw{key}.dat') if p.is_file())
        suffixes[(table.name,lo,hi)]=(table,origin,key,lo,hi,prefix)
    for n in sorted({s for c in cells for s in c['budgets']}):
        table=W/n;origin=W/original[n]
        if 'prefix-log-' not in table.name:add(table,origin);continue
        receipt=json.loads(table.with_name('scalar-receipt.json').read_text())
        for row in receipt['cells']:
            for t,old,new in row[3:]:add(W/t,W/receipt['original'][t],W/old)
    assert suffixes
    for table,origin,key,l,h,pre in suffixes.values():
        if a.match not in origin.as_posix():continue
        subprocess.run([sys.executable,'-B',str(HERE/'terminal_atlas.py'),'--repo',str(a.repo.resolve()),
                        '--key',key,'--window',str(l),str(h),'--prefix',str(pre),'--out',str(table),'--check'],check=True)
        print('Verified tail',origin.name,l,h,flush=True)
if __name__=='__main__':main()
