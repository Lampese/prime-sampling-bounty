"""Uniform six-character completion on the full recursive product strip, with an optional partition of its input axis."""
from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
WORK=HERE.parent
GRAM=WORK/'gram-cycle'

def main():
    ap=ArgumentParser(add_help=False)
    ap.add_argument('--subgrid',type=int,default=3200);ap.add_argument('--fibre-pieces',type=int,default=4)
    a,rest=ap.parse_known_args()
    assert a.subgrid%200==0 and a.subgrid>=200 and 1<=a.fibre_pieces<=32
    sys.path[:0]=list(map(str,(GRAM,WORK/'operator-new',WORK/'trace-dilate')))
    from scaled_trace import factory
    from scaled_caps import ParentCaps
    canonical=WORK/'hyperbola-next/rectangles.py'
    src=canonical.read_text(encoding='utf8')
    start=src.index('    centered_tri.install(')
    stop=src.index("    branches=('with3',)",start)
    src=src[:start]+src[stop:]
    start=src.index('    @cache\n    def box(u,v,w,z):')
    stop=src.index('    @cache\n    def price(u,v,w,z):',start)
    src=src[:start]+"""    normalized=factory(m,args.left,args.right,axis_factors,False,True,fibre_pieces,True,True,True,parents,True,True)
    @cache
    def box(u,v,w,z):
        a,b=normalized(u,v,w,z)
        return m.upint(a),m.upint(b)

"""+src[stop:]
    src=src.replace('    def price(u,v,w,z):','    def unsplit(u,v,w,z):',1)
    marker='    def bounds(u,v,inside):'
    assert src.count(marker)==1
    src=src.replace(marker,"""    @cache
    def price(u,v,w,z):
        base=unsplit(u,v,w,z)
        if (v-u)*subgrid<=1:return base
        cuts=[u,*[F(k,subgrid) for k in range((u*subgrid).__floor__()+1,(v*subgrid).__ceil__())],v]
        split=tuple(map(sum,zip(*(unsplit(a,b,w,z) for a,b in zip(cuts,cuts[1:])))))
        return tuple(map(min,base,split))

"""+marker)
    files=[WORK/'wide-coverage'/f'{key}g3200{s}.json' for key in ('l150a','l150b','l151a','l151b') for s in ('q4','angular')]
    parents=ParentCaps([p for p in files if p.is_file()])
    env={'__name__':'__main__','__file__':str(canonical),'factory':factory,'subgrid':a.subgrid,'parents':parents,'fibre_pieces':a.fibre_pieces}
    sys.argv=[str(canonical),'--cheap','--local-axis','--abel',*rest]
    exec(compile(src,str(canonical),'exec'),env)
if __name__=='__main__':main()
