"""Publish the local archive only after a clean extraction has passed the complete bounty checker."""
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile
import json,os,subprocess,sys
HERE=Path(__file__).resolve().parent;W=HERE.parent
release=HERE/'release-bounty'
def main():
    runs=json.loads((release/'runs.json').read_text())
    assert len(runs)==1 and F(runs[0]['left'])==F(4801,32) and F(runs[0]['right'])==152
    output=W.parent/'outputs';out=output/'prime-sampling-150-bounty.zip'
    package=HERE/'bounty-audited-stage.zip';logpath=HERE/'bounty-audited-cold.txt'
    subprocess.run([sys.executable,'-B',str(HERE/'archive_cells.py'),str(release),'--out',str(package)],check=True)
    candidate=sha256(package.read_bytes()).hexdigest();temp_root=Path('D:/Temp') if os.name=='nt' else None
    with TemporaryDirectory(prefix='ps150-',dir=temp_root) as temp:
        with ZipFile(package) as z:
            bad=z.testzip()
            if bad is not None:raise ValueError(f'Corrupt member {bad}')
            z.extractall(temp)
        env=dict(os.environ,PYTHONUNBUFFERED='1',PYTHONIOENCODING='utf-8');env.pop('PYTHONOPTIMIZE',None)
        with logpath.open('wb',buffering=0) as log:
            subprocess.run([sys.executable,'-B',str(Path(temp)/'verify_all.py'),'--require-bounty'],cwd=temp,
                           env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
    text=logpath.read_text(encoding='utf-8')
    assert 'Closed cells verified: 186 minimum margin in 1e-12:' in text
    assert 'Threshold 150: strict positivity on the entire closed interval [150,651/4].' in text
    assert candidate==sha256(package.read_bytes()).hexdigest()
    header='Upstream commit 63a2d41e8124320784c244336ff36ac5f2285418\nArchive SHA256 '+candidate+'\n'
    report=output/'prime-sampling-150-bounty-verification.txt';stage=report.with_suffix('.pending')
    stage.write_text(header+text,encoding='utf-8');os.replace(package,out);os.replace(stage,report)
    print(text.splitlines()[-5:]);print(out,candidate,flush=True)
if __name__=='__main__':main()
