"""Regenerate one family of analytic macro bounds at the actual endpoints of a slab."""
from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
import json,os,subprocess,sys

HOME=Path(__file__).resolve().parent
WORK=HOME.parent
families={
    'front':('hyperbola-next/rectangles.py',['--trace-four','--local-axis','--abel','--mode','pair','--depth','4'],list(range(67,75))),
    'middle':('weighted-base/hyperbola.py',['--wide','--shape-bound','--mode','six'],list(range(75,84))),
    'scaled':('analytic-coverage/scaled_rectangles.py',['--depth','4','--mode','six','--subgrid','3200'],list(range(77,100))),
    'dilation':('dilations/macro.py',['--tuned','--triple','--energy','--wide','--shape-bound','--mode','six'],[78,80]),
    'reflection':('reflection/macro.py',['--profile','--tuned','--sharp','--wide','--shape-bound','--mode','six'],[82]),
    'abel':('hyperbola-next/rectangles.py',['--wide','--near-shape','--local-axis','--abel','--mode','six','--depth','4'],[77,79,81]),
    'upper':('operator-new/envelope_macro.py',['--angular','--local-conductor','--reweight','--mode','six'],list(range(83,95))),
    'phase_middle':('gram-cycle/recursive_phase.py',['--phase-slabs','4','--two-sections','--angular','--local-conductor','--reweight','--paley-four','--tetra-four','--mode','six','--bins','96'],list(range(83,100))),
    'phase_end':('gram-cycle/recursive_phase.py',['--phase-slabs','4','--angular','--local-conductor','--reweight','--paley-four','--tetra-four','--mode','six','--bins','96'],list(range(95,100))),
    'end':('operator-new/envelope_macro.py',['--angular','--local-conductor','--reweight','--paley-four','--tetra-four','--mode','six'],list(range(95,100))),
    'pair':('hyperbola-next/rectangles.py',['--trace-four','--local-axis','--abel','--mode','pair','--depth','2'],list(range(74,100))),
}


def main():
    ap=ArgumentParser(description=__doc__)
    ap.add_argument('--repo',type=Path,default=WORK/'prime-sampling')
    ap.add_argument('--window',nargs=2,required=True,type=F)
    ap.add_argument('--family',choices=families,required=True)
    ap.add_argument('--macros',type=int,nargs='+')
    ap.add_argument('--out',required=True,type=Path)
    ap.add_argument('--template',type=Path);ap.add_argument('--capture',type=Path)
    ap.add_argument('--check',action='store_true')
    args=ap.parse_args()
    l,h=args.window;assert 150<=l<h<=154 and h-l<=F(1,2)
    script,flags,default=families[args.family]
    macros=args.macros or default
    assert macros and all(67<=j<100 for j in macros)
    metadata={'left':str(l),'right':str(h),'family':args.family,'macros':macros}
    env=dict(os.environ);env.pop('PYTHONOPTIMIZE',None)
    if (WORK/'zig-cxx.cmd').is_file():
        env.setdefault('CXX',str(WORK/'zig-cxx.cmd'));env.setdefault('ZIG_GLOBAL_CACHE_DIR',str(WORK/'zig-cache'))
        env.setdefault('ZIG_LOCAL_CACHE_DIR',str(WORK/'zig-local-cache'))
    env['PRIME_TREE_DIR']=str(WORK/'harmonic-research/predecessor/certified-trees')
    if args.capture and args.template:raise ValueError('Choose one layout operation')
    if args.capture:env['PRIME_MACRO_CAPTURE']=str(args.capture.resolve())
    if args.template:
        from hashlib import sha256
        env['PRIME_MACRO_TEMPLATE']=str(args.template.resolve())
        metadata['template_sha256']=sha256(args.template.read_bytes()).hexdigest()
    if args.family!='scaled':env['PRIME_RECTANGLE_RATES']=str(args.out.resolve().with_suffix('.four.json'))
    env['PRIME_CERT_PROGRESS']=str(args.out.resolve().with_suffix('.partial.json'))
    env['PRIME_CERT_METADATA']=json.dumps(metadata)
    from tempfile import TemporaryDirectory
    with TemporaryDirectory(dir=args.out.resolve().parent) as temp:
        dest=Path(temp)/'priced.json'
        subprocess.run([sys.executable,'-B',str(WORK/script),'--repo',str(args.repo.resolve()),
                        '--left',str(l),'--right',str(h),*flags,'--macros',*map(str,macros),
                        '--out',str(dest)],check=True,env=env)
        vals=json.loads(dest.read_text())
    assert set(map(int,vals))==set(macros)
    final=dict(metadata,fees=vals)
    if args.check:assert final==json.loads(args.out.read_text())
    else:
        stage=args.out.with_suffix('.pending');stage.write_text(json.dumps(final,indent=2),encoding='ascii')
        stage.replace(args.out)


if __name__=='__main__':main()
