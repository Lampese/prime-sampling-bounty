"""Construct native prime-modulus slabs from a shared reciprocal-difference envelope."""
from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
import json,subprocess,sys

WORK=Path(__file__).resolve().parents[1]
HERE=WORK/'wide-coverage'
PROPOSALS=['--wide','--near-shape','--shared-shapes','--trapezoid','--frequency-envelope','--local-conductor','--reweight']


def run(source,*args):
    subprocess.run([sys.executable,'-B',str(source),*map(str,args)],check=True)


def main():
    ap=ArgumentParser(description=__doc__)
    ap.add_argument('--key',required=True);ap.add_argument('--parent',type=F,nargs=2,required=True)
    ap.add_argument('--component',choices=['q4','angular','base','cell'],required=True)
    ap.add_argument('--bounds',type=F,nargs='+',required=True);ap.add_argument('--labels',required=True)
    a=ap.parse_args();left,right=a.parent;seq=a.bounds
    assert a.key.isalnum() and all(c.isalpha() for c in a.labels)
    assert len(seq)==len(a.labels)+1 and len(set(a.labels))==len(a.labels)
    assert left<=seq[0]<seq[-1]<=right and all(x<y for x,y in zip(seq,seq[1:]))
    repo=WORK/'prime-sampling'
    tab=lambda k:HERE/f'{a.key}g3200{k}.json'
    stock=HERE/f'n{a.key}stock'/'budget.dat'
    if a.component in ('q4','angular'):
        suffix=a.component
        macros=range(67,92) if suffix=='q4' else range(92,100)
        groups=4 if suffix=='q4' else 16
        parent=tab(suffix);ready=False
        if parent.exists():
            prev=json.loads(parent.read_text())
            ready=(list(map(F,(prev['left'],prev['right'])))==[left,right]
                   and prev.get('ratio_caps') and prev.get('coupled_caps') and len(prev['envelopes'])==len(macros)*groups)
        if not ready:
            run(HERE/'caps_only.py','--repo',repo,'--left',left,'--right',right,'--grid',3200,
                '--groups',groups,'--wide','--ratio','--couple-scale',*(['--angular'] if suffix=='angular' else []),
                '--macro',*macros,'--out',parent)
        run(HERE/'parameter_layers.py','--repo',repo,'--key',a.key,'--component',suffix,'--bounds',*seq,'--labels',a.labels)
        return
    if a.component=='base':
        stock.parent.mkdir(parents=True,exist_ok=True)
        entries=json.loads((repo/'data/index.json').read_text())['budgets']
        allowed=[(l,h,r,*v) for _,l,h,r,v in entries if F(l)<=left<right<=F(h)]
        assert allowed
        stock.write_text(''.join(' '.join(map(str,w))+'\n' for w in allowed),encoding='ascii')
        run(HERE/'portfolio_cell.py','--repo',repo,'--base-grid',3200,'--window',left,right,
            '--stock',stock,'--out',HERE/f'c{a.key}base')
        return
    for tag,l,h in zip(a.labels,seq,seq[1:]):
        target=HERE/f'c{a.key}part{tag}'
        inputs=[]
        for suffix in ('q4','angular'):
            p=HERE/f'lhs{a.key}{tag}{suffix}.json'
            data=json.loads(p.read_text());assert list(map(F,(data['left'],data['right'])))==[l,h]
            inputs+=['--component',p,tab(suffix)]
        run(HERE/'portfolio_cell.py','--repo',repo,'--retarget',HERE/f'c{a.key}base','--window',l,h,
            *inputs,'--stock',stock,'--out',target)
        run(HERE/'portfolio_cell.py','--repo',repo,'--condition-geometry',target,'--out',HERE/f'c{a.key}part{tag}geom')


if __name__=='__main__':main()
