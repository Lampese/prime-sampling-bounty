"""Reprice all rectangles and all four truncations for each modulus branch on consecutive closed cells."""
from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
import json,sys
from score import score

HERE=Path(__file__).resolve().parent
WORK=HERE.parent
def run(repo,manifest):
    d=json.loads(manifest.read_text())
    cursor=F(d['left']);end=F(d['right'])
    assert F(150)<=cursor<end<=F(651,4)
    def sources(items):
        files=[(WORK/k).resolve() for k in items]
        if not all(p.is_file() and p.is_relative_to(WORK) for p in files):raise ValueError('Invalid local input path')
        return files
    margins=[]
    for w in d['cells']:
        l,h=F(w['left']),F(w['right']);assert cursor==l<h<=end
        data=score(repo,l,h,sources(w['reports']),sources(w['native']),sources(w['budgets']),w.get('tree',True),w.get('rectangle_mass',False),w.get('individual_mass',False))
        result={}
        for br,r in data.items():
            best=max(r['cutoffs'],key=lambda t:t['margin'] if t['margin'] is not None else -10**14)
            assert best['margin'] is not None and best['margin']>0,(l,h,br,best)
            result[br]=best;print(l,h,br,'d',str(best['cut'])+'/200','A',best['A'],'R',best['R'],'T',best['T'],'margin',best['margin'],flush=True)
        assert len(result)==2
        if w.get('expected'):assert result==w['expected']
        margins.append(min(z['margin'] for z in result.values()))
        cursor=h
    assert cursor==end and margins
    print('Continuously verified',d['left'],d['right'],'closed cells',len(margins),'minimum margin in 1e-12',min(margins),flush=True)

if __name__=='__main__':
    if not __debug__:raise RuntimeError('Use Python with assertions enabled')
    p=ArgumentParser(description=__doc__);p.add_argument('manifest',type=Path)
    p.add_argument('--repo',type=Path,default=WORK/'prime-sampling')
    a=p.parse_args();run(a.repo.resolve(),a.manifest)
