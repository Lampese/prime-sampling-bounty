"""Use every finished matched source to check consecutive rational slabs without interpolation."""
from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
import json,os,subprocess,sys
from score import score

HERE=Path(__file__).resolve().parent
WIDE=HERE.parent/'wide-coverage'


def cached_geometry(src,old,out):
    import shutil
    fresh=json.loads((src/'source.json').read_text())
    prior=json.loads((old/'source.json').read_text())
    keys=['left','right','geometry_window','mass_steps','local_geometry','grid']
    assert all(fresh.get(k)==prior.get(k) for k in keys) and prior['conditional_geometry']
    exact=json.loads((src/'cell.json').read_text())
    saved=json.loads((old/'cell.json').read_text())
    tablemap={(t['grid'],t['kind']):old/t['file'] for t in saved['tables']}
    out.mkdir(exist_ok=True)
    for t in exact['tables']:
        tab=[list(map(int,s.split())) for s in (src/t['file']).read_text().splitlines()]
        limits=tablemap[t['grid'],t['kind']].read_text().splitlines()
        for row,other in zip(tab,limits,strict=True):
            r=list(map(int,other.split()))
            assert row[0]==r[0] and len(row)==len(r)==9
            row[5:8]=map(min,zip(row[5:8],r[5:8]));row[8]=max(row[8],r[8])
            assert row[8]<=row[5]
        (out/t['file']).write_text(''.join(' '.join(map(str,r))+'\n' for r in tab),encoding='ascii')
    for name in exact.get('budgets',[]):shutil.copyfile(src/name,out/name)
    fresh['conditional_geometry']=True
    (out/'source.json').write_text(json.dumps(fresh,indent=2),encoding='ascii')
    shutil.copyfile(src/'cell.json',out/'cell.json')

def materialize(repo,key,tag,sources,condition):
    pair=[]
    for path,data in sources:
        suffix='angular' if path.stem.endswith('angular') else 'q4'
        parent=WIDE/f'{key}g3200{suffix}.json'
        info=json.loads(parent.read_text())
        assert info.get('caps_only') and not data.get('hypothetical')
        pair.append((path,parent))
    data=sources[0][1];left,right=map(F,(data['left'],data['right']))
    assert all((left,right)==tuple(map(F,(z['left'],z['right']))) for _,z in sources)
    label=''.join('a' if p.stem.endswith('angular') else 'q' for p,_ in pair)
    dest=WIDE/f'c{key}part{tag}{label}'
    opt=['--repo',str(repo),'--retarget',str(WIDE/f'c{key}base'),'--window',str(left),str(right)]
    for source,parent in pair:opt+=['--component',str(source),str(parent)]
    cmd=[sys.executable,'-B',str(WIDE/'portfolio_cell.py')]
    if not (dest/'cell.json').exists():
        subprocess.run([*cmd,*opt,'--stock',str(WIDE/f'n{key}stock'/'budget.dat'),'--out',str(dest)],check=True)
    if condition:
        geo=dest.with_name(dest.name+'geom')
        if not (geo/'cell.json').is_file():
            matching=next((p for p in sorted(WIDE.glob(f'c{key}part{tag}*geom')) if (p/'cell.json').is_file()),None)
            if matching:cached_geometry(dest,matching,geo)
            else:subprocess.run([*cmd,'--repo',str(repo),'--condition-geometry',str(dest),'--out',str(geo)],check=True)
        dest=geo
    return left,right,dest/'cell.json'


def main():
    ap=ArgumentParser(description=__doc__);ap.add_argument('--keys',nargs='+',required=True)
    ap.add_argument('--labels',default='abcde');ap.add_argument('--partial',action='store_true')
    ap.add_argument('--report-dir',type=Path,nargs='*',default=[]);ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--repo',type=Path,default=HERE.parent/'prime-sampling');ap.add_argument('--stock-bank',action='store_true')
    ap.add_argument('--spectra',type=Path,nargs='*',default=[])
    ap.add_argument('--rectangle-mass',action='store_true')
    ap.add_argument('--parent-mass',action='store_true',help='use parent rectangle mass bounds without conditioning them again')
    args=ap.parse_args();repo=args.repo.resolve();reports=[]
    from slab import families
    for d in args.report_dir:
        for path in sorted(d.glob('*.json')):
            data=json.loads(path.read_text())
            if isinstance(data,dict) and (data.get('family') in families or data.get('family')=='joint-diagonal') and data.get('fees'):reports.append(path)
    import hashlib
    frozen=[]
    for p in args.spectra:
        raw=p.read_bytes()
        data=json.loads(raw)
        assert data['native_geometry']=='all_contained_subwindows'
        folder=HERE/'spectrum-inputs'/hashlib.sha256(raw).hexdigest()
        folder.mkdir(parents=True,exist_ok=True);dest=folder/p.name
        if not dest.exists():dest.write_bytes(raw)
        frozen.append(dest)
    args.spectra=frozen
    budgets=HERE.parent/'portable-fit/clipped-through152.dat'
    budget_files=[budgets,*sorted(HERE.glob('log-budgets-*.dat')),*sorted((HERE.parent/'prefix-cap-audit').glob('c32-*.dat')),*sorted(HERE.glob('prefix-log-*.dat'))]
    by_rank=[s.split() for s in budgets.read_text().splitlines()]
    records=[]
    for key in args.keys:
        for tag in args.labels:
            src=[]
            for suffix,n in [('q4',400),('angular',128)]:
                path=WIDE/f'lhs{key}{tag}{suffix}.json'
                if not path.exists():continue
                try:data=json.loads(path.read_text())
                except json.JSONDecodeError:continue
                assert not data.get('hypothetical')
                if len(data['rows'])==n:src.append((path,data))
            if not src or (len(src)<2 and not args.partial):continue
            l,h,cell=materialize(repo,key,tag,src,not args.parent_mass)
            native=[cell]
            if args.spectra:
                from universal_cell import apply
                import hashlib
                sig=hashlib.sha256(b''.join(p.read_bytes() for p in args.spectra)).hexdigest()[:12]
                for extra in [cell,WIDE/f'c{key}base1600'/'cell.json']:
                    if not extra.is_file():continue
                    grids={t['grid'] for t in json.loads(extra.read_text())['tables']}
                    if not any(json.loads(p.read_text())['grid'] in grids for p in args.spectra):continue
                    dest=extra.parent.with_name(extra.parent.name+'scaled'+sig)
                    if not (dest/'cell.json').is_file():apply(extra,args.spectra,dest)
                    native.append(dest/'cell.json')
            cuts=sorted({l,h,*[pt for w in by_rank for pt in map(F,w[:2]) if l<pt<h]})
            for a,b in zip(cuts,cuts[1:]):
                r=score(repo,a,b,reports,native,budget_files,not args.stock_bank,args.rectangle_mass)
                best={br:max(d['cutoffs'],key=lambda x:x['margin'] if x['margin'] is not None else -10**18) for br,d in r.items()}
                record=dict(left=str(a),right=str(b),cells=[str(t.relative_to(HERE.parent)) for t in native],results=best,
                            macro_costs={k:v['macros'] for k,v in r.items()})
                records.append(record)
                print(str(a),str(b),*(f"{k} {x['margin']}" for k,x in best.items()),flush=True)
                stage=args.out.with_suffix('.pending')
                stage.write_text(json.dumps(records,indent=2),encoding='ascii');stage.replace(args.out)


if __name__=='__main__':main()
