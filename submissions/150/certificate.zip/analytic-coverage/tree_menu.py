"""Freeze and independently check all sparse sieve majorants on one modulus branch."""
from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
import os,sys
work=Path(__file__).resolve().parents[1];original=work/'harmonic-research/predecessor'
ap=ArgumentParser(description=__doc__);ap.add_argument('--right',type=F,required=True);ap.add_argument('--branch',required=True,choices=['with3','without3']);ap.add_argument('--repo',type=Path,default=work/'prime-sampling');a=ap.parse_args()
sys.path[:0]=[str(a.repo.resolve()),str(original)]
import tree_sieve_trial as t,tree_catalog as c
from prime_sampling.accounting import ledger
seq=ledger.rank(a.right,a.branch);folder=original/'certified-trees'
os.environ['PRIME_TREE_CAPTURE']=str(folder)
for k in (['pair','single','six'] if a.branch=='with3' else ['pair','single']):
    result=t.new_bank(seq,k)
    checked=c.load(folder/c.name(seq,k),seq,k,*t.original_bank(seq,k),t.exact,ledger.I)
    assert checked==result
    print(k,len(seq),'verified all',len(result[0]),'coordinate price rows',flush=True)
