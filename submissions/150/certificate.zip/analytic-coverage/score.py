"""Combine genuine rectangular or whole-macro inequalities at matched real endpoints."""
from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
import json,os,sys


from functools import cache


@cache
def strip_prices(path,grid,kind,seq,tree):
    from prime_sampling.accounting import ledger as v
    if not tree:return v.strip_costs(path,grid,kind,seq)
    from tree_sieve_trial import new_bank
    bank=v.bank
    try:
        v.bank=new_bank
        return v.strip_costs.__wrapped__(path,grid,kind,seq)
    finally:
        v.bank=bank


def score(repo,left,right,reports,natives,budgets,tree=True,extra_mass=False,individual_mass=False):
    work=Path(__file__).resolve().parents[1]
    sys.path.insert(0,str(repo.resolve()));sys.path.insert(0,str(work/'main-density-new'))
    sys.path.insert(0,str(work/'harmonic-research/predecessor'))
    import importlib.util
    spec=importlib.util.spec_from_file_location('slab_density_verifier',work/'main-density-new/verify.py')
    density=importlib.util.module_from_spec(spec);spec.loader.exec_module(density)
    window_bounds=density.window_bounds
    from prime_sampling.accounting import ledger as v
    os.environ.setdefault('PRIME_TREE_DIR',str(work/'harmonic-research/predecessor/certified-trees'))
    assert 150<=left<right<=175
    A=max(v.allowance(right),(v.J*window_bounds(left,right)[0]).__floor__())
    files=list(v.TABLES);geometries={}
    for path in natives:
        cell=json.loads(path.read_text());lo,hi=map(F,(cell['left'],cell['right']))
        if extra_mass:
            from rectangle_budget import geometry_window
            geom=geometry_window(path)
        for t in cell['tables']:
            if extra_mass:geometries[path.parent/t['file']]=geom
            files.append(('extra',t['kind'],lo,hi,t['grid'],path.parent/t['file']))
    priced=[json.loads(p.read_text()) for p in reports]
    rows=[]
    for p in budgets:
        for line in p.read_text().splitlines():
            a,b,r,*cost=line.split()
            assert len(cost)==4 and all(int(k)>=0 for k in cost)
            if F(a)<=left<right<=F(b):rows.append((int(r),list(map(int,cost))))
    result={}
    for branch in ('with3','without3'):
        seq=v.rank(right,branch)
        from math import prod
        g=prod(1-F(1,p) for p in seq)
        fees={};native_edges={}
        for _,kind,lo,hi,grid,path in files:
            if not lo<=left<right<=hi or (kind=='six' and branch!='with3'):continue
            vals=strip_prices(path,grid,kind,seq,tree)
            if path in geometries:
                from rectangle_budget import capped_prices
                ml,mh=(left,right) if individual_mass else (lo,hi)
                vals=capped_prices(path,grid,kind,seq,tree,repo,ml,mh,*geometries[path])
            for i,cost in enumerate(vals,67*grid//200):
                a,b=F(i,grid),F(i+1,grid)
                row=native_edges.setdefault(a,{})
                row[b]=min(cost,row.get(b,cost))
            for j in range(67,100):
                p=(j-67)*grid//200
                choice=sum(vals[p:p+grid//200]),path.name
                fees[j]=min(fees.get(j,choice),choice)
        for j in range(67,100):
            end=F(j+1,200);start=F(j,200);tail={end:0}
            for a in sorted((t for t in native_edges if start<=t<end),reverse=True):
                vals=[cost+tail[b] for b,cost in native_edges[a].items() if b in tail]
                if vals:tail[a]=min(vals)
            if start in tail and tail[start]<fees[j][0]:fees[j]=tail[start],'native microstrip path'
        for path,data in zip(reports,priced):
            if not F(data['left'])<=left<right<=F(data['right']):continue
            if v.rank(F(data['right']),branch)!=seq:continue
            for j,bybranch in data['fees'].items():
                k=int(j);assert 67<=k<100
                if branch in bybranch:
                    charge=bybranch[branch];assert type(charge)==int and charge>=0
                    choice=charge,path.name
                    fees[k]=min(fees.get(k,choice),choice)
        missing=set(range(67,100))-fees.keys()
        if missing:
            if (work/'zig-cxx.cmd').is_file():
                os.environ.setdefault('CXX',str(work/'zig-cxx.cmd'))
                os.environ.setdefault('ZIG_GLOBAL_CACHE_DIR',str(work/'zig-cache'))
                os.environ.setdefault('ZIG_LOCAL_CACHE_DIR',str(work/'zig-local-cache'))
            from prime_sampling.rectangles import boxes
            boxes.initialize(left,right)
            for j in missing:
                integral=sum(boxes.mass(F(j*8+i,1600),F(j*8+i+1,1600)) for i in range(8))
                fees[j]=((v.J*(1/g-1)*integral).__ceil__(),'trivial')
        eligible=[c for r,c in rows if r>=len(seq)]
        out=[]
        for cut in v.CUTS:
            T=sum(fees[j][0] for j in range(cut,100))
            R=min((v.J//10**9*c[cut-67] for c in eligible),default=None)
            margin=A-R-T if R is not None else None
            out.append(dict(cut=cut,A=A,T=T,R=R,allowable_R=A-T,margin=margin))
        result[branch]=dict(cutoffs=out,macros=fees)
    return result


def main():
    root=Path(__file__).resolve().parents[1];ap=ArgumentParser(description=__doc__)
    ap.add_argument('--repo',type=Path,default=root/'prime-sampling')
    ap.add_argument('--window',nargs=2,type=F,required=True)
    ap.add_argument('--reports',type=Path,nargs='*',default=[])
    ap.add_argument('--native',type=Path,nargs='*',default=[])
    ap.add_argument('--budgets',type=Path,nargs='*',default=[])
    ap.add_argument('--out',type=Path);ap.add_argument('--positive',action='store_true')
    ap.add_argument('--stock-bank',action='store_true',help='restrict the native rates to the upstream coordinate polynomials')
    ap.add_argument('--rectangle-mass',action='store_true')
    a=ap.parse_args();result=score(a.repo,*a.window,a.reports,a.native,a.budgets,not a.stock_bank,a.rectangle_mass)
    for branch,data in result.items():
        best=max(data['cutoffs'],key=lambda t:t['margin'] if t['margin'] is not None else t['allowable_R'])
        print(branch,best,flush=True)
        if a.positive:assert best['margin'] is not None and best['margin']>0
    if a.out:a.out.write_text(json.dumps(result,indent=2),encoding='ascii')


if __name__=='__main__':main()
