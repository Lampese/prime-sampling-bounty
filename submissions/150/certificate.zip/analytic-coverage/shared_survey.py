"""Assemble conditional and uniform rates on the same physical geometry, including partially priced families."""
from argparse import ArgumentParser
from fractions import Fraction as F
from functools import cache
from hashlib import sha256
from pathlib import Path
import json,sys
from join_ledger import gather,relative
from score import score

HERE=Path(__file__).resolve().parent
W=HERE.parent;WIDE=W/'wide-coverage'
sys.path[:0]=[str(WIDE),str(W/'spectral-coupling')]
from portfolio_cell import checked
from coset_split import close_six

@cache
def read(p):return json.loads(p.read_bytes())
def interval(d):return F(d['left']),F(d['right'])
def contains(dom,l,h):return dom[0]<=l<h<=dom[1]

def freeze(p):
    raw=p.read_bytes()
    json.loads(raw)
    d=HERE/'spectrum-inputs'/sha256(raw).hexdigest();d.mkdir(parents=True,exist_ok=True)
    f=d/p.name
    if not f.exists():f.write_bytes(raw)
    return f

def family(key,universal):
    bases=[WIDE/f'c{key}base'/'cell.json',WIDE/f'c{key}base1600'/'cell.json']
    base=read(bases[0]);gl,gh=interval(base)
    raw=[];geom=[]
    for tag in 'abcde':
        for suffix in ('q4','angular'):
            p=WIDE/f'lhs{key}{tag}{suffix}.json'
            if not p.exists():continue
            copy=freeze(p);a=read(copy)
            if not a['rows']:continue
            assert tuple(map(F,a['geometry_window']))==(gl,gh)
            parent=WIDE/f'{key}g3200{suffix}.json';checked(a,read(parent))
            raw.append(copy)
        for folder in WIDE.glob(f'c{key}part{tag}*geom'):
            if (folder/'cell.json').is_file():
                a=read(folder/'source.json')
                if a.get('conditional_geometry') and tuple(map(F,a['geometry_window']))==(gl,gh):
                    geom.append(folder/'cell.json')
    return bases,raw,geom,universal

def assemble(key,win,p,dirname):
    bases,components,saved,universal=p
    gl,gh=interval(read(bases[0]));left,right=win
    assert contains((gl,gh),left,right)
    raw=[p for p in components if contains(interval(read(p)),left,right)]
    condition=[p for p in saved if contains(interval(read(p)),left,right)]
    spectra=[p for p in universal if contains(interval(read(p)),left,right)
             and contains(tuple(map(F,read(p).get('geometry_window',interval(read(p))))),gl,gh)]
    used=[*bases,*raw,*condition,*spectra]
    keyhash=sha256(('|'.join(relative(p) for p in used)).encode()).hexdigest()[:16]
    dest=dirname/(key+keyhash);target=dest/'cell.json'
    if target.is_file():return target
    # Intersect all parameter windows, leaving the original rectangle endpoints common.
    lo=max([gl,*[interval(read(p))[0] for p in [*raw,*condition,*spectra]]])
    hi=min([gh,*[interval(read(p))[1] for p in [*raw,*condition,*spectra]]])
    assert lo<=left<right<=hi
    rows={}
    for p in [*bases,*condition]:
        for t in read(p)['tables']:
            g,k=t['grid'],t['kind'];tab=[]
            for line in (p.parent/t['file']).read_text().splitlines():
                if line[:1].isdigit():tab.append(list(map(int,line.split())))
            assert len(tab)==33*g//200
            if (g,k) not in rows:rows[g,k]=tab
            else:
                for x,y in zip(rows[g,k],tab,strict=True):
                    assert x[0]==y[0];x[1:8]=map(min,zip(x[1:8],y[1:8]));x[8]=max(x[8],y[8])
    for p in raw:
        d=read(p);g=d['grid']
        for i,pair,six in d['rows']:
            for k,sp in [('pair',pair),('six',six)]:
                row=rows[g,k][i-67*g//200];assert row[0]==i
                row[1:5]=map(min,zip(row[1:5],sp))
    for p in spectra:
        d=read(p);g=d['grid'];assert d['native_geometry']=='all_contained_subwindows'
        mode=d.get('mode','single');assert mode in ('single','six')
        for k in (['six'] if mode=='six' else ['pair','six']):
            if (g,k) not in rows:continue
            for i,y in d['rows'].items():
                i=int(i);x=rows[g,k][i-67*g//200];assert x[0]==i and len(y)==4 and all(type(v)==int and 0<=v<=10**10 for v in y)
                if mode=='single' and k=='six':
                    gi,qi,go,qo=y
                    y=(gi,(2*gi+qi+2)//3,go,(2*go+qo+2)//3)
                x[1:5]=map(min,zip(x[1:5],y))
    for g in {g for g,k in rows}:rows[g,'six']=[close_six(a,b) for a,b in zip(rows[g,'pair'],rows[g,'six'],strict=True)]
    tables=[];dest.mkdir(parents=True,exist_ok=True)
    for (g,k),tab in rows.items():
        f=dest/f'{k}-{g}.dat';f.write_text(''.join(' '.join(map(str,r))+'\n' for r in tab),encoding='ascii')
        tables.append(dict(kind=k,grid=g,file=f.name))
    record=dict(left=str(lo),right=str(hi),geometry_window=list(map(str,(gl,gh))),tables=tables)
    (dest/'source.json').write_text(json.dumps(dict(record,inputs=list(map(relative,used))),indent=1),encoding='ascii')
    target.write_text(json.dumps(record,indent=1),encoding='ascii');return target

def main():
    p=ArgumentParser(description=__doc__);p.add_argument('--keys',nargs='+',default=['l150a','l150b','l151a','l151b'])
    p.add_argument('--out',required=True,type=Path);p.add_argument('--rectangles',action='store_true')
    p.add_argument('--repo',type=Path,default=W/'prime-sampling');a=p.parse_args()
    reports,budgets=gather()
    names=['scaled-native-150-153.json','scaled-six-150-153.json','scaled-six-150-153-g1600.json',
           'scaled-six-strong-150-153-g1600.json','scaled-six-strong-150-153-g3200.json',
           'scaled-150a-parent-g3200.json','scaled-150-151-parent-g3200.json','scaled-150firsteighth-g3200.json',
           'scaled-150a-shape-g3200.json','scaled-150a-trap-g3200.json','scaled-150a-reflected-g3200.json',
           'scaled-150b-trap-g3200.json','scaled-151-152-trap-g3200.json']
    universal=[freeze(f) for n in names if (f:=W/'gram-cycle'/n).is_file()]
    cuts=set()
    for b in budgets:
        for s in b.read_text().splitlines():cuts.update(map(F,s.split()[:2]))
    cells=[];repo=a.repo.resolve()
    for k in a.keys:
        data=family(k,universal);lo,hi=interval(read(data[0][0]))
        cuts2=sorted({lo,hi,*[v for v in cuts if lo<v<hi],*[v for p in data[1] for v in interval(read(p)) if lo<v<hi]})
        for l,h in zip(cuts2,cuts2[1:]):
            inputs=assemble(k,(l,h),data,HERE/'shared-tables')
            valid=[p for p,d in reports.items() if contains(interval(d),l,h)]
            result=score(repo,l,h,valid,[inputs],budgets,True,a.rectangles)
            best={br:max(row['cutoffs'],key=lambda w:w['margin']) for br,row in result.items()}
            record=dict(left=str(l),right=str(h),cells=[relative(inputs)],reports=list(map(relative,valid)),budgets=list(map(relative,budgets)),
                        rectangle_mass=a.rectangles,results=best,macro_costs={k:w['macros'] for k,w in result.items()})
            cells.append(record);stage=a.out.with_suffix('.pending')
            stage.write_text(json.dumps(cells,indent=1),encoding='ascii');stage.replace(a.out)
            print(l,h,*(w['margin'] for w in best.values()),flush=True)
if __name__=='__main__':main()
