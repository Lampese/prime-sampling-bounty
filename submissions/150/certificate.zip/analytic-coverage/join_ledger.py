"""Join certified per-macro prices on contained rational cells, then replay from the contributing tables."""
from argparse import ArgumentParser
from fractions import Fraction as F
from functools import cache
from pathlib import Path
import json,sys
HERE=Path(__file__).resolve().parent
WORK=HERE.parent
@cache
def relative(path):return path.resolve().relative_to(WORK).as_posix()
def load_inputs(paths):return ((p,json.loads(p.read_text())) for p in sorted(set(paths)))
def gather():
    from slab import families
    directories=[HERE/n for n in ('150a','150-near','strips','diagonal','152a','mask-reports','book-reports')]
    reports={}
    for d in directories:
        for p,r in load_inputs(d.glob('*.json')):
            if isinstance(r,dict) and r.get('family') in {*families,'joint-diagonal','soft-mask','rectangle-book'} and 'fees' in r and r.get('method')!='local_model':reports[p]=r
    for p,r in load_inputs((WORK/'gram-cycle').glob('convex-*.json')):
        if r.get('family')=='rectangle-native-convex':reports[p]=r
    budget=[WORK/'portable-fit/clipped-through152.dat',*sorted((WORK/'prefix-cap-audit').glob('c32-*.dat')),
            *sorted(f for f in HERE.glob('log-budgets-*.dat') if '-pooled-' not in f.name),*sorted(HERE.glob('prefix-log-*.dat')),
            *sorted((WORK/'narrow-prefix').glob('*/budget*.dat'))]
    return reports,budget
def candidates(paths):
    refs=[]
    for p,survey in load_inputs(paths):
        assert isinstance(survey,list)
        for row in survey:refs.append((p,row,F(row['left']),F(row['right'])))
    return refs
def inventory(repo,inputs,left,right):
    sys.path.insert(0,str(repo));from prime_sampling.accounting import ledger as ledger
    reports,budget=gather()
    population=[(p,F(w[0]),F(w[1]),int(w[2]),list(map(int,w[3:]))) for p in budget
                for line in p.read_text().splitlines() for w in [line.split()]]
    src=candidates(inputs)
    edges={left,right,*[x for _,_,a,b in src for x in (a,b) if left<x<right],
           *[x for _,a,b,_,_ in population for x in (a,b) if left<x<right]}
    for v in reports.values():edges.update(t for t in map(F,(v['left'],v['right'])) if left<t<right)
    cuts=sorted(edges);records=[]
    for l,h in zip(cuts,cuts[1:]):
        baseline=[x for x in src if x[2]<=l<h<=x[3]]
        if not baseline:continue
        A=max(r['results']['with3']['A'] for _,r,_,_ in baseline)
        record={'left':str(l),'right':str(h),'A':A,'branches':{}}
        for br in ('with3','without3'):
            seq=ledger.rank(h,br);rows=[t for t in population if t[1]<=l<h<=t[2] and t[3]>=len(seq)]
            fees={}
            def insert(j,amount,path,source):
                old=fees.get(j);cand=amount,relative(path),source
                if old is None or cand<old:fees[j]=cand
            for p,r,a,b in baseline:
                if ledger.rank(b,br)!=seq:continue
                for j,(amount,s) in r['macro_costs'][br].items():insert(int(j),amount,p,s)
            for p,data in reports.items():
                if not F(data['left'])<=l<h<=F(data['right']) or ledger.rank(F(data['right']),br)!=seq:continue
                for j,by in data['fees'].items():
                    if br in by:insert(int(j),by[br],p,'report')
            if set(fees)!=set(range(67,100)) or not rows:continue
            margins=[]
            for j in ledger.CUTS:
                R,best=min((t[4][j-67]*1000,relative(t[0])) for t in rows)
                T=sum(fees[t][0] for t in range(j,100))
                margins.append((A-R-T,j,R,T,best))
            margin,j,R,T,src_R=max(margins)
            record['branches'][br]=dict(margin=margin,cut=j,T=T,R=R,budget=src_R,macros=fees)
        records.append(record)
    return records

def main():
    p=ArgumentParser(description=__doc__);p.add_argument('--repo',type=Path,default=WORK/'prime-sampling')
    p.add_argument('--window',nargs=2,type=F,default=[F(4801,32),F(152)])
    p.add_argument('--survey',nargs='+',type=Path,required=True);p.add_argument('--out',required=True,type=Path)
    a=p.parse_args();records=inventory(a.repo.resolve(),a.survey,*a.window)
    text=json.dumps(records,indent=1)
    stage=a.out.with_suffix('.pending');stage.write_text(text,encoding='ascii');stage.replace(a.out)
    valid=0
    for w in records:
        m=[w['branches'][b]['margin'] for b in w['branches']]
        valid+=len(m)==2 and min(m)>0
        print(w['left'],w['right'],*m)
    print('closed cells with both margins positive',valid,'of',len(records))
if __name__=='__main__':main()
