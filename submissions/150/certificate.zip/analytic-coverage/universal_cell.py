"""Intersect four spectral columns on a certified native rectangle family with a uniform scale inequality."""
from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import json,sys

WORK=Path(__file__).resolve().parents[1]


def apply(cell,spectra,out):
    src=cell.parent;record=json.loads(cell.read_text())
    geom=record.get('geometry_window',[record['left'],record['right']])
    for name in ('source.json','universal.json'):
        metadata=src/name
        if metadata.is_file():
            desc=json.loads(metadata.read_text())
            if desc.get('geometry_window'):
                geom=desc['geometry_window']
                break
    lo,hi=map(F,geom);l,h=map(F,(record['left'],record['right']))
    assert lo<=l<h<=hi and src.resolve()!=out.resolve()
    out.mkdir(parents=True,exist_ok=True)
    files={};chosen=[]
    for t in record['tables']:
        path=src/t['file']
        arr=[list(map(int,s.split())) for s in path.read_text().splitlines() if s and s[0].isdigit()]
        assert all(len(row)==9 for row in arr)
        files[t['grid'],t['kind']]=arr
    for path in spectra:
        raw=path.read_bytes();data=json.loads(raw)
        assert data['native_geometry']=='all_contained_subwindows' and data.get('mode','single') in ('six','single')
        sl,sh=map(F,(data['left'],data['right']))
        gl,gh=map(F,data.get('geometry_window',(sl,sh)))
        if not(sl<=l<h<=sh and gl<=lo<hi<=gh):continue
        g=data['grid'];cost=data['rows']
        if not any(grid==g for grid,kind in files):continue
        for (grid,kind),rows in files.items():
            if grid!=g or (data.get('mode','single')=='six' and kind!='six'):continue
            for r in rows:
                col=cost.get(str(r[0]))
                if col is None:continue
                assert len(col)==4 and all(type(x)==int and 0<=x<=10**10 for x in col)
                if kind=='six' and data.get('mode','single')=='single':
                    gi,qi,go,qo=col
                    col=(gi,(2*gi+qi+2)//3,go,(2*go+qo+2)//3)
                r[1:5]=map(min,zip(r[1:5],col))
        chosen.append(dict(file=path.name,sha256=sha256(raw).hexdigest()))
    assert chosen
    sys.path.insert(0,str(WORK/'spectral-coupling'))
    from coset_split import close_six
    for g in {grid for grid,kind in files}:
        if (g,'pair') in files and (g,'six') in files:
            files[g,'six']=[close_six(p,s) for p,s in zip(files[g,'pair'],files[g,'six'],strict=True)]
    tables=[]
    for (g,kind),rows in files.items():
        dest=out/f'{kind}-{g}.dat'
        dest.write_text(''.join(' '.join(map(str,r))+'\n' for r in rows),encoding='ascii')
        tables.append(dict(kind=kind,grid=g,file=dest.name))
    result={k:record[k] for k in ('left','right','main_lower')};result.update(tables=tables)
    (out/'cell.json').write_text(json.dumps(result,indent=2),encoding='ascii')
    (out/'universal.json').write_text(json.dumps(dict(geometry_window=geom,source=src.name,inputs=chosen),indent=2),encoding='ascii')
    return out/'cell.json'


if __name__=='__main__':
    ap=ArgumentParser(description=__doc__);ap.add_argument('--cell',type=Path,required=True)
    ap.add_argument('--sources',type=Path,nargs='+',required=True);ap.add_argument('--out',type=Path,required=True)
    a=ap.parse_args();apply(a.cell,a.sources,a.out)
