"""Regenerate selected macro prices and merge the frozen component spectra independently."""
from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
from tempfile import TemporaryDirectory
import json,subprocess,sys
HERE=Path(__file__).resolve().parent
WORK=HERE.parent
def load(p):return json.loads(p.read_bytes())
def run(file,*flags):subprocess.run([sys.executable,'-B',str(file),*map(str,flags)],check=True)
def main():
    p=ArgumentParser(description=__doc__)
    p.add_argument('--release',type=Path,default=HERE/'release')
    p.add_argument('--repo',type=Path,default=WORK/'prime-sampling')
    p.add_argument('--step',choices=['merges','spectra','macros'],required=True)
    p.add_argument('--match',default='');a=p.parse_args();repo=a.repo.resolve()
    cells=[c for r in load(a.release/'runs.json') for c in load(a.release/r['manifest'])['cells']]
    reports=sorted({WORK/n for c in cells for n in c['reports']})
    natives={WORK/n for c in cells for n in c['native']}
    for f in reports:
        d=load(f)
        if d['family']=='soft-mask':natives.add(WORK/d['cell'])
    trees={sha256(p.read_bytes()).hexdigest():p for p in [*HERE.glob('150-near/*-tree.json'),*HERE.glob('150a/*-plan.json')]}
    def slab(d,target):
        cmd=['--repo',repo,'--family',d['family'],'--window',d['left'],d['right'],'--macros',*d['macros'],'--out',target]
        if d.get('template_sha256'):cmd+=['--template',trees[d['template_sha256']]]
        run(HERE/'slab.py',*cmd)
    if a.step=='macros':
        for f in reports:
            if a.match not in f.name:continue
            d=load(f);family=d['family']
            if family=='rectangle-native-convex':
                run(WORK/'gram-cycle/rectangle_fees.py','--repo',repo,'--check',f)
                continue
            flags=['--repo',repo,'--window',d['left'],d['right'],'--macros',*d['macros']]
            with TemporaryDirectory() as tmp:
                target=Path(tmp)/'proof.json'
                if family=='rectangle-book':
                    for n in d['inputs']:
                        source=load(WORK/n);slab(source['source'],target)
                        rows={tuple(r) for r in load(target.with_suffix('.four.json'))['rows']}
                        assert all(tuple(r) in rows for r in source['rows'])
                    cmd=['--files',*[WORK/n for n in d['inputs']],'--mode',d['mode'],'--phase-parts',d['phase_parts']]
                    if d.get('tree'):cmd+=['--tree',HERE/'150-near'/d['tree']]
                    run(HERE/'book_macro.py',*flags,*cmd,'--out',target)
                elif family=='soft-mask':
                    run(HERE/'soft_macro.py',*flags,'--cell',WORK/d['cell'],'--parts',d['parts'],'--out',target)
                elif family=='joint-diagonal':
                    assert load(HERE/'diagonal'/f.name)==d
                    run(HERE/'diagonal/verify.py','--repo',repo,'--case',f.name.split('-fee')[0])
                    continue
                else:slab(d,target)
                assert load(target)==d,f
            print('Regenerated macro proof',f.name,flush=True)
        return
    from shared_survey import assemble,checked
    from portfolio_cell import FLAGS
    done=set()
    for f in sorted(natives):
        d=load(f.parent/'source.json');sources=[WORK/n for n in d['inputs']]
        bases=sources[:2];key=bases[0].parent.name[1:-4]
        condition=[p for p in sources[2:] if p.name=='cell.json']
        raw=[p for p in sources[2:] if p.name.startswith('lhs')]
        uniform=[p for p in sources[2:] if p not in raw and p not in condition]
        assert [*bases,*raw,*condition,*uniform]==sources
        if a.step=='merges':
            for p in raw:
                method='angular' if 'angular' in p.name else 'q4'
                checked(load(p),load(WORK/'wide-coverage'/f'{key}g3200{method}.json'))
            with TemporaryDirectory() as tmp:
                out=assemble(key,tuple(map(F,(d['left'],d['right']))),(bases,raw,condition,uniform),Path(tmp))
                assert load(out)==load(f) and load(out.parent/'source.json')==d
                for t in load(f)['tables']:assert (f.parent/t['file']).read_text()==(out.parent/t['file']).read_text()
            print('Verified both grids and geometry domains',f.parent.name,flush=True)
            continue
        for p in sources:
            if p in done or a.match not in p.as_posix():continue
            done.add(p)
            if p in bases+condition:
                run(WORK/'wide-coverage/portfolio_cell.py','--repo',repo,'--replay',p.parent)
            elif p in uniform:run(WORK/'gram-cycle/replay_scaled.py',p,'--repo',repo)
            else:
                info=load(p);method='angular' if 'angular' in p.name else 'q4'
                cap=WORK/'wide-coverage'/f'{key}g3200{method}.json'
                groups=checked(info,load(cap));flags=['--'+k.replace('_','-') for k in FLAGS if info.get(k)]
                macros=sorted({i*200//info['grid'] for i,_,_ in info['rows']})
                with TemporaryDirectory() as tmp:
                    out=Path(tmp)/p.name
                    run(WORK/'hyperbola-next/smooth_rows.py','--repo',repo,'--left',info['left'],'--right',info['right'],
                        '--geometry-window',*info['geometry_window'],'--groups',groups,'--grid',info['grid'],
                        '--caps',cap,'--macro',*macros,*flags,'--out',out)
                    rebuilt=load(out)
                    for field in ('rows','envelopes'):assert sorted(rebuilt[field])==sorted(info[field])
if __name__=='__main__':main()
