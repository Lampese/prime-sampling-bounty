"""A logarithmically weighted prime-factor convolution for all rough cofactors in a multiplicative interval."""
from bisect import bisect_left,bisect_right
from fractions import Fraction as F
from functools import cache
from itertools import accumulate
from math import factorial

UNIT=10**22
EXP_UNIT=10**75


def power_coefficients(weights,degree,limit):
    """Kronecker substitution with enough room for the sum of all positive coefficients."""
    if degree==0:return [1]
    total=sum(weights)
    block=max(1,((total**degree).bit_length()+7)//8)
    radix=1<<(8*block)
    assert total**degree<radix
    packed=int.from_bytes(b''.join(w.to_bytes(block,'little') for w in weights),'little')
    poly=packed**degree
    count=min(degree*(len(weights)-1),limit)+1
    buf=(poly%(radix**count)).to_bytes(block*count,'little')
    return [int.from_bytes(buf[i:i+block],'little') for i in range(0,len(buf),block)]


def model(core):
    s=core.s
    @cache
    def reciprocal(t,step):
        old=core.harmonic(t,step)
        if t>=8 and t+step<=F(4374,100):
            # Buethe's x - theta(x) bracket extends to 10^19.  exp(43.74)<10^19.
            assert s.eu(t+step)<=10**19
            val=s.lu(1+step/t)+F(195,100)*s.eu(-t/2)/t+s.eu(-t)
            return min(old,val)
        return old
    @cache
    def density(a,L,H,step=F(1,16),bins=32):
        assert 25<=a and L<=H<5*a and 0<s.LAM<1 and L+s.ld(s.LAM)>1
        degree=(H/a).__floor__()
        eta=s.eta_for(a,F(1))
        edge=H*s.eu(-a)
        nodes=[s.LAM+(1-s.LAM)*i/bins for i in range(bins+1)]
        log_low=[s.ld(c) for c in nodes]
        # All nonsquarefree products, including equal prime factors in different slots.
        first=s.trans(a,'exp',False).__ceil__()
        value=F(1,first-1)
        max_i=max(0,((H-2*a)/step).__floor__())
        weights=[(UNIT*reciprocal(a+i*step,step)).__ceil__() for i in range(max_i+1)]
        advance=(EXP_UNIT*s.trans(step,'exp',False)).__floor__()
        for length in range(1,degree+1):
            r=length-1
            limit=((H-length*a)/step).__floor__()
            w=power_coefficients(weights,r,limit)
            thresholds=[(EXP_UNIT*s.trans(length*a-H,'exp',False)).__floor__()]
            for _ in range(1,len(w)):
                thresholds.append(thresholds[-1]*advance//EXP_UNIT)
            totals=[0,*accumulate(w)]
            offsets=[0,*accumulate(x*y for x,y in zip(w,thresholds))]
            norm=factorial(r)*UNIT**r
            for i,(c,d) in enumerate(zip(nodes,nodes[1:])):
                # Widen the endpoint for any lattice equality at exp(a).
                n=bisect_right(thresholds,d*EXP_UNIT)
                m=bisect_left(thresholds,c*EXP_UNIT,0,n)
                coverage=(d-c)*totals[m]+d*(totals[n]-totals[m])-F(offsets[n]-offsets[m],EXP_UNIT)
                W=coverage+(2*eta*d+edge)*totals[n]
                assert W>=0
                value+=W/(norm*(L+log_low[i]))
        return s.up(value)
    return reciprocal,density


def check():
    from itertools import product
    for w in ([1,0,2],[5,7],[8]):
        for d in (0,1,2,3,4):
            expected=[0]*(d*(len(w)-1)+1)
            for ix in product(range(len(w)),repeat=d):
                from math import prod
                expected[sum(ix)]+=prod(w[j] for j in ix)
            assert power_coefficients(w,d,len(expected))==expected
    print('All positive convolution identities reproduced.')


if __name__=='__main__':check()
