"""Upper masses for the actual pair of enclosing and enclosed rectangles, in units of 1e-12."""
from fractions import Fraction as F
from functools import cache
from pathlib import Path
from tempfile import NamedTemporaryFile
import json,sys

HERE=Path(__file__).resolve().parent

def geometry_window(cell):
    data=json.loads(cell.read_text())
    for name in ('source.json','universal.json'):
        src=cell.parent/name
        if src.exists():
            a=json.loads(src.read_text())
            if a.get('geometry_window'):return tuple(map(F,a['geometry_window']))
    return tuple(map(F,data.get('geometry_window',(data['left'],data['right']))))

@cache
def rectangle_caps(repo,left,right,gl,gh,grid,parts=4):
    assert gl<=left<right<=gh and 1<=parts<=32 and grid>=600 and grid%200==0
    key=('_'.join(map(str,(left,right,gl,gh,grid,parts)))).replace('/','x')
    folder=HERE/'geometry-limits';folder.mkdir(exist_ok=True)
    dest=folder/(key+'.json')
    if dest.exists():
        data=json.loads(dest.read_text())
        assert len(data)==33*grid//200
        return data
    sys.path.insert(0,str(HERE.parent/'mass-geometry'))
    from refine import setup
    z,_=setup(repo,gl,gh)
    fixed=[]
    for i in range(67*grid//200,grid//2):
        u,v=F(i,grid),F(i+1,grid)
        fixed.append((*z.inner(u,v),max(z.LAM*z.Xlo(u-v),z.Xlo(2*u-1))))
    z,_=setup(repo,left,right)
    rows=[]
    for i,(C,E,O) in enumerate(fixed,67*grid//200):
        u,v=F(i,grid),F(i+1,grid)
        eps=z.thetaerr(min(u*z.zl,(1-u)*z.zl+z.b(O,'ln',False)))
        unit=(v-u)/parts
        H=sum(2*z.Xhi(k*unit)*((1+eps)*(z.Xhi(unit)-1)*(1/(u+k*unit)+1/(u+(k+1)*unit))/2
                    +2*eps/(u+k*unit)) for k in range(parts))
        def vertical(c,d):
            if c>=d:return 0
            # 1/log(y) is convex on the entire positive logarithmic range.
            loglo=lambda x:(1-u)*z.zl+z.b(x,'ln',False)
            w=(d-c)/parts
            return sum((1+eps)*w*(1/loglo(c+j*w)+1/loglo(c+(j+1)*w))/2+
                       2*eps*(c+j*w)/loglo(c+j*w) for j in range(parts))
        rows.append([(10**12*H*vertical(c,d)).__ceil__() for c,d in ((C,E),(O,F(1)))])
    with NamedTemporaryFile('w',dir=folder,delete=False,encoding='ascii') as f:
        json.dump(rows,f,separators=(',',':'));stage=Path(f.name)
    stage.replace(dest)
    return rows

@cache
def capped_prices(path,grid,kind,seq,tree,repo,left,right,gl,gh):
    from prime_sampling.accounting import ledger as v
    from score import strip_prices
    sys.path.insert(0,str(HERE.parent/'mass-geometry'))
    from joint_bounds import upper_fee
    raw=strip_prices(path,grid,kind,seq,tree)
    if kind=='single':return raw
    from tree_sieve_trial import new_bank
    bank,scale=(new_bank if tree else v.bank)(seq,kind)
    @cache
    def excluded(g,q):
        return max(0,max(m-v.ceil(n*g+k*q,v.I) for m,n,k in bank))
    mass=rectangle_caps(repo,left,right,gl,gh,grid)
    answer=[]
    for r,old,caps in zip(v.check_rows(path,grid),raw,mass,strict=True):
        fee=upper_fee(v.I,v.J,scale,excluded(*r[:2]),excluded(*r[2:4]),r[4:],caps)
        answer.append(min(old,fee))
    return answer
