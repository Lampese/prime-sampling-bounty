"""Connect every completed local physical support path to each applicable independently priced terminal path."""
from fractions import Fraction as F
from pathlib import Path
import subprocess,sys,json
HERE=Path(__file__).resolve().parent;WORK=HERE.parent
repo=WORK/'prime-sampling';narrow=WORK/'narrow-prefix';portable=WORK/'portable-fit'
def main():
    ready='--ready' in sys.argv[1:]
    assert all(s=='--ready' for s in sys.argv[1:])
    base={}
    for line in (portable/'cases.dat').read_text().splitlines():
        key,l,h,r=line.split()
        p=portable/f'aw-strong{key}.dat'
        if not p.exists():p=portable/f'aw{key}.dat'
        t=HERE/f'log-budgets-{key}.dat'
        if t.exists():base[t]=p
    for key,pre in [('early',narrow/'left150/partial-prefix.dat'),('eighth2',WORK/'prefix-cap-audit/a-wide.dat'),
                    ('q2',WORK/'prefix-cap-audit/a-wide.dat'),('q3',portable/'aw150b.dat'),('q4',portable/'aw150b.dat'),('q6',portable/'aw151a.dat')]:
        t=HERE/f'log-budgets-narrow-{key}.dat'
        if t.exists():base[t]=pre
    for line in (HERE/"terminal-cases.dat").read_text().splitlines():
        name,case,left,right,source=line.split()
        f=HERE/f"log-budgets-local-{name}.dat"
        if f.is_file():base[f]=WORK/source
    new=[]
    for line in (narrow/'cases.dat').read_text().splitlines():
        key,l,h,r=line.split();folder=narrow/key
        extra=folder/'extra.dat';seed=folder/'seed.txt'
        if not extra.exists() or not seed.exists():continue
        if len(extra.read_text().splitlines())!=8 or 'seed <=' not in seed.read_text():continue
        if ready:
            if not (folder/'prefix.dat').is_file():continue
        else:
            subprocess.run([sys.executable,'-I','-B',str(narrow/'build.py'),key,'--repo',str(repo),'--step','join'],check=True,stdout=subprocess.DEVNULL)
        new.append(folder/'prefix.dat')
        improved=folder/'prefix-fine.dat'
        if improved.is_file():
            a,b,rank,*_=improved.read_text().split()
            assert (F(a),F(b),int(rank))==(F(l),F(h),int(r))
            new.append(improved)
    values={}
    for t,p in base.items():
        old=p.read_text().split();rows=[s.split() for s in t.read_text().splitlines()]
        for n in new:
            a,b,r,P,*path=n.read_text().split()
            if r!=old[2] or int(P)>=int(old[3]):continue
            assert path[-1]==old[-1]=='26'
            saving=(int(old[3])-int(P))//1000
            for x,y,rt,*cost in rows:
                assert rt==old[2] and F(old[0])<=F(x)<F(y)<=F(old[1])
                left,right=max(F(x),F(a)),min(F(y),F(b))
                if left>=right:continue
                price=tuple(int(z)-saving for z in cost);k=left,right,r
                if k not in values:values[k]=[(None,None)]*4
                for j,z in enumerate(price):
                    oldprice=values[k][j][0]
                    if oldprice is None or z<oldprice:
                        values[k][j]=z,[str(s.relative_to(WORK).as_posix()) for s in (t,p,n)]
    lines=[];recipes=[]
    for key in sorted(values):
        row=values[key];lines.append(' '.join(map(str,[*key,*[z for z,_ in row]])))
        recipes.append([*map(str,key),*[s for _,s in row]])
    assert lines
    name_data='prefix-log-ready.dat' if ready else 'prefix-log-atlas.dat'
    name_map='prefix-ready-sources.json' if ready else 'prefix-atlas-sources.json'
    for name,content in [(name_data,'\n'.join(lines)+'\n'),(name_map,json.dumps(recipes,indent=1))]:
        f=HERE/name;stage=f.with_suffix('.pending');stage.write_text(content,encoding='ascii');stage.replace(f)
        if name==name_data:
            from scalar_receipts import record
            record(f,recipes)
    print('Completed physical prefixes',len(new),'closed cells',len(lines),flush=True)
if __name__=='__main__':main()
