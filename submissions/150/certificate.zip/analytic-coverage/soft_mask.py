"""Optimize column deletions and two row sections, charging the true target points they touch."""
from fractions import Fraction as F
from functools import cache
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
W=HERE.parent
def geometry(z,grid,index,O,parts=8):
    u=F(index,grid);v=F(index+1,grid);half=(1+O)/2
    eps=z.thetaerr(min(u*z.zl,(1-u)*z.zl+z.b(O,'ln',False)))
    x=[u+(v-u)*j/parts for j in range(parts+1)]
    Z=(1-u)*z.zl;H=(1-u)*z.zh
    @cache
    def axes(i,j):
        a,b=x[i],x[j]
        upper=2*z.Xhi(a-u)*((1+eps)*z.Xhi(b-a)-(1-eps))/a
        lower=2*z.Xlo(a-u)*max(0,(1-eps)*z.Xlo(b-a)-(1+eps))/b
        return lower,upper
    @cache
    def vertical(c,d):
        if c>=d:return 0,0
        low=max(0,(1-eps)*d-(1+eps)*c)/(H+z.b(d,'ln',True))
        high=((1+eps)*d-(1-eps)*c)/(Z+z.b(c,'ln',False))
        return low,high
    envelope=[(max(O,z.LAM*z.Xlo(u-x[k+1]),z.Xlo(u+x[k]-1)),min(1,z.Xhi(u-x[k]))) for k in range(parts)]
    J=10**12
    outer_lower=0
    for k,(b,t) in enumerate(envelope):
        assert O<=b<=t<=1
        outer_lower+=(J*axes(k,k+1)[0]*(vertical(O,b)[0]+vertical(t,F(1))[0])).__floor__()
    def panel(i,j):
        R=axes(i,j)[0]
        def bounds(c,d):
            if c>=d:return (0,0)
            physical=(J*R*vertical(c,d)[0]).__floor__()
            hit=sum(axes(k,k+1)[1]*vertical(max(c,envelope[k][0]),min(d,envelope[k][1]))[1] for k in range(i,j))
            return (physical,(J*hit).__ceil__())
        low={(0,0)};top={(0,0)}
        for k in range(i,j+1):
            bottom=max(z.LAM*z.Xlo(u-x[k]),z.Xlo(u+x[k]-1))
            upper=z.Xhi(u-x[k])
            low.add(bounds(O,min(half,max(O,bottom))))
            top.add(bounds(min(1,max(half,upper)),F(1)))
        def reduce(opts):
            return tuple((a,b) for a,b in opts if not any(c>=a and d<=b and (c,d)!=(a,b) for c,d in opts))
        return reduce(low),reduce(top)
    splits=range(2,parts,2)
    pairs=[(panel(0,j),panel(j,parts)) for j in splits]
    return outer_lower,panel(0,parts),pairs

def fee(I,J,scale,bank,fi,go,qo,geom,limits,data):
    sys.path.insert(0,str(W/'gram-cycle'))
    from corner_phase import extra_saving
    cap,collar,excess,inner_min=geom
    inner,outer=limits;U=J*I**2
    si=scale*(I-fi)*I-U;beta=scale*I**2-U
    maximum=min(cap,inner+collar,outer)
    outside,one,two=data
    def ceil(a,b):return -(-a//b)
    best=ceil(si*inner+beta*collar,U)
    for f,n,q in (*bank,(0,0,0)):
        upper=(I-f)*I
        lower=upper if (f,n,q)==(0,0,0) else upper-I
        point=max(0,lower-(n+q)*I)
        def saving(panel):
            return sum(max((lower-point)*a-(I**2-point)*b for a,b in group) for group in panel)
        spec=n*go+q*qo
        pure=saving(one)
        partitions=max((saving(a)+saving(b) for a,b in two),default=0)
        gain=scale*(point*outside+max(pure,extra_saving(partitions,spec*outer)))
        D=scale*(upper+spec);d=D*outer-gain;so=D-U
        assert min(si,so,beta)>=0
        for slope,intercept in ((beta,-(beta-si)*inner_min),(si,(beta-si)*collar),(so,D*excess-gain)):
            best=min(best,ceil(slope*maximum+intercept,U),ceil(slope*d+U*intercept,U*(U+slope)))
    return best

@cache
def shapes(repo,left,right,gl,gh,grid,indices,parts):
    sys.path.insert(0,str(W/'mass-geometry'))
    from refine import setup
    z,_=setup(repo,gl,gh)
    fixed={i:max(z.LAM*z.Xlo(F(-1,grid)),z.Xlo(F(2*i,grid)-1)) for i in indices}
    z,_=setup(repo,left,right)
    return {i:geometry(z,grid,i,o,parts) for i,o in fixed.items()}
