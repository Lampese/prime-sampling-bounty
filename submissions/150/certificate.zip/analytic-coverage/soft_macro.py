"""Price a certified native spectral table using masks which may remove a bounded part of the target."""
from argparse import ArgumentParser
from fractions import Fraction as F
from functools import cache
from hashlib import sha256
from pathlib import Path
import json,os,sys
from rectangle_budget import geometry_window,rectangle_caps
from soft_mask import fee,shapes
from score import strip_prices
HERE=Path(__file__).resolve().parent
WORK=HERE.parent

def main():
    p=ArgumentParser(description=__doc__);p.add_argument('--repo',type=Path,default=WORK/'prime-sampling')
    p.add_argument('--cell',type=Path,required=True);p.add_argument('--window',nargs=2,type=F,required=True)
    p.add_argument('--macros',nargs='+',type=int,default=list(range(67,100)))
    p.add_argument('--parts',type=int,default=8);p.add_argument('--out',type=Path,required=True);p.add_argument('--check',action='store_true')
    a=p.parse_args();repo=a.repo.resolve();cell=a.cell.resolve();l,h=a.window
    info=json.loads(cell.read_text());gl,gh=geometry_window(cell)
    assert gl<=F(info['left'])<=l<h<=F(info['right'])<=gh and a.parts in (4,8,12,16)
    sys.path[:0]=[str(repo),str(WORK/'harmonic-research/predecessor')]
    os.environ.setdefault('PRIME_TREE_DIR',str(WORK/'harmonic-research/predecessor/certified-trees'))
    from tree_sieve_trial import new_bank
    from prime_sampling.accounting import ledger as v
    graphs={b:{} for b in ('with3','without3')};inputs={}
    assert all(67<=j<100 for j in a.macros)
    for t in info['tables']:
        grid=t['grid'];kind=t['kind'];path=cell.parent/t['file']
        if kind not in ('six','pair'):continue
        indices=tuple(i for j in a.macros for i in range(j*grid//200,(j+1)*grid//200))
        book=shapes(repo,l,h,gl,gh,grid,indices,a.parts)
        limits=rectangle_caps(repo,l,h,gl,gh,grid);rows=v.check_rows(path,grid)
        inputs[t['file']]=sha256(path.read_bytes()).hexdigest()
        for branch,edges in graphs.items():
            if branch=='without3' and kind=='six':continue
            seq=v.rank(h,branch);bank,scale=new_bank(seq,kind)
            @cache
            def excluded(g,q):return max(0,max(f-v.ceil(n*g+k*q,v.I) for f,n,k in bank))
            old=strip_prices(path,grid,kind,seq,True)
            for i in indices:
                pos=i-grid*67//200;row=rows[pos]
                price=fee(v.I,v.J,scale,bank,excluded(*row[:2]),*row[2:4],row[4:],limits[pos],book[i])
                x,y=F(i,grid),F(i+1,grid)
                graph=edges.setdefault(x,{});val=min(price,old[pos]);graph[y]=min(val,graph.get(y,val))
    costs={}
    for j in a.macros:
        low,high=F(j,200),F(j+1,200)
        for br,edges in graphs.items():
            dp={high:0}
            for x in sorted((x for x in edges if low<=x<high),reverse=True):
                avail=[v+dp[y] for y,v in edges[x].items() if y in dp]
                if avail:dp[x]=min(avail)
            costs.setdefault(str(j),{})[br]=dp[low]
    result=dict(left=str(l),right=str(h),family='soft-mask',parts=a.parts,cell=cell.relative_to(WORK).as_posix(),inputs=inputs,macros=a.macros,fees=costs)
    if a.check:assert result==json.loads(a.out.read_text())
    else:
        stage=a.out.with_suffix('.pending');stage.write_text(json.dumps(result,indent=2),encoding='ascii');stage.replace(a.out)
    print(str(l),str(h),sum(v['with3'] for v in costs.values()),flush=True)

if __name__=='__main__':main()
