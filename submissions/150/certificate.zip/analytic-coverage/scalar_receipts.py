"""Exact disaggregation of scalar prefix replacements at the four matched cutoffs."""
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import json
HERE=Path(__file__).resolve().parent
WORK=HERE.parent

def keep(path):
    raw=path.read_bytes();folder=HERE/'selected-inputs'/sha256(raw).hexdigest()
    folder.mkdir(parents=True,exist_ok=True);target=folder/path.name
    if not target.is_file():target.write_bytes(raw)
    return target.relative_to(WORK).as_posix()

def validate(table,evidence):
    rows=[s.split() for s in table.read_text().splitlines()]
    assert len(rows)==len(evidence['cells'])
    for row,recipe in zip(rows,evidence['cells']):
        assert row[:3]==recipe[:3]
        l,h,r=F(row[0]),F(row[1]),int(row[2])
        assert len(recipe)==7
        for j,paths in enumerate(recipe[3:]):
            tail,before,after=[WORK/n for n in paths]
            assert '-pooled-' not in tail.name
            for path in (tail,before,after):assert sha256(path.read_bytes()).hexdigest()==path.parent.name
            p,q=before.read_text().split(),after.read_text().split()
            for x in (p,q):
                assert int(x[2])==r and F(x[0])<=l<h<=F(x[1]) and x[-1]=='26'
            delta=(int(p[3])-int(q[3]))//1000
            assert delta>=0
            assert any(int(t[2])==r and F(t[0])<=l<h<=F(t[1]) and int(t[3+j])-delta==int(row[3+j])
                       for s in tail.read_text().splitlines() for t in [s.split()])

def record(table,recipes):
    paths={n:keep(WORK/n) for row in recipes for trip in row[3:] for n in trip}
    data=dict(original={v:k for k,v in paths.items()},cells=[[*r[:3],*[[paths[n] for n in trip] for trip in r[3:]]] for r in recipes])
    validate(table,data)
    fixed=WORK/keep(table)
    file=fixed.with_name('scalar-receipt.json')
    if file.exists():assert json.loads(file.read_text())==data
    else:file.write_text(json.dumps(data,indent=1),encoding='ascii')
