"""Independently recompute the ledger from native rows, exact endpoint macro proofs and physical budgets."""
from argparse import ArgumentParser
from fractions import Fraction as F
from functools import cache
from hashlib import sha256
from pathlib import Path
import json
from score import score
from join_ledger import gather,relative

HERE=Path(__file__).resolve().parent;WORK=HERE.parent
def snapshot(f):
    raw=f.read_bytes();folder=HERE/'selected-inputs'/sha256(raw).hexdigest()
    folder.mkdir(parents=True,exist_ok=True);dest=folder/f.name
    if not dest.exists():dest.write_bytes(raw)
    return dest
def main():
    p=ArgumentParser(description=__doc__);p.add_argument('--surveys',nargs='+',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True);p.add_argument('--repo',type=Path,default=WORK/'prime-sampling')
    p.add_argument('--certified-release',action='store_true')
    p.add_argument('--rectangle-mass',action='store_true')
    p.add_argument('--individual-mass',action='store_true')
    p.add_argument('--window',nargs=2,type=F,default=[F(4801,32),F(152)]);a=p.parse_args();repo=a.repo.resolve()
    reports,budgets=gather()
    if a.certified_release:
        budgets=[p for p in budgets if not p.name.startswith('prefix-log-') or p.name=='prefix-log-ready.dat']
        assert (HERE/'prefix-log-ready.dat') in budgets
        from scalar_receipts import validate
        tab=snapshot(HERE/'prefix-log-ready.dat')
        validate(tab,(json.loads(tab.with_name('scalar-receipt.json').read_bytes())))
    frozen=[];original={}
    for f in budgets:
        t=snapshot(f);frozen.append(t);original[relative(t)]=relative(f)
    budgets=frozen;all_reports={}
    for f,r in reports.items():
        # Completed siblings carry the same proofs as their shorter checkpoint.
        if f.name.endswith('.partial.json') and f.with_name(f.name.replace('.partial.json','.json')).exists():continue
        t=snapshot(f);all_reports[t]=json.loads(t.read_bytes());original[relative(t)]=relative(f)
    records=[];bycell={}
    for f in a.surveys:
        for w in json.loads(f.read_text()):
            l,h=F(w['left']),F(w['right'])
            if a.window[0]<=l<h<=a.window[1]:
                bycell.setdefault((l,h),set()).update(WORK/x for x in w['cells'])
    for (l,h),tables in sorted(bycell.items()):
        proofs=[p for p,r in all_reports.items() if F(r['left'])<=l<h<=F(r['right'])]
        possible=[]
        for p in budgets:
            if any(F(w[0])<=l<h<=F(w[1]) for line in p.read_text().splitlines() for w in [line.split()]):possible.append(p)
        data=score(repo,l,h,proofs,sorted(tables),possible,True,a.rectangle_mass or a.individual_mass,a.individual_mass)
        best={k:max(v['cutoffs'],key=lambda t:t['margin']) for k,v in data.items()}
        chosen={}
        # Keep only a direct proof used by at least one actual macro. Use all
        # matching files with the winning basename to handle duplicate names.
        for d in data.values():
            for j,(cost,name) in d['macros'].items():
                for p in proofs:
                    if p.name==name:chosen[p]=None
        required=[]
        from prime_sampling.accounting import ledger
        for br,z in best.items():
            found=None;r=len(ledger.rank(h,br))
            for p in possible:
                for line in p.read_text().splitlines():
                    x,y,k,*fees=line.split()
                    if F(x)<=l<h<=F(y) and int(k)>=r and int(fees[z['cut']-67])*1000==z['R']:
                        found=p;break
                if found:break
            assert found
            required.append(found)
        record=dict(left=str(l),right=str(h),native=list(map(relative,sorted(tables))),
                    reports=list(map(relative,sorted(chosen))),budgets=list(map(relative,sorted(set(required)))),
                    expected=best,tree=True,rectangle_mass=a.rectangle_mass or a.individual_mass,individual_mass=a.individual_mass)
        records.append(record)
        print(str(l),str(h),*[t['margin'] for t in best.values()],flush=True)
    out=a.out;out.mkdir(parents=True,exist_ok=True)
    (out/'ledger.json').write_text(json.dumps(records,indent=1),encoding='ascii')
    (out/'input-paths.json').write_text(json.dumps(original,indent=1),encoding='ascii')
    runs=[]
    for w in records:
        if min(z['margin'] for z in w['expected'].values())<=0:continue
        if not runs or runs[-1][-1]['right']!=w['left']:runs.append([])
        runs[-1].append(w)
    index=[]
    for i,cells in enumerate(runs):
        manifest=dict(left=cells[0]['left'],right=cells[-1]['right'],cells=cells)
        name=f'positive-{i}.json';(out/name).write_text(json.dumps(manifest,indent=1),encoding='ascii')
        index.append(dict(manifest=name,left=manifest['left'],right=manifest['right'],cells=len(cells),
                          floor=min(z['margin'] for w in cells for z in w['expected'].values())))
    (out/'runs.json').write_text(json.dumps(index,indent=1),encoding='ascii');print(index,flush=True)
if __name__=='__main__':main()
