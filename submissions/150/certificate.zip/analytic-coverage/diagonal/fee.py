"""Price true diagonal-strip charges on matching native rectangles and solve the mixed-grid tiling exactly."""
from argparse import ArgumentParser
from fractions import Fraction as F
from functools import cache
from importlib.util import module_from_spec,spec_from_file_location
from math import isqrt,lcm
from pathlib import Path
from tempfile import TemporaryDirectory
import hashlib,json,os,sys

HERE=Path(__file__).resolve().parent
WORK=HERE.parents[1]


def main():
    ap=ArgumentParser(description=__doc__)
    ap.add_argument('--repo',type=Path,default=WORK/'prime-sampling')
    ap.add_argument('--inputs',type=Path,nargs='+',default=[])
    ap.add_argument('--neutral-grids',type=int,nargs='+',default=[])
    ap.add_argument('--window',type=F,nargs=2)
    ap.add_argument('--macros',type=int,nargs='+',default=[98,99])
    ap.add_argument('--steps',type=int,default=32)
    ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--check',action='store_true')
    args=ap.parse_args();assert 4<=args.steps<=256 and all(67<=k<=99 for k in args.macros)
    if not __debug__:raise RuntimeError('Run the verifier without -O')
    data=[];digests={}
    for path in args.inputs:
        raw=path.read_bytes()
        if path.name in digests:raise ValueError('Input filenames must be distinct')
        digests[path.name]=hashlib.sha256(raw).hexdigest()
        data.append(json.loads(raw))
    if args.neutral_grids:
        if not args.window:ap.error('A neutral native grid needs its actual parameter window')
        for g in args.neutral_grids:
            assert g%200==0 and g>=600
            indices=[i for k in args.macros for i in range(k*g//200,(k+1)*g//200)]
            data.append(dict(left=str(args.window[0]),right=str(args.window[1]),grid=g,rows=[(i,[10**10]*4,[10**10]*4) for i in indices]))
    if not data:ap.error('Supply spectra or neutral grids')
    ref=data[0]
    l,h=map(F,(ref['left'],ref['right']));repo=args.repo.resolve()
    assert 150<=l<h<=175 and all((F(d['left']),F(d['right']))==(l,h) and not d.get('hypothetical') for d in data)
    if any(tuple(map(F,d.get('geometry_window',(l,h))))!=(l,h) for d in data):
        raise ValueError('Every spectrum must refer to the same true native rectangles')
    spec=spec_from_file_location('diagonal_mass',WORK/'mass-geometry/refine.py')
    mg=module_from_spec(spec);spec.loader.exec_module(mg)
    z,ledger=mg.setup(repo,l,h);I,J=ledger.I,ledger.J
    sys.path[:0]=[str(WORK/p) for p in ('wide-coverage','mass-geometry','spectral-coupling','harmonic-research/predecessor')]
    from local_geometry import refine_grid
    from joint_bounds import rectangle_limits,upper_fee
    from coset_split import close_six
    from tree_sieve_trial import new_bank
    saved=WORK/'harmonic-research/predecessor/certified-trees'
    if saved.is_dir():os.environ.setdefault('PRIME_TREE_DIR',str(saved))
    def completion(a,b,v,s,k,span,pm,p):
        radius=(span+1)//2+1;sqrtp=isqrt(p)+1
        c=min((pm-1)//2,max(2*radius,isqrt(2*sqrtp*radius*s)))
        value=min(F(1),z.nthroot(F(c,c-radius)*(F(c,s)+2*sqrtp)/k)) if c>radius and 2*c<pm else F(1)
        return value,value
    z.rates=completion
    inputs={}
    for d in data:
        g=d['grid'];assert g%200==0 and g>=600
        seen=set()
        for i,p,s in d['rows']:
            if i in seen or not 67*g//200<=i<g//2:raise ValueError('Invalid row index')
            seen.add(i)
            if any(len(a)!=4 or any(type(x) is not int or not 0<=x<=I for x in a) for a in (p,s)):
                raise ValueError('Invalid four-column spectral bound')
            j=i*200//g
            if j not in args.macros:continue
            old=inputs.setdefault(g,{}).get(i,([I]*4,[I]*4))
            inputs[g][i]=(list(map(min,zip(old[0],p,strict=True))),list(map(min,zip(old[1],s,strict=True))))
    unit=lcm(*inputs);tariffs={branch:{} for branch in ('with3','without3')}
    with TemporaryDirectory() as name:
        folder=Path(name)
        for g,rows in sorted(inputs.items()):
            geom=mg.factory(z,ledger,args.steps,4)
            arrays={'pair':[],'six':[]};limits={}
            for i,(p,six) in sorted(rows.items()):
                u,v=F(i,g),F(i+1,g);C,E=z.inner(u,v)
                O=max(z.LAM*z.Xlo(u-v),z.Xlo(2*u-1))
                assert min(u*z.zl,(1-u)*z.zl+z.b(min(C,O),'ln',False))>=40
                inner=z.joint(u,v,C,E);outer=z.joint(u,v,O,F(1))
                both=[z.upint(q) for q in (*inner[:2],*outer[:2])]
                geo=list(geom(g,i));geo[3]=max(geo[3],(J*inner[2]).__floor__())
                limits[i]=rectangle_limits(z,g,i,args.steps)
                for k,vals in [('pair',p),('six',six)]:
                    arrays[k].append([i,*map(min,zip(both,vals,strict=True)),*geo])
            arrays['six']=[close_six(a,b) for a,b in zip(arrays['pair'],arrays['six'],strict=True)]
            for kind,ary in arrays.items():
                (folder/(kind+'.dat')).write_text(''.join(' '.join(map(str,row))+'\n' for row in ary),encoding='ascii')
            refine_grid(repo,l,h,g,folder,args.steps)
            for kind in arrays:
                final=[list(map(int,line.split())) for line in (folder/(kind+'.dat')).read_text().splitlines()]
                for branch in tariffs:
                    if branch=='without3' and kind=='six':continue
                    options,scale=new_bank(ledger.rank(h,branch),kind)
                    @cache
                    def excluded(a,b):
                        return max(0,max(mu-ledger.ceil(ng*a+nq*b,I) for mu,ng,nq in options))
                    for i,gi,qi,go,qo,m,collar,e,m0 in final:
                        fi,fo=excluded(gi,qi),excluded(go,qo)
                        ordinary=min(m-fi*m0//I,ledger.ceil((I-fi)*m+fi*collar,I),ledger.ceil((I-fo)*(m+e),I))
                        cost=min(ledger.ceil(scale*ordinary,J)-m,upper_fee(I,J,scale,fi,fo,(m,collar,e,m0),limits[i]))
                        key=i*unit//g,(i+1)*unit//g
                        old=tariffs[branch].get(key)
                        tariffs[branch][key]=cost if old is None else min(old,cost)
    ans={}
    for j in args.macros:
        start,end=j*unit//200,(j+1)*unit//200
        for branch,edges in tariffs.items():
            dp={end:0}
            for a in sorted({a for a,b in edges if start<=a<end},reverse=True):
                choices=[cost+dp[b] for (x,b),cost in edges.items() if x==a and b in dp]
                if choices:dp[a]=min(choices)
            if start not in dp:raise ValueError(f'Uncovered macro {j}')
            ans.setdefault(str(j),{})[branch]=dp[start]
    result=dict(left=str(l),right=str(h),family='joint-diagonal',macros=args.macros,steps=args.steps,neutral_grids=args.neutral_grids,
                inputs=digests,fees=ans)
    if args.check:
        if result!=json.loads(args.out.read_text()):raise ValueError('Diagonal pricing differs')
    else:args.out.write_text(json.dumps(result,indent=2)+'\n',encoding='ascii')
    print(ans,flush=True)


if __name__=='__main__':main()
