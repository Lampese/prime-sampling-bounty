# Two late macrostrips on an actual prime-parameter interval

`rows.py` certifies the four rectangle rates for each native microstrip in the requested macrostrips. On grid \(g\), macro \(j\) consists exactly of indices \(jg/200\le i<(j+1)g/200\). Each row uses the parameters and inscribed and circumscribed rectangles from `prime_sampling.rectangles.boxes` on the declared closed interval of \(\log p\). The common cap for the two spectra uses the true width bound \(V=B(1-X_-^{-1/g})\) rounded up and both the scalar ratio and angular covering. As in `wide-coverage/portfolio-geometry.md` and `fibre-lines/angular-proof.md`, the latter is an integer-certified lattice covering, uniform in the shift. Kernel selection is followed by exact rational evaluation in `operator-new/mixed.py`. The two-band trapezoid, local conductor and projective fourth-moment inputs are unchanged from the independently reusable rectangle estimates. Rows and caps from a different window must be regenerated unless their actual rectangle and parameter enclosures are independently checked.

`fee.py` supplements these rates by the original completion bound in both orientations using the original `squarerates.rates` first inequality, and by the rate already in `boxes.joint`. It optionally takes pointwise minima for repeated copies of the same rectangle. The six-spectrum closure is `spectral-coupling/coset_split.close_six`. The exclusion rate for each rectangle and branch uses the original sieve layouts together with integer and rational evaluation of the finite tree witnesses. In particular the ranks are computed from the right parameter endpoint, and a branch without 3 uses only the pair spectrum.

For the inner rectangle, true strip and outer rectangle let the respective true normalized masses be \(i,w,o\). Compute upper bounds \(m,h,e,I_+,O_+\) for \(w,w-i,o-w,i,o\), and a lower bound \(m_0\) for \(i\). `mass-geometry/refine.py`, `wide-coverage/local_geometry.py` and `mass-geometry/joint_bounds.py` provide these bounds by outward quadrature. The lower diagonal cutoff for the larger prime is retained on every horizontal subinterval. `wide-coverage/joint-geometry.md` derives the affine charge bounds implemented in `upper_fee`, using this single common \(w\). These multiply normalized excluded fractions on full rectangles, then bound the count of points in their collars. They use only inclusion and positivity to restrict a rectangular bound to the ordered prime domain. The calculation never assumes symmetry of a summand under exchange of the two primes.

The native charge and the joint charge can be compared on every row with the same certified rates. Every directed edge of the final finite dynamic program is one such row on the common denominator of the grids. A path traversing exactly the requested macro covers every horizontal slice once, so the least path cost is a valid whole-macro upper bound. Its units are \(10^{-12}\). `score.py` may take a minimum with any other complete proof for that same macro and actual window. The support covers two macrostrips only, so the resulting JSON is a macro report and cannot substitute for a complete nine-column table.

From the project directory use the following PowerShell commands. The narrow computation uses the exact second 1/32 window. The half window in these examples is wider and is recomputed independently.

```powershell
$d='work/analytic-coverage/diagonal'
foreach ($g in 2400,4800,6400) {
    python -B "$d/rows.py" --repo work/prime-sampling --window 4801/32 2401/16 --grid $g --macros 99 98 --out "$d/thin-$g.json"
}
python -B "$d/fee.py" --repo work/prime-sampling --inputs "$d/thin-2400.json" "$d/thin-4800.json" "$d/thin-6400.json" --out "$d/thin-fee.json" --check
python -B "$d/rows.py" --repo work/prime-sampling --window 150 301/2 --grid 4800 --macros 99 98 --out "$d/half-4800.json"
python -B "$d/fee.py" --repo work/prime-sampling --inputs "$d/half-4800.json" --out "$d/half-fee.json" --check
```

Use Python 3.10 or later and a C++17 compiler in `CXX`. On Windows the local Zig launcher is used if present. `rows.py --caps FILE` reuses compatible envelope records when replaying the spectrum step. For a fresh result remove `--check` from each pricing command. The output stores the SHA-256 of every exact rate input it consumed.

`verify.py --repo PATH --case NAME` reproduces the enclosing caps, spectra and macro charges in a temporary directory. `--fees-only` starts from the saved spectral rows and redoes all geometry and sieve charges. `sources.py --case NAME` lists the portable files. The original checkout is supplied separately at revision `63a2d41e8124320784c244336ff36ac5f2285418`. `cold.py` can copy the listed files to an isolated root before running the check.

| Name | Closed interval for log p | Native grids |
| --- | --- | --- |
| thin | [4801/32, 2401/16] | 2400, 4800, 6400 |
| half | [150, 301/2] | 4800 |
| next | [2401/16, 1201/8] | 4800 |
| mid | [1201/8, 601/4] | 4800 |
| late | [601/4, 301/2] | 4800 |
| second | [301/2, 151] | 4800 |

The integer costs in the `fees` field can be used separately for each full macrostrip. For the `thin` window the respective hard-branch costs of macros 98 and 99 are 64,626,230,558 and 39,910,570,183. For the enclosing `half` window they are 70,874,890,536 and 43,177,549,569. Every quoted value is in units of one trillionth.
