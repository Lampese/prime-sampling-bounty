"""Directly reprice one settled weak cell from all matching genuine input records."""
from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
import json,sys
from weak import AC,WORK,surveys
from join_ledger import gather,relative
from score import score


if __name__=='__main__':
    cli=ArgumentParser(description=__doc__)
    cli.add_argument('--window',nargs=2,type=F,required=True)
    cli.add_argument('--out',type=Path,required=True)
    cli.add_argument('--repo',type=Path,default=WORK/'prime-sampling')
    cli.add_argument('--positive',action='store_true');a=cli.parse_args();l,h=a.window
    direct,budgets=gather();natives=set()
    for p in surveys():
        for r in json.loads(p.read_bytes()):
            if F(r['left'])<=l<h<=F(r['right']):natives.update(WORK/f for f in r['cells'])
    reports=[p for p,r in direct.items() if F(r['left'])<=l<h<=F(r['right'])]
    fees=[p for p in budgets if any(F(w[0])<=l<h<=F(w[1]) for t in p.read_text().splitlines() for w in [t.split()])]
    result=score(a.repo,l,h,reports,sorted(natives),fees,True,True)
    best={k:max(v['cutoffs'],key=lambda s:s['margin']) for k,v in result.items()}
    print(str(l),str(h),best,flush=True)
    if a.positive:assert min(w['margin'] for w in best.values())>0
    a.out.write_text(json.dumps(dict(left=str(l),right=str(h),cells=[dict(left=str(l),right=str(h),reports=list(map(relative,reports)),
                     native=list(map(relative,sorted(natives))),budgets=list(map(relative,fees)),tree=True,rectangle_mass=True,expected=best)]),indent=1),encoding='ascii')
