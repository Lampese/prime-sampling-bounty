"""Source and certificate files for a portable diagonal-macro replay, relative to work/."""
from argparse import ArgumentParser
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path

HERE=Path(__file__).resolve().parent
WORK=HERE.parents[1]
spec=spec_from_file_location('diagonal_case_replay', HERE/'verify.py')
replay=module_from_spec(spec)
spec.loader.exec_module(replay)
CASES=replay.CASES
SHARED={
    'fibre-lines':('*.py','*.md','main_shape.cpp','shape-schedules.json'),
    'fibre-portfolio':('directional.py','directional-proof.md'),
    'gram-cycle':('trap_envelope.py','local_conductor.py','paley_four.py','conductor.md','frequency-audit.md','paley-four.md','tetrahedral.md'),
    'mass-geometry':('joint_bounds.py','refine.py','proof.md'),
    'near-lines':('*.py','*.cpp','*.md','shape-865.txt'),
    'operator-new':('mixed.py','mixed_selector.cpp','*.h','fejer.py','frequency_envelope.py','centered_powers.py','*.md'),
    'spectral-coupling':('coset_split.py','cosets-and-trace.md'),
    'wide-coverage':('caps_only.py','ratio_caps.py','local_geometry.py','portfolio-geometry.md','joint-geometry.md'),
    'hyperbola-next':('smooth_rows.py',),
    'harmonic-research/predecessor':('tree_sieve_trial.py','tree_catalog.py','certified-trees/*.json'),
    'harmonic-research/kernel':('harmonic-proof.txt','centered-tri-proof.txt'),
}


def files(case):
    _,_,grids=CASES[case]
    own=['rows.py','fee.py','sources.py','verify.py','proof.md',f'{case}-fee.json']
    for g in grids:own.extend((f'{case}-{g}.json',f'{case}-{g}.caps.json'))
    result={HERE/n for n in own}
    for d,patterns in SHARED.items():
        for pat in patterns:result.update((WORK/d).glob(pat))
    for path in result:
        if not path.is_file():raise FileNotFoundError(path)
    return sorted(result)


if __name__=='__main__':
    cli=ArgumentParser(description=__doc__)
    cli.add_argument('--case',required=True,choices=CASES)
    for path in files(cli.parse_args().case):print(path.relative_to(WORK).as_posix())
