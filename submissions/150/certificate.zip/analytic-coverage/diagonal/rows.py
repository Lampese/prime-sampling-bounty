"""Rebuild one native diagonal grid on actual log-prime endpoints with coupled angular fibres."""
from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
import subprocess,sys

HERE=Path(__file__).resolve().parent
WORK=HERE.parents[1]


def main():
    cli=ArgumentParser(description=__doc__)
    cli.add_argument('--repo',type=Path,default=WORK/'prime-sampling')
    cli.add_argument('--window',nargs=2,type=F,required=True)
    cli.add_argument('--grid',type=int,required=True)
    cli.add_argument('--macros',nargs='+',type=int,default=[98,99])
    cli.add_argument('--out',type=Path,required=True)
    cli.add_argument('--caps',type=Path)
    args=cli.parse_args();l,h=map(str,args.window)
    if args.grid%200 or args.grid<600 or not all(67<=j<=99 for j in args.macros):raise ValueError('Invalid native grid or macros')
    caps=args.caps or args.out.with_suffix('.caps.json')
    common=['--repo',str(args.repo.resolve()),'--grid',str(args.grid),'--groups',str(args.grid//200),
            '--wide','--left',l,'--right',h,'--macro',*map(str,args.macros)]
    if not args.caps:
        subprocess.run([sys.executable,'-B',str(WORK/'wide-coverage/caps_only.py'),*common,'--ratio','--couple-scale',
                        '--angular','--out',str(caps)],check=True)
    subprocess.run([sys.executable,'-B',str(WORK/'hyperbola-next/smooth_rows.py'),*common,'--near-shape','--shared-shapes',
                    '--trapezoid','--frequency-envelope','--local-conductor','--reweight','--paley-four','--tetra-four',
                    '--caps',str(caps),'--out',str(args.out)],check=True)


if __name__=='__main__':main()
