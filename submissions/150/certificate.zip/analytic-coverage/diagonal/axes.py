"""Reprice selected native rectangles using their actual sampling endpoints in both coordinate directions."""
from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
from tempfile import TemporaryDirectory
import json
import os
import subprocess
import sys

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[1]


def main():
    ap = ArgumentParser(description=__doc__)
    ap.add_argument('--repo', type=Path, default=WORK/'prime-sampling')
    ap.add_argument('--caps', type=Path, required=True)
    ap.add_argument('--rows', type=int, nargs='+', required=True)
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--horizontal-only', action='store_true')
    args = ap.parse_args()
    if not __debug__:raise RuntimeError('Run without -O')
    source = json.loads(args.caps.read_bytes())
    assert source['caps_only'] and source['angular_caps'] and not source.get('hypothetical')
    grid = source['grid'];lo,hi=map(F,(source['left'],source['right']))
    assert 150<=lo<hi<=175 and grid%200==0
    caps = {(start,stop):tuple(row) for start,stop,*row in source['envelopes']}
    if (WORK/'zig-cxx.cmd').is_file():
        os.environ.setdefault('CXX',str(WORK/'zig-cxx.cmd'))
        os.environ.setdefault('ZIG_GLOBAL_CACHE_DIR',str(WORK/'zig-cache'))
        os.environ.setdefault('ZIG_LOCAL_CACHE_DIR',str(WORK/'zig-local-cache'))
    dirs = ('wide-coverage','fibre-lines','fibre-portfolio','gram-cycle','operator-new','near-lines')
    sys.path[:0] = [str(args.repo.resolve()),*(str(WORK/p) for p in dirs)]
    from prime_sampling.rectangles import boxes as z
    from prime_sampling.spectrum import squarerates as sr
    import mixed,shape_near,ratio_caps,smooth_wide
    z.initialize(lo,hi)
    shape_near.install()
    rates = {}
    for kind in ('pair','six'):
        z.rates=lambda *p:(F(1),F(1))
        mixed.install(kind,z,opposite=lambda:opposite,trapezoid=True,envelope=True,conductor=True,
                      reweight=True,paley_four=True,tetra_four=True)
        rates[kind]=z.rates
    def fibre(a,b,width,pm,p):
        assert (a,b,width,pm,p)==(*input_axis[:3],z.pmin,z.pmax)
        return bound
    sr.square_cap=fibre
    report=dict(left=str(lo),right=str(hi),grid=grid,actual_sampling_axis=True,
                transposed=not args.horizontal_only,rows=[])
    with TemporaryDirectory() as temp:
        if not args.horizontal_only:
            exe=Path(temp)/('lattice'+('.exe' if os.name=='nt' else ''))
            subprocess.run([os.getenv('CXX','c++'),'-O3','-std=c++17',str(WORK/'fibre-lines/main_shape.cpp'),'-o',str(exe)],check=True)
            os.environ['PRIME_SHAPE_EXE']=str(exe)
        for i in args.rows:
            assert 67*grid//200<=i<grid//2
            u,v=F(i,grid),F(i+1,grid)
            eps,_,a,b,s,width,ylo,yhi=z.params(u,v)
            a0,b0,v0,primary=caps[i,i+1]
            assert a0<=a<=b<=b0 and width<=v0
            horizontal=(a,b,width,s)
            columns={k:[] for k in rates}
            for c,e in (z.inner(u,v),(max(z.LAM*z.Xlo(u-v),z.Xlo(2*u-1)),F(1))):
                if c>=e:
                    for col in columns.values():col.extend((10**10,10**10))
                    continue
                ep=max(eps,z.thetaerr((1-u)*z.zl+z.b(c,'ln',False)))
                k=(z.abel.lower_count(c,e,ep,(1-u)*z.zh,z)*ylo).__ceil__()
                span=((e-c)*yhi).__ceil__()+2
                xx,yy=(c*ylo).__floor__(),(e*yhi).__ceil__()
                vertical=(xx,yy,min(yy-xx,span),k)
                assert min(k,s)>1
                input_axis,bound,opposite=horizontal,primary,(xx,yy)
                best={mode:fn(a,b,width,s,k,span,z.pmin,z.pmax) for mode,fn in rates.items()}
                if not args.horizontal_only:
                    input_axis=vertical;opposite=(a,b)
                    x,y,V,count=input_axis
                    alpha=c/e
                    rho=(e-c)*z.Xhi(-u)/(lo-F('1.1'))+F(2,z.pmin)
                    bound=min(smooth_wide.calculate(x,y,V,z.pmin,z.pmax),
                              ratio_caps.calculate(x,y,V,z.pmin,z.pmax,alpha,rho),
                              ratio_caps.calculate(x,y,V,z.pmin,z.pmax,alpha,rho,angular=True))
                    for mode,fn in rates.items():
                        switched=fn(x,y,V,count,s,width,z.pmin,z.pmax)
                        best[mode]=list(map(min,zip(best[mode],switched,strict=True)))
                for mode,val in best.items():columns[mode].extend(map(z.upint,val))
            report['rows'].append([i,columns['pair'],columns['six']])
            args.out.write_text(json.dumps(report),encoding='ascii')
            print(grid,i,flush=True)
    if os.name=='nt':
        import _ctypes
        _ctypes.FreeLibrary(sr._lib._handle)


if __name__=='__main__':main()
