"""Identify exposed macrostrips and their source files from the available certified cell comparisons."""
from fractions import Fraction as F
from pathlib import Path
import json,sys

HERE=Path(__file__).resolve().parent;AC=HERE.parent;WORK=AC.parent
sys.path.insert(0,str(AC))
from join_ledger import inventory


def surveys():
    paths=[]
    for p in AC.glob('*.json'):
        try:data=json.loads(p.read_bytes())
        except ValueError:continue
        if isinstance(data,list) and data and all(isinstance(w,dict) and {'cells','results','macro_costs'}<=w.keys() for w in data):
            paths.append(p)
    return paths


if __name__=='__main__':
    paths=surveys()
    ledger=inventory(WORK/'prime-sampling',paths,F(4801,32),F(151))
    (HERE/'weak-latest.json').write_text(json.dumps(ledger,indent=1),encoding='ascii')
    ref=ledger[0]['branches']['with3']['macros']
    print('surveys',*[p.name for p in paths],flush=True)
    for w in ledger:
        l,h=map(F,(w['left'],w['right']))
        if not (F(601,4)<=l<h<=F(301,2) or F(603,4)<=l<h<=151):continue
        br=w['branches']['with3'];rr=w['branches']['without3'];print(l,h,br['margin'],rr['margin'],br['T'],br['R'],flush=True)
        if h in (F(1203,8),F(301,2),F(1207,8),F(151)):
            for j in sorted(br['macros'],key=lambda j:br['macros'][j][0]-ref[j][0],reverse=True)[:12]:
                n,p,src=br['macros'][j];print(j,n,n-ref[j][0],Path(p).name,src)
