"""Restrict the four true mass columns and rectangle masses to the actual parameter window, on fixed Fourier rectangles."""
from argparse import ArgumentParser
from fractions import Fraction as F
from functools import cache
from hashlib import sha256
from math import lcm
from pathlib import Path
from tempfile import TemporaryDirectory
import json,os,sys

HERE=Path(__file__).resolve().parent;AC=HERE.parent;WORK=AC.parent


def limits(z,u,v,C,E,O,parts):
    eps=z.thetaerr(min(u*z.zl,(1-u)*z.zl+z.b(min(C,O),'ln',False)))
    s=(v-u)/parts
    horiz=sum(2*z.Xhi(k*s)*((1+eps)*(z.Xhi(s)-1)*(1/(u+k*s)+1/(u+(k+1)*s))/2+2*eps/(u+k*s)) for k in range(parts))
    def vert(c,d):
        if c>=d:return 0
        h=(d-c)/parts
        def log(x):return (1-u)*z.zl+z.b(x,'ln',False)
        total=sum((1+eps)*h*(1/log(c+k*h)+1/log(c+(k+1)*h))/2+2*eps*(c+k*h)/log(c+k*h) for k in range(parts))
        return (10**12*horiz*total).__ceil__()
    return vert(C,E),vert(O,F(1))


def main():
    p=ArgumentParser(description=__doc__)
    p.add_argument('--repo',type=Path,default=WORK/'prime-sampling')
    p.add_argument('--window',nargs=2,type=F,required=True)
    p.add_argument('--cells',nargs='+',type=Path,required=True)
    p.add_argument('--macros',nargs='+',type=int,required=True)
    p.add_argument('--out',type=Path,required=True)
    p.add_argument('--check',action='store_true');a=p.parse_args()
    sys.path[:0]=[str(AC),str(WORK/'mass-geometry'),str(WORK/'spectral-coupling'),str(WORK/'harmonic-research/predecessor'),str(a.repo.resolve())]
    from refine import setup
    from rectangle_budget import geometry_window
    from coset_split import close_six
    from tree_sieve_trial import new_bank
    from joint_bounds import upper_fee
    sys.path.insert(0,str(WORK/'wide-coverage'))
    from local_geometry import refine_grid
    os.environ.setdefault('PRIME_TREE_DIR',str(WORK/'harmonic-research/predecessor/certified-trees'))
    l,h=a.window;assert 150<=l<h<=175
    assert len(set(a.macros))==len(a.macros) and all(67<=j<=99 for j in a.macros)
    cells=[(f,json.loads(f.read_bytes())) for f in a.cells]
    geos={geometry_window(f) for f,d in cells};assert len(geos)==1
    gl,gh=geos.pop();stamp={};tables={}
    l0=max(F(d['left']) for f,d in cells);h0=min(F(d['right']) for f,d in cells)
    assert gl<=l0<=l<h<=h0<=gh
    for f,d in cells:
        for t in d['tables']:
            g,k=t['grid'],t['kind'];assert k in ('pair','six') and g%200==0
            path=f.parent/t['file'];raw=path.read_bytes();stamp[path.resolve().relative_to(WORK).as_posix()]=sha256(raw).hexdigest()
            to=tables.setdefault(g,{}).setdefault(k,{})
            for line in raw.decode('ascii').splitlines():
                if not line or not line[0].isdigit():continue
                i,*row=map(int,line.split());assert len(row)==8
                if i*200//g not in a.macros:continue
                if i in to:row=[*map(min,zip(to[i][:-1],row[:-1],strict=True)),max(to[i][-1],row[-1])]
                to[i]=row
    denominator=lcm(*tables);edges={br:{} for br in ('with3','without3')}
    repo=a.repo.resolve()
    with TemporaryDirectory() as tmp:
        directory=Path(tmp)
        for g,table in tables.items():
            pair=table['pair'];six=table['six'];assert pair.keys()==six.keys()
            fixed={};z,v=setup(repo,gl,gh);I,J=v.I,v.J
            for i in sorted(pair):
                u,w=F(i,g),F(i+1,g)
                fixed[i]=(*z.inner(u,w),max(z.LAM*z.Xlo(u-w),z.Xlo(2*u-1)))
                for t in range(4,8):
                    both=(min if t<7 else max)(pair[i][t],six[i][t]);pair[i][t]=six[i][t]=both
                six[i]=close_six([i,*pair[i]],[i,*six[i]])[1:]
            allcaps=[]
            for lo,hi in ((l0,h0),(l,h)):
                z,_=setup(repo,lo,hi)
                allcaps.append({i:limits(z,F(i,g),F(i+1,g),*rect,4) for i,rect in fixed.items()})
            for kind,book in table.items():
                (directory/(kind+'.dat')).write_text(''.join(' '.join(map(str,(i,*row)))+'\n' for i,row in sorted(book.items())),encoding='ascii')
            refine_grid(repo,l,h,g,directory,32,fixed_window=(gl,gh))
            for kind,book in table.items():
                final={r[0]:r[1:] for line in (directory/(kind+'.dat')).read_text().splitlines() for r in [list(map(int,line.split()))]}
                for br,graph in edges.items():
                    if br=='without3' and kind=='six':continue
                    opts,scale=new_bank(v.rank(h,br),kind)
                    @cache
                    def excluded(x,y):return max(0,max(mu-v.ceil(n*x+q*y,I) for mu,n,q in opts))
                    for i,(gi,qi,go,qo,*oldgeo) in book.items():
                        fi,fo=excluded(gi,qi),excluded(go,qo)
                        def fee(geo,cap):
                            m,coll,e,m0=geo
                            d=min(m-fi*m0//I,v.ceil((I-fi)*m+fi*coll,I),v.ceil((I-fo)*(m+e),I))
                            return min(v.ceil(scale*d,J)-m,upper_fee(I,J,scale,fi,fo,geo,cap))
                        candidates=(fee(oldgeo,allcaps[0][i]),fee(oldgeo,allcaps[1][i]),fee(final[i][4:],allcaps[1][i]))
                        vals=(candidates[0],min(candidates[:2]),min(candidates))
                        key=(i*denominator//g,(i+1)*denominator//g)
                        if key in graph:vals=tuple(map(min,zip(graph[key],vals,strict=True)))
                        graph[key]=vals
    ans={};base={};localcap={}
    for j in a.macros:
        start,end=j*denominator//200,(j+1)*denominator//200
        for br,graph in edges.items():
            dp={end:(0,0,0)}
            for x in sorted({x for x,y in graph if start<=x<end},reverse=True):
                opts=[tuple(c+d for c,d in zip(cost,dp[y],strict=True)) for (xx,y),cost in graph.items() if xx==x and y in dp]
                if opts:dp[x]=tuple(map(min,zip(*opts)))
            for t,dst in zip(dp[start],(base,localcap,ans),strict=True):dst.setdefault(str(j),{})[br]=t
    result=dict(left=str(l),right=str(h),family='joint-diagonal',method='local_model',macros=a.macros,
                inputs=stamp,cells=[p.resolve().relative_to(WORK).as_posix() for p in a.cells],broad=base,local_caps=localcap,fees=ans)
    if a.check:assert result==json.loads(a.out.read_bytes())
    else:a.out.write_text(json.dumps(result,indent=2),encoding='ascii')
    print('broad',base,'local caps',localcap,'all local masses',ans,flush=True)


if __name__=='__main__':main()
