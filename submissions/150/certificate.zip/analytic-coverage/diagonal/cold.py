"""Run a diagonal replay from just the listed sources and the separately pinned upstream checkout."""
from argparse import ArgumentParser
from pathlib import Path
from tempfile import TemporaryDirectory
import os
import shutil
import subprocess
import sys
from sources import CASES, WORK, files


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--case',choices=CASES,required=True)
    parser.add_argument('--repo',type=Path,required=True)
    parser.add_argument('--cxx',default=os.getenv('CXX','c++'))
    parser.add_argument('--fees-only',action='store_true')
    a=parser.parse_args()
    repo=a.repo.resolve()
    compiler=str(Path(shutil.which(a.cxx) or a.cxx).resolve())
    env=dict(os.environ,CXX=compiler)
    for k in ('PYTHONPATH','PRIME_TREE_DIR','PRIME_TREE_CAPTURE','PRIME_SHAPE_EXE','PYTHONOPTIMIZE'):
        env.pop(k,None)
    with TemporaryDirectory() as name:
        base=Path(name)
        selected=files(a.case)
        for p in selected:
            dest=base/p.relative_to(WORK)
            dest.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(p,dest)
        script=base/'analytic-coverage/diagonal/verify.py'
        command=[sys.executable,'-B',str(script),'--repo',str(repo),'--case',a.case]
        if a.fees_only:command.append('--fees-only')
        subprocess.run(command,cwd=base,env=env,check=True)
        print('Cold source replay passed:',len(selected),'files',flush=True)
