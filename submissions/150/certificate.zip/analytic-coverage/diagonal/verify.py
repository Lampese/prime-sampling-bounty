"""Rebuild the selected diagonal certificate in a temporary directory and verify its integer charges."""
from argparse import ArgumentParser
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory

HERE = Path(__file__).resolve().parent
CASES = {
    'thin': ('4801/32', '2401/16', (2400, 4800, 6400)),
    'half': ('150', '301/2', (4800,)),
    'next': ('2401/16', '1201/8', (4800,)),
    'mid': ('1201/8', '601/4', (4800,)),
    'late': ('601/4', '301/2', (4800,)),
    'second': ('301/2', '151', (4800,)),
}


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--case', choices=CASES, required=True)
    parser.add_argument('--fees-only', action='store_true')
    args = parser.parse_args()
    left, right, grids = CASES[args.case]
    repo = args.repo.resolve()
    if not (repo/'prime_sampling/rectangles/boxes.py').is_file():
        parser.error('--repo must point to the original prime-sampling checkout')
    fees = HERE/f'{args.case}-fee.json'
    with TemporaryDirectory() as name:
        output = Path(name)
        inputs = []
        for grid in grids:
            saved = HERE/f'{args.case}-{grid}.json'
            if args.fees_only:
                inputs.append(saved)
                continue
            candidate = output/saved.name
            subprocess.run([sys.executable, '-B', str(HERE/'rows.py'), '--repo', str(repo),
                            '--window', left, right, '--grid', str(grid), '--macros', '99', '98',
                            '--out', str(candidate)], check=True)
            for suffix in ('.caps.json', '.json'):
                expected = saved.with_suffix(suffix)
                actual = candidate.with_suffix(suffix)
                if json.loads(expected.read_bytes()) != json.loads(actual.read_bytes()):
                    raise ValueError(f'Rebuilt rows or enclosing caps differ for {expected.name}')
            inputs.append(candidate)
        subprocess.run([sys.executable, '-B', str(HERE/'fee.py'), '--repo', str(repo),
                        '--inputs', *map(str, inputs), '--out', str(fees), '--check'], check=True)
    print(f'Verified both branches of both {args.case} diagonal macrostrips.', flush=True)


if __name__ == '__main__':
    main()
