"""Optimize a fresh Abel cover and its terminal phase masks using individually proved rectangle rates."""
from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
from tempfile import TemporaryDirectory
import json,os,sys

HERE=Path(__file__).resolve().parent;W=HERE.parent
def main():
    p=ArgumentParser(description=__doc__);p.add_argument('--repo',type=Path,default=W/'prime-sampling')
    p.add_argument('--window',type=F,nargs=2,required=True);p.add_argument('--macros',type=int,nargs='+')
    p.add_argument('--out',type=Path,required=True);p.add_argument('--check',action='store_true')
    p.add_argument('--files',nargs='+',type=Path);p.add_argument('--phase-parts',type=int,default=4)
    p.add_argument('--mode',choices=['six','pair'],default='six');p.add_argument('--tree',type=Path)
    a=p.parse_args();l,h=a.window
    use=a.files or sorted((HERE/'strips').glob('*.four.json'))
    bank={};inputs={}
    for f in use:
        raw=f.read_bytes();d=json.loads(raw)
        assert d['mode'] in ('six','pair')
        if not F(d['left'])<=l<h<=F(d['right']) or d['mode']!=a.mode:continue
        if not d['rows']:continue
        src=HERE/'spectrum-inputs'/sha256(raw).hexdigest()/f.name;src.parent.mkdir(parents=True,exist_ok=True)
        if not src.exists():src.write_bytes(raw)
        inputs[src.relative_to(W).as_posix()]=sha256(raw).hexdigest()
        for *coords,g,q in d['rows']:
            key=tuple(map(F,coords));assert len(coords)==4 and all(type(v)==int and 0<=v<=10**10 for v in (g,q))
            pair=bank.get(key,(10**10,10**10));bank[key]=min(g,pair[0]),min(q,pair[1])
    if not bank:return
    macros=sorted({(k[0]*200).__floor__() for k in bank})
    if a.macros:macros=sorted(set(macros)&set(a.macros))
    if not macros:return
    os.environ['PRIME_TREE_DIR']=str(W/'harmonic-research/predecessor/certified-trees')
    if a.tree:os.environ['PRIME_MACRO_TEMPLATE']=str(a.tree.resolve())
    else:os.environ.pop('PRIME_MACRO_TEMPLATE',None)
    os.environ.pop('PRIME_CERT_PROGRESS',None);os.environ.pop('PRIME_RECTANGLE_RATES',None)
    sys.path[:0]=[str(W/'hyperbola-next'),str(W/'gram-cycle')]
    from recursive_phase import leaf_factory
    canon=W/'hyperbola-next/rectangles.py';src=canon.read_text(encoding='utf8')
    start=src.index('    sieved_lift.install(m)');end=src.index("    branches=('with3',)",start)
    src=src[:start]+src[end:]
    start=src.index('    @cache\n    def box(u,v,w,z):');end=src.index('    @cache\n    def price(u,v,w,z):',start)
    src=src[:start]+"""    @cache
    def box(u,v,w,z):
        return saved_rates.get((u,v,w,z),(I,I))

"""+src[end:]
    anchor='    def pieces(u,v,interval,parent):'
    src=src.replace(anchor,"    phase_leaf=leaf_factory(m,banks,branches,I,J,mass,box,bounds,axis_factors,phase_parts,True)\n"+anchor)
    anchor='    @cache\n    def evaluate(u,v,parent,depth):'
    src=src.replace(anchor,"""    @cache
    def book_terminal(u,v,outer,parent):
        old=[s+boundary(u,v) for s in pieces(u,v,outer,parent)]
        seg=subtract(outer,parent)
        if not seg:return tuple(old)
        if not any((u,v,w,z) in saved_rates for w,z in seg):return tuple(old)
        trial=map(sum,zip(*(phase_leaf(u,v,w,z) if (u,v,w,z) in saved_rates else price(u,v,w,z) for w,z in seg)))
        return tuple(min(x,y+boundary(u,v)) for x,y in zip(old,trial))

"""+anchor)
    src=src.replace('        value=[s+boundary(u,v) for s in pieces(u,v,outer,parent)]','        value=list(book_terminal(u,v,outer,parent))')
    src=src.replace('            return pieces(u,v,bounds(u,v,False),parent)[branch]+boundary(u,v)','            return book_terminal(u,v,bounds(u,v,False),parent)[branch]')
    with TemporaryDirectory() as name:
        fees=Path(name)/'fees.json'
        sys.argv=[str(canon),'--repo',str(a.repo.resolve()),'--left',str(l),'--right',str(h),'--cheap','--abel','--local-axis',
                  '--mode',a.mode,'--depth','4','--macros',*map(str,macros),'--out',str(fees)]
        env={'__name__':'__main__','__file__':str(canon),'saved_rates':bank,'leaf_factory':leaf_factory,'phase_parts':a.phase_parts}
        exec(compile(src,str(canon),'exec'),env)
        result=dict(left=str(l),right=str(h),family='rectangle-book',mode=a.mode,macros=macros,inputs=inputs,
                    tree=a.tree.name if a.tree else None,phase_parts=a.phase_parts,fees=json.loads(fees.read_text()))
    if a.check:assert result==json.loads(a.out.read_text())
    else:
        stage=a.out.with_suffix('.pending');stage.write_text(json.dumps(result,indent=2),encoding='ascii');stage.replace(a.out)
if __name__=='__main__':main()
