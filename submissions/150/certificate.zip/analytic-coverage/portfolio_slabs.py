"""Reprice the same finite rectangle cover on closed slabs; only its tree is shared."""
from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
import subprocess,sys

HERE=Path(__file__).resolve().parent
def main():
    ap=ArgumentParser(description=__doc__)
    ap.add_argument('--family',required=True)
    ap.add_argument('--windows',nargs='+',required=True,help='successive left and right endpoints')
    ap.add_argument('--macros',nargs='+',type=int,required=True)
    ap.add_argument('--tree',choices=['core','outer'],default='core')
    a=ap.parse_args()
    assert len(a.windows)%2==0
    output=HERE/'strips'
    output.mkdir(exist_ok=True)
    hint=HERE/'150-near'/(a.tree+'-tree.json')
    for l,h in zip(a.windows[::2],a.windows[1::2]):
        l,h=F(l),F(h)
        name=f'{l}_{h}_{a.family}_{a.tree}_'+'-'.join(map(str,a.macros))
        dest=output/(name.replace('/','x')+'.json')
        if dest.is_file():continue
        cmd=[sys.executable,'-B',str(HERE/'slab.py'),'--family',a.family,
             '--window',str(l),str(h),'--template',str(hint),'--macros',*map(str,a.macros),'--out',str(dest)]
        print('pricing',l,h,a.family,*a.macros,flush=True)
        with dest.with_suffix('.log').open('w') as log:
            subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
        print('completed',dest.name,flush=True)

if __name__=='__main__':main()
