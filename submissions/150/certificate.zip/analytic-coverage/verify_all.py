"""Recompute the strict two-branch inequalities and the exact union of closed parameter intervals."""
from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import json,os,re,subprocess,sys

ROOT=Path(__file__).resolve().parent
def main():
    p=ArgumentParser(description=__doc__)
    p.add_argument('--require-bounty',action='store_true',help='reject any gap in [150,651/4]')
    args=p.parse_args()
    if not __debug__:raise RuntimeError('Assertions must be enabled.')
    for f,digest in json.loads((ROOT/'hashes.json').read_text()).items():
        path=(ROOT/f).resolve()
        if not path.is_relative_to(ROOT) or sha256(path.read_bytes()).hexdigest()!=digest:
            raise ValueError(f'Input digest mismatch: {f}')
    repo=ROOT/'prime-sampling';release=ROOT/'analytic-coverage/release'
    env={k:v for k,v in os.environ.items() if not k.startswith('PRIME_') and k not in ('PYTHONOPTIMIZE','PYTHONPATH')}
    env['PYTHONIOENCODING']='utf-8'
    env['PRIME_TREE_DIR']=str(ROOT/'harmonic-research/predecessor/certified-trees')
    def run(cmd,where=ROOT):
        subprocess.run([sys.executable,'-B',*map(str,cmd)],cwd=where,env=env,check=True)
    run([ROOT/'first-window/hyperbola-next/replay.py','--repo',repo])
    first=json.loads((ROOT/'first-window/hyperbola-next/margins.json').read_text())
    assert set(first)=={'with3','without3'} and min(first.values())>0
    sys.path.insert(0,str(ROOT/'analytic-coverage'))
    from scalar_receipts import validate
    for receipt in (ROOT/'analytic-coverage/selected-inputs').glob('*/scalar-receipt.json'):
        for table in receipt.parent.glob('prefix-log-*.dat'):validate(table,json.loads(receipt.read_text()))
    run([ROOT/'narrow-prefix/release_audit.py','--repo',repo,'--release',release])
    run([ROOT/'analytic-coverage/verify_sources.py','--step','merges','--repo',repo])
    spans=[(F(150),F(4801,32))];floors=[min(first.values())];count=1
    for row in json.loads((release/'runs.json').read_text()):
        path=release/row['manifest'];m=json.loads(path.read_text())
        assert (row['left'],row['right'])==(m['left'],m['right']) and len(m['cells'])==row['cells']
        run([ROOT/'analytic-coverage/verify_cells.py',path,'--repo',repo])
        spans.append((F(m['left']),F(m['right'])))
        floor=min(z['margin'] for w in m['cells'] for z in w['expected'].values())
        assert floor==row['floor'];floors.append(floor);count+=len(m['cells'])
    native=ROOT/'native-continuation/submission.json'
    output=subprocess.check_output([sys.executable,'-B','-m','prime_sampling.cli.grade',str(native)],cwd=repo,env=env,text=True)
    print(output,end='',flush=True)
    result=re.search(r'(\d+) submitted cells, both branches, minimum ([0-9]+\.[0-9]+)\.',output)
    assert result,output
    count+=int(result[1]);signed=F(result[2])*10**12;assert signed.denominator==1;floors.append(int(signed))
    spec=json.loads(native.read_text())
    spans.append((F(spec['target']),F(spec['cells'][-1]['right'])))
    merged=[]
    for l,h in sorted(spans):
        if merged and l<=merged[-1][1]:merged[-1][1]=max(merged[-1][1],h)
        else:merged.append([l,h])
    assert merged[0][0]==150 and merged[-1][1]>=F(651,4)
    for l,h in merged:print('Both branches verified on the closed interval',l,h,flush=True)
    print('Closed cells verified:',count,'minimum margin in 1e-12:',min(floors),flush=True)
    gaps=[(a[1],b[0]) for a,b in zip(merged,merged[1:])]
    for l,h in gaps:print('Uncertified open interval',l,h,flush=True)
    if gaps and args.require_bounty:raise SystemExit(2)
    if not gaps:print('Threshold 150: strict positivity on the entire closed interval [150,651/4].')
if __name__=='__main__':main()
