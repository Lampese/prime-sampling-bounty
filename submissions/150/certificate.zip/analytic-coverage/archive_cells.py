"""Materialize a self-contained release without copying working runs or untracked executables."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import json,subprocess
HERE=Path(__file__).resolve().parent
W=HERE.parent
OUT=W.parent/'outputs'
def main():
    cli=ArgumentParser(description=__doc__)
    cli.add_argument('release',type=Path);cli.add_argument('--out',type=Path,required=True)
    a=cli.parse_args();release=a.release.resolve()
    records={};proofs=set()
    def put(name,raw):records[name]=raw
    def add(p,as_name=None):
        if not p.is_file():raise FileNotFoundError(p)
        put(as_name or p.relative_to(W).as_posix(),p.read_bytes())
    for source,sub in [('first-window','first-window'),('continuous-extension','native-continuation')]:
        with ZipFile(OUT/f'prime-sampling-{source}.zip') as z:
            for n in z.namelist():
                if n.endswith('/'):continue
                data=z.read(n);put(f'{sub}/{n}',data)
                if sub=='first-window':put(n,data)
    repo=W/'prime-sampling'
    output=subprocess.check_output(['git','-C',repo,'ls-files','-z'])
    for n in output.decode().split(chr(0)):
        if n:add(repo/n)
    commit=subprocess.check_output(['git','-C',repo,'rev-parse','HEAD'],text=True).strip()
    assert commit=='63a2d41e8124320784c244336ff36ac5f2285418'
    put('UPSTREAM.txt',(commit+chr(10)).encode())
    for d in ['analytic-coverage','wide-coverage','hyperbola-next','gram-cycle','operator-new','weighted-base','fibre-lines',
              'fibre-portfolio','mass-geometry','near-lines','dilations','reflection','spectral-coupling','trace-dilate',
              'harmonic-research/kernel','harmonic-research/predecessor','residue-bridge/crt-fast','main-density-new',
              'seed-weights','seed-bridge','smooth-portable','cofactor-refined','transfer-bilinear','transfer-weights',
              'portable-fit','narrow-prefix','prefix-cap-audit','scalar-tail']:
        for f in (W/d).glob('*'):
            if f.is_file() and f.suffix in {'.cpp','.h','.py','.md'}:add(f)
    for f in (W/'harmonic-research/predecessor/certified-trees').glob('*.json'):add(f)
    for f in (HERE/'diagonal').glob('*'):
        if f.suffix in {'.py','.md'}:add(f)
    for pattern in ['*-proof.txt','terminal-cases.dat','log-budgets-*.dat','prefix-log-*.dat','prefix-atlas-sources.json','150-near/*-tree.json','150a/upper-plan.json']:
        for f in HERE.glob(pattern):
            if '-pooled-' not in f.name:add(f)
    for directory in ['portable-fit','prefix-cap-audit']:
        d=W/directory;add(d/'manifest.txt')
        for line in (d/'manifest.txt').read_text().splitlines():add(d/line)
    for name in (W/'portable-fit/external.txt').read_text().splitlines():add(W/name)
    for pat in ['*.dat','*/seed.txt','*/*.dat']:
        for f in (W/'narrow-prefix').glob(pat):add(f)
    for d in ['fibre-lines','fibre-portfolio','near-lines']:
        for pat in ['shape*.txt','shape*json']:
            for f in (W/d).glob(pat):add(f)
    for pat in ['l150*g3200*.json','l151*g3200*.json','lhsl150*.json','lhsl151*.json']:
        for f in (W/'wide-coverage').glob(pat):add(f)
    def physical(f):
        if f in proofs:return
        proofs.add(f);add(f)
        if f.name in ('prefix-log-atlas.dat','prefix-log-ready.dat'):
            receipt=f.with_name('scalar-receipt.json');add(receipt)
            for n in json.loads(receipt.read_bytes())['original']:physical(W/n)
        if f.suffix!='.json':return
        data=json.loads(f.read_bytes())
        if f.name=='cell.json':
            for t in data['tables']:add(f.parent/t['file'])
            source=f.parent/'source.json';add(source)
            raw=json.loads(source.read_bytes())
            for name in raw.get('inputs',[]):physical(W/name)
            for row in raw.get('portfolio_components',[]):add(W/'wide-coverage'/row['parent'])
        for row in data.get('parent_caps',[]):
            parent=W/'wide-coverage'/row['file']
            if sha256(parent.read_bytes()).hexdigest()!=row['sha256']:raise ValueError(parent)
            add(parent)
        if data.get('family')=='joint-diagonal':
            folder=HERE/'diagonal';add(folder/f.name)
            for leaf,hashval in data['inputs'].items():
                path=folder/leaf;assert sha256(path.read_bytes()).hexdigest()==hashval
                add(path);add(path.with_suffix('.caps.json'))
        if data.get('family')=='rectangle-book':
            for name,digest in data['inputs'].items():
                path=W/name
                assert sha256(path.read_bytes()).hexdigest()==digest
                physical(path)
        if data.get('family')=='soft-mask':physical(W/data['cell'])
        if data.get('family')=='rectangle-native-convex':
            for n in data['cells']:physical(W/n)
    sources=json.loads((release/'input-paths.json').read_text());used={}
    index=json.loads((release/'runs.json').read_text())
    add(release/'runs.json','analytic-coverage/release/runs.json')
    add(release/'ledger.json','analytic-coverage/release/ledger.json')
    for row in index:
        name=row['manifest'];f=release/name;add(f,'analytic-coverage/release/'+name)
        for cell in json.loads(f.read_text())['cells']:
            for n in cell['native']+cell['budgets']+cell['reports']:
                if '-pooled-' in n:raise ValueError('Unvalidated second-moment input: '+n)
                physical(W/n)
                if n in sources:used[n]=sources[n]
    put('analytic-coverage/release/input-paths.json',json.dumps(used,indent=1).encode())
    add(HERE/'verify_all.py','verify_all.py')
    add(HERE/'methods-zh.txt','方法与复验.txt')
    put('README.txt',('Run from this directory with Python 3.10 or later: python -B verify_all.py --require-bounty'+chr(10)+
        'The checker runs the first-window proof replay, separate rational per-cell ledgers, and the unmodified upstream grade for [152,651/4].'+chr(10)+
        'It prints the exact union and exits with code 2 if there is a gap. Stored estimates have proof sources and may be regenerated separately.'+chr(10)+
        'Each hash in analytic-coverage/selected-inputs and spectrum-inputs identifies the exact input used.'+chr(10)).encode())
    put('hashes.json',json.dumps({n:sha256(b).hexdigest() for n,b in sorted(records.items())},indent=1).encode())
    dest=a.out;dest.parent.mkdir(exist_ok=True,parents=True);stage=dest.with_suffix('.pending')
    with ZipFile(stage,'w',compression=ZIP_DEFLATED,compresslevel=4) as z:
        for n,b in sorted(records.items()):z.writestr(n,b)
    stage.replace(dest);print(len(records),'files',dest.stat().st_size,'bytes',sha256(dest.read_bytes()).hexdigest(),flush=True)
if __name__=='__main__':main()
