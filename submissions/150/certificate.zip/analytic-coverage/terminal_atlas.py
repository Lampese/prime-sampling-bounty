"""Price all child cutoffs as prefixes of one exact positive path on their common parent."""
from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
from weighted_terminal import model,WORK


def compile_prices(repo,key,out,check,window=None,supplied=None,pooled=False):
    release=WORK/'portable-fit'
    cases={w[0]:w[1:] for row in (release/'cases.dat').read_text().splitlines() for w in [row.split()]}
    L,H,rank=cases[key];lo,hi,r=F(L),F(H),int(rank)
    names=['aw-strong','aw']
    target=next(release/f'{s}{key}.dat' for s in names if (release/f'{s}{key}.dat').is_file())
    if supplied:target=supplied
    w=target.read_text().split()
    if window:lo,hi=window
    assert F(w[0])<=lo<hi<=F(w[1]) and int(w[2])==r and F(w[-1])==26
    prefix=F(int(w[3]),10**12)
    import sys
    sys.path.insert(0,str(repo.resolve()))
    from prime_sampling.budget import widerough as s
    _,_,rates=model(repo,lo,hi,r,pooled=pooled)
    child=[lo]
    while child[-1]<hi:
        child.append(min(hi,F((32*child[-1]).__floor__()+1,32)))
    ends=[(s.up(h-s.ld(h-F('1.1')))*cut/200,h,cut) for h in child[1:] for cut in range(67,71)]
    unit=F(1,80);u=F(26);total=F(0);vals={}
    schedule=[(27,8),(29,14),(31,23),(35,38),(41,50),(45,72),(48,100),(100,240)]
    def price(u,v):
        if u==v:return F(0)
        n=next(n for end,n in schedule if u<end)
        ks={max(1,((v-u)*80*n).__ceil__()),max(1,((v-u)*1800).__ceil__())}
        return min(rates(u,v,k)[1] for k in ks)
    for end,h,cut in sorted(ends):
        while u+unit<=end:
            total+=price(u,u+unit)
            u+=unit
        vals[h,cut]=((prefix+total+price(u,end))*10**9).__ceil__()
    records=[]
    for l,h in zip(child,child[1:]):
        records.append(' '.join(map(str,(l,h,r,*(vals[h,j] for j in range(67,71))))))
    text='\n'.join(records)+'\n'
    if check:assert out.read_text()==text
    else:
        stage=out.with_suffix('.pending');stage.write_text(text,encoding='ascii');stage.replace(out)
    print(target.name,'closed slabs',len(records),'first',records[0],'last',records[-1],flush=True)


if __name__=='__main__':
    ap=ArgumentParser(description=__doc__);ap.add_argument('--repo',type=Path,default=WORK/'prime-sampling')
    ap.add_argument('--key',required=True);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--check',action='store_true')
    ap.add_argument('--window',nargs=2,type=F);ap.add_argument('--prefix',type=Path)
    ap.add_argument('--pooled',action='store_true')
    a=ap.parse_args();compile_prices(a.repo,a.key,a.out,a.check,a.window,a.prefix,a.pooled)
