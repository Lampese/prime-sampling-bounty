"""Replace only the total mean mass in a group of equal upstream transfer steps."""
from argparse import ArgumentParser
from fractions import Fraction as F
from functools import cache
from pathlib import Path
import sys
from log_population import model as population_model

WORK=Path(__file__).resolve().parents[1]


def model(repo,left,right,rank,pooled=False):
    sys.path[:0]=[str(repo.resolve()),str(WORK/'cofactor-refined')]
    import reprice as core
    core.setup(repo);s=core.s;band=core.band
    reciprocal,pop=population_model(core)
    opts=core.options(rank)
    zl=s.dn(left-s.lu(left+1));zh=s.up(right-s.ld(right-F('1.1')))
    @cache
    def densities(a,b):
        L,H=zl-b,zh-a
        stock=core.density_core(a,L,H,F(1,2),12)[0]
        new=pop(a,L,H)
        return stock,min(stock,new)
    def prices(u,v,n):
        a=(u*4).__floor__()/F(4)
        b=max(a+F(1,4),v)
        assert 26<=a<=u<v<=b and zh-a<5*a
        usual,new=densities(a,b)
        w=(v-u)/n
        eps=s.eta_for(u,F('.01')/u**2);U=s.eu(w)
        H=min(s.up((U-1+(U+1)*eps)/u),s.up((1+eps)*s.lu(1+w/u)+2*eps/u))
        stock=s.up(2*zh*H*usual)
        # Average over the whole group's actual q. The identical row and
        # polynomial selected below apply on every constituent microinterval.
        grouped=min(n*H,reciprocal(u,v-u))
        replacement=s.up(2*zh*grouped*new/n)
        raw=band.params(left,right,u,v,n)
        if pooled:
            from cofactor_variance import average_rows
            raw=average_rows(s,left,right,zl,zh,u,v,n,new,grouped,raw)
        return tuple(n*band.price([(min(w0,X+e),e,di,of) for w0,e,di,of in raw],opts) for X in (stock,replacement))
    return zh,densities,prices


def terminal(repo,left,right,rank,samples=None):
    zh,dens,prices=model(repo,left,right,rank)
    total=F(0);old=F(0);rows=[];u=F(26)
    schedule=[(27,8),(29,14),(31,23),(35,38),(41,50),(45,72),(48,100),(100,240)]
    def price(u,v):
        n=next(k for end,k in schedule if u<end)
        widths={max(1,((v-u)*80*n).__ceil__()),max(1,((v-u)*1800).__ceil__())}
        return tuple(map(min,zip(*(prices(u,v,k) for k in widths))))
    if samples:
        for t in samples:
            v=t+F(1,80);a,b=price(t,v);d=dens(t,t+F(1,4))
            print(t,'densities',*map(float,d),'savings per log unit',float((a-b)*80),flush=True)
        return
    for j in range(67,71):
        cap=zh*j/200
        while u<cap:
            v=min(cap,u+F(1,80))
            oa,na=price(u,v);total+=na;old+=oa;u=v
        rows.append((total*10**12).__ceil__())
        print(j,'absolute terminal',rows[-1],'old ceiling',(old*10**12).__ceil__(),flush=True)
    return rows


if __name__=='__main__':
    cli=ArgumentParser(description=__doc__);cli.add_argument('--repo',type=Path,default=WORK/'prime-sampling')
    cli.add_argument('--window',nargs=2,type=F,required=True);cli.add_argument('--rank',type=int,required=True)
    cli.add_argument('--samples',nargs='+',type=F);cli.add_argument('--out',type=Path);cli.add_argument('--check',type=Path)
    a=cli.parse_args();values=terminal(a.repo,*a.window,a.rank,a.samples)
    if a.out or a.check:
        assert values
        text=' '.join(map(str,(*a.window,a.rank,*values)))+'\n'
        if a.check:assert a.check.read_text()==text
        if a.out:a.out.write_text(text,encoding='ascii')
