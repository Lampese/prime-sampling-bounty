"""Pool sharp prime populations and the outer rough support before the second-moment inequality."""
from fractions import Fraction as F

def average_rows(s, left, right, zl, zh, u, v, n, density, grouped, rows):
    w=(v-u)/n
    t=v-w
    eps=s.eta_for(u,F('.01')/u**2)
    mult=s.eu(w)
    c=s.up((mult-1+(mult+1)*eps)/u)
    harm=min(c,s.up((1+eps)*s.lu(1+w/u)+2*eps/u))
    # For Q_i < q <= Q_i exp(w), c_i = #q/Q_i <= exp(w) sum 1/q.
    avg_c=min(F(1),mult*grouped/(n*c))
    avg_h=min(F(1),grouped/(n*harm))
    # J_i=(lambda exp(-w)Y_i,Y_i], Y_i=X/Q_i.
    # Each extra integer in its bottom collar costs at most one.
    outer=density+s.LAM*(1-s.trans(-w,'exp',False))+s.eu(v-zl)
    sharp=F('.6')/u
    if 2*t>zl-v:
        sharp=max(sharp,1/(zl-v-F('1.1'))+s.eu(v)*(left+1)*s.eu(-left))
    smooth=sharp
    if 4*u>=zh-u:
        def hh(x):
            return (1+s.eta)*s.lu(x/u)+2*s.eta/u if x>u else F(0)
        cap=zh-u;y=zl-t;pad=s.ALOG+w
        den=1/(y-pad)+hh(cap/2)/(y/2-pad)
        if 3*u<=cap:den+=hh(cap/3)*hh((cap-u)/2)/(y/3-pad)
        smooth=min(smooth,(1-s.LAM*s.trans(-w,'exp',False)+2*s.eta)*den)
    answer=[]
    for j,(W,e,di,off) in enumerate(rows):
        sharp_row=j<len(range(0,23,2))
        r=min(F(1),outer/(sharp if sharp_row else smooth))
        # Sharp diagonal is a positive linear form in H_i,c_i. Smooth uses c_i.
        # Off-diagonal uses c_i^2 <= c*c_i in both families.
        dd=di*r*(max(avg_c,avg_h) if sharp_row else avg_c)
        oo=off*r*avg_c
        answer.append((W,e,s.up(dd),s.up(oo)))
    return answer
