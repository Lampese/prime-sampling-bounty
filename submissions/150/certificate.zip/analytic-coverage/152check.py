"""Price the active 152 windows in one process, sharing the actual rank-specific polynomial bank."""
from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
import json,sys

from score import score

here=Path(__file__).resolve().parent
work=here.parent
wide=work/'wide-coverage'


def main():
    ap=ArgumentParser(description=__doc__)
    ap.add_argument('--window',nargs=2,type=F,action='append',required=True)
    ap.add_argument('--stock-bank',action='store_true')
    args=ap.parse_args()
    sys.path.insert(0,str(wide))
    from budget_sources import candidates
    all_budgets=candidates(wide)
    for left,right in args.window:
        if not 152<=left<right<=153:ap.error('Supply a tested 152 window')
        cells=[]
        for cell in wide.glob('c152*/cell.json'):
            if not cell.with_name('source.json').is_file():continue
            obj=json.loads(cell.read_text())
            if F(obj['left'])<=left<right<=F(obj['right']):cells.append(cell)
        reports=[]
        for folder in (here/'152a',here/'152b'):
            for path in folder.glob('*.json'):
                report=json.loads(path.read_text())
                if 'fees' in report and F(report['left'])<=left<right<=F(report['right']):reports.append(path)
        budgets=[p for p,ww in all_budgets if any(l<=left<right<=h for l,h in ww)]
        if not budgets or not cells:raise ValueError('Missing an actual cost or matrix source')
        result=score(work/'prime-sampling',left,right,sorted(reports),sorted(cells),sorted(budgets),not args.stock_bank)
        out=here/('152b' if left>=F(305,2) else '152a')
        name='ledger-'+str(left).replace('/','_')+'-'+str(right).replace('/','_')+('-stock' if args.stock_bank else '')+'.json'
        names=lambda paths:sorted(p.relative_to(work).as_posix() for p in paths)
        source={'window':[str(left),str(right)],'ordinary_repricing':args.stock_bank,'reports':names(reports),'native':names(cells),'budgets':names(budgets)}
        for branch,stats in result.items():
            best=max(stats['cutoffs'],key=lambda x:x['margin'])
            print(left,right,branch,best,flush=True)
        (out/name).write_text(json.dumps(dict(source=source,result=result),indent=2),encoding='ascii')


if __name__=='__main__':main()
