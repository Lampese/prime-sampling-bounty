"""Propose finite sieve polynomials. The saved coefficients are checked exactly."""
from argparse import ArgumentParser
from pathlib import Path
from fractions import Fraction as F
from math import comb,prod
import json,sys
from polynomial import basis,vertices,evaluate,entry

def main():
    base=Path(__file__).resolve().parents[1]
    ap=ArgumentParser(description=__doc__)
    ap.add_argument('--repo',type=Path,default=base/'prime-sampling')
    ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--head',type=int,nargs='+',default=[2,3,5])
    ap.add_argument('--distinguished',type=int,default=3)
    ap.add_argument('--tail',type=int,nargs='+',default=[6,14,32])
    ap.add_argument('--degree',type=int,default=2)
    ap.add_argument('--branch',default='with3')
    args=ap.parse_args()
    sys.path[:0]=[str(args.repo.resolve()),str(base/'math-libs'),str(base/'harmonic-research/predecessor')]
    import numpy as np
    from scipy.optimize import linprog
    from scipy.sparse import csc_matrix,eye,hstack,vstack
    from prime_sampling.accounting import ledger
    from tree_sieve_trial import new_bank
    seq=ledger.rank(F(4801,32),args.branch)
    kind='six' if args.branch=='with3' else 'pair'
    original=new_bank(seq,kind)[0]
    candidates={}
    m=args.distinguished
    for h in args.head:
        for n0 in args.tail:
            n=min(n0,len(seq)-h-m)
            d=min(n,args.degree)
            mat=np.array(basis(tuple(seq[h:h+m+n]),m,d),dtype=float)
            # The constant frequency is nonnegative by the Boolean constraints.
            mu=mat[0]; rest=csc_matrix(mat[1:]); N=len(mu); L=rest.shape[0]
            verts=np.array(vertices(m,n,d),dtype=float)
            cond=vstack([hstack([-csc_matrix(verts),csc_matrix((len(verts),L))]),
                         hstack([rest,-eye(L)]),hstack([-rest,-eye(L)])]).tocsc()
            limit=np.zeros(cond.shape[0]);limit[0]=-1
            gains=[]
            for g in (.00012,.0004,.0012,.0035,.009,.02):
                # Candidate g=q. The resulting polynomial is valid at every rate.
                ratio=(2**h)*g/(1-g)
                cost=np.r_[mu*(1+ratio),np.full(L,ratio)]
                sol=linprog(cost,A_ub=cond,b_ub=limit,bounds=[(None,None)]*N+[(0,None)]*L,method='highs')
                if not sol.success:continue
                co=[F(float(x)).limit_denominator(10000) for x in sol.x[:N]]
                for z in range(1<<m):
                    extra=max(int(t==0 and z==0)-sum(comb(t,j)*co[z*(d+1)+j] for j in range(min(d,t)+1)) for t in range(n+1))
                    co[z*(d+1)]+=max(0,extra)
                cert=dict(head=h,distinguished=m,tail=n,degree=d,coefficients=list(map(str,co)))
                key=json.dumps(cert,sort_keys=True)
                if key not in candidates:
                    meg,nu=evaluate(seq,cert)
                    candidates[key]=(cert,entry(meg,nu,kind,ledger.I))
                _,candidate=candidates[key]
                def value(row):return (row[0]-g*(row[1]+row[2]))/ledger.I
                gains.append(round(value(candidate)-max(map(value,original)),8))
            print('head',h,'distinguished',m,'tail',n,'gains',gains,flush=True)
            rows=[c for c,_ in candidates.values()]
            args.out.write_text(json.dumps({'branch':args.branch,'primes':seq,'polynomials':rows},indent=1))
if __name__=='__main__':main()
