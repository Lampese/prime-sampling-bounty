"""Fourier coefficients of a Boolean majorant in a symmetric tail."""
from fractions import Fraction as F
from itertools import combinations,product
from math import comb,prod
from functools import cache

@cache
def basis(primes,distinguished,degree):
    q = [F(1,p) for p in primes]
    head,tail = q[:distinguished],q[distinguished:]
    d=min(degree,len(tail))
    patterns=list(product((0,1),repeat=len(head)))
    def head_matrix(freq,vertex):
        return prod((u if v else 1-u) if not s else (1-u if v else u-1)
                    for s,v,u in zip(freq,vertex,head))
    frequencies=[]
    for k in range(d+1):
        if k==d:
            weight=sum(prod(1-tail[i] for i in subset) for subset in combinations(range(len(tail)),k))
            frequencies.append([F(0)]*d+[weight])
            continue
        for subset in combinations(range(len(tail)),k):
            sym=[F(1)]+[F(0)]*(d-k)
            for i,u in enumerate(tail):
                if i not in subset:
                    for j in range(d-k,0,-1):sym[j]+=u*sym[j-1]
            weight=prod(1-tail[i] for i in subset)
            frequencies.append([F(0)]*k+[v*weight for v in sym])
    # All rows are signed Fourier coefficients times their multiplicities.
    return [[head_matrix(s,v)*x for v in patterns for x in f]
            for s in patterns for f in frequencies]

def vertices(m,n,d):
    return [[(comb(t,j) if j<=t else 0) if i==z else 0
             for i in range(2**m) for j in range(d+1)]
            for z in range(2**m) for t in range(n+1)]

def evaluate(seq,cert):
    h,m,n,d=(cert[k] for k in ('head','distinguished','tail','degree'))
    assert h+m+n<=len(seq) and 1<=d<=n and h>=1
    co=tuple(F(x) for x in cert['coefficients'])
    assert len(co)==(1<<m)*(d+1)
    for i,row in enumerate(vertices(m,n,d)):
        assert sum(a*b for a,b in zip(row,co)) >= (1 if i==0 else 0)
    coeff=[sum(a*b for a,b in zip(row,co)) for row in basis(tuple(seq[h:h+m+n]),m,d)]
    prefix=prod(1-F(1,p) for p in seq[:h])
    assert coeff[0]>0
    return prefix*coeff[0],(2**h)*prefix*sum(abs(v) for v in coeff)

def entry(mu,norm,kind,unit):
    multiplier={'six':3,'pair':1,'single':0}[kind]
    return (((1-mu)*unit).__floor__(),((norm-(1+multiplier)*mu)*unit).__ceil__(),
            (multiplier*mu*unit).__ceil__())
