"""Non-symmetric quadratic sieve with a certificate for every Boolean atom."""
from argparse import ArgumentParser
from fractions import Fraction as F
from itertools import combinations
from math import prod
from pathlib import Path
import json,sys


def exact(primes,a,b,q):
    n=len(primes)
    assert len(a)==n and 2<=q<n and all(0<=v<=1 for v in a)
    assert set(b)==set(combinations(range(n),2)) and all(v>=0 for v in b.values())
    for i in range(n):
        incident=sorted(b[min(i,j),max(i,j)] for j in range(n) if j!=i)
        assert sum(incident[:q])>=a[i]
    for k in range(2,q+1):
        for sub in combinations(range(n),k):
            assert 1-sum(a[i] for i in sub)+sum(b[p] for p in combinations(sub,2))>=0
    f=[F(1,p) for p in primes]
    mean=1-sum(ai*x for ai,x in zip(a,f))+sum(v*f[i]*f[j] for (i,j),v in b.items())
    first=sum((1-f[i])*abs(sum(b[min(i,j),max(i,j)]*f[j] for j in range(n) if i!=j)-a[i]) for i in range(n))
    second=sum(v*(1-f[i])*(1-f[j]) for (i,j),v in b.items())
    return mean,mean+first+second


def propose(primes,q,head,rate,np,sparse,linprog):
    # Use one threshold per vertex to express the sum of the q smallest edges.
    n=len(primes);pairs=list(combinations(range(n),2));m=len(pairs)
    pi={p:n+i for i,p in enumerate(pairs)}
    absidx=n+m;threshold=absidx+n;slack=threshold+n
    rows=[];cols=[];vals=[];rhs=[]
    def le(coeff,bound):
        rows.extend([len(rhs)]*len(coeff))
        cols.extend(k for k,v in coeff);vals.extend(v for k,v in coeff);rhs.append(bound)
    f=[1./p for p in primes]
    for i in range(n):
        star=[(j,pi[min(i,j),max(i,j)]) for j in range(n) if j!=i]
        for sign in (-1,1):
            le([(i,-sign),(absidx+i,-1)]+[(b,sign*f[j]) for j,b in star],0)
        for k,(j,b) in enumerate(star):
            le([(threshold+i,1),(b,-1),(slack+i*(n-1)+k,-1)],0)
        le([(i,1),(threshold+i,-q)]+[(slack+i*(n-1)+k,1) for k in range(n-1)],0)
    for k in range(2,q+1):
        for sub in combinations(range(n),k):
            le([(i,1) for i in sub]+[(pi[p],-1) for p in combinations(sub,2)],1)
    dim=slack+n*(n-1)
    mat=sparse.coo_matrix((vals,(rows,cols)),shape=(len(rhs),dim)).tocsr()
    g=float(rate);coef=1-g+2**head*g
    cost=np.zeros(dim)
    for i,t in enumerate(f):
        cost[i]=-coef*t;cost[absidx+i]=2**head*g*(1-t)
    for i,j in pairs:
        cost[pi[i,j]]=coef*f[i]*f[j]+2**head*g*(1-f[i])*(1-f[j])
    result=linprog(cost,A_ub=mat,b_ub=rhs,bounds=[(0,1)]*n+[(0,None)]*(dim-n),method='highs')
    if not result.success:raise RuntimeError(result.message)
    # Round coefficients outwards; small guards preserve tight atom constraints.
    unit=10**7
    a=[max(F(0),F(int(float(x)*unit)-2,unit)) for x in result.x[:n]]
    b={p:F(int(max(0.,result.x[pi[p]])*unit)+3,unit) if result.x[pi[p]]>1e-12 else F(0) for p in pairs}
    return a,b


def main():
    here=Path(__file__).resolve().parent;work=here.parent
    cli=ArgumentParser(description=__doc__)
    cli.add_argument('--head',nargs='+',type=int,default=[2,3,4])
    cli.add_argument('--tail',nargs='+',type=int,default=[8,14,22])
    cli.add_argument('--order',nargs='+',type=int,default=[2,3])
    cli.add_argument('--out',type=Path,required=True)
    args=cli.parse_args()
    sys.path[:0]=list(map(str,(work/'math-libs',work/'prime-sampling',work/'harmonic-research/predecessor')))
    import numpy as np
    from scipy import sparse
    from scipy.optimize import linprog
    from prime_sampling.accounting import ledger
    from tree_sieve_trial import new_bank
    from polynomial import entry
    seq=ledger.rank(F(4801,32),'with3')
    bank=new_bank(seq,'six')[0];I=ledger.I;certs=[]
    for h in args.head:
        pre=prod(1-F(1,p) for p in seq[:h])
        for n in args.tail:
            tail=seq[h:h+n]
            for q in args.order:
                gains=[]
                for g in map(F,('.00012','.0004','.0012','.0035','.009','.02')):
                    a,b=propose(tail,q,h,g,np,sparse,linprog)
                    mu,norm=exact(tail,a,b,q)
                    row=entry(pre*mu,pre*2**h*norm,'six',I)
                    value=lambda r: (r[0]-g*(r[1]+r[2]))/I
                    gain=value(row)-max(map(value,bank))
                    gains.append(round(float(gain),8))
                    if gain>0:
                        certs.append(dict(head=h,order=q,tail=n,a=list(map(str,a)),
                                     b=[str(b[p]) for p in combinations(range(n),2)],row=row))
                print(h,n,q,'change in excluded fraction',gains,flush=True)
                args.out.write_text(json.dumps(certs,indent=1),encoding='ascii')


if __name__=='__main__':main()
